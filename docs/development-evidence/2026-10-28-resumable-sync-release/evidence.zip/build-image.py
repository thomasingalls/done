from pathlib import Path
import subprocess,json
s=Path(__file__).parent;v=json.loads((s/'source.json').read_text());argv=['docker','buildx','build','--platform','linux/arm64','--build-arg','APP_BUILD_REVISION='+v['source'],'--build-arg','APP_BUILD_DATE='+v['date']]
for k,x in v['featureOverrides'].items():argv+=['--build-arg',k+'='+x]
argv+=['--tag',v['candidateTag'],'--load','--metadata-file',str(s/'build-metadata.json'),str(s/'source')];(s/'build-command.json').write_text(json.dumps(argv,indent=2)+'\n');print('Building '+v['candidateTag'],flush=True);q=subprocess.run(argv);raise SystemExit(q.returncode)

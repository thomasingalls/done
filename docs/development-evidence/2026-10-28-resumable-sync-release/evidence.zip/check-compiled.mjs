import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFileSync,readdirSync,writeFileSync } from 'node:fs';
import { retentionPreparationIdentity } from './source/vite/retentionPreparationIdentity.ts';
const {parseSync}=createRequire('/Users/thomasingalls/.codex/worktrees/7fda/done/package.json')('@babel/core');
const s='/private/tmp/done-resumable-release-20261028',meta=JSON.parse(readFileSync(s+'/source.json')),flags={...meta.featureOverrides,VITE_ACCOUNT_LEDGER:'',$mode:'production'},identity=retentionPreparationIdentity(s+'/source',flags),found=[],proofFiles=[];
const expected={VITE_ACCOUNT_BASELINE_READ:'1',VITE_ACCOUNT_BASELINE_INSTALL:'1',VITE_ACCOUNT_RETENTION:'1',VITE_ACCOUNT_RETENTION_AUTO:'1',VITE_ACCOUNT_RETENTION_RESUME:'1',VITE_ACCOUNT_HISTORY_AUTO:'0',VITE_ACCOUNT_BATCH:'coordinated-2000'};
for(const file of readdirSync(s+'/frontend/assets').filter(x=>x.endsWith('.js'))){
 const data=readFileSync(s+'/frontend/assets/'+file,'utf8');if(data.includes(identity.digest))proofFiles.push(file);
 const source=parseSync(data,{babelrc:false,configFile:false,sourceType:'module'});
 const visit=node=>{
  if(node.type==='MemberExpression'&&node.property.name==='VITE_ACCOUNT_RETENTION_AUTO'){
   assert.equal(node.object.type,'ObjectExpression');const values=Object.fromEntries(node.object.properties.filter(p=>p.type==='ObjectProperty').map(p=>[p.key.name,p.value.type==='TemplateLiteral'?p.value.quasis[0].value.cooked:p.value.value]));
   for(const[k,v]of Object.entries(expected))assert.equal(values[k],v,k);found.push({file,flags:Object.fromEntries(Object.entries(values).filter(([k])=>k.startsWith('VITE_ACCOUNT_')))});
  }
  for(const v of Object.values(node))if(Array.isArray(v))v.forEach(x=>{if(x&&typeof x.type==='string')visit(x)});else if(v&&typeof v.type==='string')visit(v);
 };visit(source);
}
assert(found.length>0);assert(proofFiles.length>0,'Actual frontend must carry exact verifier-source identity');
writeFileSync(s+'/compiled-flags.json',JSON.stringify({expected,compiledGateReads:found,verifierIdentity:{digest:identity.digest,inputCount:identity.inputs.length,flags:identity.flags,foundIn:proofFiles},actualExtractedFrontend:true},null,2)+'\n');console.log('Exact image flags and verifier identity checked: '+found.length+' gate read sites, '+proofFiles.length+' proof owners.');

from pathlib import Path
import subprocess,json,hashlib,uuid,tarfile
root=Path(__file__).resolve().parent
source=json.loads((root/'source.json').read_text());tag=source['candidateTag'];name='done-release-extract-'+uuid.uuid4().hex
run=lambda *args:subprocess.check_output(['docker',*args],text=True).strip()
image=json.loads(run('image','inspect',tag))[0]
assert image['Architecture']=='arm64' and image['Os']=='linux'
assert image['Config']['Labels']['org.opencontainers.image.revision']==source['source']
assert image['Config']['User']=='65532:65532'
assert image['Config']['Entrypoint']==['node','scripts/public-account.mjs']
assert image['Config']['Cmd']==['app']
created=False
try:
 run('create','--name',name,tag);created=True
 run('cp',name+':/app/dist',str(root/'frontend'))
 code=root/'image-code';code.mkdir()
 for folder in ['account-service','account-protocol','scripts']:
  run('cp',name+':/app/'+folder,str(code/folder))
finally:
 if created:run('rm',name)
records=[]
for file in sorted((root/'image-code').rglob('*')):
 if not file.is_file():continue
 rel=file.relative_to(root/'image-code');data=file.read_bytes()
 assert data==(root/'source'/rel).read_bytes(),str(rel)
 records.append({'path':str(rel),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
(root/'runtime-source-files.json').write_text(json.dumps(records,indent=2)+'\n')
front=[]
for file in sorted((root/'frontend').rglob('*')):
 if file.is_file():
  data=file.read_bytes();front.append({'path':str(file.relative_to(root/'frontend')),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
(root/'frontend-before.json').write_text(json.dumps(front,indent=2)+'\n')
(root/'source/dist').symlink_to(root/'frontend',target_is_directory=True)
archive=root/'candidate-image.tar';run('image','save',tag,'-o',str(archive))
with tarfile.open(archive) as tar:
 def blob(d):
  algo,digest=d['digest'].split(':');assert algo=='sha256'
  data=tar.extractfile('blobs/sha256/'+digest).read();assert hashlib.sha256(data).hexdigest()==digest
  return json.loads(data)
 top=json.load(tar.extractfile('index.json'))
 index=[d for d in top['manifests'] if d['digest']==image['Id']];assert len(index)==1
 indexed=blob(index[0]);runtime=[d for d in indexed['manifests'] if d.get('platform')=={'architecture':'arm64','os':'linux'}];assert len(runtime)==1
 manifest=blob(runtime[0]);config=blob(manifest['config']);assert config['architecture']=='arm64'
result={'tag':tag,'source':source['source'],'indexDigest':image['Id'],'runtimeManifestDigest':runtime[0]['digest'],'runtimeConfigDigest':manifest['config']['digest'],'archiveSha256':hashlib.file_digest(archive.open('rb'),'sha256').hexdigest(),'archiveBytes':archive.stat().st_size,'archivePath':str(archive),'runtimeSourceFilesMatched':len(records),'frontendFiles':len(front),'platform':'linux/arm64','user':image['Config']['User'],'entrypoint':image['Config']['Entrypoint'],'sizeBytes':image['Size'],'compatibleRollback':json.loads(run('image','inspect','done-public:dc53fecf'))[0]['Id']}
(root/'image.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

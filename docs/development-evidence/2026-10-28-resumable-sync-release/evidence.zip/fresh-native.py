from pathlib import Path
import subprocess,json,os
s=Path(__file__).parent;r=s/'source';node='/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node';env=dict(os.environ,PATH=str(Path(node).parent)+':'+os.environ['PATH'],CHROMIUM_PATH='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome');rows=[]
for name in ['preparation','preparation-owner','progress']:
 path='test/local-baseline/'+name+'.node.mjs'
 with (s/('native-'+name+'.log')).open('wb') as out:q=subprocess.run([node,'--test','--test-concurrency=1',path],cwd=r,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=300)
 rows.append({'name':name,'path':path,'exitCode':q.returncode,'scope':'Fresh native source fixture from clean signed archive; not the immutable frontend image'});print(name,q.returncode,flush=True)
 if q.returncode:break
(s/'native-checks.json').write_text(json.dumps(rows,indent=2)+'\n');raise SystemExit(any(v['exitCode'] for v in rows))

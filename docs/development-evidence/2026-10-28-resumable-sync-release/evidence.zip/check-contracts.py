from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,os,subprocess
r=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');s=Path(__file__).parent;node='/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node';env=dict(os.environ,PATH=str(Path(node).parent)+os.pathsep+os.environ['PATH']);contracts=json.loads((r/'docs/development-evidence/2026-10-26-signed-ux-retention-checkpoint/contracts.json').read_text());assert len(contracts)==40
jobs=[(f'contract-{i}',v['argv'],v['env']) for i,v in enumerate(contracts)]
jobs.append(('metadata-adapters',[node,'--test','--test-concurrency=2',*['test/release-validation/'+x+'.test.mjs' for x in ['onboarding-gates','vitest','playwright','general-tests','generated-tests','account-fixtures','campaign-wrappers','manifest']],'test/account-first-authority/registry.test.mjs'],{}))
def run(v):
 name,argv,extra=v
 try:
  q=subprocess.run(argv,cwd=r,env=dict(env,**extra),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=240);code=q.returncode;log=q.stdout
 except subprocess.TimeoutExpired as e:code=124;log=(e.stdout or b'')+b'\n240s harness deadline reached.\n'
 (s/('fresh-'+name+'.log')).write_bytes(log);print(name,code,flush=True);return {'name':name,'argv':argv,'env':extra,'node':'24.18.0','exitCode':code}
with ThreadPoolExecutor(max_workers=2) as pool:rows=list(pool.map(run,jobs))
(s/'fresh-contract-checks.json').write_text(json.dumps(rows,indent=2)+'\n');raise SystemExit(any(v['exitCode']!=0 for v in rows))

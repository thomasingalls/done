
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {mkdirSync,rmSync,chmodSync,writeFileSync} from 'node:fs';
import {resolve,join} from 'node:path';
const [image,dir]=process.argv.slice(2),out=resolve(dir);
mkdirSync(out,{recursive:true});
const fixture=join(out,'fixture');mkdirSync(fixture);
const receipt={image,ok:false,checks:[]};
function run(command,args){const r=spawnSync(command,args,{encoding:'utf8',timeout:45000});assert.ifError(r.error);assert.equal(r.status,0,r.stderr+r.stdout);return r.stdout.trim();}
try {
run('openssl',['req','-x509','-newkey','rsa:2048','-nodes','-keyout',join(fixture,'key.pem'),'-out',join(fixture,'cert.pem'),'-days','1','-subj','/CN=localhost','-addext','subjectAltName=DNS:localhost,IP:127.0.0.1']);
chmodSync(join(fixture,'key.pem'),0o644); // Disposable test key must be readable by container UID 65532.
const probe=async()=>{
 const assert=require('node:assert/strict'),fs=require('node:fs'),https=require('node:https');
 const {once}=require('node:events'),key=fs.readFileSync('/fixture/key.pem'),cert=fs.readFileSync('/fixture/cert.pem');
 const server=https.createServer({key,cert},(req,res)=>res.end('fixture-ok'));
 server.listen(0,'127.0.0.1');await once(server,'listening');
 const url='https://127.0.0.1:'+server.address().port;
 const get=(options)=>new Promise((resolve,reject)=>{
  const req=https.get(url,options,res=>{let text='';res.setEncoding('utf8');res.on('data',x=>text+=x);res.on('end',()=>resolve(text));});req.on('error',reject);
 });
 try {await assert.rejects(get({}),e=>/SELF_SIGNED_CERT/.test(e.code));assert.equal(await get({ca:cert}),'fixture-ok');}
 finally{await new Promise(r=>server.close(r));}
 console.log('default rejects untrusted TLS; explicit disposable CA positive control passed');
};
receipt.checks.push(run('docker',['run','--rm','--network','none','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--mount','type=bind,source='+fixture+',target=/fixture,readonly','--entrypoint','node',image,'-e','('+probe.toString()+')().catch(e=>{console.error(e);process.exitCode=1})']));
receipt.checks.push(run('docker',['run','--rm','--add-host','nodejs.org:104.16.212.131','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--entrypoint','node',image,'-e',"fetch('https://nodejs.org/en/',{signal:AbortSignal.timeout(15000)}).then(r=>{if(!r.ok)throw Error('HTTP '+r.status);console.log('public HTTPS default trust passed: '+r.status)}).catch(e=>{console.error(e);process.exitCode=1})"]));
receipt.ok=true;
} finally {rmSync(fixture,{recursive:true,force:true});writeFileSync(join(out,'tls-check.json'),JSON.stringify(receipt,null,2)+'\n');}

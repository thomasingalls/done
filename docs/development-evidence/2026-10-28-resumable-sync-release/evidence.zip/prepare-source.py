from pathlib import Path
import subprocess,json,tarfile,io,hashlib,os
r=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');s=Path('/private/tmp/done-resumable-release-20261028');rows=json.loads((s/'signed-commits.json').read_text());assert len(rows)==38;head=rows[-1]['commit']
def git(*a):return subprocess.check_output(['git',*a],cwd=r)
assert git('rev-parse','HEAD').decode().strip()==head;assert not git('status','--porcelain=v1')
assert git('rev-parse','HEAD^{tree}').decode().strip()=='66bbe1bd729570d80b6ed2752e0539a2a8207fd9'
old=json.loads((r/'docs/development-evidence/2026-10-26-ux-retention-release/source.json').read_text());inputs=old['inputs'];tracked=git('ls-tree','-r','--name-only',head).decode().splitlines();extra=[p for p in tracked if '/' not in p and (p.startswith('tsconfig') and p.endswith('.json') or p.startswith('playwright') and p.endswith('.config.ts'))];inputs=sorted(set(inputs+extra))
archive=git('archive','--format=tar',head,'--',*inputs);(s/'signed-source.tar').write_bytes(archive);context=s/'source';context.mkdir();files=[]
with tarfile.open(fileobj=io.BytesIO(archive)) as t:
 for member in t:
  assert not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
  if member.isdir():continue
  assert member.isfile(),member.name;assert not any(k in Path(member.name).parts for k in ['.git','.env','.dev','node_modules','docs'])
  data=t.extractfile(member).read();p=context/member.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);p.chmod(member.mode);assert data==(r/member.name).read_bytes();files.append({'path':member.name,'sha256':hashlib.sha256(data).hexdigest(),'executable':bool(member.mode&0o111)})
verified=[]
for v in rows:
 q=subprocess.run(['git','verify-commit',v['commit']],cwd=r,capture_output=True,text=True);assert q.returncode==0,q.stdout+q.stderr;assert git('rev-parse',v['commit']+'^{tree}').decode().strip()==v['tree'];verified.append({'phase':v['phase'],'commit':v['commit'],'tree':v['tree'],'verification':(q.stdout+q.stderr).strip()})
date=git('show','-s','--format=%cs',head).decode().strip();record={'source':head,'tree':git('rev-parse',head+'^{tree}').decode().strip(),'date':date,'inputs':inputs,'files':files,'archiveBytes':len(archive),'archiveSha256':hashlib.sha256(archive).hexdigest(),'signatures':verified,'platform':'linux/arm64','candidateTag':'done-public:'+head[:8],'featureOverrides':{'VITE_ACCOUNT_RETENTION_AUTO':'1','VITE_ACCOUNT_RETENTION_RESUME':'1','VITE_ACCOUNT_HISTORY_AUTO':'0','VITE_ACCOUNT_BATCH':'coordinated-2000'},'sourceResumeAndServiceDefaultsStill0':True,'measuredSourceTree':'551991664565e96d336da66bd76171967246364c','phone':'deferred by operator','generalQualification':'paused;935 obligations/389 unresolved; no aggregate credit'}
(s/'source.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'source':head,'candidateTag':record['candidateTag'],'inputs':len(files),'verifiedCommits':len(verified),'featureOverrides':record['featureOverrides']},indent=2))

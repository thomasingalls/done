import { defineConfig } from '/Users/thomasingalls/.codex/worktrees/7fda/done/node_modules/vitest/dist/config.js';
export default defineConfig({
  root: '/private/tmp/done-goals-implementation-2026-10-25/review-card-context',
  test: {
    include: ['*.test.ts'],
    environment: 'jsdom',
    setupFiles: ['/Users/thomasingalls/.codex/worktrees/7fda/done/test/setup.ts'],
    maxWorkers: 1,
    reporters: ['verbose', 'json'],
    outputFile: '/private/tmp/done-goals-implementation-2026-10-25/review-card-context/result.json',
  },
});

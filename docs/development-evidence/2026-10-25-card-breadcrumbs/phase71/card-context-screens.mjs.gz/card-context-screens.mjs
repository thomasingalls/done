import {chromium,expect} from '/Users/thomasingalls/.codex/worktrees/7fda/done/node_modules/@playwright/test/index.mjs';
const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'});
try{
 const page=await browser.newPage({viewport:{width:1378,height:935},colorScheme:'dark'});await page.goto('http://127.0.0.1:53921/');const editor=page.locator('.goals .cm-content');await editor.click();
 const doc='# Work\n## Studio site\n### Launch\n- Ask Leila which photos we can use\n- Replace the coming soon page\n  - Use the short introduction from the pitch\n  - Link the two recent projects\n\n# Home\n## Kitchen\n- Measure the cabinet doors';await page.keyboard.insertText(doc);
 const choose=async(line)=>editor.evaluate((element,line)=>{const view=element.cmTile.root.view;const at=view.state.doc.toString().indexOf(line);view.dispatch({selection:{anchor:at}});view.focus();},line);
 for(const [line,to]of [['- Ask Leila','Next'],['- Measure the cabinet','Scheduled']]){await choose(line);await page.locator('.goals-destinations').getByRole('button',{name:to,exact:true}).click();}
 await expect(page.locator('.day-panel[data-active="true"] .card-goals-context')).toHaveCount(2);await choose('- Replace');await page.locator('.goals .cm-scroller').evaluate(el=>el.scrollTop=0);await expect(page.locator('.goals-breadcrumbs')).toHaveAttribute('title','Goals › Work');
 await page.screenshot({path:'/private/tmp/done-goals-implementation-2026-10-25/card-context-desktop.png'});
 await page.locator('details[data-menu-section="Account"] summary').click();await page.getByRole('checkbox',{name:'Goals breadcrumbs on cards',exact:true}).scrollIntoViewIfNeeded();await page.screenshot({path:'/private/tmp/done-goals-implementation-2026-10-25/card-context-settings.png'});
 await page.setViewportSize({width:390,height:844});await page.getByRole('button',{name:'Close',exact:true}).filter({visible:true}).first().click().catch(()=>{});await page.keyboard.press('Alt+ArrowLeft');await page.screenshot({path:'/private/tmp/done-goals-implementation-2026-10-25/card-context-mobile.png'});
}finally{await browser.close();}

# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: non-overlapping-sessions.spec.ts >> confirmed uploads survive non-overlapping sessions second-to-first
- Location: test/packaged-account/non-overlapping-sessions.spec.ts:45:3

# Error details

```
Error: response.body: Protocol error (Network.getResponseBody): No data found for resource with given identifier
Response body is not available for a response that was navigated away from. Read response.body() before triggering any navigation.
```

# Test source

```ts
  1   | import { test, expect, type Page, type BrowserContext } from '@playwright/test';
  2   | import { DatabaseSync } from 'node:sqlite';
  3   | import { join } from 'node:path';
  4   | import { performance } from 'node:perf_hooks';
  5   | import { decodeSubmit } from '../../account-protocol/deliveryTransport';
  6   | import { decodeSubmission } from '../../account-protocol/submission';
  7   | import { decodeNetworkEnvelope } from '../../account-protocol/envelope';
  8   | import { decodePositionResponse } from '../../account-protocol/positionDecision';
  9   | import { openMenuSection } from '../geometry/openApp';
  10  | import { pairedEditors, credentials, restoreAuthenticator, openSaved, add } from './devices';
  11  | import { startService, stopService, startBackend, stopProcess, origin } from './server';
  12  | 
  13  | async function settledSending(page: Page) {
  14  |   await openMenuSection(page, 'Sync');
  15  |   const sync = page.locator('.sync-details');
  16  |   await expect(sync.getByText('Sending: idle', { exact: true })).toBeVisible({ timeout: 20000 });
  17  |   const position = await sync.getByText(/^Accepted position: \d+$/).textContent();
  18  |   return Number(position!.match(/\d+$/)![0]);
  19  | }
  20  | 
  21  | async function closeDevice(page: Page) {
  22  |   const context = page.context();
  23  |   await page.close();
  24  |   await context.setOffline(true);
  25  |   expect(context.pages()).toHaveLength(0);
  26  | }
  27  | 
  28  | async function openOffline(
  29  |   context: BrowserContext,
  30  |   saved: Awaited<ReturnType<typeof credentials>>,
  31  |   code: string,
  32  |   joining: boolean,
  33  | ) {
  34  |   expect(context.pages()).toHaveLength(0);
  35  |   const page = await context.newPage();
  36  |   const auth = await restoreAuthenticator(page, saved);
  37  |   await page.goto(origin + '/');
  38  |   expect(await page.evaluate(() => !!navigator.serviceWorker.controller)).toBe(true);
  39  |   expect(await page.evaluate(() => navigator.onLine)).toBe(false);
  40  |   await openSaved(page, code, joining);
  41  |   return { page, auth };
  42  | }
  43  | 
  44  | for (const direction of ['first-to-second', 'second-to-first']) {
  45  |   test(`confirmed uploads survive non-overlapping sessions ${direction}`, async ({
  46  |     page,
  47  |     browser,
  48  |   }, info) => {
  49  |     const state = info.outputPath('service');
  50  |     const service = await startService(state, undefined, true, true);
  51  |     let pair: Awaited<ReturnType<typeof pairedEditors>> | undefined;
  52  |     const errors: string[] = [];
  53  |     try {
  54  |       pair = await pairedEditors(page, browser, true);
  55  |       const firstSends = direction === 'first-to-second';
  56  |       const sender = firstSends ? page : pair.second;
  57  |       let receiver = firstSends ? pair.second : page;
  58  |       const senderContext = sender.context(),
  59  |         receiverContext = receiver.context();
  60  |       const receiverSaved = await credentials(firstSends ? pair.next.auth : pair.first.auth);
  61  |       const receiverCode = firstSends ? pair.next.code : pair.first.code;
  62  |       for (const context of [senderContext, receiverContext])
  63  |         context.on('page', (p) => p.on('pageerror', (error) => errors.push(error.message)));
  64  |       sender.on('pageerror', (error) => errors.push(error.message));
  65  |       receiver.on('pageerror', (error) => errors.push(error.message));
  66  |       const baselinePosition = await settledSending(sender);
  67  |       const marker = `Accepted while the receiver is closed: ${direction}`;
  68  |       await expect(receiver.locator('.shell')).not.toContainText(marker);
  69  |       await closeDevice(receiver);
  70  | 
  71  |       // A successful status alone is insufficient: bind the accepted decision to its exact request,
  72  |       // independently inspect committed server bytes, and require the client's verified frontier.
  73  |       const accepted = sender.waitForResponse(
  74  |         (response) =>
  75  |           new URL(response.url()).pathname === '/account/delivery/submit' &&
  76  |           response.status() === 200,
  77  |         { timeout: 20000 },
  78  |       );
  79  |       await add(sender, marker);
  80  |       const response = await accepted;
  81  |       const wire = decodeSubmit(new Uint8Array(response.request().postDataBuffer()!));
  82  |       const envelope = decodeNetworkEnvelope(decodeSubmission(wire.bytes).envelope);
> 83  |       const responseBytes = new Uint8Array(await response.body());
      |                                                           ^ Error: response.body: Protocol error (Network.getResponseBody): No data found for resource with given identifier
  84  |       const decision = decodePositionResponse(responseBytes);
  85  |       expect(decision.kind).toBe('accepted');
  86  |       if (decision.kind !== 'accepted') throw Error('Upload was not accepted');
  87  |       expect(decision.head).toMatchObject({
  88  |         workspace: wire.workspaceId,
  89  |         credential: envelope.credential_id,
  90  |         position: envelope.seq,
  91  |       });
  92  |       expect(decision.leaf).toEqual({
  93  |         epoch: envelope.epoch,
  94  |         digest: Buffer.from(envelope.digest).toString('hex'),
  95  |       });
  96  |       expect(envelope.seq).toBeGreaterThan(baselinePosition);
  97  |       const db = new DatabaseSync(join(state, 'account.sqlite'), { readOnly: true });
  98  |       try {
  99  |         const rows = db
  100 |           .prepare(`
  101 |           SELECT d.kind, d.submission, d.response FROM publisher_decisions d
  102 |           JOIN promotions p ON p.account_id=d.account_id
  103 |           WHERE p.workspace_id=? AND d.credential_id=? AND d.position=? AND d.digest=?
  104 |           UNION ALL
  105 |           SELECT d.kind, d.submission, d.response FROM delivery_decisions d
  106 |           JOIN promotions p ON p.account_id=d.account_id
  107 |           WHERE p.workspace_id=? AND d.position=? AND d.digest=?
  108 |         `)
  109 |           .all(
  110 |             wire.workspaceId,
  111 |             envelope.credential_id,
  112 |             envelope.seq,
  113 |             decision.leaf.digest,
  114 |             wire.workspaceId,
  115 |             envelope.seq,
  116 |             decision.leaf.digest,
  117 |           );
  118 |         expect(rows).toHaveLength(1);
  119 |         expect(rows[0]!['kind']).toBe('accepted');
  120 |         expect(new Uint8Array(rows[0]!['submission'] as Uint8Array)).toEqual(wire.bytes);
  121 |         expect(new Uint8Array(rows[0]!['response'] as Uint8Array)).toEqual(responseBytes);
  122 |       } finally {
  123 |         db.close();
  124 |       }
  125 |       expect(await settledSending(sender)).toBe(envelope.seq);
  126 |       expect(receiverContext.pages()).toHaveLength(0);
  127 |       await closeDevice(sender);
  128 | 
  129 |       // Restarting the API also rules out live sender state or an in-memory delivery queue.
  130 |       await stopProcess(service.backend);
  131 |       service.backend = await startBackend(state, true, true);
  132 |       expect(senderContext.pages()).toHaveLength(0);
  133 |       expect(receiverContext.pages()).toHaveLength(0);
  134 |       const opened = await openOffline(receiverContext, receiverSaved, receiverCode, firstSends);
  135 |       receiver = opened.page;
  136 |       await expect(receiver.locator('.shell')).toContainText('Keep the first device writing');
  137 |       await expect(receiver.locator('.shell')).not.toContainText(marker);
  138 |       const started = performance.now();
  139 |       await receiverContext.setOffline(false);
  140 |       await expect(receiver.locator('.shell')).toContainText(marker, { timeout: 20000 });
  141 |       const catchupMs = performance.now() - started;
  142 |       expect(senderContext.pages()).toHaveLength(0);
  143 |       const retainedCredentials = await credentials(opened.auth);
  144 |       // A second offline document must see admitted storage, not the previous live projection.
  145 |       await closeDevice(receiver);
  146 |       receiver = (await openOffline(receiverContext, retainedCredentials, receiverCode, firstSends))
  147 |         .page;
  148 |       await expect(receiver.locator('.shell')).toContainText(marker);
  149 |       expect(senderContext.pages()).toHaveLength(0);
  150 |       expect(errors).toEqual([]);
  151 |       await info.attach('non-overlapping-session-evidence', {
  152 |         contentType: 'application/json',
  153 |         body: JSON.stringify({
  154 |           direction,
  155 |           acceptedPosition: envelope.seq,
  156 |           exactCommittedUploadAndResponse: true,
  157 |           clientVerifiedAcceptance: true,
  158 |           senderClosedAndOfflineBeforeReceiverOpened: true,
  159 |           receiverInitiallyOfflineAndMissingMarker: true,
  160 |           apiRestartedBetweenUploadAndReceive: true,
  161 |           catchupMs,
  162 |           receiverOfflineReopenRetainedWriting: true,
  163 |           pageErrors: errors,
  164 |         }),
  165 |       });
  166 |     } finally {
  167 |       await pair?.other.close();
  168 |       await stopService(service);
  169 |     }
  170 |   });
  171 | }
  172 | 
```
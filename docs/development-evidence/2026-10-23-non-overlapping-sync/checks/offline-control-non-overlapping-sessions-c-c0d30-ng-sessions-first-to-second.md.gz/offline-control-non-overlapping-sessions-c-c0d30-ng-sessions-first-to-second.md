# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: non-overlapping-sessions.spec.ts >> confirmed uploads survive non-overlapping sessions first-to-second
- Location: test/packaged-account/non-overlapping-sessions.spec.ts:61:3

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: false
Received: true
```

# Test source

```ts
  1   | import { test, expect, type Page, type BrowserContext } from '@playwright/test';
  2   | import { DatabaseSync } from 'node:sqlite';
  3   | import { join } from 'node:path';
  4   | import { performance } from 'node:perf_hooks';
  5   | import { decodeSubmit } from '../../account-protocol/deliveryTransport';
  6   | import { decodeSubmission } from '../../account-protocol/submission';
  7   | import { decodeNetworkEnvelope } from '../../account-protocol/envelope';
  8   | import { decodePositionResponse } from '../../account-protocol/positionDecision';
  9   | import { openMenuSection } from '../geometry/openApp';
  10  | import { pairedEditors, credentials, restoreAuthenticator, openSaved, add } from './devices';
  11  | import { startService, stopService, startBackend, stopProcess, origin } from './server';
  12  | 
  13  | async function settledSending(page: Page) {
  14  |   await openMenuSection(page, 'Sync');
  15  |   const sync = page.locator('.sync-details');
  16  |   await expect(sync.getByText('Sending: idle', { exact: true })).toBeVisible({ timeout: 20000 });
  17  |   const position = await sync.getByText(/^Accepted position: \d+$/).textContent();
  18  |   return Number(position!.match(/\d+$/)![0]);
  19  | }
  20  | 
  21  | async function closeDevice(page: Page) {
  22  |   const context = page.context();
  23  |   await page.close();
  24  |   await context.setOffline(true);
  25  |   expect(context.pages()).toHaveLength(0);
  26  | }
  27  | 
  28  | async function openOffline(
  29  |   context: BrowserContext,
  30  |   saved: Awaited<ReturnType<typeof credentials>>,
  31  |   code: string,
  32  |   joining: boolean,
  33  | ) {
  34  |   expect(context.pages()).toHaveLength(0);
  35  |   const page = await context.newPage();
  36  |   const auth = await restoreAuthenticator(page, saved);
  37  |   await context.setOffline(true);
  38  |   await page.goto(origin + '/');
  39  |   expect(await page.evaluate(() => !!navigator.serviceWorker.controller)).toBe(true);
  40  |   const reachable = await page.evaluate(async () => {
  41  |     try {
  42  |       return (
  43  |         await fetch('/__account-setup/config', {
  44  |           method: 'POST',
  45  |           headers: { 'Content-Type': 'application/json' },
  46  |           body: '{}',
  47  |           cache: 'no-store',
  48  |         })
  49  |       ).status;
  50  |     } catch {
  51  |       return null;
  52  |     }
  53  |   });
  54  |   expect(reachable).toBeNull();
> 55  |   expect(await page.evaluate(() => navigator.onLine)).toBe(false);
      |                                                       ^ Error: expect(received).toBe(expected) // Object.is equality
  56  |   await openSaved(page, code, joining);
  57  |   return { page, auth };
  58  | }
  59  | 
  60  | for (const direction of ['first-to-second', 'second-to-first']) {
  61  |   test(`confirmed uploads survive non-overlapping sessions ${direction}`, async ({
  62  |     page,
  63  |     browser,
  64  |   }, info) => {
  65  |     const state = info.outputPath('service');
  66  |     const service = await startService(state, undefined, true, true);
  67  |     let pair: Awaited<ReturnType<typeof pairedEditors>> | undefined;
  68  |     const errors: string[] = [];
  69  |     try {
  70  |       pair = await pairedEditors(page, browser, true);
  71  |       const firstSends = direction === 'first-to-second';
  72  |       const sender = firstSends ? page : pair.second;
  73  |       let receiver = firstSends ? pair.second : page;
  74  |       const senderContext = sender.context(),
  75  |         receiverContext = receiver.context();
  76  |       const receiverSaved = await credentials(firstSends ? pair.next.auth : pair.first.auth);
  77  |       const receiverCode = firstSends ? pair.next.code : pair.first.code;
  78  |       for (const context of [senderContext, receiverContext])
  79  |         context.on('page', (p) => p.on('pageerror', (error) => errors.push(error.message)));
  80  |       sender.on('pageerror', (error) => errors.push(error.message));
  81  |       receiver.on('pageerror', (error) => errors.push(error.message));
  82  |       const baselinePosition = await settledSending(sender);
  83  |       const marker = `Accepted while the receiver is closed: ${direction}`;
  84  |       await expect(receiver.locator('.shell')).not.toContainText(marker);
  85  |       await closeDevice(receiver);
  86  | 
  87  |       // A successful status alone is insufficient: bind the accepted decision to its exact request,
  88  |       // independently inspect committed server bytes, and require the client's verified frontier.
  89  |       let accepted:
  90  |         | { request: Uint8Array<ArrayBuffer>; response: Uint8Array<ArrayBuffer> }
  91  |         | undefined;
  92  |       await sender.route('**/account/delivery/submit', async (route) => {
  93  |         const response = await route.fetch();
  94  |         if (response.status() === 200)
  95  |           accepted = {
  96  |             request: new Uint8Array(route.request().postDataBuffer()!),
  97  |             response: new Uint8Array(await response.body()),
  98  |           };
  99  |         await route.fulfill({ response });
  100 |       });
  101 |       await add(sender, marker);
  102 |       await expect.poll(() => !!accepted, { timeout: 20000 }).toBe(true);
  103 |       const wire = decodeSubmit(accepted!.request);
  104 |       const envelope = decodeNetworkEnvelope(decodeSubmission(wire.bytes).envelope);
  105 |       const responseBytes = accepted!.response;
  106 |       const decision = decodePositionResponse(responseBytes);
  107 |       expect(decision.kind).toBe('accepted');
  108 |       if (decision.kind !== 'accepted') throw Error('Upload was not accepted');
  109 |       expect(decision.head).toMatchObject({
  110 |         workspace: wire.workspaceId,
  111 |         credential: envelope.credential_id,
  112 |         position: envelope.seq,
  113 |       });
  114 |       expect(decision.leaf).toEqual({
  115 |         epoch: envelope.epoch,
  116 |         digest: Buffer.from(envelope.digest).toString('hex'),
  117 |       });
  118 |       expect(envelope.seq).toBeGreaterThan(baselinePosition);
  119 |       const db = new DatabaseSync(join(state, 'account.sqlite'), { readOnly: true });
  120 |       try {
  121 |         const rows = db
  122 |           .prepare(`
  123 |           SELECT d.kind, d.submission, d.response FROM publisher_decisions d
  124 |           JOIN promotions p ON p.account_id=d.account_id
  125 |           WHERE p.workspace_id=? AND d.credential_id=? AND d.position=? AND d.digest=?
  126 |           UNION ALL
  127 |           SELECT d.kind, d.submission, d.response FROM delivery_decisions d
  128 |           JOIN promotions p ON p.account_id=d.account_id
  129 |           WHERE p.workspace_id=? AND d.position=? AND d.digest=?
  130 |         `)
  131 |           .all(
  132 |             wire.workspaceId,
  133 |             envelope.credential_id,
  134 |             envelope.seq,
  135 |             decision.leaf.digest,
  136 |             wire.workspaceId,
  137 |             envelope.seq,
  138 |             decision.leaf.digest,
  139 |           );
  140 |         expect(rows).toHaveLength(1);
  141 |         expect(rows[0]!['kind']).toBe('accepted');
  142 |         expect(new Uint8Array(rows[0]!['submission'] as Uint8Array)).toEqual(wire.bytes);
  143 |         expect(new Uint8Array(rows[0]!['response'] as Uint8Array)).toEqual(responseBytes);
  144 |       } finally {
  145 |         db.close();
  146 |       }
  147 |       expect(await settledSending(sender)).toBe(envelope.seq);
  148 |       expect(receiverContext.pages()).toHaveLength(0);
  149 |       await sender.unrouteAll({ behavior: 'wait' });
  150 |       await closeDevice(sender);
  151 | 
  152 |       // Restarting the API also rules out live sender state or an in-memory delivery queue.
  153 |       await stopProcess(service.backend);
  154 |       service.backend = await startBackend(state, true, true);
  155 |       expect(senderContext.pages()).toHaveLength(0);
```
# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: non-overlapping-sessions.spec.ts >> confirmed uploads survive non-overlapping sessions first-to-second
- Location: test/packaged-account/non-overlapping-sessions.spec.ts:45:3

# Error details

```
Error: Service shutdown timeout: /private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node scripts/serve-account.mjs
(node:36342) Warning: The 'NO_COLOR' env is ignored due to the 'FORCE_COLOR' env being set.
(Use `node --trace-warnings ...` to show where the warning was created)
Account packaged development: http://localhost:53221/

```

# Test source

```ts
  1   | import { spawn, type ChildProcess } from 'node:child_process';
  2   | import { resolve } from 'node:path';
  3   | export const port = '53221';
  4   | export const origin = 'http://localhost:' + port;
  5   | const servicePort = '53222';
  6   | const processOutput = new WeakMap<ChildProcess, () => string>();
  7   | async function startProcess(
  8   |   script: string,
  9   |   ready: string,
  10  |   state?: string,
  11  |   build = resolve('dist'),
  12  |   networkSessions = false,
  13  |   membershipContinuation = false,
  14  | ) {
  15  |   const child = spawn(process.execPath, [script], {
  16  |     env: {
  17  |       ...process.env,
  18  |       ACCOUNT_NETWORK_SESSIONS: networkSessions ? '1' : '0',
  19  |       ACCOUNT_MEMBERSHIP_CONTINUATION: membershipContinuation ? '1' : '0',
  20  |       ACCOUNT_SETUP_PORT: port,
  21  |       ACCOUNT_SETUP_ORIGIN: origin,
  22  |       ACCOUNT_SERVICE_PORT: servicePort,
  23  |       ...(state ? { ACCOUNT_SETUP_STATE: state } : {}),
  24  |       ACCOUNT_SETUP_DIST: build,
  25  |     },
  26  |     stdio: ['ignore', 'pipe', 'pipe'],
  27  |   });
  28  |   let output = '';
  29  |   processOutput.set(child, () => output);
  30  |   await new Promise<void>((accept, reject) => {
  31  |     const timer = setTimeout(() => {
  32  |       child.kill('SIGTERM');
  33  |       reject(Error('Service startup timeout: ' + output));
  34  |     }, 15000);
  35  |     child.once('error', (error) => {
  36  |       clearTimeout(timer);
  37  |       reject(error);
  38  |     });
  39  |     child.once('exit', (code) => {
  40  |       clearTimeout(timer);
  41  |       reject(Error(`Service exited ${code}: ${output}`));
  42  |     });
  43  |     const data = (chunk: Buffer) => {
  44  |       output = (output + chunk.toString()).slice(-8000);
  45  |       if (output.includes(ready)) {
  46  |         clearTimeout(timer);
  47  |         accept();
  48  |       }
  49  |     };
  50  |     child.stdout!.on('data', data);
  51  |     child.stderr!.on('data', data);
  52  |   });
  53  |   return child;
  54  | }
  55  | export async function stopProcess(child: ChildProcess) {
  56  |   if (child.exitCode !== null || child.signalCode !== null) return;
  57  |   await new Promise<void>((accept, reject) => {
  58  |     const timer = setTimeout(() => {
  59  |       child.kill('SIGKILL');
  60  |       reject(
> 61  |         Error(
      |         ^ Error: Service shutdown timeout: /private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node scripts/serve-account.mjs
  62  |           `Service shutdown timeout: ${child.spawnargs.join(' ')}\n${processOutput.get(child)?.()}`,
  63  |         ),
  64  |       );
  65  |     }, 10000);
  66  |     child.once('exit', () => {
  67  |       clearTimeout(timer);
  68  |       accept();
  69  |     });
  70  |     child.kill('SIGTERM');
  71  |   });
  72  | }
  73  | 
  74  | export const startBackend = (
  75  |   state: string,
  76  |   networkSessions = false,
  77  |   membershipContinuation = false,
  78  | ) =>
  79  |   startProcess(
  80  |     'scripts/serve-account-service.mjs',
  81  |     'Account API development:',
  82  |     state,
  83  |     resolve('dist'),
  84  |     networkSessions,
  85  |     membershipContinuation,
  86  |   );
  87  | export const startApplication = (build = resolve('dist')) =>
  88  |   startProcess('scripts/serve-account.mjs', 'Account packaged development:', undefined, build);
  89  | export async function startService(
  90  |   state: string,
  91  |   build = resolve('dist'),
  92  |   networkSessions = false,
  93  |   membershipContinuation = false,
  94  | ) {
  95  |   const backend = await startBackend(state, networkSessions, membershipContinuation);
  96  |   try {
  97  |     return { backend, app: await startApplication(build) };
  98  |   } catch (cause) {
  99  |     await stopProcess(backend);
  100 |     throw cause;
  101 |   }
  102 | }
  103 | export async function stopService(service: Awaited<ReturnType<typeof startService>>) {
  104 |   await Promise.all([stopProcess(service.app), stopProcess(service.backend)]);
  105 | }
  106 | 
```
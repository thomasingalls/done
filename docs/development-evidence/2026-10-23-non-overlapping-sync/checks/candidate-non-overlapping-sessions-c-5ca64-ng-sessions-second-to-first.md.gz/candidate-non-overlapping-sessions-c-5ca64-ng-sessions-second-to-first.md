# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: non-overlapping-sessions.spec.ts >> confirmed uploads survive non-overlapping sessions second-to-first
- Location: test/packaged-account/non-overlapping-sessions.spec.ts:45:3

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: false
Received: true
```

# Test source

```ts
  1   | import { test, expect, type Page, type BrowserContext } from '@playwright/test';
  2   | import { DatabaseSync } from 'node:sqlite';
  3   | import { join } from 'node:path';
  4   | import { performance } from 'node:perf_hooks';
  5   | import { decodeSubmit } from '../../account-protocol/deliveryTransport';
  6   | import { decodeSubmission } from '../../account-protocol/submission';
  7   | import { decodeNetworkEnvelope } from '../../account-protocol/envelope';
  8   | import { decodePositionResponse } from '../../account-protocol/positionDecision';
  9   | import { openMenuSection } from '../geometry/openApp';
  10  | import { pairedEditors, credentials, restoreAuthenticator, openSaved, add } from './devices';
  11  | import { startService, stopService, startBackend, stopProcess, origin } from './server';
  12  | 
  13  | async function settledSending(page: Page) {
  14  |   await openMenuSection(page, 'Sync');
  15  |   const sync = page.locator('.sync-details');
  16  |   await expect(sync.getByText('Sending: idle', { exact: true })).toBeVisible({ timeout: 20000 });
  17  |   const position = await sync.getByText(/^Accepted position: \d+$/).textContent();
  18  |   return Number(position!.match(/\d+$/)![0]);
  19  | }
  20  | 
  21  | async function closeDevice(page: Page) {
  22  |   const context = page.context();
  23  |   await page.close();
  24  |   await context.setOffline(true);
  25  |   expect(context.pages()).toHaveLength(0);
  26  | }
  27  | 
  28  | async function openOffline(
  29  |   context: BrowserContext,
  30  |   saved: Awaited<ReturnType<typeof credentials>>,
  31  |   code: string,
  32  |   joining: boolean,
  33  | ) {
  34  |   expect(context.pages()).toHaveLength(0);
  35  |   const page = await context.newPage();
  36  |   const auth = await restoreAuthenticator(page, saved);
  37  |   await page.goto(origin + '/');
  38  |   expect(await page.evaluate(() => !!navigator.serviceWorker.controller)).toBe(true);
> 39  |   expect(await page.evaluate(() => navigator.onLine)).toBe(false);
      |                                                       ^ Error: expect(received).toBe(expected) // Object.is equality
  40  |   await openSaved(page, code, joining);
  41  |   return { page, auth };
  42  | }
  43  | 
  44  | for (const direction of ['first-to-second', 'second-to-first']) {
  45  |   test(`confirmed uploads survive non-overlapping sessions ${direction}`, async ({
  46  |     page,
  47  |     browser,
  48  |   }, info) => {
  49  |     const state = info.outputPath('service');
  50  |     const service = await startService(state, undefined, true, true);
  51  |     let pair: Awaited<ReturnType<typeof pairedEditors>> | undefined;
  52  |     const errors: string[] = [];
  53  |     try {
  54  |       pair = await pairedEditors(page, browser, true);
  55  |       const firstSends = direction === 'first-to-second';
  56  |       const sender = firstSends ? page : pair.second;
  57  |       let receiver = firstSends ? pair.second : page;
  58  |       const senderContext = sender.context(),
  59  |         receiverContext = receiver.context();
  60  |       const receiverSaved = await credentials(firstSends ? pair.next.auth : pair.first.auth);
  61  |       const receiverCode = firstSends ? pair.next.code : pair.first.code;
  62  |       for (const context of [senderContext, receiverContext])
  63  |         context.on('page', (p) => p.on('pageerror', (error) => errors.push(error.message)));
  64  |       sender.on('pageerror', (error) => errors.push(error.message));
  65  |       receiver.on('pageerror', (error) => errors.push(error.message));
  66  |       const baselinePosition = await settledSending(sender);
  67  |       const marker = `Accepted while the receiver is closed: ${direction}`;
  68  |       await expect(receiver.locator('.shell')).not.toContainText(marker);
  69  |       await closeDevice(receiver);
  70  | 
  71  |       // A successful status alone is insufficient: bind the accepted decision to its exact request,
  72  |       // independently inspect committed server bytes, and require the client's verified frontier.
  73  |       let accepted:
  74  |         | { request: Uint8Array<ArrayBuffer>; response: Uint8Array<ArrayBuffer> }
  75  |         | undefined;
  76  |       await sender.route('**/account/delivery/submit', async (route) => {
  77  |         const response = await route.fetch();
  78  |         if (response.status() === 200)
  79  |           accepted = {
  80  |             request: new Uint8Array(route.request().postDataBuffer()!),
  81  |             response: new Uint8Array(await response.body()),
  82  |           };
  83  |         await route.fulfill({ response });
  84  |       });
  85  |       await add(sender, marker);
  86  |       await expect.poll(() => !!accepted, { timeout: 20000 }).toBe(true);
  87  |       const wire = decodeSubmit(accepted!.request);
  88  |       const envelope = decodeNetworkEnvelope(decodeSubmission(wire.bytes).envelope);
  89  |       const responseBytes = accepted!.response;
  90  |       const decision = decodePositionResponse(responseBytes);
  91  |       expect(decision.kind).toBe('accepted');
  92  |       if (decision.kind !== 'accepted') throw Error('Upload was not accepted');
  93  |       expect(decision.head).toMatchObject({
  94  |         workspace: wire.workspaceId,
  95  |         credential: envelope.credential_id,
  96  |         position: envelope.seq,
  97  |       });
  98  |       expect(decision.leaf).toEqual({
  99  |         epoch: envelope.epoch,
  100 |         digest: Buffer.from(envelope.digest).toString('hex'),
  101 |       });
  102 |       expect(envelope.seq).toBeGreaterThan(baselinePosition);
  103 |       const db = new DatabaseSync(join(state, 'account.sqlite'), { readOnly: true });
  104 |       try {
  105 |         const rows = db
  106 |           .prepare(`
  107 |           SELECT d.kind, d.submission, d.response FROM publisher_decisions d
  108 |           JOIN promotions p ON p.account_id=d.account_id
  109 |           WHERE p.workspace_id=? AND d.credential_id=? AND d.position=? AND d.digest=?
  110 |           UNION ALL
  111 |           SELECT d.kind, d.submission, d.response FROM delivery_decisions d
  112 |           JOIN promotions p ON p.account_id=d.account_id
  113 |           WHERE p.workspace_id=? AND d.position=? AND d.digest=?
  114 |         `)
  115 |           .all(
  116 |             wire.workspaceId,
  117 |             envelope.credential_id,
  118 |             envelope.seq,
  119 |             decision.leaf.digest,
  120 |             wire.workspaceId,
  121 |             envelope.seq,
  122 |             decision.leaf.digest,
  123 |           );
  124 |         expect(rows).toHaveLength(1);
  125 |         expect(rows[0]!['kind']).toBe('accepted');
  126 |         expect(new Uint8Array(rows[0]!['submission'] as Uint8Array)).toEqual(wire.bytes);
  127 |         expect(new Uint8Array(rows[0]!['response'] as Uint8Array)).toEqual(responseBytes);
  128 |       } finally {
  129 |         db.close();
  130 |       }
  131 |       expect(await settledSending(sender)).toBe(envelope.seq);
  132 |       expect(receiverContext.pages()).toHaveLength(0);
  133 |       await sender.unrouteAll({ behavior: 'wait' });
  134 |       await closeDevice(sender);
  135 | 
  136 |       // Restarting the API also rules out live sender state or an in-memory delivery queue.
  137 |       await stopProcess(service.backend);
  138 |       service.backend = await startBackend(state, true, true);
  139 |       expect(senderContext.pages()).toHaveLength(0);
```

import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {dirname,join} from 'node:path';
import {fileURLToPath} from 'node:url';
const out=dirname(fileURLToPath(import.meta.url)),repo='/Users/thomasingalls/.codex/worktrees/7fda/done';
function run(bin,args){const r=spawnSync(bin,args,{encoding:'utf8',cwd:repo});assert.equal(r.status,0,r.stderr);return r.stdout.trim();}
const result={head:run('git',['rev-parse','HEAD']),realIndexEmpty:run('git',['diff','--cached','--name-only'])==='',unchangedRuntimeFromRelease:run('git',['diff','51d8550d','--name-only','--','package.json','pnpm-lock.yaml','account-service','account-protocol','scripts/public-account.mjs','scripts/public-healthcheck.mjs'])==='',source:{},images:{},validationBlocker:'AMD64 Docker builds fail the existing eight-second backup-worker readiness check under emulation, before final runtime construction.'};
for(const file of ['Dockerfile','.dockerignore','package.json','pnpm-lock.yaml','scripts/test-runtime-image.mjs'])result.source[file]=createHash('sha256').update(readFileSync(join(repo,file))).digest('hex');
for(const image of ['done-public:51d8550d','done-distroless:55-arm64','done-distroless:55-amd64','done-distroless:55-tools-arm64','done-distroless:55-tools-amd64']){
 const r=spawnSync('docker',['image','inspect',image],{encoding:'utf8'});
 if(r.status!==0){assert.equal(image,'done-distroless:55-amd64');result.images[image]={built:false,reason:result.validationBlocker};continue;}
 const d=JSON.parse(r.stdout)[0];
 result.images[image]={built:true,id:d.Id,repoDigests:d.RepoDigests,platform:d.Os+'/'+d.Architecture,size:d.Size,user:d.Config.User,entrypoint:d.Config.Entrypoint,cmd:d.Config.Cmd,workingDirectory:d.Config.WorkingDir,labels:d.Config.Labels};
}
writeFileSync(join(out,'source-image-identities.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));

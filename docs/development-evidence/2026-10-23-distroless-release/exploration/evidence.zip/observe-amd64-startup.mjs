
/* Diagnostic only, not a passing regression gate: observe first startup beyond the original 8 s deadline. */
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {dirname,join} from 'node:path';
import {fileURLToPath} from 'node:url';
const out=dirname(fileURLToPath(import.meta.url)),repo='/Users/thomasingalls/.codex/worktrees/7fda/done';
let source=readFileSync(join(repo,'test/public-backup/worker.test.mjs'),'utf8');
const old='    const deadline = Date.now() + 8000;',at='  assert.equal((await healthy()).backups, 1);';
assert(source.includes(old)&&source.includes(at));
source=source.replace(old,'    const deadline = Date.now() + 15000;');
source=source.replace('    child.stderr.resume();',"    child.stderr.on('data', bytes => console.error('CHILD',bytes.toString()));");
source=source.replace('  start();\n'+at,"  const began=Date.now();start();\n"+at+"\n  console.error('DIAGNOSTIC_ONLY_FIRST_STARTUP_READY_MS', Date.now()-began); return;");
assert(source.includes('DIAGNOSTIC_ONLY_FIRST_STARTUP_READY_MS'));
writeFileSync(join(out,'startup-observation.test.mjs'),source);

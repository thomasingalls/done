from pathlib import Path
import os,subprocess,json,hashlib,shutil
root=Path(__file__).resolve().parent
repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done')
old=Path('/private/tmp/done-non-overlap-20261023-patches')
old_series=json.loads((old/'series.json').read_text());phase54=old_series['phases'][-1]
assert phase54['name']=='54-non-overlapping-device-sessions'
def run(*args,env=None):
 return subprocess.check_output(args,cwd=root,env=env,text=True).strip()
head=run('git','-C',str(repo),'rev-parse','HEAD')
assert head==old_series['baseCommit']=='77669ec79f78779d77e500d0f163c0299156b968'
assert run('git','-C',str(repo),'diff','--cached','--name-only')==''
old_patch=Path(phase54['patch']);assert hashlib.sha256(old_patch.read_bytes()).hexdigest()==phase54['sha256']=='070372f7bdf864bcc784eac6c61f9fa5c83d7fc62d3aa7bedceb284f9f3e35c6'
db=root/'patch-index.git'
if not db.exists():
 run('git','init','--bare',str(db))
 (db/'objects/info/alternates').write_text(str(old/'index.git/objects')+'\n')
git=['git','--git-dir='+str(db),'--work-tree='+str(repo)]
run(*git,'read-tree',phase54['tree'])
paths=['Dockerfile','scripts/test-runtime-image.mjs','docs/public-runtime.md','docs/completed.md','docs/release-validation-graph.json']
run(*git,'add','-A','--',*[str(repo/p) for p in paths])
run(*git,'diff','--cached','--check',phase54['tree'])
tree=run(*git,'write-tree');changed=run(*git,'diff','--cached','--name-only',phase54['tree']).splitlines()
assert sorted(changed)==sorted(paths),(changed,paths)
patches=root/'patches';patches.mkdir(exist_ok=True)
p55=patches/'55-distroless-runtime.patch'
p55.write_bytes(subprocess.check_output([*git,'diff','--cached','--binary','--full-index',phase54['tree']],cwd=root))
p54=patches/old_patch.name;shutil.copyfile(old_patch,p54)
verify_index=root/'patch-verify.index';verify_index.unlink(missing_ok=True)
env={**os.environ,'GIT_INDEX_FILE':str(verify_index)}
run(*git,'read-tree',head,env=env);run(*git,'apply','--cached',str(p54),env=env)
assert run(*git,'write-tree',env=env)==phase54['tree']
run(*git,'apply','--cached',str(p55),env=env);assert run(*git,'write-tree',env=env)==tree
actual_index=root/'actual-checkout.index';actual_index.unlink(missing_ok=True)
actual_env={**os.environ,'GIT_INDEX_FILE':str(actual_index)}
run(*git,'read-tree',head,env=actual_env);run(*git,'add','-A','--',str(repo),env=actual_env)
assert run(*git,'write-tree',env=actual_env)==tree,'Cumulative checkout contains changes outside the sealed patches'
assert run('git','-C',str(repo),'diff','--cached','--name-only')==''
assert run('git','-C',str(repo),'rev-parse','HEAD')==head
r55={'name':'55-distroless-runtime','base':phase54['tree'],'tree':tree,'patch':'patches/'+p55.name,'sha256':hashlib.sha256(p55.read_bytes()).hexdigest(),'paths':paths,'committed':False,'alreadyInCumulativeCheckout':True,'verification':'ARM64 passed; AMD64 blocked by original builder readiness gate under emulation'}
r54={**phase54,'patch':'patches/'+p54.name}
record={'baseCommit':head,'phases':[r54,r55],'realIndexEmpty':True,'sequentialReplayVerified':True,'cumulativeCheckoutTree':tree,'originalPatch54Unchanged':True}
(root/'series.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'patch55':r55,'patch54Sha256':r54['sha256'],'realIndexEmpty':True,'sequentialReplayVerified':True,'cumulativeCheckoutVerified':True},indent=2))

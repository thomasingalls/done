
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {dirname,join} from 'node:path';
import {fileURLToPath} from 'node:url';
const out=dirname(fileURLToPath(import.meta.url)),repo='/Users/thomasingalls/.codex/worktrees/7fda/done';
let source=readFileSync(join(repo,'test/public-backup/worker.test.mjs'),'utf8');
assert(source.includes('    child.stderr.resume();'));
source=source.replace('    child.stderr.resume();',"    child.stderr.on('data', bytes => console.error('CHILD',bytes.toString()));");
assert(source.includes('        const value = await r.json();'));
source=source.replace('        const value = await r.json();',"        const value = await r.json(); console.error('BACKUP_HEALTH', JSON.stringify(value));");
writeFileSync(join(out,'instrumented-worker.test.mjs'),source);

import json, collections, pathlib
root=pathlib.Path(__file__).parent
summary={}
for label in ['baseline','candidate','candidate-patched-age']:
 data=json.loads((root/(label+'-vulnerabilities.json')).read_text())
 counts=collections.Counter(); targets=[]
 for result in data.get('Results',[]):
  vcs=result.get('Vulnerabilities',[]);counts.update(v['Severity'] for v in vcs)
  targets.append({'target':result['Target'],'type':result.get('Type'),'packages':len(result.get('Packages',[])),'counts':dict(collections.Counter(v['Severity'] for v in vcs)),'criticalHigh':[{'id':v['VulnerabilityID'],'package':v['PkgName'],'installed':v['InstalledVersion'],'fixed':v.get('FixedVersion'),'severity':v['Severity']} for v in vcs if v['Severity'] in ['CRITICAL','HIGH']]})
 summary[label]={'artifact':data.get('ArtifactName'),'os':data.get('Metadata',{}).get('OS'),'counts':dict(counts),'targets':targets}
(root/'scan-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for label,data in summary.items():
 print(label,data['counts'])
 for target in data['targets']:
  if target['criticalHigh']: print(target['target'],target['criticalHigh'])

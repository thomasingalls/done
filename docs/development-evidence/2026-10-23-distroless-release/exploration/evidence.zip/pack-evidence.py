from pathlib import Path
import hashlib,json,zipfile
root=Path(__file__).resolve().parent
workspace=root.parents[1]
records=[]
allowed={'.log','.json','.md','.py','.mjs','.diff','.patch','.txt','.tap'}
with zipfile.ZipFile(root/'evidence.zip','w',zipfile.ZIP_DEFLATED) as bundle:
 for p in sorted(root.rglob('*')):
  if not p.is_file() or 'trivy-cache' in p.parts or any(x.endswith('.git') for x in p.parts) or p.suffix not in allowed or p.name=='artifact-index.json': continue
  if 'helpers' in p.parts or 'fixture' in p.parts: raise RuntimeError('Unexpected fixture retained: '+str(p))
  rel=str(p.relative_to(root));data=p.read_bytes()
  bundle.writestr(rel,data);records.append({'path':rel,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 for p in sorted((workspace/'test-results/public-runtime').glob('*/container-smoke.json')):
  rel='smoke-results/'+p.parent.name+'/'+p.name;data=p.read_bytes()
  bundle.writestr(rel,data);records.append({'path':rel,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 metadata=root/'trivy-cache/db/metadata.json'
 if metadata.exists():
  data=metadata.read_bytes();bundle.writestr('scanner-db-metadata.json',data);records.append({'path':'scanner-db-metadata.json','bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 index={'files':records,'note':'No container archives, scanner databases, build trees, private accounts or generated identities retained.'}
 bundle.writestr('artifact-index.json',json.dumps(index,indent=2)+'\n')
(root/'artifact-index.json').write_text(json.dumps(index,indent=2)+'\n')
print(json.dumps({'files':len(records),'archiveBytes':(root/'evidence.zip').stat().st_size,'archiveSha256':hashlib.sha256((root/'evidence.zip').read_bytes()).hexdigest()}))

from pathlib import Path
import json,subprocess,hashlib,difflib,copy
root=Path(__file__).resolve().parent;infra=Path('/Users/thomasingalls/Code/ol-infra')
image=json.loads((root/'image.json').read_text());source=json.loads((root/'source.json').read_text())
path='infra/apps/done/components/runtime/kustomization.yaml'
raw=(infra/path).read_text();base=subprocess.check_output(['git','-C',str(infra),'rev-parse','HEAD'],text=True).strip()
assert raw.encode()==subprocess.check_output(['git','-C',str(infra),'show',base+':'+path])
old=image['compatibleRollback'];new=image['indexDigest']
assert raw.count(old)==1
comment='# Published signed source 51d8550d; exact tested ARM64 index verified 2026-10-23.'
assert raw.count(comment)==1
proposed=raw.replace(old,new).replace(comment,'# Signed source '+source['source'][:8]+'; exact tested ARM64 index verified 2026-10-23.')
def yaml(text):return json.loads(subprocess.check_output(['ruby','-ryaml','-rjson','-e','puts JSON.generate(YAML.safe_load(STDIN.read))'],input=text,text=True))
before=yaml(raw);after=yaml(proposed);expected=copy.deepcopy(before)
assert len(expected['images'])==1 and expected['images'][0]['name']=='ghcr.io/thomasingalls/done'
assert expected['images'][0]['digest']==old
expected['images'][0]['digest']=new;assert after==expected
patch=''.join(difflib.unified_diff(raw.splitlines(keepends=True),proposed.splitlines(keepends=True),fromfile='a/'+path,tofile='b/'+path))
(root/'infra-image-pin.patch').write_text(patch)
subprocess.run(['git','-C',str(infra),'apply','--check',str(root/'infra-image-pin.patch')],check=True)
compat=json.loads((root/'infra-command-compatibility.json').read_text())
for f in compat['files']:assert hashlib.sha256((infra/f['path']).read_bytes()).hexdigest()==f['sha256']
record={'infraRepository':str(infra),'localBaseCommit':base,'scope':'Local preparation only; refresh and review remote base before an infrastructure PR.','paths':[path],'baseFileSha256':hashlib.sha256(raw.encode()).hexdigest(),'proposedFileSha256':hashlib.sha256(proposed.encode()).hexdigest(),'patchSha256':hashlib.sha256(patch.encode()).hexdigest(),'testedSource':source['source'],'currentIndex':old,'proposedIndex':new,'gitApplyCheck':True,'independentYamlEqualityExceptImageDigest':True,'runtimeCommandManifestsMatchFinalImageCompatibilityCheck':True,'applied':False,'published':False,'deployed':False,'activationPrerequisites':['Operator application merge preserving signed commits','Merged build-input equality against tested source','Exact private image publication, remote digest and authenticated pull verification','Fresh infrastructure base and separate operator merge']}
(root/'infra-image-pin-preparation.json').write_text(json.dumps(record,indent=2)+'\n')
print('Prepared and independently checked one-file digest/comment patch; infrastructure remains untouched.')

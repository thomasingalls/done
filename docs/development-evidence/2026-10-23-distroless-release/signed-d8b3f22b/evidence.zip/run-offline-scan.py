from pathlib import Path
import subprocess,json,hashlib
root=Path(__file__).resolve().parent
args=['docker','run','--rm','--pull','never','--network','none','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--memory','2g','--tmpfs','/tmp:rw,noexec,nosuid,size=2g','--mount',f'type=bind,source={root}/candidate-image.tar,target=/analysis/image.tar,readonly','--mount',f'type=bind,source={root}/scanner-cache,target=/cache','aquasec/trivy:0.75.0@sha256:af6acf9a6b85dfe389a1941505c0ce9efef52a4719635e1a962f022a3d855daa','image','--cache-dir','/cache','--skip-db-update','--skip-java-db-update','--offline-scan','--scanners','vuln','--format','json','--input','/analysis/image.tar']
with (root/'vulnerabilities.json').open('w') as out,(root/'scan.log').open('w') as err:
 r=subprocess.run(args,stdout=out,stderr=err,timeout=600)
(root/'scanner-command.json').write_text(json.dumps({'argv':args,'exit':r.returncode,'network':'none','suppression':'none','archiveSha256':hashlib.file_digest((root/'candidate-image.tar').open('rb'),'sha256').hexdigest()},indent=2)+'\n')
assert r.returncode==0,'See retained scan.log'
print('Offline exact-image scan completed without suppressions.')

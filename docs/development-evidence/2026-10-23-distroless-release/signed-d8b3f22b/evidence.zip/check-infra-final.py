from pathlib import Path
import json,subprocess,hashlib
root=Path(__file__).resolve().parent
infra=Path('/Users/thomasingalls/Code/ol-infra')
files=['infra/apps/done/deployment.yaml','infra/apps/done/operations/initialize/job.yaml','infra/apps/done/operations/maintenance/job.yaml']
record={'scope':'Read-only local manifest compatibility, not a live-cluster check or infrastructure change','infraHead':subprocess.check_output(['git','-C',str(infra),'rev-parse','HEAD'],text=True).strip(),'files':[]}
probe_commands=set();init_command=None
for path in files:
 raw=(infra/path).read_bytes()
 doc=json.loads(subprocess.check_output(['ruby','-ryaml','-rjson','-e','puts JSON.generate(YAML.safe_load(File.read(ARGV.fetch(0))))',str(infra/path)],text=True))
 spec=doc['spec']['template']['spec'];commands=[]
 assert spec['nodeSelector']['kubernetes.io/arch']=='arm64'
 for role in ['containers','initContainers']:
  for c in spec.get(role,[]):
   cmd=c.get('command',['node','scripts/public-account.mjs'])+c.get('args',[])
   assert cmd[0]=='node',(path,c['name'],cmd)
   commands.append({'container':c['name'],'command':cmd})
   if c['name']=='prepare-backup-workspace':init_command=cmd
   for probe in ['startupProbe','readinessProbe','livenessProbe']:
    if probe in c:
     p=c[probe]['exec']['command'];assert p[:2]==['node','scripts/public-healthcheck.mjs'];assert p[2] in ['api','app']
     probe_commands.add(tuple(p))
 record['files'].append({'path':path,'sha256':hashlib.sha256(raw).hexdigest(),'commands':commands})
assert init_command and len(probe_commands)==2
r=subprocess.run(['docker','run','--rm','--network','none','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--memory','64m','--tmpfs','/backup-work:rw,noexec,nosuid,size=64m,uid=0,gid=65532,mode=0770','--entrypoint',init_command[0],'done-public:d8b3f22b',*init_command[1:]],text=True,capture_output=True,timeout=30000)
record['backupWorkspaceInitializer']={'exitCode':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'memoryLimit':'64m','fixture':'disposable tmpfs, root-owned/group65532 writable parent'}
assert r.returncode==0,r.stderr
record['probeCommands']=sorted(probe_commands);record['probesExercisedBy']='uninstrumented exact-image smoke'
(root/'infra-command-compatibility.json').write_text(json.dumps(record,indent=2)+'\n');print('All production commands use Node; exact backup-workspace initializer passed with read-only root and64MiB limit.')

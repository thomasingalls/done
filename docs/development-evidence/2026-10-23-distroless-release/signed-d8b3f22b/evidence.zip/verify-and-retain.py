from pathlib import Path
import json,hashlib,re,shutil,subprocess,collections,zipfile
root=Path(__file__).resolve().parent
repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done')
image=json.loads((root/'image.json').read_text());source=json.loads((root/'source.json').read_text())
assert image['source']==source['source']=='d8b3f22b0790770192a809aa8d83064fd42d9804'
assert source['sourceTree']=='fce1eea07e6fd684ac423af436c0c8fe4b766b5b'
assert subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()==source['source']
# The exact signed archive was captured from a clean checkout. During the image
# checks, only this seat's active documentation may differ; build inputs stay pinned.
dirty = subprocess.check_output(['git','-C',str(repo),'status','--porcelain','-uall'],text=True).splitlines()
assert dirty == [' M docs/progress.md'], dirty
assert subprocess.check_output(['git','-C',str(repo),'diff','--name-only',source['source'],'--',*source['inputs']],text=True).strip()==''
for name,manifest in [('frontend','frontend-before.json'),('predecessor-frontend','predecessor-frontend-before.json')]:
 expected=sorted(r['path'] for r in json.loads((root/manifest).read_text()))
 actual=sorted(str(p.relative_to(root/name)) for p in (root/name).rglob('*') if p.is_file())
 assert actual==expected, name
 for record in json.loads((root/manifest).read_text()):
  assert hashlib.sha256((root/name/record['path']).read_bytes()).hexdigest()==record['sha256']
runtime=json.loads((root/'runtime-final/runtime-image-check.json').read_text());assert runtime['ok'] and runtime['imageId']==image['indexDigest']
counts={}
for p in (root/'runtime-final').glob('*.tap'):
 text=p.read_text();passed=int(re.search(r'^# pass (\d+)$',text,re.M)[1]);failed=int(re.search(r'^# fail (\d+)$',text,re.M)[1])
 assert failed==0;counts[p.stem]=passed
assert counts=={'maintenance':6,'backup':5,'runtime-gateway':16,'restore':6}
smoke=list((root/'source/test-results/public-runtime').glob('*/container-smoke.json'));assert len(smoke)==1
smokeRecord=json.loads(smoke[0].read_text());assert smokeRecord['ok'] and not smokeRecord['cleanupFailures']
assert smokeRecord['sourceRevision']==source['source']
shutil.copyfile(smoke[0],root/'container-smoke.json')
assert json.loads((root/'tls/tls-check.json').read_text())['ok']
upgrade=json.loads((root/'upgrade-results.json').read_text());assert upgrade['stats']['expected']==1 and upgrade['stats']['unexpected']==0
scan=json.loads((root/'vulnerabilities.json').read_text())
scanner=json.loads((root/'scanner-command.json').read_text())
assert scanner['exit']==0 and scanner['suppression']=='none' and scanner['network']=='none'
assert scanner['archiveSha256']==image['archiveSha256']
assert scan['ArtifactName']=='/analysis/image.tar'
infra=json.loads((root/'infra-command-compatibility.json').read_text())
assert infra['backupWorkspaceInitializer']['exitCode']==0 and len(infra['files'])==3 and len(infra['probeCommands'])==2
hosted=json.loads((root/'hosted-bookkeeping-status.json').read_text())
assert hosted['headSha']==source['source']
job=next(j for j in hosted['jobs'] if j['name']=='Build and regression gates')
for name in ['Check security contracts and published vectors','Check the complete release inventory','Check release execution adapters']:
 assert next(s for s in job['steps'] if s['name']==name)['conclusion']=='success'
severities=collections.Counter(v['Severity'] for r in scan.get('Results',[]) for v in r.get('Vulnerabilities',[]))
assert severities['CRITICAL']==0 and severities['HIGH']==0
shutil.copyfile(root/'source/test/release-probe/publication-upgrade.spec.ts',root/'publication-upgrade.spec.ts.txt')
record={'status':'ARM64 artifact checks passed; publication is separate','source':source['source'],'tree':source['sourceTree'],'platform':'linux/arm64','image':image,'runtimeCases':counts,'runtimePassed':33,'upgradeRollbackPassed':1,'upgradeBoundary':'Exact predecessor and candidate frontends; candidate host Node24 backend throughout, not predecessor-server rollback. Isolated Chromium contexts, not physical-device checks.','frontendManifestsUnchanged':True,'tlsPassed':True,'smokePassed':True,'existingInfraNodeCommandsCompatible':True,'scan':{k:severities[k] for k in ['CRITICAL','HIGH','MEDIUM','LOW','UNKNOWN']},'priorUnitRun':{'source':'e86bd26cf14e4d396aeccd6613de1be35e9ca7c4','passed':1927,'existingSkipped':1},'priorBrowserRuns':{'initial90':{'passed':79,'failed':11},'affected29':{'passed':26,'failed':3},'finalRemaining3':{'passed':3,'failed':0},'note':'All original failures have passing reruns; not a new single clean90-case run. Original failed attempts and apparatus corrections retained separately.'},'archiveCapturedFromCleanCheckout':True,'activeRecordOnlyDuringVerification':True,'sourcePushed':True,'published':False,'deployed':False,'generalizedQualificationRun':False}
(root/'verification.json').write_text(json.dumps(record,indent=2)+'\n')
names=['source.json','source-prepare.log','image.json','runtime-source-files.json','frontend-before.json','predecessor-frontend-before.json','build-metadata.json','build.log','extract-image.log','runtime-final.log','runtime-final/runtime-image-check.json','container-smoke.json','smoke.log','scan.log','vulnerabilities.json','tls.log','tls/tls-check.json','upgrade.log','upgrade-results.json','upgrade-apparatus.json','prepare-upgrade.log','publication-upgrade.spec.ts.txt','infra-command-compatibility.log','infra-command-compatibility.json','verification.json']
names+=['scanner-database.json','scanner-command.json','hosted-bookkeeping-status.json','infra-image-pin.patch','infra-image-pin-preparation.json','infra-preparation.log']
names+=sorted(str(p.relative_to(root)) for p in (root/'repo-checks').glob('*'))
names+=sorted(str(p.relative_to(root)) for p in root.glob('*.py'))
names+=sorted(str(p.relative_to(root)) for p in root.glob('*.mjs'))
names+=sorted(str(p.relative_to(root)) for p in (root/'runtime-final').glob('*.tap'))
files=[]
for name in sorted(set(names)):
 p=root/name;assert p.is_file() and not p.is_symlink()
 files.append({'path':name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(root/'evidence-index.json').write_text(json.dumps({'files':files,'excluded':'Image/source tar archives remain local. No private keys, service databases, browser profiles or dependency trees are retained in the evidence zip.'},indent=2)+'\n')
with zipfile.ZipFile(root/'evidence.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=1) as archive:
 archive.write(root/'evidence-index.json','evidence-index.json')
 for file in files:archive.write(root/file['path'],file['path'])
print(json.dumps({'source':source['source'],'image':image['indexDigest'],'runtimePassed':33,'upgradePassed':1,'scan':record['scan'],'evidenceSha256':hashlib.sha256((root/'evidence.zip').read_bytes()).hexdigest(),'evidenceBytes':(root/'evidence.zip').stat().st_size,'files':len(files)},indent=2))

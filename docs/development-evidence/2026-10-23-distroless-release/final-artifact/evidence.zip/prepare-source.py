from pathlib import Path
import subprocess,json,tarfile,hashlib,sys
root=Path(__file__).resolve().parent
repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done')
def git(*args):return subprocess.check_output(['git','-C',str(repo),*args],text=True).strip()
assert len(sys.argv)==2,'Expected exact signed source commit'
head=git('rev-parse','HEAD')
assert head==sys.argv[1]
assert git('status','--porcelain')=='','Signed source must have a clean checkout'
assert git('merge-base','--is-ancestor','dcb4e9bb34446dd8b2b5b1889a53b81916df2077',head)==''
commits=[]
refs=git('rev-list','--reverse','77669ec79f78779d77e500d0f163c0299156b968..'+head).splitlines()
for ref in refs:
 result=subprocess.run(['git','-C',str(repo),'verify-commit',ref],capture_output=True,text=True,check=True)
 commits.append({'commit':ref,'tree':git('rev-parse',ref+'^{tree}'),'parent':git('show','-s','--format=%P',ref),'signature':result.stderr.strip()})
inputs=['.dockerignore','Dockerfile','package.json','pnpm-lock.yaml','pnpm-workspace.yaml','vite.config.ts','index.html','local.html','account-service','account-protocol','src','public','private','vite','scripts','test','vendor-patches','relay/src/auth.ts','wasm/journal-seal/seal.generated.ts']
tracked=git('ls-tree','--name-only',head).splitlines()
inputs+=sorted(p for p in tracked if p.startswith('playwright') and p.endswith('.config.ts'))
inputs+=sorted(p for p in tracked if p.startswith('tsconfig') and p.endswith('.json'))
archive=root/'source.tar'
with archive.open('wb') as stream:subprocess.run(['git','-C',str(repo),'archive','--format=tar',head,'--',*inputs],stdout=stream,check=True)
context=root/'source';context.mkdir(exist_ok=False)
with tarfile.open(archive) as tar:
 for m in tar.getmembers():
  assert not m.name.startswith('/') and '..' not in Path(m.name).parts
  assert not Path(m.name).name.startswith('.env')
  assert not m.issym() and not m.islnk(),'Unexpected source symlink'
 tar.extractall(context,filter='data')
record={'source':head,'sourceTree':git('rev-parse','HEAD^{tree}'),'sourceDate':git('show','-s','--format=%cs',head),'sourceCommitDate':git('show','-s','--format=%cI',head),'signedCommits':commits,'archiveSha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archiveBytes':archive.stat().st_size,'inputs':inputs,'platform':'linux/arm64','candidateTag':'done-public:'+head[:8],'featureOverrides':{},'published':False,'deployed':False}
(root/'source.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))

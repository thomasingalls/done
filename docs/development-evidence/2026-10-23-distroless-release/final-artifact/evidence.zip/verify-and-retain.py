from pathlib import Path
import json,hashlib,re,shutil,subprocess,collections,zipfile
root=Path(__file__).resolve().parent
repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done')
image=json.loads((root/'image.json').read_text());source=json.loads((root/'source.json').read_text())
assert image['source']==source['source']=='d1c2784bef0ccc3ea88d99dfd82f1db3a83af384'
assert source['sourceTree']=='647e606a9c02f09d478bb1b313bd2a940d94968b'
assert subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()==source['source']
assert subprocess.check_output(['git','-C',str(repo),'status','--porcelain'],text=True).strip()==''
for name,manifest in [('frontend','frontend-before.json'),('predecessor-frontend','predecessor-frontend-before.json')]:
 for record in json.loads((root/manifest).read_text()):
  assert hashlib.sha256((root/name/record['path']).read_bytes()).hexdigest()==record['sha256']
runtime=json.loads((root/'runtime-final/runtime-image-check.json').read_text());assert runtime['ok'] and runtime['imageId']==image['indexDigest']
counts={}
for p in (root/'runtime-final').glob('*.tap'):
 text=p.read_text();passed=int(re.search(r'^# pass (\d+)$',text,re.M)[1]);failed=int(re.search(r'^# fail (\d+)$',text,re.M)[1])
 assert failed==0;counts[p.stem]=passed
assert sum(counts.values())==33
smoke=list((root/'source/test-results/public-runtime').glob('*/container-smoke.json'));assert len(smoke)==1
smokeRecord=json.loads(smoke[0].read_text());assert smokeRecord['ok'] and not smokeRecord['cleanupFailures']
assert smokeRecord['sourceRevision']==source['source']
shutil.copyfile(smoke[0],root/'container-smoke.json')
assert json.loads((root/'tls/tls-check.json').read_text())['ok']
upgrade=json.loads((root/'upgrade-results.json').read_text());assert upgrade['stats']['expected']==1 and upgrade['stats']['unexpected']==0
scan=json.loads((root/'vulnerabilities.json').read_text())
severities=collections.Counter(v['Severity'] for r in scan.get('Results',[]) for v in r.get('Vulnerabilities',[]))
assert severities['CRITICAL']==0 and severities['HIGH']==0
shutil.copyfile(root/'source/test/release-probe/publication-upgrade.spec.ts',root/'publication-upgrade.spec.ts.txt')
record={'status':'ARM64 artifact checks passed; publication is separate','source':source['source'],'tree':source['sourceTree'],'platform':'linux/arm64','image':image,'runtimeCases':counts,'runtimePassed':33,'upgradeRollbackPassed':1,'upgradeBoundary':'Exact predecessor and candidate frontends; candidate host Node24 backend throughout, not predecessor-server rollback. Isolated Chromium contexts, not physical-device checks.','frontendManifestsUnchanged':True,'tlsPassed':True,'smokePassed':True,'existingInfraNodeCommandsCompatible':True,'scan':{k:severities[k] for k in ['CRITICAL','HIGH','MEDIUM','LOW','UNKNOWN']},'priorUnitRun':{'source':'e86bd26cf14e4d396aeccd6613de1be35e9ca7c4','passed':1927,'existingSkipped':1},'priorBrowserRuns':{'initial90':{'passed':79,'failed':11},'affected29':{'passed':26,'failed':3},'finalRemaining3':{'passed':3,'failed':0},'note':'All original failures have passing reruns; not a new single clean90-case run. Original failed attempts and apparatus corrections retained separately.'},'checkoutClean':True,'pushed':False,'published':False,'deployed':False,'generalizedQualificationRun':False}
(root/'verification.json').write_text(json.dumps(record,indent=2)+'\n')
names=['source.json','source-prepare.log','image.json','runtime-source-files.json','frontend-before.json','predecessor-frontend-before.json','build-metadata.json','build.log','extract-image.log','runtime-final.log','runtime-final/runtime-image-check.json','container-smoke.json','smoke.log','scan.log','vulnerabilities.json','tls.log','tls/tls-check.json','upgrade.log','upgrade-results.json','upgrade-apparatus.json','prepare-upgrade.log','publication-upgrade.spec.ts.txt','infra-command-compatibility.log','infra-command-compatibility.json','verification.json']
names+=sorted(str(p.relative_to(root)) for p in root.glob('*.py'))
names+=sorted(str(p.relative_to(root)) for p in root.glob('*.mjs'))
names+=sorted(str(p.relative_to(root)) for p in (root/'runtime-final').glob('*.tap'))
files=[]
for name in sorted(set(names)):
 p=root/name;assert p.is_file() and not p.is_symlink()
 files.append({'path':name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(root/'evidence-index.json').write_text(json.dumps({'files':files,'excluded':'Image/source tar archives remain local. No private keys, service databases, browser profiles or dependency trees are retained in the evidence zip.'},indent=2)+'\n')
with zipfile.ZipFile(root/'evidence.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=1) as archive:
 archive.write(root/'evidence-index.json','evidence-index.json')
 for file in files:archive.write(root/file['path'],file['path'])
print(json.dumps({'source':source['source'],'image':image['indexDigest'],'runtimePassed':33,'upgradePassed':1,'scan':record['scan'],'evidenceSha256':hashlib.sha256((root/'evidence.zip').read_bytes()).hexdigest(),'evidenceBytes':(root/'evidence.zip').stat().st_size,'files':len(files)},indent=2))

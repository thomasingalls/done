from pathlib import Path
import os,subprocess,json,hashlib
root=Path(__file__).resolve().parent;repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');db=root/'followup-index.git'
series=json.loads((root/'followup-series.json').read_text());git=['git','--git-dir='+str(db),'--work-tree='+str(repo)]
def run(*args,env=None):return subprocess.check_output(args,cwd=root,env=env,text=True).strip()
index=root/'followup-verify.index';index.unlink(missing_ok=True);env={**os.environ,'GIT_INDEX_FILE':str(index)}
run(*git,'read-tree',series['baseCommit'],env=env)
for p in series['phases']:
 patch=root/p['patch'];assert hashlib.sha256(patch.read_bytes()).hexdigest()==p['sha256']
 run(*git,'apply','--cached',str(patch),env=env);assert run(*git,'write-tree',env=env)==p['tree']
actual=root/'followup-actual.index';actual.unlink(missing_ok=True);ae={**os.environ,'GIT_INDEX_FILE':str(actual)}
run(*git,'read-tree',series['baseCommit'],env=ae);run(*git,'add','-A','--',str(repo),env=ae)
assert run(*git,'write-tree',env=ae)==series['phases'][-1]['tree']
assert run('git','-C',str(repo),'diff','--cached','--name-only')==''
assert run('git','-C',str(repo),'rev-parse','HEAD')==series['baseCommit']
receipt={'baseCommit':series['baseCommit'],'finalTree':series['phases'][-1]['tree'],'sequentialReplay':True,'matchesCumulativeCheckout':True,'realIndexEmpty':True,'phases':series['phases']}
(root/'followup-verification.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))

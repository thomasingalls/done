from pathlib import Path
import shutil,json,hashlib
root=Path(__file__).resolve().parent
copy=root/'fixture-check';source=root/'source'
records=[]
for path in sorted(source.iterdir()):
 if path.name in ['node_modules','dist','test'] or path.name.startswith('playwright.release'):continue
 target=copy/path.name
 if target.is_symlink():target.unlink()
 elif target.exists():continue
 if path.is_dir():shutil.copytree(path,target)
 else:shutil.copyfile(path,target)
 for file in ([target] if target.is_file() else target.rglob('*')):
  if file.is_file():
   relative=file.relative_to(copy);assert file.read_bytes()==(source/relative).read_bytes()
   records.append({'path':str(relative),'sha256':hashlib.sha256(file.read_bytes()).hexdigest()})
gateway=copy/'scripts/lib/account-gateway.mjs'
gateway.write_bytes(Path('/Users/thomasingalls/.codex/worktrees/7fda/done/scripts/lib/account-gateway.mjs').read_bytes())
(root/'fixture-build-inputs.json').write_text(json.dumps({'buildInputs':records,'runtimeGateway':'dcb4e9bb signed','gatewaySha256':hashlib.sha256(gateway.read_bytes()).hexdigest(),'reason':'Restore complete regular-file build topology; HTML symlinks emitted invalid outside-root asset paths.','frontend':'unchanged e86 image dist; successor is intentionally rebuilt by existing update tests.'},indent=2)+'\n')
config=(copy/'playwright.last-fixtures.config.ts').read_text().replace('last-fixtures','last-fixtures-complete')
(copy/'playwright.last-fixtures-complete.config.ts').write_text(config)

from pathlib import Path
import json,shutil,hashlib
root=Path(__file__).resolve().parent;source=root/'source';repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');copy=root/'fixture-check';copy.mkdir()
for name in ['account-service','account-protocol','src','scripts','node_modules','dist']:(copy/name).symlink_to(source/name,target_is_directory=True)
for name in ['package.json','tsconfig.json','tsconfig.app.json','tsconfig.node.json']:(copy/name).symlink_to(source/name)
shutil.copytree(source/'test',copy/'test')
paths=['test/packaged-account/account-creation-entry.spec.ts','test/packaged-account/membership-connection.spec.ts']
for name in paths:shutil.copyfile(repo/name,copy/name)
server=copy/'test/packaged-account/server.ts';before=server.read_text();after=before.replace("'53221'","'53225'").replace("'53222'","'53226'");assert before!=after;server.write_text(after)
config="import {defineConfig} from '@playwright/test';\nexport default defineConfig("+json.dumps({'testDir':str(copy/'test/packaged-account'),'testMatch':['account-creation-entry.spec.ts','membership-connection.spec.ts'],'outputDir':str(root/'fixture-check-artifacts'),'timeout':120000,'workers':1,'retries':0,'reporter':[['list'],['json',{'outputFile':str(root/'fixture-check-results.json')}]],'use':{'baseURL':'http://localhost:53225','viewport':{'width':1280,'height':900},'launchOptions':{'executablePath':'/Users/thomasingalls/Library/Caches/ms-playwright/chromium-1234/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'}}},indent=2)+");\n"
(copy/'playwright.fixture.config.ts').write_text(config)
(root/'fixture-check-inputs.json').write_text(json.dumps({'runtimeSource':'signed e86bd26c; unchanged scripts/service/protocol/frontend','files':[{'path':p,'sha256':hashlib.sha256((copy/p).read_bytes()).hexdigest()} for p in paths],'testOnlyPorts':[53225,53226],'serverOriginalSha256':hashlib.sha256(before.encode()).hexdigest(),'serverCopySha256':hashlib.sha256(after.encode()).hexdigest()},indent=2)+'\n')

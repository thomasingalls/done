from pathlib import Path
import json
root=Path(__file__).resolve().parent
source=root/'source'
deps=Path('/Users/thomasingalls/.codex/worktrees/7fda/done/node_modules')
assert deps.is_dir()
assert (source/'pnpm-lock.yaml').read_bytes()==Path('/Users/thomasingalls/.codex/worktrees/7fda/done/pnpm-lock.yaml').read_bytes()
(source/'node_modules').symlink_to(deps,target_is_directory=True)
browser=Path('/Users/thomasingalls/Library/Caches/ms-playwright/chromium-1234/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing')
assert browser.is_file()
config="import {defineConfig} from '@playwright/test';\\n".replace('\\n','\n')
config+="export default defineConfig("+json.dumps({'testDir':str(source/'test/packaged-account'),'outputDir':str(root/'browser-artifacts'),'timeout':120000,'workers':1,'retries':0,'reporter':[['list'],['json',{'outputFile':str(root/'browser-results.json')}]],'use':{'baseURL':'http://localhost:53221','viewport':{'width':1280,'height':900},'launchOptions':{'executablePath':str(browser)}}},indent=2)+");\n"
(source/'playwright.release.config.ts').write_text(config)
print('Frozen lockfile matches installed dependency owner; disposable source test apparatus prepared.')

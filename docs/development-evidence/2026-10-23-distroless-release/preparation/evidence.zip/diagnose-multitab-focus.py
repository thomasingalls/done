from pathlib import Path
root=Path(__file__).resolve().parent
copy=root/'fixture-check'
original=(root/'source/test/device-enrollment/helpers.ts').read_text()
(copy/'test/device-enrollment/helpers.ts').write_text(original)
test=(root/'source/test/packaged-account/multi-tab-protection.spec.ts').read_text()
needle="      await page.getByRole('button', { name: 'Create passkey', exact: true }).click();"
assert test.count(needle)==1
test=test.replace(needle,"      await page.bringToFront();\n"+needle)
(copy/'test/packaged-account/multi-tab-protection.spec.ts').write_text(test)
config=(copy/'playwright.multitab-diagnose.config.ts').read_text().replace('multitab-diagnostic','multitab-focus-control')
(copy/'playwright.multitab-focus-control.config.ts').write_text(config)

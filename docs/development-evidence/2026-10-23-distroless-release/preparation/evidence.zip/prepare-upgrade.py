from pathlib import Path
import json,subprocess,hashlib,uuid
root=Path(__file__).resolve().parent;repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done')
source=json.loads((root/'source.json').read_text());head=source['source'];old='51d8550d30585c93e623af0f2b3adf610781eebb'
probe=root/'source/test/release-probe';probe.mkdir()
records=[]
for path in ['test/packaged-account/devices.ts','test/device-enrollment/helpers.ts']:
 data=subprocess.check_output(['git','-C',str(repo),'show',old+':'+path]);out=probe/'legacy'/path;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(data)
 records.append({'source':old,'path':path,'sha256':hashlib.sha256(data).hexdigest()})
original=subprocess.check_output(['git','-C',str(repo),'show',head+':docs/development-evidence/2026-10-23-signed-sync-artifact/upgrade-probe/publication-upgrade.spec.ts.txt'],text=True)
text=original.replace("from './publication-legacy-devices'","from './legacy/test/packaged-account/devices'").replace("from './devices'","from '../packaged-account/devices'").replace("from './server'","from '../packaged-account/server'")
text="import { openMenuSection } from '../geometry/openApp';\n"+text
text=text.replace("'faf465f7'","'__PREDECESSOR__'").replace("'51d8550d'",repr(head[:8])).replace("'__PREDECESSOR__'","'51d8550d'")
lock="await d.page.getByRole('button', { name: 'Lock workspace', exact: true }).click();"
assert text.count(lock)==2
text=text.replace(lock,"await openMenuSection(d.page, 'Account');\n      "+lock)
assert text.count('await expect(version(d.page))')==2
text=text.replace('await expect(version(d.page))',"await openMenuSection(d.page, 'Account');\n      await expect(version(d.page))")
(probe/'publication-upgrade.spec.ts').write_text(text)
record={'predecessor':old,'candidate':head,'legacyHelpers':records,'probeOriginalSha256':hashlib.sha256(original.encode()).hexdigest(),'probeSha256':hashlib.sha256(text.encode()).hexdigest(),'changes':'version identities, exact historical helper paths, and open collapsed Account before reading Version/Lock; all existing assertions retained','serverBoundary':'candidate host Node24 backend throughout; not predecessor-server rollback'}
(root/'upgrade-apparatus.json').write_text(json.dumps(record,indent=2)+'\n')
name='done-predecessor-extract-'+uuid.uuid4().hex
subprocess.run(['docker','create','--name',name,'done-public:51d8550d'],capture_output=True,check=True)
try:subprocess.run(['docker','cp',name+':/app/dist',str(root/'predecessor-frontend')],capture_output=True,check=True)
finally:subprocess.run(['docker','rm',name],capture_output=True,check=True)
front=[]
for file in sorted((root/'predecessor-frontend').rglob('*')):
 if file.is_file():front.append({'path':str(file.relative_to(root/'predecessor-frontend')),'sha256':hashlib.sha256(file.read_bytes()).hexdigest()})
(root/'predecessor-frontend-before.json').write_text(json.dumps(front,indent=2)+'\n')
config="import {defineConfig} from '@playwright/test';\nexport default defineConfig("+json.dumps({'testDir':str(probe),'outputDir':str(root/'upgrade-artifacts'),'timeout':180000,'workers':1,'retries':0,'reporter':[['list'],['json',{'outputFile':str(root/'upgrade-results.json')}]],'use':{'baseURL':'http://localhost:53221','viewport':{'width':1280,'height':900},'launchOptions':{'executablePath':'/Users/thomasingalls/Library/Caches/ms-playwright/chromium-1234/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'}}},indent=2)+");\n"
(root/'source/playwright.release-upgrade.config.ts').write_text(config)
print('Prepared predecessor51d8550d → signed candidate → predecessor → candidate rehearsal; original safety assertions retained.')

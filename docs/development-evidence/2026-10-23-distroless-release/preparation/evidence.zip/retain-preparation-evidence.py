from pathlib import Path
import json,hashlib,zipfile
root=Path(__file__).resolve().parent
names=[
 'source.json','source-prepare.log','image.json','runtime-source-files.json','frontend-before.json',
 'build-metadata.json','build.log','vitest.log','vitest-results.json','vitest-final.log','vitest-final-results.json',
 'browser.log','browser-results.json','browser-list.log','fixture-check.log','fixture-check-results.json','fixture-check-inputs.json',
 'multitab-diagnostic.log','multitab-diagnostic-results.json','multitab-focus-control.log','multitab-focus-control-results.json',
 'affected-browser.log','affected-browser-results.json','affected-browser-inputs.json','last-fixtures.log','last-fixtures-results.json',
 'last-fixtures-complete.log','last-fixtures-complete-results.json','fixture-build-inputs.json',
 'gateway-regression-baseline.tap','gateway-regression-fixed-final.tap','gateway-signed-57.tap',
 'gateway-idle-probe.json','gateway-idle-probe.log','image-preconnect-probe.json','image-preconnect-probe.log',
 'followup-series.json','followup-verification.json','followup-verification.log','followup-build.log','followup-format.log','followup-lint.log',
 'runtime-final.log','followup-runtime.log','native-sessions.tap','native-sessions-final.tap','smoke.log','tls.log','tls-final.log',
 'scan.log','vulnerabilities.json','infra-command-compatibility.json','infra-command-compatibility.log',
 '56-release-browser-fixtures.patch','57-gateway-unrequested-sockets.patch','58-browser-shell-focus-fixtures.patch','58-verification.json',
 'tls/tls-check.json','runtime-final/runtime-image-check.json','followup-runtime/runtime-image-check.json'
]
names+=sorted(str(p.relative_to(root)) for p in root.glob('*.py'))
names+=sorted(str(p.relative_to(root)) for p in root.glob('*.mjs'))
for folder in ['runtime-final','followup-runtime']:
 names+=sorted(str(p.relative_to(root)) for p in (root/folder).glob('*.tap'))
names=sorted(set(names))
records=[]
for name in names:
 path=root/name
 assert path.is_file(),name
 assert not path.is_symlink(),name
 assert path.stat().st_size<20_000_000,name
 records.append({'path':name,'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
manifest={'purpose':'Retain original failed attempts, discriminating controls and passing reruns before final signed ARM64 image rebuild. No private profiles, keys, service databases, dependencies, source tar or image tar included.','files':records,'initialBrowser':{'passed':79,'failed':11},'affectedFiles':{'passed':26,'failed':3},'finalRemaining':{'passed':3,'failed':0},'unit':{'passed':1927,'existingSkipped':1},'published':False,'deployed':False}
(root/'preparation-evidence-index.json').write_text(json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(root/'preparation-evidence.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=1) as archive:
 archive.write(root/'preparation-evidence-index.json','preparation-evidence-index.json')
 for name in names:archive.write(root/name,name)
print(json.dumps({'files':len(records),'bytes':(root/'preparation-evidence.zip').stat().st_size,'sha256':hashlib.sha256((root/'preparation-evidence.zip').read_bytes()).hexdigest()}))

from pathlib import Path
import subprocess,json,os,hashlib,sys
root=Path(__file__).resolve().parent;repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');db=root/'followup-index.git'
node='/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node'
def run(*args,env=None):return subprocess.check_output(args,cwd=root,env=env,text=True).strip()
head=run('git','-C',str(repo),'rev-parse','HEAD');assert head=='e86bd26cf14e4d396aeccd6613de1be35e9ca7c4'
assert run('git','-C',str(repo),'diff','--cached','--name-only')==''
name=sys.argv[1]
if not db.exists():
 run('git','init','--bare',str(db));objects=run('git','-C',str(repo),'rev-parse','--git-path','objects');objects=str((repo/objects).resolve()) if not objects.startswith('/') else objects
 (db/'objects/info/alternates').write_text(objects+'\n')
series_path=root/'followup-series.json';series=json.loads(series_path.read_text()) if series_path.exists() else {'baseCommit':head,'phases':[]}
base=series['phases'][-1]['tree'] if series['phases'] else head
paths={'56-release-browser-fixtures':['test/packaged-account/account-creation-entry.spec.ts','test/packaged-account/membership-connection.spec.ts','docs/completed.md','docs/release-validation-graph.json'],'57-gateway-unrequested-sockets':['scripts/lib/account-gateway.mjs','test/account-application/gateway.test.mjs','docs/completed.md','docs/release-validation-graph.json']}[name]
saved={}
try:
 if name.startswith('56-'):
  for p in ['scripts/lib/account-gateway.mjs','test/account-application/gateway.test.mjs']:
   saved[p]=(repo/p).read_bytes();(repo/p).write_bytes(subprocess.check_output(['git','-C',str(repo),'show',head+':'+p]))
 run(node,str(repo/'scripts/release-validation/check.mjs'),'--record')
 git=['git','--git-dir='+str(db),'--work-tree='+str(repo)]
 run(*git,'read-tree',base);run(*git,'add','-A','--',*[str(repo/p) for p in paths]);run(*git,'diff','--cached','--check',base)
 tree=run(*git,'write-tree');patch=root/(name+'.patch');patch.write_bytes(subprocess.check_output([*git,'diff','--cached','--binary','--full-index',base],cwd=root))
 record={'name':name,'base':base,'tree':tree,'patch':patch.name,'sha256':hashlib.sha256(patch.read_bytes()).hexdigest(),'paths':paths,'committed':False,'alreadyInCumulativeCheckout':True}
 series['phases'].append(record);series_path.write_text(json.dumps(series,indent=2)+'\n');print(json.dumps(record,indent=2))
finally:
 for p,data in saved.items():(repo/p).write_bytes(data)


import {startAccountGateway} from './source/scripts/lib/account-gateway.mjs';
import {createServer} from 'node:http';
import {connect} from 'node:net';
import {once} from 'node:events';
import {setTimeout as delay} from 'node:timers/promises';
import {writeFileSync} from 'node:fs';
const backend=createServer((req,res)=>res.end('ok'));backend.listen(0,'127.0.0.1');await once(backend,'listening');
const app=await startAccountGateway({port:0,origin:'http://localhost:4999',servicePort:backend.address().port,packaged:new URL('./frontend',import.meta.url).pathname});
const socket=connect(app.port,'127.0.0.1');await once(socket,'connect');await delay(25);
let timer,closed=false;const start=performance.now();
try{await Promise.race([app.close().then(()=>{closed=true}),new Promise(resolve=>{timer=setTimeout(resolve,1000)})]);}
finally{clearTimeout(timer);socket.destroy();await app.close();await new Promise(r=>backend.close(r));}
writeFileSync(new URL('./gateway-idle-probe.json',import.meta.url),JSON.stringify({idleSocketCloseWithin1s:closed,elapsedMs:performance.now()-start,scope:'diagnostic preconnected socket only; no source changes'},null,2)+'\n');

from pathlib import Path
import os,subprocess,json,hashlib
root=Path(__file__).resolve().parent
repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done')
base='dcb4e9bb34446dd8b2b5b1889a53b81916df2077'
patch=root/'58-browser-shell-focus-fixtures.patch'
assert hashlib.sha256(patch.read_bytes()).hexdigest()=='77e66a0610f0f98025434b37801f54fe60e7382e4a3b2073efd966731347d395'
git=['git','--git-dir='+str(root/'followup-index.git'),'--work-tree='+str(repo)]
def run(*args,env=None):return subprocess.check_output(args,cwd=root,env=env,text=True).strip()
index=root/'58-verify.index';index.unlink(missing_ok=True);env={**os.environ,'GIT_INDEX_FILE':str(index)}
run(*git,'read-tree',base,env=env);run(*git,'apply','--cached',str(patch),env=env)
tree=run(*git,'write-tree',env=env)
actual=root/'58-actual.index';actual.unlink(missing_ok=True);ae={**os.environ,'GIT_INDEX_FILE':str(actual)}
run(*git,'read-tree',base,env=ae);run(*git,'add','-A','--',str(repo),env=ae)
assert run(*git,'write-tree',env=ae)==tree
assert run('git','-C',str(repo),'rev-parse','HEAD')==base
assert run('git','-C',str(repo),'diff','--cached','--name-only')==''
record={'phase':58,'base':base,'patch':patch.name,'sha256':hashlib.sha256(patch.read_bytes()).hexdigest(),'tree':tree,'matchesCumulativeCheckout':True,'realIndexEmpty':True,'signed':False,'published':False,'deployed':False}
(root/'58-verification.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))

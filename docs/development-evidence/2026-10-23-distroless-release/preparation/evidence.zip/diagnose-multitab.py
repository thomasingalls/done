from pathlib import Path
import json
root=Path(__file__).resolve().parent;copy=root/'fixture-check'
original=(root/'source/test/device-enrollment/helpers.ts').read_text()
needle="  const cdp = await page.context().newCDPSession(page);"
assert original.count(needle)==1
observe="""  await page.addInitScript(() => {
    const create = navigator.credentials.create.bind(navigator.credentials);
    navigator.credentials.create = async (options) => {
      console.log('CREDENTIAL_ENV', JSON.stringify({focus:document.hasFocus(),visibility:document.visibilityState,activation:navigator.userActivation.isActive}));
      return create(options);
    };
  });
  page.on('console', message => { if(message.text().startsWith('CREDENTIAL_ENV')) console.log(message.text()); });
"""
(copy/'test/device-enrollment/helpers.ts').write_text(original.replace(needle,observe+needle))
config="import {defineConfig} from '@playwright/test';\nexport default defineConfig("+json.dumps({'testDir':str(copy/'test/packaged-account'),'testMatch':['multi-tab-protection.spec.ts'],'outputDir':str(root/'multitab-diagnostic-artifacts'),'timeout':120000,'workers':1,'retries':0,'reporter':[['list'],['json',{'outputFile':str(root/'multitab-diagnostic-results.json')}]],'use':{'baseURL':'http://localhost:53225','viewport':{'width':1280,'height':900},'launchOptions':{'executablePath':'/Users/thomasingalls/Library/Caches/ms-playwright/chromium-1234/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'}}},indent=2)+");\n"
(copy/'playwright.multitab-diagnose.config.ts').write_text(config)

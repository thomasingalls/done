from pathlib import Path
import json,shutil
root=Path(__file__).resolve().parent
copy=root/'fixture-check'
# Run the signed/staged gateway repair; all frontend, protocol and account sources stay at e86.
scripts=copy/'scripts'
assert scripts.is_symlink()
scripts.unlink()
scripts.symlink_to('/Users/thomasingalls/.codex/worktrees/7fda/done/scripts',target_is_directory=True)
changes={
 'passkey-local-access.spec.ts':("async function syncSetup(page: Page, first = true) {","async function syncSetup(page: Page, first = true) {\n  await expect(page.locator('.shell')).toBeVisible();"),
 'missed-rotations.spec.ts':("    const connect = async (owner: Page, code: string, joining: Page) => {","    const connect = async (owner: Page, code: string, joining: Page) => {\n      await expect(owner.locator('.shell')).toBeVisible();"),
 'updates.spec.ts':("    await page.reload();\n    await openMenuSection(page, 'Account');","    await page.reload();\n    await expect(page.locator('.shell')).toBeVisible();\n    await openMenuSection(page, 'Account');"),
}
for name,(before,after) in changes.items():
 text=(root/'source/test/packaged-account'/name).read_text()
 assert text.count(before)==1,name
 (copy/'test/packaged-account'/name).write_text(text.replace(before,after))
failures=[]
def walk(suite):
 for spec in suite.get('specs',[]):
  if any(t.get('status')=='unexpected' for t in spec.get('tests',[])):
   failures.append((spec['file'],spec['title']))
 for child in suite.get('suites',[]):walk(child)
for suite in json.loads((root/'browser-results.json').read_text())['suites']:walk(suite)
assert len(failures)==11
config=json.dumps({
 'testDir':str(copy/'test/packaged-account'),
 'testMatch':sorted(set(Path(f).name for f,t in failures)),
 'outputDir':str(root/'affected-browser-artifacts'),
 'timeout':120000,'workers':1,'retries':0,
 'reporter':[['list'],['json',{'outputFile':str(root/'affected-browser-results.json')}]],
 'use':{'baseURL':'http://localhost:53225','viewport':{'width':1280,'height':900},'launchOptions':{'executablePath':'/Users/thomasingalls/Library/Caches/ms-playwright/chromium-1234/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'}}
},indent=2)
(copy/'playwright.affected.config.ts').write_text("import {defineConfig} from '@playwright/test';\nexport default defineConfig("+config+");\n")
(root/'affected-browser-inputs.json').write_text(json.dumps({'previousFailures':failures,'runtimeGateway':'workspace patch57 staged tree b280bfd37b0b564177df703317e5e3b2ce969696','frontend':'e86bd26c exact image frontend','testChanges':'approved56 plus four proposed narrow phase58 fixtures','allAssertionsAndDeadlinesRetained':True},indent=2)+'\n')
print(json.dumps(failures))

from pathlib import Path
import shutil,json
root=Path(__file__).resolve().parent
copy=root/'fixture-check';source=root/'source'
repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done')
for name in ['index.html','local.html','vite.config.ts','vite','public','private','wasm','vendor-patches']:
 assert not (copy/name).exists(),name
 (copy/name).symlink_to(source/name,target_is_directory=(source/name).is_dir())
shutil.copyfile(repo/'test/packaged-account/missed-rotations.spec.ts',copy/'test/packaged-account/missed-rotations.spec.ts')
config=(copy/'playwright.affected.config.ts').read_text()
start=config.index('  "testMatch": [');end=config.index('  ],',start)+4
config=config[:start]+'  "testMatch": ["missed-rotations.spec.ts","updates.spec.ts"],'+config[end:]
config=config.replace('affected-browser','last-fixtures')
(copy/'playwright.last-fixtures.config.ts').write_text(config)

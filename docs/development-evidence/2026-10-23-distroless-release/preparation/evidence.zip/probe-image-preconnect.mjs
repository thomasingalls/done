
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {writeFileSync} from 'node:fs';
const probe=async()=>{
 const {startAccountGateway}=await import('/app/scripts/lib/account-gateway.mjs');
 const {createServer,get}=await import('node:http');
 const {connect}=await import('node:net');const {once}=await import('node:events');
 const backend=createServer((req,res)=>res.end('ok'));backend.listen(0,'127.0.0.1');await once(backend,'listening');
 const app=await startAccountGateway({port:0,origin:'http://localhost:4999',servicePort:backend.address().port,packaged:'/app/dist',health:true});
 const socket=connect(app.port,'127.0.0.1');await once(socket,'connect');
 await new Promise((resolve,reject)=>get({host:'127.0.0.1',port:app.port,path:'/healthz',agent:false},res=>{res.resume();res.on('end',resolve)}).on('error',reject));
 let closed=false,timer;const began=performance.now();const closing=app.close().then(()=>closed=true);
 await Promise.race([closing,new Promise(r=>{timer=setTimeout(r,300)})]);clearTimeout(timer);
 const result={idleSocketClosedBeforeDeadline:closed,observedMs:performance.now()-began,socketStillOpen:!socket.destroyed};
 socket.destroy();await closing;await new Promise(r=>backend.close(r));result.closedAfterExplicitClientCleanup=closed;
 console.log(JSON.stringify(result));
};
const r=spawnSync('docker',['run','--rm','--read-only','--network','none','--cap-drop','ALL','--security-opt','no-new-privileges','--entrypoint','node','done-public:e86bd26c','--input-type=module','-e','('+probe.toString()+')()'],{encoding:'utf8',timeout:10000});
assert.ifError(r.error);assert.equal(r.status,0,r.stderr);
const result=JSON.parse(r.stdout.trim());writeFileSync(new URL('./image-preconnect-probe.json',import.meta.url),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));

from pathlib import Path
import subprocess,json,tarfile,hashlib
root=Path(__file__).resolve().parent;repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done')
head=json.loads((root/'source.json').read_text())['source']
inputs=['docs/account-crypto/first-authority.json','docs/storage-conformance.md']
archive=root/'unit-fixtures.tar'
with archive.open('wb') as stream:subprocess.run(['git','-C',str(repo),'archive','--format=tar',head,'--',*inputs],stdout=stream,check=True)
with tarfile.open(archive) as tar:tar.extractall(root/'source',filter='data')
record={'source':head,'scope':'test-only normative fixtures excluded from Docker build context; no old test changes','inputs':inputs,'archiveSha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':[{'path':p,'sha256':hashlib.sha256((root/'source'/p).read_bytes()).hexdigest()} for p in inputs]}
(root/'unit-fixtures.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))

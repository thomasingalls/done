# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: lifecycle-owner.spec.ts >> Reduced owners survive initial handoff, two rotations, replacement, restart and detached editing
- Location: test/local-baseline/lifecycle-owner.spec.ts:127:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "applying"
Received: "pending"

Call Log:
- Timeout 20000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- main [ref=f5e4]:
  - generic:
    - complementary:
      - generic: done
      - generic: Today
      - generic: Yesterday
      - generic: Tomorrow
      - generic: Your space, at your pace.
    - generic:
      - generic: Today
      - generic:
        - generic:
          - generic:
            - text: Next
            - generic: 2 / 3
          - generic:
            - generic:
              - generic: Make a little room for the big idea
              - generic:
                - text: Done
                - generic: Later
            - generic:
              - generic: Take the long way home
              - generic:
                - text: Done
                - generic: Later
        - generic:
          - generic: Done
          - generic:
            - generic: Got the idea out of my head
            - generic: Sent the message I was putting off
            - generic: Made time for a walk
          - generic:
            - text: What got done?
            - generic: +
    - complementary:
      - generic: Goals
      - generic:
        - strong: A little space for everything
        - generic: Ideas, plans, loose ends.
        - generic: Things to come back to.
        - strong: Make something of my own
        - generic: Write down the spark
        - generic: Find one small place to start
        - generic: Share a first draft
        - strong: Outside of work
        - generic: Learn to make really good bread
        - generic: Plan a weekend with no plans
        - generic: More dinners with friends
  - region [ref=f5e5]:
    - text: done
    - heading "Your Workspace" [level=1] [ref=f5e6]
    - paragraph [ref=f5e7]: Everything on your mind. One thing at a time.
    - generic [ref=f5e8]:
      - button "Create a workspace" [ref=f5e9] [cursor=pointer]
      - button "Create a local-only workspace" [ref=f5e10] [cursor=pointer]
    - button "I already have a workspace" [ref=f5e11] [cursor=pointer]
```

# Test source

```ts
  256 |     await expect(third.locator('.shell')).toContainText('Offline survivor writing after removal');
  257 |     await expect(page.locator('.shell')).toContainText('Offline survivor writing after removal', {
  258 |       timeout: 20000,
  259 |     });
  260 |     await add(page, 'Survivor generation two travels after passive activation');
  261 |     await expect(third.locator('.shell')).toContainText(
  262 |       'Survivor generation two travels after passive activation',
  263 |       { timeout: 20000 },
  264 |     );
  265 |     await add(third, 'Passive survivor replies with generation two');
  266 |     await expect(page.locator('.shell')).toContainText(
  267 |       'Passive survivor replies with generation two',
  268 |       { timeout: 20000 },
  269 |     );
  270 |     for (const [p, code, joining] of [
  271 |       [page, pair.first.code, false],
  272 |       [third, next.code, true],
  273 |     ] as const) {
  274 |       await p.getByRole('button', { name: 'Lock workspace', exact: true }).click();
  275 |       await p.goto('/');
  276 |       await openSaved(p, code, joining);
  277 |       await expect(p.locator('.shell')).toContainText(
  278 |         'Passive survivor replies with generation two',
  279 |       );
  280 |       await expect(p.locator('.workspace-status')).toHaveCount(0);
  281 |     }
  282 |     for (const p of [page, third]) {
  283 |       await anchor(p, 2);
  284 |       if (readerActive) continue;
  285 |       await expect
  286 |         .poll(
  287 |           () =>
  288 |             p.evaluate(async (reduced) => {
  289 |               const owner = (globalThis as unknown as { __baselineOwner: Owner }).__baselineOwner;
  290 |               try {
  291 |                 return reduced
  292 |                   ? await owner.removeLocalHistory(2)
  293 |                   : await owner.replaceLocalBaseline(2);
  294 |               } catch (error) {
  295 |                 // Retention retires old network flights. A durability barrier may observe that
  296 |                 // pre-commit refusal; only retry while admission is still active.
  297 |                 if (
  298 |                   error instanceof Error &&
  299 |                   error.message === 'Receive authority was superseded' &&
  300 |                   owner.workspace.status.state === 'active'
  301 |                 )
  302 |                   return { kind: 'retired-flight' };
  303 |                 throw error;
  304 |               }
  305 |             }, reduced),
  306 |           { timeout: 15000 },
  307 |         )
  308 |         .toEqual({ kind: reduced ? 'already-removed' : 'already-installed' });
  309 |     }
  310 |     // A second removal keeps the generation-two opener while its replacement pointer is pending.
  311 |     await third.getByRole('button', { name: 'Lock workspace', exact: true }).click();
  312 |     await third.goto('/');
  313 |     await third.evaluate(chunk.code);
  314 |     const secondTarget = await third.evaluate(
  315 |       async (code) =>
  316 |         window.MembershipCustody.participant(
  317 |           'joined',
  318 |           await window.MembershipCustody.accountSlot(),
  319 |           code,
  320 |         ),
  321 |       next.code,
  322 |     );
  323 |     await openSaved(third, next.code, true);
  324 |     await thirdContext.setOffline(true);
  325 |     await add(third, 'Second removed device keeps its offline generation-two writing');
  326 |     await page.getByRole('button', { name: 'Lock workspace', exact: true }).click();
  327 |     await page.goto('/');
  328 |     await page.evaluate(chunk.code);
  329 |     const laterArgs = { slot, code: pair.first.code, target: secondTarget };
  330 |     const laterJournal = await page.evaluate(
  331 |       ({ slot, code }) => window.MembershipCustody.journalOnly('promotion', slot, code),
  332 |       laterArgs,
  333 |     );
  334 |     let later = await page.evaluate(
  335 |       ({ slot, code, target }) =>
  336 |         window.MembershipCustody.removal('promotion', slot, code, target, true),
  337 |       laterArgs,
  338 |     );
  339 |     expect(later.result).toBe('pending');
  340 |     expect(later.after.previous).toHaveLength(1);
  341 |     expect(later.after.previous![0]!.generation).toBe(2);
  342 |     await page.reload();
  343 |     await page.evaluate(chunk.code);
  344 |     await expect
  345 |       .poll(
  346 |         async () => {
  347 |           later = await page.evaluate(
  348 |             ({ slot, code, target }) =>
  349 |               window.MembershipCustody.removal('promotion', slot, code, target),
  350 |             laterArgs,
  351 |           );
  352 |           return later.result;
  353 |         },
  354 |         { timeout: 20000, intervals: [2000] },
  355 |       )
> 356 |       .toBe('applying');
      |        ^ Error: expect(received).toBe(expected) // Object.is equality
  357 |     expect(later.after.successor!.epoch.generation).toBe(3);
  358 |     expect(
  359 |       await page.evaluate(
  360 |         ({ slot, code }) => window.MembershipCustody.activateRemoval('promotion', slot, code, true),
  361 |         laterArgs,
  362 |       ),
  363 |     ).toEqual({ generation: 0, head: 'interrupted' });
  364 |     await page.reload();
  365 |     await page.evaluate(chunk.code);
  366 |     expect(
  367 |       await page.evaluate(
  368 |         ({ slot, code }) => window.MembershipCustody.activateRemoval('promotion', slot, code),
  369 |         laterArgs,
  370 |       ),
  371 |     ).toEqual({ generation: 3, head: later.after.successor!.head });
  372 |     expect(await page.evaluate((key) => localStorage.getItem(key), laterJournal)).toBeNull();
  373 |     await page.goto('/');
  374 |     await openSaved(page, pair.first.code);
  375 |     await add(page, 'Generation three survives two rotations');
  376 |     await page.getByRole('button', { name: 'Lock workspace', exact: true }).click();
  377 |     await page.goto('/');
  378 |     await openSaved(page, pair.first.code);
  379 |     await expect(page.locator('.shell')).toContainText('Generation three survives two rotations');
  380 |     await thirdContext.setOffline(false);
  381 |     await expect(third.locator('.shell')).toHaveCount(0, { timeout: 25000 });
  382 |     await third.goto('/');
  383 |     await openSaved(third, next.code, true);
  384 |     await expect(third.getByText('Removed from account.', { exact: false })).toBeVisible();
  385 |     await expect(third.locator('.shell')).toContainText(
  386 |       'Second removed device keeps its offline generation-two writing',
  387 |     );
  388 |     await expect(third.locator('.shell')).not.toContainText(
  389 |       'Generation three survives two rotations',
  390 |     );
  391 |     await add(third, 'Detached generation two can still edit');
  392 |     await third.getByRole('button', { name: 'Lock workspace', exact: true }).click();
  393 |     await third.goto('/');
  394 |     await openSaved(third, next.code, true);
  395 |     await expect(third.locator('.shell')).toContainText('Detached generation two can still edit');
  396 |     const networkWrites: string[] = [];
  397 |     pair.second.on('request', (r) => {
  398 |       if (r.url().includes('/account/delivery/') || r.url().includes('/notifications/'))
  399 |         networkWrites.push(r.url());
  400 |     });
  401 |     await pair.second.goto('/');
  402 |     await openSaved(pair.second, pair.next.code, true);
  403 |     await expect(pair.second.locator('.shell')).toContainText(
  404 |       'Writing before this device is removed',
  405 |     );
  406 |     await expect(pair.second.locator('.shell')).not.toContainText(
  407 |       'Survivor generation two travels after passive activation',
  408 |     );
  409 |     await expect(pair.second.getByText('Removed from account.', { exact: false })).toBeVisible();
  410 |     await add(pair.second, 'Writing retained only in this detached copy');
  411 |     await pair.second.getByRole('button', { name: 'Lock workspace', exact: true }).click();
  412 |     await pair.second.goto('/');
  413 |     await openSaved(pair.second, pair.next.code, true);
  414 |     await expect(pair.second.locator('.shell')).toContainText(
  415 |       'Writing retained only in this detached copy',
  416 |     );
  417 |     for (const p of [page, pair.second, third]) {
  418 |       await p.evaluate(() =>
  419 |         (
  420 |           globalThis as unknown as { __baselineOwner: Owner }
  421 |         ).__baselineOwner.workspace.whenDurable(),
  422 |       );
  423 |       expect(
  424 |         await p.evaluate(
  425 |           () =>
  426 |             (globalThis as unknown as { __baselineOwner: Owner }).__baselineOwner.workspace.status
  427 |               .state,
  428 |         ),
  429 |       ).toBe('active');
  430 |     }
  431 |     expect(networkWrites).toEqual([]);
  432 |     await expect(page.locator('.shell')).not.toContainText(
  433 |       'Writing retained only in this detached copy',
  434 |     );
  435 |     if (process.env['ACCOUNT_BASELINE_READ'] === '1')
  436 |       expect([...observed].sort()).toEqual([
  437 |         'catchup',
  438 |         'detached',
  439 |         'membership-source',
  440 |         'prospective',
  441 |         'rebase',
  442 |         'rotation',
  443 |         'rotation-journal',
  444 |       ]);
  445 |   } finally {
  446 |     for (const p of [pair?.second, third])
  447 |       if (p && !p.isClosed())
  448 |         console.log(
  449 |           'Secondary messages',
  450 |           await p.locator('[role=alert], [role=status]').allTextContents(),
  451 |         );
  452 |     await pair?.other.close();
  453 |     await thirdContext.close();
  454 |     await stopService(service);
  455 |   }
  456 | });
```
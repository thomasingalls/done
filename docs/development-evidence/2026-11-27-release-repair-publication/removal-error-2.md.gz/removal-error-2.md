# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: removal-regressions.spec.ts >> a delayed registration reply cannot recreate removed setup after Start fresh
- Location: test/packaged-account/removal-regressions.spec.ts:6:3

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: locator('[role=alert]')
Expected substring: "retired"
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toContainText" with timeout 5000ms
  - waiting for locator('[role=alert]')

```

```yaml
- main:
  - region "Locking and finishing storage operations…":
    - text: done
    - button "Back"
    - heading "Locking and finishing storage operations…" [level=1]
    - status: Your writing stays in this workspace.
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | import { openApp, protectApp, openMenuSection } from '../geometry/openApp';
  3  | import { startService, stopService } from './server';
  4  | 
  5  | for (const freshBeforeReply of [false, true])
  6  |   test(`a delayed registration reply cannot recreate removed setup${freshBeforeReply ? ' after Start fresh' : ''}`, async ({
  7  |     page,
  8  |     context,
  9  |   }, info) => {
  10 |     const service = await startService(info.outputPath('service'), undefined, true, true);
  11 |     let release!: () => void, received!: () => void;
  12 |     const held = new Promise<void>((yes) => {
  13 |       release = yes;
  14 |     });
  15 |     const waiting = new Promise<void>((yes) => {
  16 |       received = yes;
  17 |     });
  18 |     try {
  19 |       // Simulate a suspended setup coordinator which misses the cooperative retirement notice.
  20 |       // The durable epoch fence must work independently of BroadcastChannel delivery.
  21 |       await page.addInitScript(() => {
  22 |         const RealChannel = BroadcastChannel;
  23 |         window.BroadcastChannel = class extends RealChannel {
  24 |           constructor(name: string) {
  25 |             super(name);
  26 |             if (name === 'done/slot-lifecycle')
  27 |               this.addEventListener('message', (event) => event.stopImmediatePropagation());
  28 |           }
  29 |         };
  30 |       });
  31 |       await openApp(page);
  32 |       await protectApp(page);
  33 |       await page.route('**/__account-setup/begin', async (route) => {
  34 |         const response = await route.fetch();
  35 |         received();
  36 |         await held;
  37 |         await route.fulfill({ response });
  38 |       });
  39 |       await openMenuSection(page, 'Sync');
  40 |       await page.getByRole('button', { name: 'Set up sync', exact: true }).click();
  41 |       await page.getByRole('button', { name: 'Sync this list', exact: true }).click();
  42 |       await page.getByRole('button', { name: 'Continue to passkey setup', exact: true }).click();
  43 |       await waiting;
  44 |       const removal = await context.newPage();
  45 |       await removal.goto('/remove/local');
  46 |       await removal.getByRole('button', { name: 'Continue to confirmation' }).click();
  47 |       await removal.getByLabel('Type REMOVE to confirm').fill('REMOVE');
  48 |       await removal.getByRole('button', { name: 'Remove local data', exact: true }).click();
  49 |       await expect(
  50 |         removal.getByRole('heading', { name: 'Removed from this device' }),
  51 |       ).toBeVisible();
  52 |       if (freshBeforeReply) {
  53 |         await removal.getByRole('button', { name: 'Start fresh', exact: true }).click();
  54 |         await expect(removal.locator('.shell')).toBeVisible();
  55 |       }
  56 |       release();
> 57 |       await expect(page.locator('[role=alert]')).toContainText(
     |                                                  ^ Error: expect(locator).toContainText(expected) failed
  58 |         freshBeforeReply ? 'retired' : 'removed',
  59 |       );
  60 |       expect(
  61 |         await removal.evaluate(
  62 |           () =>
  63 |             new Promise<unknown>((resolve, reject) => {
  64 |               const r = indexedDB.open('done.first-device-setup.v1');
  65 |               r.onerror = () => reject(r.error);
  66 |               r.onsuccess = () => {
  67 |                 const db = r.result,
  68 |                   tx = db.transaction('attempt'),
  69 |                   row = tx.objectStore('attempt').get('current');
  70 |                 tx.oncomplete = () => {
  71 |                   db.close();
  72 |                   resolve(row.result ?? null);
  73 |                 };
  74 |                 tx.onabort = () => {
  75 |                   db.close();
  76 |                   reject(tx.error);
  77 |                 };
  78 |               };
  79 |             }),
  80 |         ),
  81 |       ).toBeNull();
  82 |       await removal.close();
  83 |     } finally {
  84 |       release();
  85 |       await stopService(service);
  86 |     }
  87 |   });
  88 | 
```
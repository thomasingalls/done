# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: removal-checkpoint.spec.ts >> reduced original and joined owners exchange/undo writing, refuse an unfinished checkpoint cut, then retain its installation through another cut and cold open
- Location: test/local-baseline/removal-checkpoint.spec.ts:34:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 2
Received: 1

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=f1e4]:
  - complementary "Menu" [ref=f1e5]:
    - generic [ref=f1e6]:
      - heading "Day" [level=2] [ref=f1e7]
      - paragraph [ref=f1e8]: Tue 13 Oct 2026
      - generic [ref=f1e9]:
        - button "Tue 6 Oct" [ref=f1e10] [cursor=pointer]
        - button "Sun 11 Oct" [ref=f1e11] [cursor=pointer]
        - button "Yesterday" [ref=f1e12] [cursor=pointer]
        - button "Today" [ref=f1e13] [cursor=pointer]
        - button "Tomorrow" [ref=f1e14] [cursor=pointer]
        - button "Thu 15 Oct" [ref=f1e15] [cursor=pointer]
        - button "Tue 20 Oct" [ref=f1e16] [cursor=pointer]
      - generic [ref=f1e17]:
        - text: Go to date
        - textbox "Go to date" [ref=f1e18]: 2026-10-13
    - generic [ref=f1e19]:
      - heading "Storage" [level=2] [ref=f1e20]
      - generic [ref=f1e21]:
        - generic [ref=f1e22]: Local data
        - generic [ref=f1e23]: Best-effort
      - paragraph [ref=f1e24]: Writing is encrypted in this browser. Export a readable backup when you need one.
      - button "Export markdown" [ref=f1e25] [cursor=pointer]
      - button "Lock workspace" [ref=f1e26] [cursor=pointer]
      - generic [ref=f1e27]:
        - button "Undo" [ref=f1e28] [cursor=pointer]
        - button "Redo" [disabled] [ref=f1e29] [cursor=pointer]
    - generic [ref=f1e30]:
      - heading "Account" [level=2] [ref=f1e31]
      - generic [ref=f1e32]:
        - generic [ref=f1e33]: Name
        - generic [ref=f1e34]: Device owner
      - generic [ref=f1e35]:
        - generic [ref=f1e36]: Account ID
        - code [ref=f1e37]: i9XDHzngZGdCDgE6X0avyNybsot-GDLqS5DsIcMBv94
      - complementary "Sync status" [ref=f1e38]:
        - generic [ref=f1e39]:
          - paragraph [ref=f1e40]: "Sending: idle"
          - paragraph [ref=f1e41]: "Last accepted upload: 11:11:35 PM"
          - paragraph [ref=f1e42]: "Accepted position: 5"
        - generic [ref=f1e43]:
          - paragraph [ref=f1e44]: "Receiving: retrying"
          - paragraph [ref=f1e45]: "Last successful receive check: 11:11:36 PM"
          - paragraph [ref=f1e46]: "Received positions: 9"
          - paragraph [ref=f1e47]:
            - text: "Reason:"
            - code [ref=f1e48]: receive:network-unavailable
          - button "Retry receiving" [ref=f1e49] [cursor=pointer]
      - button "Devices" [ref=f1e50] [cursor=pointer]
      - button "History maintenance" [expanded] [ref=f1e51] [cursor=pointer]
      - region "History maintenance" [ref=f1e52]:
        - paragraph [ref=f1e53]: Save a verified encrypted snapshot of your account’s writing. If another approved device exists, use this action there too to verify it.
        - paragraph [ref=f1e54]: After two snapshots are verified, you can remove older covered encrypted history from the service. The two latest snapshots and their remaining updates are kept.
        - status [ref=f1e55]: Verified snapshot 1 is saved.
        - button "Check history" [ref=f1e56] [cursor=pointer]
        - button "Create history snapshot" [ref=f1e57] [cursor=pointer]
      - button "Use another account" [ref=f1e58] [cursor=pointer]
      - status [ref=f1e59]: Account login remembered on this device.
      - button "Sign out" [ref=f1e60] [cursor=pointer]
    - generic [ref=f1e61]:
      - heading "Identity and preferences" [level=2] [ref=f1e62]
      - generic [ref=f1e63]:
        - generic [ref=f1e64]: Actor
        - generic [ref=f1e65]: Device owner
      - generic [ref=f1e67]:
        - generic [ref=f1e68]: Version
        - generic [ref=f1e69]: f75a19e7
      - generic [ref=f1e70]:
        - generic [ref=f1e71]:
          - generic [ref=f1e72]: Device
          - textbox "Device name" [ref=f1e73]: This device
        - generic [ref=f1e74]:
          - generic [ref=f1e75]: Name
          - textbox "Actor name" [ref=f1e76]: Device owner
        - generic [ref=f1e77]:
          - generic [ref=f1e78]: Color
          - textbox "Actor color" [ref=f1e79]: "#e0662f"
        - generic [ref=f1e80]:
          - generic [ref=f1e81]: Day rollover
          - combobox "Day rollover hour" [ref=f1e82]:
            - option "00:00" [selected]
            - option "01:00"
            - option "02:00"
            - option "03:00"
            - option "04:00"
            - option "05:00"
            - option "06:00"
            - option "07:00"
            - option "08:00"
            - option "09:00"
            - option "10:00"
            - option "11:00"
            - option "12:00"
            - option "13:00"
            - option "14:00"
            - option "15:00"
            - option "16:00"
            - option "17:00"
            - option "18:00"
            - option "19:00"
            - option "20:00"
            - option "21:00"
            - option "22:00"
            - option "23:00"
        - button "Save preferences" [ref=f1e83] [cursor=pointer]
    - generic [ref=f1e84]:
      - heading "Install" [level=2] [ref=f1e85]
      - paragraph [ref=f1e86]: If the install button does not appear, use Install app in your browser menu.
  - complementary [ref=f1e87]:
    - generic [ref=f1e88]:
      - heading [level=2] [ref=f1e89]: Unfiled
      - generic [ref=f1e90]: "0"
      - button [ref=f1e91] [cursor=pointer]: Close
    - paragraph [ref=f1e93]: These cards were retained because their original collection can no longer display them. Choose a new home or remove them explicitly.
  - button "Close unfiled cards"
  - main "Days" [ref=f1e95]:
    - generic:
      - button "Go to Yesterday" [ref=f1e96] [cursor=pointer]
      - button "Go to Tomorrow" [ref=f1e97] [cursor=pointer]
    - generic [ref=f1e98]:
      - region:
        - generic:
          - heading [level=1]: Mon 12 Oct
          - button: Today
        - generic:
          - generic:
            - heading [level=2]:
              - generic: Next
              - generic: 0/3
            - paragraph: Empty.
          - generic:
            - heading [level=2]:
              - generic: Done
            - paragraph: Nothing yet.
            - generic:
              - textbox:
                - /placeholder: What got done?
              - button [disabled]: Add
      - region "Today" [ref=f1e99]:
        - heading "Tue 13 Oct" [level=1] [ref=f1e101]
        - generic [ref=f1e102]:
          - generic [ref=f1e103]:
            - heading "Next 0 of 3" [level=2] [ref=f1e104]:
              - generic [ref=f1e105]: Next
              - generic "0 of 3" [ref=f1e106]: 0/3
            - paragraph [ref=f1e107]: Empty.
          - generic [ref=f1e108]:
            - heading "Done" [level=2] [ref=f1e109]
            - generic [ref=f1e111]:
              - article [ref=f1e112]:
                - generic "Local writing while history waits — press Enter to unlock" [ref=f1e113]: Local writing while history waits
                - generic [ref=f1e115]:
                  - button "Reorder Local writing while history waits" [ref=f1e116]
                  - button "Unlock" [ref=f1e119] [cursor=pointer]
                  - 'button "Remove this card: Local writing while history waits" [ref=f1e120] [cursor=pointer]': Remove
              - article [ref=f1e121]:
                - generic "Remote writing during history inspection — press Enter to unlock" [ref=f1e122]: Remote writing during history inspection
                - generic [ref=f1e124]:
                  - button "Reorder Remote writing during history inspection" [ref=f1e125]
                  - button "Unlock" [ref=f1e128] [cursor=pointer]
                  - 'button "Remove this card: Remote writing during history inspection" [ref=f1e129] [cursor=pointer]': Remove
              - article [ref=f1e130]:
                - generic "Joined writing after actual removal — press Enter to unlock" [ref=f1e131]: Joined writing after actual removal
                - generic [ref=f1e133]:
                  - button "Reorder Joined writing after actual removal" [ref=f1e134]
                  - button "Unlock" [ref=f1e137] [cursor=pointer]
                  - 'button "Remove this card: Joined writing after actual removal" [ref=f1e138] [cursor=pointer]': Remove
              - article [ref=f1e139]:
                - generic "Original writing after actual removal — press Enter to unlock" [ref=f1e140]: Original writing after actual removal
                - generic [ref=f1e142]:
                  - button "Reorder Original writing after actual removal" [ref=f1e143]
                  - button "Unlock" [ref=f1e146] [cursor=pointer]
                  - 'button "Remove this card: Original writing after actual removal" [ref=f1e147] [cursor=pointer]': Remove
              - article [ref=f1e148]:
                - generic "Keep the first device writing — press Enter to unlock" [ref=f1e149]: Keep the first device writing
                - generic [ref=f1e151]:
                  - button "Reorder Keep the first device writing" [ref=f1e152]
                  - button "Unlock" [ref=f1e155] [cursor=pointer]
                  - 'button "Remove this card: Keep the first device writing" [ref=f1e156] [cursor=pointer]': Remove
            - generic [ref=f1e157]:
              - textbox "What got done?" [active] [ref=f1e158]
              - button "Add" [disabled] [ref=f1e159]
      - region:
        - generic:
          - heading [level=1]: Wed 14 Oct
          - button: Today
        - generic:
          - generic:
            - heading [level=2]:
              - generic: Next
              - generic: 0/3
            - paragraph: Empty.
          - generic:
            - heading [level=2]:
              - generic: Done
            - paragraph: Nothing yet.
            - generic:
              - textbox:
                - /placeholder: What got done?
              - button [disabled]: Add
  - complementary "Goals" [ref=f1e160]:
    - heading [level=2] [ref=f1e162]:
      - button "Goals. Open document outline" [ref=f1e163] [cursor=pointer]:
        - generic [ref=f1e164]: Goals
    - generic [ref=f1e169]:
      - status
      - textbox [ref=f1e172]:
        - generic [ref=f1e173]: Everything. Tasks, projects, someday-maybes, notes to self.
    - group "Selected lines" [ref=f1e175]:
      - generic [ref=f1e176]:
        - group "Transfer selected lines" [ref=f1e177]:
          - generic [ref=f1e179] [cursor=pointer]:
            - radio "Copy to" [checked] [ref=f1e180]
            - generic: Copy to
          - generic [ref=f1e181] [cursor=pointer]:
            - radio "Move to" [ref=f1e182]
            - generic: Move to
        - button "More Goals actions" [ref=f1e184] [cursor=pointer]
      - generic [ref=f1e189]:
        - button "Next" [disabled] [ref=f1e190]
        - button "Scheduled" [disabled] [ref=f1e191]
        - button "Done" [disabled] [ref=f1e192]
```

# Test source

```ts
  22  |           at,
  23  |           at +
  24  |             '\n        if (globalThis.__historyBeforeApply) await globalThis.__historyBeforeApply(updates.length);',
  25  |         );
  26  |       }
  27  |       if (id.endsWith('/src/crdt/historyReceiveFence.ts')) {
  28  |         hits.add('drain');
  29  |         return insert(
  30  |           code,
  31  |           '    await whenDurable();',
  32  |           `
  33  |           if (globalThis.__historyWaiting) globalThis.__historyWaiting();
  34  |           await whenDurable();
  35  |           if (globalThis.__historyAfterDrain) await globalThis.__historyAfterDrain();`,
  36  |         );
  37  |       }
  38  |       if (id.endsWith('/src/crdt/accountReceive.ts')) {
  39  |         hits.add('guard');
  40  |         const at = 'if (pendingPromotions) throw new HistoryReceivePending();';
  41  |         return insert(
  42  |           code,
  43  |           at,
  44  |           'globalThis.__historyPending?.push(pendingPromotions);\n' +
  45  |             (process.env['HISTORY_HANDOFF_CONTROL'] === 'omit-pending-check' ? '' : at),
  46  |         );
  47  |       }
  48  |       return undefined;
  49  |     },
  50  |     buildEnd(error) {
  51  |       if (!error && hits.size !== 3) throw Error('Missing history handoff control');
  52  |     },
  53  |   };
  54  | }
  55  | interface Hooks {
  56  |   __historyBeforeApply?: (count: number) => Promise<void> | void;
  57  |   __historyAfterDrain?: () => Promise<void>;
  58  |   __historyWaiting?: () => void;
  59  |   __historyReleaseApply?: () => void;
  60  |   __historyReleaseDrain?: () => void;
  61  |   __historyHit?: number;
  62  |   __historyDrainHit?: boolean;
  63  |   __historyWaits?: number;
  64  |   __historyPending?: number[];
  65  |   __retentionOwner: {
  66  |     workspace: {
  67  |       status: { state: string };
  68  |       command(c: { kind: 'undo' | 'redo' }): { accepted: Promise<unknown> };
  69  |     };
  70  |   };
  71  | }
  72  | export async function historyDuringReceive(first: Page, second: Page) {
  73  |   const panel = second.getByRole('region', { name: 'History maintenance', exact: true });
  74  |   const check = panel.getByRole('button', { name: 'Check history', exact: true });
  75  |   for (const mode of ['empty', 'content', 'late'] as const) {
  76  |     await second.evaluate((mode) => {
  77  |       const g = globalThis as unknown as Hooks;
  78  |       delete g.__historyHit;
  79  |       g.__historyDrainHit = false;
  80  |       g.__historyWaits = 0;
  81  |       g.__historyPending = [];
  82  |       g.__historyWaiting = () => {
  83  |         g.__historyWaits!++;
  84  |       };
  85  |       if (mode === 'late')
  86  |         g.__historyAfterDrain = () =>
  87  |           new Promise<void>((resolve) => {
  88  |             g.__historyDrainHit = true;
  89  |             g.__historyReleaseDrain = () => {
  90  |               delete g.__historyAfterDrain;
  91  |               resolve();
  92  |             };
  93  |           });
  94  |       g.__historyBeforeApply = (count) => {
  95  |         if ((mode === 'content') !== count > 0) return;
  96  |         return new Promise<void>((resolve) => {
  97  |           g.__historyHit = count;
  98  |           g.__historyReleaseApply = () => {
  99  |             delete g.__historyBeforeApply;
  100 |             resolve();
  101 |           };
  102 |         });
  103 |       };
  104 |     }, mode);
  105 |     if (mode === 'late') {
  106 |       await check.click();
  107 |       await second.waitForFunction(() => (globalThis as unknown as Hooks).__historyDrainHit);
  108 |     }
  109 |     if (mode === 'content') await add(first, 'Remote writing during history inspection');
  110 |     await second.evaluate(() => globalThis.dispatchEvent(new Event('online')));
  111 |     await second.waitForFunction(() => (globalThis as unknown as Hooks).__historyHit !== undefined);
  112 |     if (mode === 'content') {
  113 |       await expect(second.locator('.shell')).not.toContainText(
  114 |         'Remote writing during history inspection',
  115 |       );
  116 |       await add(second, 'Local writing while history waits');
  117 |     }
  118 |     if (mode === 'late') {
  119 |       await second.evaluate(() => (globalThis as unknown as Hooks).__historyReleaseDrain!());
  120 |       await expect
  121 |         .poll(() => second.evaluate(() => (globalThis as unknown as Hooks).__historyWaits))
> 122 |         .toBe(2);
      |          ^ Error: expect(received).toBe(expected) // Object.is equality
  123 |       expect(
  124 |         await second.evaluate(() => (globalThis as unknown as Hooks).__historyPending),
  125 |       ).toEqual([1]);
  126 |     } else {
  127 |       await check.click();
  128 |       await second.waitForFunction(() => (globalThis as unknown as Hooks).__historyWaits! >= 1);
  129 |       expect(
  130 |         await second.evaluate(() => (globalThis as unknown as Hooks).__historyPending),
  131 |       ).toEqual([]);
  132 |     }
  133 |     await expect(check).toBeDisabled();
  134 |     await second.evaluate(() => (globalThis as unknown as Hooks).__historyReleaseApply!());
  135 |     await expect(check).toBeEnabled();
  136 |     await expect(panel).toContainText('Verified snapshot 1 is saved.');
  137 |     expect(
  138 |       await second.evaluate(
  139 |         () => (globalThis as unknown as Hooks).__retentionOwner.workspace.status.state,
  140 |       ),
  141 |     ).toBe('active');
  142 |     expect(
  143 |       (await second.evaluate(() => (globalThis as unknown as Hooks).__historyPending))!.at(-1),
  144 |     ).toBe(0);
  145 |     if (mode === 'content') {
  146 |       await expect(second.locator('.shell')).toContainText(
  147 |         'Remote writing during history inspection',
  148 |       );
  149 |       await second.evaluate(
  150 |         () =>
  151 |           (globalThis as unknown as Hooks).__retentionOwner.workspace.command({ kind: 'undo' })
  152 |             .accepted,
  153 |       );
  154 |       await expect(second.locator('.shell')).not.toContainText('Local writing while history waits');
  155 |       await expect(second.locator('.shell')).toContainText(
  156 |         'Remote writing during history inspection',
  157 |       );
  158 |       await second.evaluate(
  159 |         () =>
  160 |           (globalThis as unknown as Hooks).__retentionOwner.workspace.command({ kind: 'redo' })
  161 |             .accepted,
  162 |       );
  163 |       await expect(first.locator('.shell')).toContainText('Local writing while history waits');
  164 |     }
  165 |     console.log('History receive ordering passed:', mode);
  166 |     await second.evaluate(() => {
  167 |       const g = globalThis as unknown as Hooks;
  168 |       delete g.__historyWaiting;
  169 |       delete g.__historyPending;
  170 |     });
  171 |   }
  172 | }
  173 | 
```
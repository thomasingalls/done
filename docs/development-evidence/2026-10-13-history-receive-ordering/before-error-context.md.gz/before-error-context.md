# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: removal-diagnostic.spec.ts >> reduced original and joined owners exchange/undo writing, refuse an unfinished checkpoint cut, then retain its installation through another cut and cold open
- Location: test/local-baseline/removal-diagnostic.spec.ts:34:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "active"
Received: "closed"
```

# Page snapshot

```yaml
- generic [ref=f1e4]:
  - complementary "Menu" [ref=f1e5]:
    - generic [ref=f1e6]:
      - heading "Day" [level=2] [ref=f1e7]
      - paragraph [ref=f1e8]: Tue 13 Oct 2026
      - generic [ref=f1e9]:
        - button "Tue 6 Oct" [ref=f1e10] [cursor=pointer]
        - button "Sun 11 Oct" [ref=f1e11] [cursor=pointer]
        - button "Yesterday" [ref=f1e12] [cursor=pointer]
        - button "Today" [ref=f1e13] [cursor=pointer]
        - button "Tomorrow" [ref=f1e14] [cursor=pointer]
        - button "Thu 15 Oct" [ref=f1e15] [cursor=pointer]
        - button "Tue 20 Oct" [ref=f1e16] [cursor=pointer]
      - generic [ref=f1e17]:
        - text: Go to date
        - textbox "Go to date" [ref=f1e18]: 2026-10-13
    - generic [ref=f1e19]:
      - heading "Storage" [level=2] [ref=f1e20]
      - generic [ref=f1e21]:
        - generic [ref=f1e22]: Local data
        - generic [ref=f1e23]: Best-effort
      - paragraph [ref=f1e24]: Writing is encrypted in this browser. Export a readable backup when you need one.
      - button "Export markdown" [ref=f1e25] [cursor=pointer]
      - button "Lock workspace" [ref=f1e26] [cursor=pointer]
      - generic [ref=f1e27]:
        - button "Undo" [disabled] [ref=f1e28] [cursor=pointer]
        - button "Redo" [disabled] [ref=f1e29] [cursor=pointer]
    - generic [ref=f1e30]:
      - heading "Account" [level=2] [ref=f1e31]
      - generic [ref=f1e32]:
        - generic [ref=f1e33]: Name
        - generic [ref=f1e34]: Device owner
      - generic [ref=f1e35]:
        - generic [ref=f1e36]: Account ID
        - code [ref=f1e37]: 49HrNAq3O2K8gXSljnl-hbd4Xfyc2gukIudAXW4ERNQ
      - complementary "Sync status" [ref=f1e38]:
        - generic [ref=f1e39]:
          - paragraph [ref=f1e40]: "Sending: idle"
          - paragraph [ref=f1e41]: "Last accepted upload: None since opening"
          - paragraph [ref=f1e42]: "Accepted position: 4"
        - generic [ref=f1e43]:
          - paragraph [ref=f1e44]: "Receiving: working"
          - paragraph [ref=f1e45]: "Last successful receive check: 11:02:18 PM"
          - paragraph [ref=f1e46]: "Received positions: 7"
      - button "Devices" [ref=f1e47] [cursor=pointer]
      - button "History maintenance" [expanded] [ref=f1e48] [cursor=pointer]
      - region "History maintenance" [ref=f1e49]:
        - paragraph [ref=f1e50]: Save a verified encrypted snapshot of your account’s writing. If another approved device exists, use this action there too to verify it.
        - paragraph [ref=f1e51]: After two snapshots are verified, you can remove older covered encrypted history from the service. The two latest snapshots and their remaining updates are kept.
        - status [ref=f1e52]: Verified snapshot 1 is saved.
        - button "Check history" [ref=f1e53] [cursor=pointer]
        - button "Create history snapshot" [ref=f1e54] [cursor=pointer]
      - button "Use another account" [ref=f1e55] [cursor=pointer]
      - status [ref=f1e56]: Account login remembered on this device.
      - button "Sign out" [ref=f1e57] [cursor=pointer]
    - generic [ref=f1e58]:
      - heading "Identity and preferences" [level=2] [ref=f1e59]
      - generic [ref=f1e60]:
        - generic [ref=f1e61]: Actor
        - generic [ref=f1e62]: Device owner
      - generic [ref=f1e64]:
        - generic [ref=f1e65]: Version
        - generic [ref=f1e66]: f75a19e7
      - generic [ref=f1e67]:
        - generic [ref=f1e68]:
          - generic [ref=f1e69]: Device
          - textbox "Device name" [ref=f1e70]: This device
        - generic [ref=f1e71]:
          - generic [ref=f1e72]: Name
          - textbox "Actor name" [ref=f1e73]: Device owner
        - generic [ref=f1e74]:
          - generic [ref=f1e75]: Color
          - textbox "Actor color" [ref=f1e76]: "#e0662f"
        - generic [ref=f1e77]:
          - generic [ref=f1e78]: Day rollover
          - combobox "Day rollover hour" [ref=f1e79]:
            - option "00:00" [selected]
            - option "01:00"
            - option "02:00"
            - option "03:00"
            - option "04:00"
            - option "05:00"
            - option "06:00"
            - option "07:00"
            - option "08:00"
            - option "09:00"
            - option "10:00"
            - option "11:00"
            - option "12:00"
            - option "13:00"
            - option "14:00"
            - option "15:00"
            - option "16:00"
            - option "17:00"
            - option "18:00"
            - option "19:00"
            - option "20:00"
            - option "21:00"
            - option "22:00"
            - option "23:00"
        - button "Save preferences" [ref=f1e80] [cursor=pointer]
    - generic [ref=f1e81]:
      - heading "Install" [level=2] [ref=f1e82]
      - paragraph [ref=f1e83]: If the install button does not appear, use Install app in your browser menu.
  - complementary [ref=f1e84]:
    - generic [ref=f1e85]:
      - heading [level=2] [ref=f1e86]: Unfiled
      - generic [ref=f1e87]: "0"
      - button [ref=f1e88] [cursor=pointer]: Close
    - paragraph [ref=f1e90]: These cards were retained because their original collection can no longer display them. Choose a new home or remove them explicitly.
  - button "Close unfiled cards"
  - main "Days" [ref=f1e92]:
    - generic:
      - button "Go to Yesterday" [ref=f1e93] [cursor=pointer]
      - button "Go to Tomorrow" [ref=f1e94] [cursor=pointer]
    - generic [ref=f1e95]:
      - region:
        - generic:
          - heading [level=1]: Mon 12 Oct
          - button: Today
        - generic:
          - generic:
            - heading [level=2]:
              - generic: Next
              - generic: 0/3
            - paragraph: Empty.
          - generic:
            - heading [level=2]:
              - generic: Done
            - paragraph: Nothing yet.
            - generic:
              - textbox:
                - /placeholder: What got done?
              - button [disabled]: Add
      - region "Today" [ref=f1e96]:
        - heading "Tue 13 Oct" [level=1] [ref=f1e98]
        - generic [ref=f1e99]:
          - generic [ref=f1e100]:
            - heading "Next 0 of 3" [level=2] [ref=f1e101]:
              - generic [ref=f1e102]: Next
              - generic "0 of 3" [ref=f1e103]: 0/3
            - paragraph [ref=f1e104]: Empty.
          - generic [ref=f1e105]:
            - heading "Done" [level=2] [ref=f1e106]
            - generic [ref=f1e108]:
              - article [ref=f1e109]:
                - generic "Joined writing after actual removal — press Enter to unlock" [ref=f1e110]: Joined writing after actual removal
                - generic [ref=f1e112]:
                  - button "Reorder Joined writing after actual removal" [ref=f1e113]
                  - button "Unlock" [ref=f1e116] [cursor=pointer]
                  - 'button "Remove this card: Joined writing after actual removal" [ref=f1e117] [cursor=pointer]': Remove
              - article [ref=f1e118]:
                - generic "Original writing after actual removal — press Enter to unlock" [ref=f1e119]: Original writing after actual removal
                - generic [ref=f1e121]:
                  - button "Reorder Original writing after actual removal" [ref=f1e122]
                  - button "Unlock" [ref=f1e125] [cursor=pointer]
                  - 'button "Remove this card: Original writing after actual removal" [ref=f1e126] [cursor=pointer]': Remove
              - article [ref=f1e127]:
                - generic "Keep the first device writing — press Enter to unlock" [ref=f1e128]: Keep the first device writing
                - generic [ref=f1e130]:
                  - button "Reorder Keep the first device writing" [ref=f1e131]
                  - button "Unlock" [ref=f1e134] [cursor=pointer]
                  - 'button "Remove this card: Keep the first device writing" [ref=f1e135] [cursor=pointer]': Remove
            - generic [ref=f1e136]:
              - textbox "What got done?" [ref=f1e137]
              - button "Add" [disabled] [ref=f1e138]
      - region:
        - generic:
          - heading [level=1]: Wed 14 Oct
          - button: Today
        - generic:
          - generic:
            - heading [level=2]:
              - generic: Next
              - generic: 0/3
            - paragraph: Empty.
          - generic:
            - heading [level=2]:
              - generic: Done
            - paragraph: Nothing yet.
            - generic:
              - textbox:
                - /placeholder: What got done?
              - button [disabled]: Add
  - complementary "Goals" [ref=f1e139]:
    - heading [level=2] [ref=f1e141]:
      - button "Goals. Open document outline" [ref=f1e142] [cursor=pointer]:
        - generic [ref=f1e143]: Goals
    - generic [ref=f1e148]:
      - status
      - textbox [ref=f1e151]:
        - generic [ref=f1e152]: Everything. Tasks, projects, someday-maybes, notes to self.
    - group "Selected lines" [ref=f1e154]:
      - generic [ref=f1e155]:
        - group "Transfer selected lines" [ref=f1e156]:
          - generic [ref=f1e158] [cursor=pointer]:
            - radio "Copy to" [checked] [ref=f1e159]
            - generic: Copy to
          - generic [ref=f1e160] [cursor=pointer]:
            - radio "Move to" [ref=f1e161]
            - generic: Move to
        - button "More Goals actions" [ref=f1e163] [cursor=pointer]
      - generic [ref=f1e168]:
        - button "Next" [disabled] [ref=f1e169]
        - button "Scheduled" [disabled] [ref=f1e170]
        - button "Done" [disabled] [ref=f1e171]
```

# Test source

```ts
  48  |     },
  49  |     plugins: [
  50  |       { name: 'owner-close-diagnostics', enforce: 'pre', transform(code, id) {
  51  |         const files = ['writeSession.ts','accountReceive.ts','accountCapture.ts','admittedWorkspace.ts','admissionQueue.ts'];
  52  |         if (!files.some(n => id.endsWith('/src/crdt/' + n))) return;
  53  |         const name = id.split('/').at(-1);
  54  |         code = code.replace(/catch \((cause|e|error)\) \{/g, (match, variable, offset) => match + ` globalThis.__retentionTrace?.('${name}:catch:${code.slice(0,offset).split('\n').length}', ${variable});`);
  55  |         if (name === 'writeSession.ts') code = code.replace('    if (closing) return closing;', `    if (closing) return closing; globalThis.__retentionTrace?.('session-close:' + state, new Error('close'));`);
  56  |         if (name === 'admissionQueue.ts') {
  57  |           const at = "        if (!updates || !finish) throw Error('Remote preparation omitted its durable handoff');";
  58  |           if (!code.includes(at)) throw Error('Preparation hook moved');
  59  |           code = code.replace(at, at + '\n        await globalThis.__retentionBeforePromotion?.(updates.length);');
  60  |           code = code.replace('        input.fill(0);', '        globalThis.__retentionPromotionSettled?.(); input.fill(0);');
  61  |         }
  62  |         return code;
  63  |       } },
  64  |       {
  65  |         name: 'private-retention-checkpoint',
  66  |         enforce: 'pre',
  67  |         transform(code, id) {
  68  |           if (!id.endsWith('/src/crdt/accountReceive.ts')) return;
  69  |           const at = '  clearAccountTransition(result.accountId);';
  70  |           if (code.split(at).length !== 2) throw Error('Owner test anchor changed');
  71  |           hits++;
  72  |           return code.replace(at, at + '\n  globalThis.__retentionOwner = result;');
  73  |         },
  74  |       },
  75  |     ],
  76  |   });
  77  |   expect(hits).toBe(1);
  78  |   const service = await startService(info.outputPath('service'), resolve(outDir), true, true);
  79  |   let pair: Awaited<ReturnType<typeof pairedEditors>> | undefined;
  80  |   try {
  81  |     await browserContextDiagnostics(page);
  82  |     pair = await pairedEditors(page, browser, true, { beforeCompare: browserContextDiagnostics });
  83  |     const second = pair.second;
  84  |     for (const p of [page, second])
  85  |       await expect
  86  |         .poll(() => removal(p, 0), { timeout: 20000 })
  87  |         .toMatchObject({ kind: 'removed', revision: 1 });
  88  |     await add(page, 'Original writing after actual removal');
  89  |     await expect(second.locator('.shell')).toContainText('Original writing after actual removal');
  90  |     await add(second, 'Joined writing after actual removal');
  91  |     await expect(page.locator('.shell')).toContainText('Joined writing after actual removal');
  92  |     for (const kind of ['undo', 'redo'] as const) {
  93  |       await second.evaluate(async (kind) => {
  94  |         const owner = (globalThis as unknown as { __retentionOwner: Owner }).__retentionOwner;
  95  |         await owner.workspace.command({ kind }).accepted;
  96  |       }, kind);
  97  |       if (kind === 'undo')
  98  |         await expect(page.locator('.shell')).not.toContainText(
  99  |           'Joined writing after actual removal',
  100 |         );
  101 |       else
  102 |         await expect(page.locator('.shell')).toContainText('Joined writing after actual removal');
  103 |     }
  104 |     await inspect(page);
  105 |     await panel(page).getByRole('button', { name: 'Create history snapshot' }).click();
  106 |     await expect(panel(page)).toContainText(
  107 |       'Snapshot saved. Verify it from another approved device.',
  108 |     );
  109 |     expect(await removal(page, 1)).toEqual({ kind: 'skipped', reason: 'durable-attempt' });
  110 |     await inspect(second);
  111 |     await panel(second).getByRole('button', { name: 'Verify history snapshot' }).click();
  112 |     await expect(panel(second)).toContainText('Verified snapshot 1 is saved.');
  113 |     await panel(page).getByRole('button', { name: 'Check history', exact: true }).click();
  114 |     await panel(page).getByRole('button', { name: 'Resume history snapshot', exact: true }).click();
  115 |     await expect(panel(page)).toContainText('Verified snapshot 1 is saved.');
  116 |     for (const p of [page, second])
  117 |       await expect
  118 |         .poll(() => removal(p, 1), { timeout: 20000 })
  119 |         .toMatchObject({ kind: 'removed', revision: 2 });
  120 |     for (const [p, code, joining] of [
  121 |       [page, pair.first.code, false],
  122 |       [second, pair.next.code, true],
  123 |     ] as const) {
  124 |       await p.getByRole('button', { name: 'Lock workspace', exact: true }).click();
  125 |       await p.goto('/');
  126 |       await openSaved(p, code, joining);
  127 |       await expect(p.locator('.shell')).toContainText('Joined writing after actual removal');
  128 |       if (process.env.RETENTION_DIAGNOSTIC_THROTTLE) {
  129 |         const cdp = await p.context().newCDPSession(p);
  130 |         await cdp.send('Emulation.setCPUThrottlingRate', { rate: Number(process.env.RETENTION_DIAGNOSTIC_THROTTLE) });
  131 |       }
  132 |       if (joining && process.env.RETENTION_DIAGNOSTIC_HOLD) {
  133 |         await p.evaluate(() => {
  134 |           const g = globalThis as any;
  135 |           g.__retentionBeforePromotion = (count: number) => new Promise(resolve => {
  136 |             g.__retentionPromotionHit = count;
  137 |             g.__retentionReleasePromotion = () => { g.__retentionBeforePromotion = undefined; resolve(undefined); };
  138 |           });
  139 |           g.__retentionPromotionSettled = () => { g.__retentionPromotionEnded = true; };
  140 |         });
  141 |         await p.waitForFunction(() => (globalThis as any).__retentionPromotionHit !== undefined);
  142 |         console.log('held promotion frames', await p.evaluate(() => (globalThis as any).__retentionPromotionHit));
  143 |       }
  144 |       await inspect(p);
  145 |       if (joining && process.env.RETENTION_DIAGNOSTIC_HOLD) {
  146 |         await p.evaluate(() => (globalThis as any).__retentionReleasePromotion());
  147 |         await p.waitForFunction(() => (globalThis as any).__retentionPromotionEnded === true);
> 148 |         expect(await p.evaluate(() => (globalThis as any).__retentionOwner.workspace.status.state)).toBe('active');
      |                                                                                                     ^ Error: expect(received).toBe(expected) // Object.is equality
  149 |         await expect(p.locator('.shell')).toBeVisible();
  150 |       }
  151 |       await expect(panel(p)).toContainText('Verified snapshot 1 is saved.');
  152 |       await expect
  153 |         .poll(() => removal(p, 1), { timeout: 15000 })
  154 |         .toEqual({ kind: 'already-removed' });
  155 |     }
  156 |     await add(second, 'Cold reduced checkpoint continues');
  157 |     await expect(page.locator('.shell')).toContainText('Cold reduced checkpoint continues');
  158 |   } finally {
  159 |     const evidence = [];
  160 |     for (const [label, p] of [['original', page], ['joined', pair?.second]] as const) {
  161 |       if (!p || p.isClosed()) continue;
  162 |       evidence.push({ label, data: await p.evaluate(() => ({
  163 |         events: globalThis.__retentionEvents, status: globalThis.__retentionOwner?.workspace.status,
  164 |         path: location.pathname,
  165 |       })).catch(e => ({ error: e.message })) });
  166 |     }
  167 |     writeFileSync(info.outputPath('owner-events.json'), JSON.stringify(evidence, null, 2));
  168 |     await pair?.other.close();
  169 |     await stopService(service);
  170 |   }
  171 | });
  172 | 
  173 | async function browserContextDiagnostics(p: Page) {
  174 |   const script = () => {
  175 |     const g = globalThis as any;
  176 |     g.__retentionEvents = [];
  177 |     g.__retentionTrace = (tag: string, error: any) => {
  178 |       g.__retentionEvents.push({ at: performance.now(), tag, name: error?.name, code: error?.code, message: error?.message, stack: error?.stack });
  179 |       if (g.__retentionEvents.length > 200) g.__retentionEvents.shift();
  180 |     };
  181 |   };
  182 |   await p.addInitScript(script);
  183 |   await p.evaluate(script);
  184 | }
  185 | 
```
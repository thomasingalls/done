import { test, expect, type Page } from '@playwright/test';
import { build } from 'vite';
import { resolve } from 'node:path';
import { writeFileSync } from 'node:fs';
import { pairedEditors, openSaved, add } from '../packaged-account/devices';
import { startService, stopService } from '../packaged-account/server';
import type { AdmittedWorkspace } from '../../src/crdt/admittedWorkspace';

type Owner = {
  removeLocalHistory(revision: number): Promise<{ kind: string; revision?: number }>;
  workspace: Pick<AdmittedWorkspace, 'whenDurable' | 'command' | 'status'>;
};
const removal = (p: Page, revision: number) =>
  p.evaluate(async (r) => {
    const owner = (globalThis as unknown as { __retentionOwner: Owner }).__retentionOwner;
    try {
      return await owner.removeLocalHistory(r);
    } catch (e) {
      if (
        e instanceof Error &&
        e.message === 'Receive authority was superseded' &&
        owner.workspace.status.state === 'active'
      )
        return { kind: 'retired-flight' };
      throw e;
    }
  }, revision);
const panel = (p: Page) => p.getByRole('region', { name: 'History maintenance', exact: true });
async function inspect(p: Page) {
  await p.getByRole('button', { name: 'History maintenance', exact: true }).click();
  await panel(p).getByRole('button', { name: 'Check history', exact: true }).click();
  await expect(panel(p).getByRole('button', { name: 'Check history', exact: true })).toBeEnabled();
}
test('reduced original and joined owners exchange/undo writing, refuse an unfinished checkpoint cut, then retain its installation through another cut and cold open', async ({
  page,
  browser,
}, info) => {
  test.setTimeout(120000);
  const outDir = info.outputPath('build');
  let hits = 0;
  await build({
    logLevel: 'error',
    build: { outDir },
    define: {
      'import.meta.env.VITE_ACCOUNT_BASELINE_INSTALL': JSON.stringify('1'),
      'import.meta.env.VITE_ACCOUNT_BASELINE_READ': JSON.stringify('1'),
      'import.meta.env.VITE_ACCOUNT_RETENTION': JSON.stringify('1'),
    },
    plugins: [
      { name: 'owner-close-diagnostics', enforce: 'pre', transform(code, id) {
        const files = ['writeSession.ts','accountReceive.ts','accountCapture.ts','admittedWorkspace.ts','admissionQueue.ts'];
        if (!files.some(n => id.endsWith('/src/crdt/' + n))) return;
        const name = id.split('/').at(-1);
        code = code.replace(/catch \((cause|e|error)\) \{/g, (match, variable, offset) => match + ` globalThis.__retentionTrace?.('${name}:catch:${code.slice(0,offset).split('\n').length}', ${variable});`);
        if (name === 'writeSession.ts') code = code.replace('    if (closing) return closing;', `    if (closing) return closing; globalThis.__retentionTrace?.('session-close:' + state, new Error('close'));`);
        if (name === 'admissionQueue.ts') {
          const at = "        if (!updates || !finish) throw Error('Remote preparation omitted its durable handoff');";
          if (!code.includes(at)) throw Error('Preparation hook moved');
          code = code.replace(at, at + '\n        await globalThis.__retentionBeforePromotion?.(updates.length);');
          code = code.replace('        input.fill(0);', '        globalThis.__retentionPromotionSettled?.(); input.fill(0);');
        }
        return code;
      } },
      {
        name: 'private-retention-checkpoint',
        enforce: 'pre',
        transform(code, id) {
          if (!id.endsWith('/src/crdt/accountReceive.ts')) return;
          const at = '  clearAccountTransition(result.accountId);';
          if (code.split(at).length !== 2) throw Error('Owner test anchor changed');
          hits++;
          return code.replace(at, at + '\n  globalThis.__retentionOwner = result;');
        },
      },
    ],
  });
  expect(hits).toBe(1);
  const service = await startService(info.outputPath('service'), resolve(outDir), true, true);
  let pair: Awaited<ReturnType<typeof pairedEditors>> | undefined;
  try {
    await browserContextDiagnostics(page);
    pair = await pairedEditors(page, browser, true, { beforeCompare: browserContextDiagnostics });
    const second = pair.second;
    for (const p of [page, second])
      await expect
        .poll(() => removal(p, 0), { timeout: 20000 })
        .toMatchObject({ kind: 'removed', revision: 1 });
    await add(page, 'Original writing after actual removal');
    await expect(second.locator('.shell')).toContainText('Original writing after actual removal');
    await add(second, 'Joined writing after actual removal');
    await expect(page.locator('.shell')).toContainText('Joined writing after actual removal');
    for (const kind of ['undo', 'redo'] as const) {
      await second.evaluate(async (kind) => {
        const owner = (globalThis as unknown as { __retentionOwner: Owner }).__retentionOwner;
        await owner.workspace.command({ kind }).accepted;
      }, kind);
      if (kind === 'undo')
        await expect(page.locator('.shell')).not.toContainText(
          'Joined writing after actual removal',
        );
      else
        await expect(page.locator('.shell')).toContainText('Joined writing after actual removal');
    }
    await inspect(page);
    await panel(page).getByRole('button', { name: 'Create history snapshot' }).click();
    await expect(panel(page)).toContainText(
      'Snapshot saved. Verify it from another approved device.',
    );
    expect(await removal(page, 1)).toEqual({ kind: 'skipped', reason: 'durable-attempt' });
    await inspect(second);
    await panel(second).getByRole('button', { name: 'Verify history snapshot' }).click();
    await expect(panel(second)).toContainText('Verified snapshot 1 is saved.');
    await panel(page).getByRole('button', { name: 'Check history', exact: true }).click();
    await panel(page).getByRole('button', { name: 'Resume history snapshot', exact: true }).click();
    await expect(panel(page)).toContainText('Verified snapshot 1 is saved.');
    for (const p of [page, second])
      await expect
        .poll(() => removal(p, 1), { timeout: 20000 })
        .toMatchObject({ kind: 'removed', revision: 2 });
    for (const [p, code, joining] of [
      [page, pair.first.code, false],
      [second, pair.next.code, true],
    ] as const) {
      await p.getByRole('button', { name: 'Lock workspace', exact: true }).click();
      await p.goto('/');
      await openSaved(p, code, joining);
      await expect(p.locator('.shell')).toContainText('Joined writing after actual removal');
      if (process.env.RETENTION_DIAGNOSTIC_THROTTLE) {
        const cdp = await p.context().newCDPSession(p);
        await cdp.send('Emulation.setCPUThrottlingRate', { rate: Number(process.env.RETENTION_DIAGNOSTIC_THROTTLE) });
      }
      if (joining && process.env.RETENTION_DIAGNOSTIC_HOLD) {
        await p.evaluate(() => {
          const g = globalThis as any;
          g.__retentionBeforePromotion = (count: number) => new Promise(resolve => {
            g.__retentionPromotionHit = count;
            g.__retentionReleasePromotion = () => { g.__retentionBeforePromotion = undefined; resolve(undefined); };
          });
          g.__retentionPromotionSettled = () => { g.__retentionPromotionEnded = true; };
        });
        await p.waitForFunction(() => (globalThis as any).__retentionPromotionHit !== undefined);
        console.log('held promotion frames', await p.evaluate(() => (globalThis as any).__retentionPromotionHit));
      }
      await inspect(p);
      if (joining && process.env.RETENTION_DIAGNOSTIC_HOLD) {
        await p.evaluate(() => (globalThis as any).__retentionReleasePromotion());
        await p.waitForFunction(() => (globalThis as any).__retentionPromotionEnded === true);
        expect(await p.evaluate(() => (globalThis as any).__retentionOwner.workspace.status.state)).toBe('active');
        await expect(p.locator('.shell')).toBeVisible();
      }
      await expect(panel(p)).toContainText('Verified snapshot 1 is saved.');
      await expect
        .poll(() => removal(p, 1), { timeout: 15000 })
        .toEqual({ kind: 'already-removed' });
    }
    await add(second, 'Cold reduced checkpoint continues');
    await expect(page.locator('.shell')).toContainText('Cold reduced checkpoint continues');
  } finally {
    const evidence = [];
    for (const [label, p] of [['original', page], ['joined', pair?.second]] as const) {
      if (!p || p.isClosed()) continue;
      evidence.push({ label, data: await p.evaluate(() => ({
        events: globalThis.__retentionEvents, status: globalThis.__retentionOwner?.workspace.status,
        path: location.pathname,
      })).catch(e => ({ error: e.message })) });
    }
    writeFileSync(info.outputPath('owner-events.json'), JSON.stringify(evidence, null, 2));
    await pair?.other.close();
    await stopService(service);
  }
});

async function browserContextDiagnostics(p: Page) {
  const script = () => {
    const g = globalThis as any;
    g.__retentionEvents = [];
    g.__retentionTrace = (tag: string, error: any) => {
      g.__retentionEvents.push({ at: performance.now(), tag, name: error?.name, code: error?.code, message: error?.message, stack: error?.stack });
      if (g.__retentionEvents.length > 200) g.__retentionEvents.shift();
    };
  };
  await p.addInitScript(script);
  await p.evaluate(script);
}

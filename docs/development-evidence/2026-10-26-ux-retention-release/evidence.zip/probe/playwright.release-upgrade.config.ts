import {defineConfig} from '@playwright/test';
export default defineConfig({
  "testDir": "/private/tmp/done-release-2026-10-26/source/test/release-probe",
  "outputDir": "/private/tmp/done-release-2026-10-26/upgrade-artifacts",
  "timeout": 180000,
  "workers": 1,
  "retries": 0,
  "reporter": [
    [
      "list"
    ],
    [
      "json",
      {
        "outputFile": "/private/tmp/done-release-2026-10-26/upgrade-results.json"
      }
    ]
  ],
  "use": {
    "baseURL": "http://localhost:53221",
    "viewport": {
      "width": 1280,
      "height": 900
    },
    "launchOptions": {
      "executablePath": "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
    }
  }
});

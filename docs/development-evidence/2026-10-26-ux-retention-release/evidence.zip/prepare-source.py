from pathlib import Path
import subprocess,json,tarfile,io,hashlib,os
root=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');out=Path('/private/tmp/done-release-2026-10-26');source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert source.startswith('dc53fecf');assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
old=json.loads((root/'docs/development-evidence/2026-10-23-distroless-release/signed-d8b3f22b/source.json').read_text());inputs=old['inputs'];archive=subprocess.check_output(['git','archive','--format=tar',source,'--',*inputs],cwd=root);(out/'signed-source.tar').write_bytes(archive)
context=out/'source';context.mkdir(exist_ok=False);files=[]
with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
 for member in tar:
  assert not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
  if member.isdir():continue
  assert member.isfile(),member.name
  data=tar.extractfile(member).read();p=context/member.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);p.chmod(member.mode)
  assert data==(root/member.name).read_bytes();files.append({'path':member.name,'sha256':hashlib.sha256(data).hexdigest(),'executable':bool(member.mode&0o111)})
verified=[]
for commit in subprocess.check_output(['git','rev-list','--reverse','0a01b715..'+source],cwd=root,text=True).splitlines():
 r=subprocess.run(['git','verify-commit',commit],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);assert r.returncode==0,r.stdout;verified.append({'commit':commit,'verification':r.stdout.strip()})
date=subprocess.check_output(['git','show','-s','--format=%cs',source],cwd=root,text=True).strip();record={'source':source,'tree':subprocess.check_output(['git','rev-parse',source+'^{tree}'],cwd=root,text=True).strip(),'date':date,'inputs':inputs,'files':files,'archiveBytes':len(archive),'archiveSha256':hashlib.sha256(archive).hexdigest(),'signatures':verified,'platform':'linux/arm64','featureOverrides':{'VITE_ACCOUNT_RETENTION_AUTO':'1'}};(out/'source.json').write_text(json.dumps(record,indent=2)+'\n');print(source,date,len(files),'allowlisted files;',len(verified),'verified signatures')

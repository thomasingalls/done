from pathlib import Path
import subprocess,json,copy,sys
root=Path('/private/tmp/ol-infra-done-release-2026-10-26');sys.path.insert(0,str(root/'infra/apps/done'))
from manifest_tools import render,one,documents
from render_operation import operation
route=root/'infra/apps/done/public/httproute.yaml';pin=root/'infra/apps/done/components/runtime/kustomization.yaml';current={route:route.read_bytes(),pin:pin.read_bytes()}
def capture():return {'base':render(root/'infra/apps/done'),'public':render(root/'infra/apps/done/public'),'gateway':render(root/'infra/gateway'),'operations':{c:operation(c,'ab'*16 if c!='initialize' else None) for c in ['initialize','maintenance-prepare','maintenance-status','maintenance-resume','maintenance-prune']}}
try:
 for path in current:path.write_bytes(subprocess.check_output(['git','-C',str(root),'show','origin/main:'+str(path.relative_to(root))]))
 before=capture()
finally:
 for path,data in current.items():path.write_bytes(data)
after=capture();old='ghcr.io/thomasingalls/done@sha256:6f1cb5d644cbee92d2b344d591d182d900ab059670ed5870acc01b556e82cacb';new='ghcr.io/thomasingalls/done@'+json.load(open('/private/tmp/done-release-2026-10-26/image.json'))['indexDigest']
serialized=json.dumps(before);expected=json.loads(serialized.replace(old,new));r=one(expected['public'],'HTTPRoute','done');filters=[{'type':'ResponseHeaderModifier','responseHeaderModifier':{'set':[{'name':'Strict-Transport-Security','value':'max-age=31536000'}]}}]
for rule in r['spec']['rules']:rule['filters']=filters
assert expected==after,'Unexpected rendered mutation beyond the image and two HTTPS HSTS filters'
# Challenge the exact-header/route guards, restoring all candidate bytes after each counterexample.
valid=route.read_text();faults={
 'missing-stream-header':valid.replace('                value: max-age=31536000','                value: max-age=0',1),
 'unrequested-subdomains':valid.replace('max-age=31536000','max-age=31536000; includeSubDomains'),
 'broken-stream-timeout':valid.replace('request: 0s','request: 1s',1),
 'wrong-host':valid.replace('done.oxidationlabs.com','other.example.com'),
}
results=[]
try:
 for name,text in faults.items():
  route.write_text(text);p=subprocess.run(['python3',str(root/'infra/apps/done/check.py')],stdout=subprocess.PIPE,stderr=subprocess.STDOUT);assert p.returncode!=0,name;results.append({'name':name,'rejected':True,'output':p.stdout.decode()})
finally:route.write_text(valid)
record={'ok':True,'base':'a7fcf5b','scope':'parsed base/public/gateway/operator jobs change only by tested image and two host-only HTTPS HSTS filters','imageOccurrences':serialized.count(old),'hsts':'max-age=31536000','counterexamples':results,'clusterMutated':False,'secretsDecrypted':False}
Path('/private/tmp/done-release-2026-10-26/infra-boundary.json').write_text(json.dumps(record,indent=2)+'\n');print({k:v for k,v in record.items() if k!='counterexamples'})

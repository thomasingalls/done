import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFileSync, readdirSync } from 'node:fs';
const { parseSync } = createRequire('/Users/thomasingalls/.codex/worktrees/7fda/done/package.json')('@babel/core');
const [dir, expected] = process.argv.slice(2); assert(['0','1'].includes(expected));
const found = [];
for (const file of readdirSync(dir).filter(f => f.endsWith('.js'))) {
 const source = parseSync(readFileSync(dir+'/'+file,'utf8'),{babelrc:false,configFile:false,sourceType:'module'});
 const visit = node => {
  if(node.type==='MemberExpression' && node.property.name==='VITE_ACCOUNT_RETENTION_AUTO') {
   assert.equal(node.object.type,'ObjectExpression');
   const flags=Object.fromEntries(node.object.properties.filter(p=>p.type==='ObjectProperty').map(p=>[p.key.name,p.value.type==='TemplateLiteral'?p.value.quasis[0].value.cooked:p.value.value]));
   assert.equal(flags.VITE_ACCOUNT_BASELINE_READ,'1');
   for(const key of ['VITE_ACCOUNT_BASELINE_INSTALL','VITE_ACCOUNT_RETENTION','VITE_ACCOUNT_RETENTION_AUTO']) assert.equal(flags[key],expected);
   found.push({file,flags:Object.fromEntries(Object.entries(flags).filter(([key])=>/BASELINE|RETENTION/.test(key)))});
  }
  for(const value of Object.values(node)) if(Array.isArray(value)) value.forEach(v=>{if(v&&typeof v.type==='string')visit(v)});else if(value&&typeof value.type==='string')visit(value);
 };visit(source);
}
assert(found.length>0);console.log(JSON.stringify({expectedAutomatic:expected,compiledGateReads:found},null,2));

from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json, os, subprocess

root = Path('/Users/thomasingalls/.codex/worktrees/7fda/done')
scratch = Path(__file__).resolve().parent
node = '/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node'
env = dict(os.environ, PATH=str(Path(node).parent) + ':' + os.environ['PATH'])
contracts = json.loads((root/'docs/development-evidence/2026-10-26-signed-ux-retention-checkpoint/contracts.json').read_text())
jobs = [(f'contract-{i}', c['argv'], c['env']) for i, c in enumerate(contracts)]
jobs += [(name, ['node', path, *args], {}) for name, path, args in [
    ('inventory', 'scripts/release-validation/check.mjs', []),
    ('plan', 'scripts/release-validation/plan.mjs', []),
    ('crypto-census', 'scripts/account-crypto-prep/run.mjs', []),
    ('first-authority', 'scripts/account-first-authority/run.mjs', []),
    ('yjs-patch', 'scripts/check-yjs-patch.mjs', []),
    ('traceability', 'scripts/check-traceability.mjs', ['--check']),
]]
jobs += [('ci-adapters', ['node', '--test', '--test-concurrency=2', *[
    'test/release-validation/'+f+'.test.mjs' for f in ['onboarding-gates', 'vitest', 'playwright', 'general-tests', 'generated-tests', 'account-fixtures', 'campaign-wrappers', 'manifest']
], 'test/account-first-authority/registry.test.mjs'], {})]
def run(job):
    name, argv, extra = job
    p = subprocess.run(argv, cwd=root, env=dict(env, **extra), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=240)
    (scratch/('fresh-'+name+'.log')).write_bytes(p.stdout)
    result = {'name': name, 'argv': argv, 'env': extra, 'node': '24.18.0', 'exitCode': p.returncode}
    print(name, p.returncode, flush=True)
    return result
with ThreadPoolExecutor(max_workers=2) as pool:
    results = list(pool.map(run, jobs))
(scratch/'fresh-bookkeeping.json').write_text(json.dumps(results, indent=2)+'\n')
assert all(r['exitCode']==0 for r in results), 'Failed checks preserved in raw logs'

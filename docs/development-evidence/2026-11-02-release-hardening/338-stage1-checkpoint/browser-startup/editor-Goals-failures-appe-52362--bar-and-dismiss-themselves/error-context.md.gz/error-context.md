# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: editor.spec.ts >> Goals failures appear once above the fixed bar and dismiss themselves
- Location: test/local-app/editor.spec.ts:308:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: locator('.workspace-status')
Expected substring: "Input is waiting for storage."
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toContainText" with timeout 5000ms
  - waiting for locator('.workspace-status')
    - locator resolved to <aside role="status" class="workspace-status">…</aside>
    - unexpected value "Input is waiting to be saved."

```

```yaml
- complementary "Menu":
  - navigation "Day":
    - text: Mon 2 Nov 2026
    - textbox "Go to date": 2026-11-02
    - button "Yesterday"
    - button "Today"
    - button "Tomorrow"
  - group:
    - heading "Account" [level=2]
  - group:
    - heading "Sync" [level=2]
  - group:
    - heading "Data" [level=2]
  - group:
    - heading "Install" [level=2]
- button "Close unfiled cards"
- main "Days":
  - button "Go to Yesterday"
  - button "Go to Tomorrow"
  - region "Today":
    - heading "Mon 2 Nov" [level=1]
    - heading "Next 0 of 3" [level=2]: Next 0/3
    - paragraph: The three most important things to focus on next.
    - heading "Done" [level=2]
    - article:
      - text: retain this
      - button "Unlock"
      - 'button "Duplicate to Scheduled: retain this"': Duplicate
      - 'button "Remove this card: retain this"': Remove
    - textbox "What got done?"
    - button "Add" [disabled]
    - heading "Scheduled" [level=2]
    - paragraph: Things planned for this day.
    - textbox "What’s scheduled?"
    - button "Add" [disabled]
- complementary "Goals":
  - heading "Goals" [level=2]:
    - button "Goals. Open document outline": Goals
    - button "Sections inside Goals"
  - status
  - textbox
  - group "Selected lines":
    - group "Transfer selected lines":
      - text: Transfer selected lines
      - radio "Copy to" [checked]
      - text: Copy to
      - radio "Move to"
      - text: Move to
    - button "More Goals actions"
    - button "Next" [disabled]
    - button "Scheduled" [disabled]
    - button "Done" [disabled]
```

# Test source

```ts
  218 |     expect((await actionBoxes(page)).map((box) => box.width)).toEqual(
  219 |       before.map((box) => box.width),
  220 |     );
  221 |     await page.setViewportSize({ width, height: 900 });
  222 |     await expect.poll(() => actionBoxes(page)).toEqual(before);
  223 |     const footer = (await goals.locator('.goals-actions').boundingBox())!;
  224 |     for (const box of before) {
  225 |       expect(box.x).toBeGreaterThanOrEqual(footer.x);
  226 |       expect(box.x + box.width).toBeLessThanOrEqual(footer.x + footer.width);
  227 |     }
  228 |     const mode = (await goals.locator('.goals-transfer-mode').boundingBox())!;
  229 |     expect(mode.x).toBe(before[0]!.x);
  230 |     expect(mode.y + mode.height).toBeLessThan(before[0]!.y);
  231 |     const more = goals.getByRole('button', { name: 'More Goals actions' });
  232 |     const moreBox = (await more.boundingBox())!;
  233 |     expect(moreBox.y).toBe(mode.y);
  234 |     expect(moreBox.x).toBeGreaterThanOrEqual(mode.x + mode.width + 16);
  235 |     expect(new Set(before.map((box) => box.y)).size).toBe(1);
  236 |     expect(footer.y + footer.height - (before[0]!.y + before[0]!.height)).toBeLessThan(16);
  237 |     await more.click();
  238 |     const menu = goals.getByRole('menu', { name: 'Goals actions' });
  239 |     await expect(menu).toBeVisible();
  240 |     expect(await actionBoxes(page)).toEqual(before);
  241 |     expect(await goals.locator('.goals-actions').boundingBox()).toEqual(footer);
  242 |     const menuBox = (await menu.boundingBox())!;
  243 |     expect(menuBox.y + menuBox.height).toBeLessThanOrEqual(moreBox.y);
  244 |     expect(menuBox.x).toBeGreaterThanOrEqual(footer.x);
  245 |     await page.keyboard.press('Escape');
  246 |     await expect(more).toBeFocused();
  247 |     await goals.getByRole('radio', { name: 'Move to', exact: true }).check();
  248 |     expect(await goals.locator('.goals-transfer-mode').boundingBox()).toEqual(mode);
  249 |     expect(await actionBoxes(page)).toEqual(before);
  250 |     await goals.getByRole('button', { name: 'Done', exact: true }).click();
  251 |     await expect(goals.getByRole('radio', { name: 'Copy to', exact: true })).toBeChecked();
  252 |     await expect(goals.getByRole('button', { name: 'Done', exact: true })).toBeDisabled();
  253 |     expect(await actionBoxes(page)).toEqual(before);
  254 |   });
  255 | }
  256 | 
  257 | test('Goals mobile menu removes the current line, undoes, redoes and dismisses accessibly', async ({
  258 |   page,
  259 | }) => {
  260 |   await page.setViewportSize({ width: 375, height: 800 });
  261 |   await openApp(page);
  262 |   await page
  263 |     .locator('.day-panel[data-active="true"] .panel-header')
  264 |     .getByRole('button', { name: 'Open Goals', exact: true })
  265 |     .click();
  266 |   const goals = page.locator('.goals');
  267 |   const content = goals.locator('.cm-content');
  268 |   const more = goals.getByRole('button', { name: 'More Goals actions' });
  269 |   const menu = goals.getByRole('menu', { name: 'Goals actions' });
  270 |   await more.click();
  271 |   for (const item of await menu.getByRole('menuitem').all()) await expect(item).toBeDisabled();
  272 |   await page.keyboard.press('Escape');
  273 |   await expect(menu).toHaveCount(0);
  274 |   await expect(more).toBeFocused();
  275 |   await expect(page.locator('.shell')).toHaveAttribute('data-goals', 'open');
  276 |   await content.click();
  277 |   await page.keyboard.insertText('keep\nremove me');
  278 |   await more.click();
  279 |   await expect(menu.getByRole('menuitem', { name: 'Undo', exact: true })).toBeEnabled();
  280 |   await expect(menu.getByRole('menuitem', { name: 'Redo', exact: true })).toBeDisabled();
  281 |   await menu.getByRole('menuitem', { name: 'Remove selected lines' }).click();
  282 |   await expect(content).toHaveText('keep');
  283 |   await expect(menu).toHaveCount(0);
  284 |   await expect(more).toBeFocused();
  285 |   await more.click();
  286 |   await menu.getByRole('menuitem', { name: 'Undo', exact: true }).click();
  287 |   await expect(content).toHaveText('keepremove me');
  288 |   await more.click();
  289 |   await menu.getByRole('menuitem', { name: 'Redo', exact: true }).click();
  290 |   await expect(content).toHaveText('keep');
  291 |   await more.press('ArrowDown');
  292 |   await expect(menu.getByRole('menuitem', { name: 'Undo', exact: true })).toBeFocused();
  293 |   await page.keyboard.press('ArrowDown');
  294 |   await expect(menu.getByRole('menuitem', { name: 'Remove selected lines' })).toBeFocused();
  295 |   await page.keyboard.press('Home');
  296 |   await expect(menu.getByRole('menuitem', { name: 'Undo', exact: true })).toBeFocused();
  297 |   await page.keyboard.press('End');
  298 |   await expect(menu.getByRole('menuitem', { name: 'Remove selected lines' })).toBeFocused();
  299 |   await page.keyboard.press('Tab');
  300 |   await expect(menu).toHaveCount(0);
  301 |   await expect(goals.getByRole('button', { name: 'Next', exact: true })).toBeFocused();
  302 |   await more.click();
  303 |   await content.click();
  304 |   await expect(menu).toHaveCount(0);
  305 |   await expect(content).toHaveText('keep');
  306 | });
  307 | 
  308 | test('Goals failures appear once above the fixed bar and dismiss themselves', async ({ page }) => {
  309 |   await openApp(page);
  310 |   const goals = page.locator('.goals');
  311 |   const content = goals.locator('.cm-content');
  312 |   await content.click();
  313 |   await page.keyboard.insertText('retain this');
  314 |   await goals.getByRole('radio', { name: 'Move to', exact: true }).check();
  315 |   const before = await actionBoxes(page);
  316 |   await faults(page);
  317 |   await goals.getByRole('button', { name: 'Done', exact: true }).click();
> 318 |   await expect(page.locator('.workspace-status')).toContainText('Input is waiting for storage.');
      |                                                   ^ Error: expect(locator).toContainText(expected) failed
  319 |   expect(await actionBoxes(page)).toEqual(before);
  320 |   await page
  321 |     .locator('.workspace-status')
  322 |     .getByRole('button', { name: 'Discard pending input' })
  323 |     .click();
  324 |   await allowStorage(page);
  325 |   const feedback = goals.getByRole('status', { name: 'Transfer result' });
  326 |   await expect(feedback).toHaveText('Nothing moved. Try again.');
  327 |   await expect(page.locator('.workspace-status')).toHaveCount(0);
  328 |   expect(await actionBoxes(page)).toEqual(before);
  329 |   const message = (await feedback.boundingBox())!;
  330 |   const footer = (await goals.locator('.goals-actions').boundingBox())!;
  331 |   expect(message.y + message.height).toBeLessThan(footer.y);
  332 |   await expect(feedback).toHaveCount(0, { timeout: 6000 });
  333 |   expect(await actionBoxes(page)).toEqual(before);
  334 |   await expect(content).toHaveText('retain this');
  335 | });
  336 | 
  337 | test('generated compose and history sequences match a separate ledger before and after cold open', async ({
  338 |   browser,
  339 |   baseURL,
  340 | }, info) => {
  341 |   test.setTimeout(120_000);
  342 |   if (!baseURL) throw Error('Native editor tests require a base URL.');
  343 |   const histories = fc.sample(
  344 |     fc.array(fc.constantFrom('compose', 'undo', 'redo'), { minLength: 3, maxLength: 12 }),
  345 |     { seed: 8941, numRuns: 20 },
  346 |   );
  347 |   await info.attach('generated-inputs', {
  348 |     body: JSON.stringify({ seed: 8941, histories }),
  349 |     contentType: 'application/json',
  350 |   });
  351 |   for (const actions of histories) {
  352 |     const context = await browser.newContext({ baseURL, viewport: { width: 1280, height: 900 } });
  353 |     try {
  354 |       const page = await context.newPage();
  355 |       await openApp(page);
  356 |       let values: string[] = [];
  357 |       const undo: string[][] = [],
  358 |         redo: string[][] = [];
  359 |       for (const [index, action] of actions.entries()) {
  360 |         if (action === 'compose') {
  361 |           const text = `entry ${index} 🙂`;
  362 |           await day(page).getByRole('textbox', { name: 'What got done?' }).fill(text);
  363 |           await day(page).getByRole('textbox', { name: 'What got done?' }).press('Enter');
  364 |           undo.push([...values]);
  365 |           redo.length = 0;
  366 |           values.unshift(text);
  367 |         } else if (action === 'undo' && undo.length) {
  368 |           await openMenuSection(page, 'Data');
  369 |           await page.getByRole('button', { name: 'Undo', exact: true }).click();
  370 |           redo.push([...values]);
  371 |           values = undo.pop()!;
  372 |         } else if (action === 'redo' && redo.length) {
  373 |           await openMenuSection(page, 'Data');
  374 |           await page.getByRole('button', { name: 'Redo', exact: true }).click();
  375 |           undo.push([...values]);
  376 |           values = redo.pop()!;
  377 |         }
  378 |         await expect(day(page).locator('.card .card-surface')).toHaveText(values);
  379 |       }
  380 |       await reloadApp(page);
  381 |       await expect(day(page).locator('.card .card-surface')).toHaveText(values);
  382 |     } finally {
  383 |       await context.close();
  384 |     }
  385 |   }
  386 | });
  387 | 
```
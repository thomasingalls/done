# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: startup.spec.ts >> interrupted creation reopens with the saved factor and original identity
- Location: test/local-app/startup.spec.ts:161:1

# Error details

```
Error: expect(locator).toHaveAttribute(expected) failed

Locator: locator('.local-startup')
Expected: "unavailable"
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toHaveAttribute" with timeout 5000ms
  - waiting for locator('.local-startup')
    4 × locator resolved to <main data-state="working" class="local-startup workspace-gate">…</main>
      - unexpected value "working"

```

```yaml
- complementary "Menu":
  - navigation "Day":
    - text: Mon 2 Nov 2026
    - textbox "Go to date": 2026-11-02
    - button "Yesterday"
    - button "Today"
    - button "Tomorrow"
  - group:
    - heading "Account" [level=2]
  - group:
    - heading "Sync" [level=2]
  - group:
    - heading "Data" [level=2]
  - group:
    - heading "Install" [level=2]
- button "Close unfiled cards"
- main "Days":
  - button "Go to Yesterday"
  - button "Go to Tomorrow"
  - region "Today":
    - heading "Mon 2 Nov" [level=1]
    - complementary "Getting started":
      - paragraph: Write everything in Goals. Choose three things for Next. Record what got done.
      - button "Open Goals"
      - button "Dismiss introduction": Dismiss
    - heading "Next 0 of 3" [level=2]: Next 0/3
    - paragraph: The three most important things to focus on next.
    - heading "Done" [level=2]
    - paragraph: Anything you finished counts, planned or unplanned.
    - textbox "What got done?"
    - button "Add" [disabled]
    - heading "Scheduled" [level=2]
    - paragraph: Things planned for this day.
    - textbox "What’s scheduled?"
    - button "Add" [disabled]
- complementary "Goals":
  - heading "Goals" [level=2]:
    - button "Goals. Open document outline": Goals
    - button "Sections inside Goals"
  - status
  - textbox
  - group "Selected lines":
    - group "Transfer selected lines":
      - text: Transfer selected lines
      - radio "Copy to" [checked]
      - text: Copy to
      - radio "Move to"
      - text: Move to
    - button "More Goals actions"
    - button "Next" [disabled]
    - button "Scheduled" [disabled]
    - button "Done" [disabled]
```

# Test source

```ts
  1   | import { openMenuSection } from '../geometry/openApp';
  2   | import { test } from '../release-validation/browser-fixture';
  3   | import { expect, type Page } from '@playwright/test';
  4   | 
  5   | // Explicit protected startup stays covered for compatible stored workspaces.
  6   | // Current automatic first-run and optional protection use the shipped entries in
  7   | // packaged.spec.ts and packaged-account/welcome.spec.ts.
  8   | const app = (page: Page) => page.locator('.local-startup');
  9   | const state = (page: Page, kind: string) =>
  10  |   kind === 'ready'
  11  |     ? expect(page.locator('.shell[data-local-workspace]')).toBeVisible()
> 12  |     : expect(app(page)).toHaveAttribute('data-state', kind);
      |                         ^ Error: expect(locator).toHaveAttribute(expected) failed
  13  | const census = (page: Page) =>
  14  |   page.evaluate(async () => ({
  15  |     databases: (await indexedDB.databases()).map((db) => db.name).sort(),
  16  |     local: { ...localStorage },
  17  |     session: { ...sessionStorage },
  18  |   }));
  19  | const enroll = async (page: Page) => {
  20  |   await state(page, 'fresh');
  21  |   await page.getByRole('button', { name: 'Create a local-only workspace' }).click();
  22  |   const code = (await page.getByLabel('Generated unlock code').textContent())!;
  23  |   await page.getByRole('button', { name: 'I saved my code' }).click();
  24  |   await expect(page.getByLabel('Generated unlock code')).toHaveCount(0);
  25  |   await page.getByLabel('Unlock code', { exact: true }).fill('wrong-code');
  26  |   await page.getByRole('button', { name: 'Confirm and create' }).click();
  27  |   await state(page, 'confirm-code');
  28  |   expect((await census(page)).databases).toEqual([]);
  29  |   await page.getByLabel('Unlock code', { exact: true }).fill(code);
  30  |   await page.getByRole('button', { name: 'Confirm and create' }).click();
  31  |   await state(page, 'ready');
  32  |   return code;
  33  | };
  34  | const lock = async (page: Page) => {
  35  |   await openMenuSection(page, 'Account');
  36  |   await page.getByRole('button', { name: 'Lock workspace', exact: true }).click();
  37  |   await state(page, 'unlock-required');
  38  | };
  39  | 
  40  | test('confirmation is required; reload and offline unlock use the same identity', async ({
  41  |   page,
  42  |   context,
  43  | }) => {
  44  |   const sockets: string[] = [];
  45  |   page.on('websocket', (socket) => sockets.push(socket.url()));
  46  |   await page.goto('/test/local-app/protected-startup.html');
  47  |   await state(page, 'fresh');
  48  |   expect((await census(page)).databases).toEqual([]);
  49  |   await page.getByRole('button', { name: 'Create a local-only workspace' }).click();
  50  |   const cancelled = await page.getByLabel('Generated unlock code').textContent();
  51  |   await page.getByRole('button', { name: 'Cancel', exact: true }).click();
  52  |   await state(page, 'fresh');
  53  |   expect(JSON.stringify(await census(page))).not.toContain(cancelled);
  54  |   const code = await enroll(page);
  55  |   const created = await census(page);
  56  |   expect(created.databases).not.toContain('done');
  57  |   expect(created.local).not.toHaveProperty('done.actor');
  58  |   expect(created.local).not.toHaveProperty('done.device');
  59  |   expect(JSON.stringify(created)).not.toContain(code);
  60  |   await lock(page);
  61  |   await page.reload();
  62  |   await state(page, 'unlock-required');
  63  |   await page.getByLabel('Unlock code', { exact: true }).fill('wrong-code');
  64  |   await page.getByRole('button', { name: 'Unlock', exact: true }).click();
  65  |   await state(page, 'unlock-failed');
  66  |   expect((await census(page)).databases).toEqual(created.databases);
  67  |   await context.setOffline(true);
  68  |   await page.getByLabel('Unlock code', { exact: true }).fill(code);
  69  |   await page.getByRole('button', { name: 'Unlock', exact: true }).click();
  70  |   await state(page, 'ready');
  71  |   expect(sockets.filter((url) => url.includes('/relay'))).toEqual([]);
  72  |   await lock(page);
  73  | });
  74  | 
  75  | test('existing legacy data refuses creation without touching its carriers', async ({ page }) => {
  76  |   await page.goto('/test/local-app/protected-startup.html');
  77  |   await state(page, 'fresh');
  78  |   await page.evaluate(async () => {
  79  |     await new Promise<void>((resolve, reject) => {
  80  |       const request = indexedDB.open('done', 1);
  81  |       request.onupgradeneeded = () => request.result.createObjectStore('updates');
  82  |       request.onsuccess = () => {
  83  |         const db = request.result;
  84  |         const tx = db.transaction('updates', 'readwrite');
  85  |         tx.objectStore('updates').put('retained source sentinel', 1);
  86  |         tx.oncomplete = () => {
  87  |           db.close();
  88  |           resolve();
  89  |         };
  90  |       };
  91  |       request.onerror = () => reject(request.error);
  92  |     });
  93  |     localStorage.setItem('done.pending-update.done.saved.0', '1:retained-journal');
  94  |   });
  95  |   const before = await census(page);
  96  |   await page.reload();
  97  |   await state(page, 'migration-required');
  98  |   await expect(page.getByRole('button', { name: 'Create a local-only workspace' })).toHaveCount(0);
  99  |   expect(await census(page)).toEqual(before);
  100 |   const value = await page.evaluate(
  101 |     () =>
  102 |       new Promise((resolve, reject) => {
  103 |         const request = indexedDB.open('done');
  104 |         request.onsuccess = () => {
  105 |           const db = request.result;
  106 |           const read = db.transaction('updates').objectStore('updates').get(1);
  107 |           read.onsuccess = () => {
  108 |             resolve(read.result);
  109 |             db.close();
  110 |           };
  111 |         };
  112 |         request.onerror = () => reject(request.error);
```
# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: editor.spec.ts >> discarded editor input never appears, and locking disposes the mounted editor
- Location: test/local-app/editor.spec.ts:59:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: locator('.workspace-status')
Expected substring: "Input is waiting for storage."
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toContainText" with timeout 5000ms
  - waiting for locator('.workspace-status')
    - locator resolved to <aside role="status" class="workspace-status">…</aside>
    - unexpected value "Input is waiting to be saved."

```

```yaml
- complementary "Menu":
  - navigation "Day":
    - text: Mon 2 Nov 2026
    - textbox "Go to date": 2026-11-02
    - button "Yesterday"
    - button "Today"
    - button "Tomorrow"
  - group:
    - heading "Account" [level=2]
  - group:
    - heading "Sync" [level=2]
  - group:
    - heading "Data" [level=2]
  - group:
    - heading "Install" [level=2]
- button "Close unfiled cards"
- main "Days":
  - button "Go to Yesterday"
  - button "Go to Tomorrow"
  - region "Today":
    - heading "Mon 2 Nov" [level=1]
    - heading "Next 0 of 3" [level=2]: Next 0/3
    - paragraph: The three most important things to focus on next.
    - heading "Done" [level=2]
    - paragraph: Anything you finished counts, planned or unplanned.
    - textbox "What got done?"
    - button "Add" [disabled]
    - heading "Scheduled" [level=2]
    - paragraph: Things planned for this day.
    - textbox "What’s scheduled?"
    - button "Add" [disabled]
- complementary "Goals":
  - heading "Goals" [level=2]:
    - button "Goals. Open document outline": Goals
    - button "Sections inside Goals"
  - status
  - textbox
  - group "Selected lines":
    - group "Transfer selected lines":
      - text: Transfer selected lines
      - radio "Copy to" [checked]
      - text: Copy to
      - radio "Move to"
      - text: Move to
    - button "More Goals actions"
    - button "Next"
    - button "Scheduled"
    - button "Done"
```

# Test source

```ts
  1   | import { test } from '../release-validation/browser-fixture';
  2   | import { expect, type Page } from '@playwright/test';
  3   | import * as fc from 'fast-check';
  4   | import { openApp, reloadApp, protectApp, openMenuSection } from '../geometry/openApp';
  5   | import { addDays } from '../../src/lib/date';
  6   | const day = (page: Page) => page.locator('.day-panel[data-active="true"]');
  7   | const faults = async (page: Page) =>
  8   |   page.evaluate(() => {
  9   |     const state = { enabled: true, journal: 0, database: 0 };
  10  |     Object.assign(window, { editorFaults: state });
  11  |     const set = Storage.prototype.setItem;
  12  |     Storage.prototype.setItem = function (key, value) {
  13  |       if (state.enabled && key.startsWith('done.pending-update.')) {
  14  |         state.journal++;
  15  |         throw new DOMException('Synthetic quota refusal', 'QuotaExceededError');
  16  |       }
  17  |       return set.call(this, key, value);
  18  |     };
  19  |     const add = IDBObjectStore.prototype.add;
  20  |     IDBObjectStore.prototype.add = function (value, key) {
  21  |       const request = add.call(this, value, key);
  22  |       if (state.enabled && this.name === 'content') {
  23  |         state.database++;
  24  |         request.addEventListener('success', () => this.transaction.abort(), { once: true });
  25  |       }
  26  |       return request;
  27  |     };
  28  |   });
  29  | const allowStorage = async (page: Page) =>
  30  |   page.evaluate(() => {
  31  |     const state = (
  32  |       window as unknown as { editorFaults: { enabled: boolean; journal: number; database: number } }
  33  |     ).editorFaults;
  34  |     state.enabled = false;
  35  |     return { journal: state.journal, database: state.database };
  36  |   });
  37  | 
  38  | test('compose keeps its draft through native refusal; retry admits it once and reopen retains it', async ({
  39  |   page,
  40  | }) => {
  41  |   await openApp(page);
  42  |   await faults(page);
  43  |   const compose = day(page).getByRole('textbox', { name: 'What got done?' });
  44  |   await compose.fill('Retain this pending draft');
  45  |   await compose.press('Enter');
  46  |   await expect(page.locator('.workspace-status')).toContainText('Input is waiting for storage.');
  47  |   await expect(compose).toHaveValue('Retain this pending draft');
  48  |   await expect(day(page).locator('.card')).toHaveCount(0);
  49  |   const seen = await allowStorage(page);
  50  |   expect(seen.journal).toBeGreaterThan(0);
  51  |   expect(seen.database).toBeGreaterThan(0);
  52  |   await page.locator('.workspace-status').getByRole('button', { name: 'Retry storage' }).click();
  53  |   await expect(day(page).locator('.card')).toHaveCount(1);
  54  |   await expect(compose).toHaveValue('');
  55  |   await reloadApp(page);
  56  |   await expect(day(page).locator('.card')).toHaveText(/Retain this pending draft/);
  57  | });
  58  | 
  59  | test('discarded editor input never appears, and locking disposes the mounted editor', async ({
  60  |   page,
  61  | }) => {
  62  |   await openApp(page);
  63  |   await protectApp(page);
  64  |   const content = page.locator('.goals .cm-content');
  65  |   await content.click();
  66  |   await page.keyboard.insertText('accepted');
  67  |   await expect(content).toHaveText('accepted');
  68  |   await faults(page);
  69  |   await page.keyboard.insertText('refused');
> 70  |   await expect(page.locator('.workspace-status')).toContainText('Input is waiting for storage.');
      |                                                   ^ Error: expect(locator).toContainText(expected) failed
  71  |   await expect(content).toHaveText('accepted');
  72  |   await page
  73  |     .locator('.workspace-status')
  74  |     .getByRole('button', { name: 'Discard pending input' })
  75  |     .click();
  76  |   await allowStorage(page);
  77  |   await openMenuSection(page, 'Account');
  78  |   await page.getByRole('button', { name: 'Lock workspace' }).click();
  79  |   await expect(page.locator('.cm-editor')).toHaveCount(0);
  80  |   await expect(page.getByText('accepted', { exact: true })).toHaveCount(0);
  81  |   await reloadApp(page);
  82  |   await expect(page.locator('.goals .cm-content')).toHaveText('accepted');
  83  | });
  84  | 
  85  | test('Goals copy and separate line removal preserve suffix boundaries and workspace undo', async ({
  86  |   page,
  87  | }) => {
  88  |   await openApp(page);
  89  |   const content = page.locator('.goals .cm-content');
  90  |   await content.click();
  91  |   await page.keyboard.insertText('keep\nremove one\nremove two');
  92  |   await expect(content).toHaveText('keepremove oneremove two');
  93  |   await content.press('Home');
  94  |   await content.press('ArrowUp');
  95  |   await content.press('Home');
  96  |   await content.press('Shift+ArrowDown');
  97  |   await content.press('Shift+End');
  98  |   await page.locator('.goals').getByRole('button', { name: 'Next', exact: true }).click();
  99  |   await expect(day(page).locator('.collection[data-section="next"] .card')).toHaveCount(2);
  100 |   await expect(page.locator('.goals-hint')).toHaveCount(0);
  101 |   await expect(content).toHaveText('keepremove oneremove two');
  102 |   await page.getByRole('button', { name: 'More Goals actions' }).click();
  103 |   await page.getByRole('menuitem', { name: 'Remove selected lines' }).click();
  104 |   await expect(content).toHaveText('keep');
  105 |   await page.getByRole('button', { name: 'More Goals actions' }).click();
  106 |   await page.getByRole('menuitem', { name: 'Undo', exact: true }).click();
  107 |   await expect(content).toHaveText('keepremove oneremove two');
  108 |   await reloadApp(page);
  109 |   await expect(day(page).locator('.collection[data-section="next"] .card')).toHaveCount(2);
  110 |   await expect(page.locator('.goals .cm-content')).toHaveText('keepremove oneremove two');
  111 | });
  112 | 
  113 | test('Goals Move is explicit, resets to Copy, disables a full destination and undoes together', async ({
  114 |   page,
  115 | }) => {
  116 |   await openApp(page);
  117 |   const goals = page.locator('.goals');
  118 |   const content = goals.locator('.cm-content');
  119 |   const nextCards = day(page).locator('.collection[data-section="next"] .card');
  120 |   await content.click();
  121 |   await page.keyboard.insertText('keep\ntransfer');
  122 |   await expect(goals.getByRole('radio', { name: 'Copy to', exact: true })).toBeChecked();
  123 |   await expect(page.getByText('Copy keeps the original.')).toHaveCount(0);
  124 |   await goals.getByRole('button', { name: 'Next', exact: true }).click();
  125 |   await expect(nextCards).toHaveCount(1);
  126 |   await expect(content).toHaveText('keeptransfer');
  127 |   await goals.getByRole('radio', { name: 'Move to', exact: true }).check();
  128 |   await goals.getByRole('button', { name: 'Done', exact: true }).click();
  129 |   await expect(content).toHaveText('keep');
  130 |   await expect(day(page).locator('.collection[data-section="done"] .card')).toHaveCount(1);
  131 |   await expect(goals.getByRole('radio', { name: 'Copy to', exact: true })).toBeChecked();
  132 |   await openMenuSection(page, 'Data');
  133 |   await page.getByRole('button', { name: 'Undo', exact: true }).click();
  134 |   await expect(content).toHaveText('keeptransfer');
  135 |   await expect(day(page).locator('.collection[data-section="done"] .card')).toHaveCount(0);
  136 |   await goals.getByRole('button', { name: 'Next', exact: true }).click();
  137 |   await expect(nextCards).toHaveCount(2);
  138 |   await goals.getByRole('button', { name: 'Next', exact: true }).click();
  139 |   await expect(nextCards).toHaveCount(3);
  140 |   await goals.getByRole('radio', { name: 'Move to', exact: true }).check();
  141 |   await expect(goals.getByRole('button', { name: 'Next', exact: true })).toBeDisabled();
  142 |   await expect(goals.getByRole('status', { name: 'Transfer result' })).toHaveCount(0);
  143 |   await expect(content).toHaveText('keeptransfer');
  144 |   await expect(nextCards).toHaveCount(3);
  145 |   await expect(goals.getByRole('radio', { name: 'Move to', exact: true })).toBeChecked();
  146 |   await reloadApp(page);
  147 |   await expect(page.locator('.goals .cm-content')).toHaveText('keeptransfer');
  148 |   await expect(nextCards).toHaveCount(3);
  149 | });
  150 | 
  151 | test('Goals destinations require room for the whole selection in either mode on the focused day', async ({
  152 |   page,
  153 | }) => {
  154 |   await openApp(page);
  155 |   const goals = page.locator('.goals');
  156 |   const content = goals.locator('.cm-content');
  157 |   const toNext = goals.getByRole('button', { name: 'Next', exact: true });
  158 |   const destinations = goals.getByRole('button', { name: /^(Next|Scheduled|Done)$/ });
  159 |   for (const button of await destinations.all()) await expect(button).toBeDisabled();
  160 |   await content.click();
  161 |   await page.keyboard.insertText('- [ ] ');
  162 |   for (const button of await destinations.all()) await expect(button).toBeDisabled();
  163 |   await page.keyboard.insertText('first\n- second');
  164 |   await expect(toNext).toBeEnabled();
  165 |   await toNext.click();
  166 |   await expect(day(page).locator('.collection[data-section="next"] .card')).toHaveCount(1);
  167 |   await toNext.click();
  168 |   await expect(day(page).locator('.collection[data-section="next"] .card')).toHaveCount(2);
  169 |   await content.click();
  170 |   await content.press('ControlOrMeta+a');
```
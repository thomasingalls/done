from pathlib import Path
import json,subprocess,hashlib,tempfile,shutil,sys
r=Path(__file__).parent;repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');registry=r/'PATCHES.json';phase=int(sys.argv[1]);slug=sys.argv[2];base=json.loads((r/'start.json').read_text())['base'];seq=json.loads(registry.read_text())if registry.exists()else{'baseCommit':base,'lane':'release hardening, no new lab phase','sequence':[]};assert(seq['sequence'][-1]['phase']if seq['sequence']else334)==phase-1;sha=lambda b:hashlib.sha256(b).hexdigest();assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==base;assert subprocess.check_output(['git','diff','--cached','--name-only'],cwd=repo,text=True)==''
for z in seq['sequence']:assert sha((r/z['patch']).read_bytes())==z['sha256']
changed=set(subprocess.check_output(['git','diff','--name-only'],cwd=repo,text=True).splitlines());new=subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=repo).decode().rstrip('\0').split('\0');new=[n for n in new if n];work=Path(tempfile.mkdtemp(prefix=f'done-hardening-{phase}-replay-',dir='/private/tmp'))
def g(*args):return subprocess.check_output(['git',*args],cwd=work)
g('init','--quiet')
# Seed each changed tracked path at the signed base, including paths present only in prior patches.
allNames=set(changed)
for z in seq['sequence']:allNames.update(z['paths'])
for n in allNames:
 p=subprocess.run(['git','show',base+':'+n],cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
 if p.returncode==0:
  dst=work/n;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(p.stdout)
for z in seq['sequence']:g('apply',str(r/z['patch']))
def inv():return{str(p.relative_to(work)):sha(p.read_bytes())for p in work.rglob('*')if p.is_file()and'.git'not in p.relative_to(work).parts}
prior=inv();g('add','--all')
for n in prior:
 if not(repo/n).exists():(work/n).unlink()
for n in set(changed)|set(new):
 p=repo/n;assert p.is_file()and not p.is_symlink();dst=work/n;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dst)
added=[n for n in new if n not in prior]
if added:g('add','--intent-to-add',*added)
paths=g('diff','--name-only').decode().splitlines();assert paths;assert all(not n.startswith('docs/performance-experiments/')for n in paths),'prior lab records must stay immutable'
patch=r/f'{phase}-{slug}.patch';assert not patch.exists();patch.write_bytes(g('diff','--binary','--no-ext-diff'));candidate=inv();assert set(paths)=={n for n in set(prior)|set(candidate)if prior.get(n)!=candidate.get(n)}
for n,h in candidate.items():assert sha((repo/n).read_bytes())==h,n
g('apply','--reverse','--check',str(patch));g('apply','--reverse',str(patch));assert inv()==prior;g('apply','--check',str(patch));g('apply',str(patch));assert inv()==candidate;assert subprocess.check_output(['git','diff','--cached','--name-only'],cwd=repo,text=True)==''
meta={'phase':phase,'baseCommit':base,'requires':seq['sequence'][-1]['patch']if seq['sequence']elsebase,'patch':patch.name,'sha256':sha(patch.read_bytes()),'paths':paths,'canonicalHardening':True,'newLabPhase':False,'checks':['immutablepredecessors','signedbase','exactcumulativebytes','forward/reverse','realindexempty','oldlabrecordsuntouched']};(r/f'{phase}-manifest.json').write_text(json.dumps(meta,indent=2)+'\n');seq['sequence'].append(meta);registry.write_text(json.dumps(seq,indent=2)+'\n');print(json.dumps({k:v for k,v in meta.items()if k!='paths'},indent=2));print('Files',len(paths))

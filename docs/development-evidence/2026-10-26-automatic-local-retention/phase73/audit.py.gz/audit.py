from pathlib import Path
import json, subprocess, hashlib
root=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');base='1d503be6abaa5e9f262ddeebfe65bae01c1aa69c'
def old(p):return json.loads(subprocess.check_output(['git','show',base+':'+p],cwd=root))
def now(p):return json.loads((root/p).read_text())
p='docs/account-crypto/census.json';a=old(p);b=now(p)
assert len(a['sources'])==408 and len(b['sources'])==409
assert {s['path'] for s in b['sources']}-{s['path'] for s in a['sources']}=={'src/crdt/automaticLocalRetention.ts'}
def domains(v):
 v=json.loads(json.dumps(v['domains']))
 for d in v:
  for s in d.get('sites',[]):s.pop('line',None)
 return v
assert domains(a)==domains(b)
p='docs/account-crypto/registry.json'
assert subprocess.check_output(['git','show',base+':'+p],cwd=root)==(root/p).read_bytes()
p='docs/account-crypto/constructions.json';previous=old(p);current=now(p)
changed=[]
for a,b in zip(previous['constructions'],current['constructions'],strict=True):
 for x,y in zip(a['sourceSites'],b['sourceSites'],strict=True):
  if x!=y:
   assert x['path']==y['path']=='src/crdt/accountReceive.ts' and x['line']==704 and y['line']==711
   assert (root/y['path']).read_text().splitlines()[y['line']-1].find(y['label'])>=0
   changed.append([x['line'],y['line']]);x['line']=y['line']
assert previous==current and changed==[[704,711]]
p='docs/release-validation-graph.json';a=old(p);b=now(p)
oldtests={x['path']:x for x in a['tests']};newtests={x['path']:x for x in b['tests']}
assert set(newtests)-set(oldtests)=={'test/automaticLocalRetention.test.ts','test/local-baseline/automatic.node.mjs'}
assert all(newtests[p]==v for p,v in oldtests.items())
p='docs/release-validation-manifest.json';a=old(p);b=now(p)
oldrows={r['id']:r for r in a['rows']};newrows={r['id']:r for r in b['rows']}
assert not(set(oldrows)-set(newrows))
assert set(a['unresolved'])<=set(b['unresolved'])
assert len(a['rows'])==902 and len(b['rows'])==904 and len(a['unresolved'])==358 and len(b['unresolved'])==360
added=sorted(set(newrows)-set(oldrows));assert added==['test:test/automaticLocalRetention.test.ts','test:test/local-baseline/automatic.node.mjs']
assert all(p in b['unresolved'] for p in added)
for p in ['test/localRetentionStorage.test.ts','test/retentionFences.test.ts','test/local-baseline/removal.native.mjs']:
 assert subprocess.check_output(['git','show',base+':'+p],cwd=root)==(root/p).read_bytes()
result={'baseTree':base,'runtimeSources':[408,409],'domains':197,'domainsAndSourceSitesUnchangedExceptLineOffsets':True,'ownershipAndConstructionDefinitionsUnchanged':True,'sourceCoordinateRefresh':{'path':'src/crdt/accountReceive.ts','before':704,'after':711},'oldTestsAndInvocationsPreserved':True,'existingSafetyTestBytesUnchanged':True,'obligations':[902,904],'unresolved':[358,360],'addedRequiredUncredited':added,'aggregateBlocked':b['status']=='blocked'}
print(json.dumps(result,indent=2))

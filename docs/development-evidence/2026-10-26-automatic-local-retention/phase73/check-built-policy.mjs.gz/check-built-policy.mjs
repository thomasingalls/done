import assert from 'node:assert/strict';
import { readFileSync, readdirSync } from 'node:fs';
import { createRequire } from 'node:module';
const { parseSync } = createRequire('/Users/thomasingalls/.codex/worktrees/7fda/done/package.json')('@babel/core');
const dir = '/private/tmp/done-auto-retention-2026-10-26/dist/assets';
const found = [];
for (const file of readdirSync(dir).filter(f => f.endsWith('.js'))) {
  const source = parseSync(readFileSync(dir + '/' + file, 'utf8'), { babelrc: false, configFile: false, sourceType: 'module' });
  const visit = node => {
    if (node.type === 'MemberExpression' && node.property.name === 'VITE_ACCOUNT_RETENTION_AUTO') {
      assert(node.object.type === 'ObjectExpression', 'Expected a build-bound environment, not a mutable runtime policy');
      const flags = Object.fromEntries(node.object.properties.filter(p => p.type === 'ObjectProperty').map(p => [p.key.name, p.value.type === 'TemplateLiteral' ? p.value.quasis[0].value.cooked : p.value.value]));
      assert.equal(flags.VITE_ACCOUNT_BASELINE_READ, '1');
      for (const flag of ['VITE_ACCOUNT_BASELINE_INSTALL', 'VITE_ACCOUNT_RETENTION', 'VITE_ACCOUNT_RETENTION_AUTO']) assert.equal(flags[flag], '0');
      found.push({ file, flags: Object.fromEntries(Object.entries(flags).filter(([k]) => /BASELINE|RETENTION/.test(k))) });
    }
    for (const value of Object.values(node)) {
      if (Array.isArray(value)) value.forEach(v => { if (v && typeof v.type === 'string') visit(v); });
      else if (value && typeof value.type === 'string') visit(value);
    }
  };
  visit(source);
}
assert(found.length > 0, 'Must inspect actual emitted gate reads');
console.log(JSON.stringify({ publicWriterAndPolicyDisabled: true, compiledGateReads: found }, null, 2));

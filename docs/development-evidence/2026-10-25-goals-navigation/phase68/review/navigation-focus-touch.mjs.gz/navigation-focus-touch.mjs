import { chromium } from '/Users/thomasingalls/.codex/worktrees/7fda/done/node_modules/@playwright/test/index.mjs';
import { writeFileSync } from 'node:fs';

const browser = await chromium.launch({ executablePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome' });
const context = await browser.newContext({ viewport: { width: 360, height: 900 }, isMobile: true, hasTouch: true });
const page = await context.newPage();
const errors = [];
page.on('pageerror', error => errors.push(error.message));
const results = { source: 'Fresh ephemeral Chromium context, phase67 built app on loopback53921', errors };
try {
  await page.goto('http://127.0.0.1:53921/');
  await page.locator('.shell[data-local-workspace]').waitFor();
  await page.keyboard.press('Alt+ArrowRight');
  await page.locator('.shell[data-goals="open"]').waitFor();
  const editor = page.locator('.goals .cm-content');
  await editor.click();
  const names = ['Work root', 'Studio projects', 'Site refresh', 'Public launch', 'Final details', 'Leaf destination'];
  const doc = names.map((name, index) => '#'.repeat(index + 1) + ' ' + name + '\n' + Array.from({ length: 40 }, (_, n) => name + ' note ' + n).join('\n')).join('\n');
  await page.keyboard.insertText(doc);
  await page.waitForFunction(text => document.querySelector('.goals .cm-content')?.cmTile.root.view.state.doc.toString() === text, doc);
  await page.locator('.goals-breadcrumbs').click();
  await page.getByRole('navigation', { name: 'Document outline' }).getByRole('button', { name: names.at(-1), exact: true }).click();
  await page.waitForFunction(() => document.querySelector('.goals-breadcrumbs')?.title.endsWith('Leaf destination'));
  await page.getByRole('button', { name: 'Sections inside Leaf destination', exact: true }).click();
  const local = page.locator('#goals-heading-menu');
  await local.getByRole('button').first().focus();
  results.focusBeforeNavigation = await page.evaluate(() => ({ tag: document.activeElement.tagName, text: document.activeElement.textContent }));
  await page.keyboard.press('Enter');
  await local.waitFor({ state: 'hidden' });
  results.focusAfterNavigation = await page.evaluate(() => ({ tag: document.activeElement.tagName, className: document.activeElement.className, text: document.activeElement.textContent.slice(0, 100) }));
  const trail = page.locator('.goals-breadcrumb-trail');
  const box = await trail.boundingBox();
  results.beforeSwipe = await trail.evaluate(element => ({ left: element.scrollLeft, width: element.clientWidth, total: element.scrollWidth, touchAction: getComputedStyle(element).touchAction, parentTouchAction: getComputedStyle(element.closest('.panel-header')).touchAction, goals: document.querySelector('.shell').dataset.goals }));
  const cdp = await context.newCDPSession(page);
  const start = box.x + box.width * 0.35, y = box.y + box.height / 2;
  await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x: start, y }] });
  for (let n = 1; n <= 12; n++) {
    await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x: start + n * 8, y }] });
    await page.waitForTimeout(20);
  }
  await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
  await page.waitForTimeout(400);
  results.afterSwipe = await trail.evaluate(element => ({ left: element.scrollLeft, width: element.clientWidth, total: element.scrollWidth, goals: document.querySelector('.shell').dataset.goals }));
} catch (error) {
  results.failure = error.stack;
  process.exitCode = 1;
} finally {
  await browser.close();
  writeFileSync('/private/tmp/done-goals-implementation-2026-10-25/review/navigation-focus-touch.json', JSON.stringify(results, null, 2) + '\n');
  console.log(JSON.stringify(results, null, 2));
}

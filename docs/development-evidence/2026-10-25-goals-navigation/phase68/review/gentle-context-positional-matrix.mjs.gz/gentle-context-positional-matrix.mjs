import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';

const root = process.argv[2] ?? '/Users/thomasingalls/.codex/worktrees/7fda/done';
const url = pathToFileURL(root + '/');
const { EditorState, EditorSelection } = await import(new URL('node_modules/@codemirror/state/dist/index.js', url));
const { markdown } = await import(new URL('node_modules/@codemirror/lang-markdown/dist/index.js', url));
const { ensureSyntaxTree } = await import(new URL('node_modules/@codemirror/language/dist/index.js', url));
const { gentleContextPlan } = await import(new URL('src/editor/gentleContext.ts', url));

// This is the exact nine-document, every-position matrix run during the initial
// read-only phase66 challenge. The reference independently walks the complete
// syntax tree; it does not call the production heading traversal or planner.
const samples = [
  '# A\ntext\n## B\ntwo\n### C\nthree\n# D\nend',
  '# A\n> ## Quote\n> quote text\nplain\n# B\nmore',
  '# A\n- ## Item\n  item text\n- another\nplain\n# B',
  'Area\n====\ntext\nChild\n-----\nmore\n# B',
  '# A\n\n```\n# Fake\n```\n\n# B\nlast',
  '# A\n\n***\n\n# B',
  '# A',
  '# A\n',
  '# A\n# B\n',
];
let comparisons = 0;
const errors = [];
for (const doc of samples) {
  for (let pos = 0; pos <= doc.length; pos++) {
    const state = EditorState.create({
      doc,
      selection: EditorSelection.single(pos),
      extensions: [markdown()],
    });
    const tree = ensureSyntaxTree(state, doc.length, 5000);
    if (!tree) throw Error('Reference parser did not finish a small sample');
    const headings = [];
    tree.iterate({
      enter(node) {
        const match = /^(?:ATX|Setext)Heading([1-6])$/u.exec(node.name);
        if (match) headings.push({ from: node.from, to: node.to, level: Number(match[1]) });
      },
    });
    const path = [];
    for (const heading of headings) {
      if (heading.from > pos) break;
      while (path.length && path.at(-1).level >= heading.level) path.pop();
      path.push(heading);
    }
    const active = path.at(-1);
    const actual = gentleContextPlan(state);
    if (!active) {
      if (actual) errors.push({ doc, pos, actual, expected: null });
      continue;
    }
    const expectedHead = path.slice(-2).map(heading => heading.from);
    const expectedNext = headings.find(heading => heading.from > active.from && heading.level <= active.level)?.from ?? doc.length + 1;
    if (
      !actual ||
      JSON.stringify(actual.headings.map(heading => heading.from)) !== JSON.stringify(expectedHead) ||
      actual.section.from !== active.from ||
      actual.section.to !== expectedNext
    ) errors.push({ doc, pos, actual, expected: { headings: expectedHead, from: active.from, to: expectedNext } });
    comparisons++;
  }
}
console.log(JSON.stringify({
  method: 'Every character boundary of nine authored Markdown samples; independent complete-tree ancestry traversal',
  source: 'src/editor/gentleContext.ts',
  sourceSha256: createHash('sha256').update(readFileSync(new URL('src/editor/gentleContext.ts', url))).digest('hex'),
  runtime: process.version,
  documentCount: samples.length,
  comparisons,
  errorCount: errors.length,
  errors,
  samples,
  limits: 'Pure planner comparison only. No DOM measurement, queued-dispatch lifetime, admission, IME, phone, or performance claim.',
}, null, 2));
if (comparisons !== 225 || errors.length) process.exitCode = 1;

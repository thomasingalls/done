# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: card-focus.spec.ts >> merge focus can leave by clicking another input and stays there while typing
- Location: test/geometry/card-focus.spec.ts:64:3

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  locator('.day-panel[data-active="true"] .card[data-section="scheduled"]').filter({ hasText: 'another task' })
Expected: 1
Received: 0
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" with timeout 5000ms
  - waiting for locator('.day-panel[data-active="true"] .card[data-section="scheduled"]').filter({ hasText: 'another task' })
    14 × locator resolved to 0 elements
       - unexpected value "0"

```

# Page snapshot

```yaml
- generic [ref=f1e3]:
  - complementary "Menu" [ref=f1e4]:
    - navigation "Day" [ref=f1e5]:
      - generic [ref=f1e6] [cursor=pointer]:
        - generic [ref=f1e7]: Sun 25 Oct 2026
        - textbox "Go to date" [ref=f1e11]: 2026-10-25
      - generic [ref=f1e12]:
        - button "Yesterday" [ref=f1e13] [cursor=pointer]
        - button "Today" [ref=f1e14] [cursor=pointer]
        - button "Tomorrow" [ref=f1e15] [cursor=pointer]
    - group [ref=f1e16]:
      - heading "Account" [level=2] [ref=f1e18] [cursor=pointer]
      - option "00:00" [selected]
      - option "01:00"
      - option "02:00"
      - option "03:00"
      - option "04:00"
      - option "05:00"
      - option "06:00"
      - option "07:00"
      - option "08:00"
      - option "09:00"
      - option "10:00"
      - option "11:00"
      - option "12:00"
      - option "13:00"
      - option "14:00"
      - option "15:00"
      - option "16:00"
      - option "17:00"
      - option "18:00"
      - option "19:00"
      - option "20:00"
      - option "21:00"
      - option "22:00"
      - option "23:00"
    - group [ref=f1e19]:
      - heading "Sync" [level=2] [ref=f1e21] [cursor=pointer]
    - group [ref=f1e22]:
      - heading "Data" [level=2] [ref=f1e24] [cursor=pointer]
    - group [ref=f1e25]:
      - heading "Install" [level=2] [ref=f1e27] [cursor=pointer]
  - complementary [ref=f1e28]:
    - generic [ref=f1e29]:
      - heading [level=2] [ref=f1e30]: Unfiled
      - generic [ref=f1e31]: "0"
      - button [ref=f1e32] [cursor=pointer]: Close
    - paragraph [ref=f1e34]: These cards were retained because their original collection can no longer display them. Choose a new home or remove them explicitly.
  - button "Close unfiled cards"
  - button "Close"
  - main "Days" [ref=f1e36]:
    - generic:
      - button "Go to Yesterday" [ref=f1e37] [cursor=pointer]
      - button "Go to Tomorrow" [ref=f1e38] [cursor=pointer]
    - generic [ref=f1e39]:
      - region:
        - generic:
          - heading [level=1]: Sat 24 Oct
          - button: Today
        - generic:
          - generic:
            - heading [level=2]:
              - generic: Next
              - generic: 0/3
            - paragraph: The three most important things to focus on next.
          - generic:
            - heading [level=2]:
              - generic: Done
            - paragraph: Anything you finished counts, planned or unplanned.
            - generic:
              - textbox:
                - /placeholder: What got done?
              - button [disabled]: Add
          - generic:
            - heading [level=2]:
              - generic: Scheduled
            - paragraph: Things planned for this day.
            - generic:
              - textbox:
                - /placeholder: What’s scheduled?
              - button [disabled]: Add
      - region "Today" [ref=f1e40]:
        - generic [ref=f1e41]:
          - button "Open menu" [ref=f1e42] [cursor=pointer]
          - heading "Sun 25 Oct" [level=1] [ref=f1e45]
          - button "Open Goals" [ref=f1e46] [cursor=pointer]: Goals →
        - generic [ref=f1e47]:
          - generic [ref=f1e48]:
            - heading "Next 0 of 3" [level=2] [ref=f1e49]:
              - generic [ref=f1e50]: Next
              - generic "0 of 3" [ref=f1e51]: 0/3
            - paragraph [ref=f1e52]: The three most important things to focus on next.
          - generic [ref=f1e53]:
            - heading "Done" [level=2] [ref=f1e54]
            - paragraph [ref=f1e56]: Anything you finished counts, planned or unplanned.
            - generic [ref=f1e57]:
              - textbox "What got done?" [ref=f1e58]
              - button "Add" [disabled] [ref=f1e59]
          - generic [ref=f1e60]:
            - heading "Scheduled" [level=2] [ref=f1e61]
            - article [ref=f1e64]:
              - generic "head|tail" [ref=f1e65]
              - generic [ref=f1e67]:
                - 'button "Move to Done: head|tail" [ref=f1e68] [cursor=pointer]': Done
                - 'button "Move to Next: head|tail" [ref=f1e69] [cursor=pointer]': Next
                - 'button "Move to tomorrow: head|tail" [ref=f1e70] [cursor=pointer]': Tomorrow
                - 'button "Duplicate to Scheduled: head|tail" [ref=f1e71] [cursor=pointer]': Duplicate
                - 'button "Remove this card: head|tail" [ref=f1e72] [cursor=pointer]': Remove
            - generic [ref=f1e73]:
              - textbox "What’s scheduled?" [ref=f1e74]
              - button "Add" [disabled] [ref=f1e75]
      - region:
        - generic:
          - heading [level=1]: Mon 26 Oct
          - button: Today
        - generic:
          - generic:
            - heading [level=2]:
              - generic: Next
              - generic: 0/3
            - paragraph: The three most important things to focus on next.
          - generic:
            - heading [level=2]:
              - generic: Done
            - paragraph: Anything you finished counts, planned or unplanned.
            - generic:
              - textbox:
                - /placeholder: What got done?
              - button [disabled]: Add
          - generic:
            - heading [level=2]:
              - generic: Scheduled
            - paragraph: Things planned for this day.
            - generic:
              - textbox:
                - /placeholder: What’s scheduled?
              - button [disabled]: Add
  - complementary "Goals" [ref=f1e76]:
    - generic [ref=f1e77]:
      - heading "Goals" [level=2] [ref=f1e78]:
        - button "Goals. Open document outline" [ref=f1e80] [cursor=pointer]:
          - generic [ref=f1e81]: Goals
      - button "Close Goals" [ref=f1e85] [cursor=pointer]: Close
    - generic [ref=f1e87]:
      - status
      - textbox [ref=f1e90]:
        - generic [ref=f1e91]: Your running list of tasks, projects, someday-maybes, notes to self, and ideas.
    - group "Selected lines" [ref=f1e93]:
      - generic [ref=f1e94]:
        - group "Transfer selected lines" [ref=f1e95]:
          - generic [ref=f1e97] [cursor=pointer]:
            - radio "Copy to" [checked] [ref=f1e98]
            - generic: Copy to
          - generic [ref=f1e99] [cursor=pointer]:
            - radio "Move to" [ref=f1e100]
            - generic: Move to
        - button "More Goals actions" [ref=f1e102] [cursor=pointer]
      - generic [ref=f1e107]:
        - button "Next" [disabled] [ref=f1e108]
        - button "Scheduled" [disabled] [ref=f1e109]
        - button "Done" [disabled] [ref=f1e110]
```

# Test source

```ts
  1  | import { devices, expect, type Page } from '@playwright/test';
  2  | import { test } from '../release-validation/browser-fixture';
  3  | import { openApp, reloadApp } from './openApp';
  4  | 
  5  | const scheduled = (page: Page) =>
  6  |   page.locator('.day-panel[data-active="true"] .card[data-section="scheduled"]');
  7  | const field = (page: Page) =>
  8  |   page.locator('.day-panel[data-active="true"]').getByRole('textbox', {
  9  |     name: 'What’s scheduled?',
  10 |   });
  11 | 
  12 | // Use Mac hardware bindings in both layouts, independently of Android's virtual
  13 | // keyboard event synthesis. This tests focus ownership, not a physical phone IME.
  14 | test.use({
  15 |   userAgent: devices['Desktop Chrome'].userAgent.replace(
  16 |     /\([^)]*\)/,
  17 |     '(Macintosh; Intel Mac OS X 10_15_7)',
  18 |   ),
  19 | });
  20 | test.beforeEach(async ({ page }) => {
  21 |   await page.addInitScript(() =>
  22 |     Object.defineProperty(navigator, 'platform', { get: () => 'MacIntel' }),
  23 |   );
  24 |   await openApp(page);
  25 | });
  26 | 
  27 | const add = async (page: Page, text: string) => {
  28 |   await field(page).fill(text);
  29 |   await field(page).press('Enter');
  30 |   await expect(field(page)).toHaveValue('');
  31 | };
  32 | 
  33 | const split = async (page: Page) => {
  34 |   await add(page, 'headtail');
  35 |   await scheduled(page).first().locator('.card-surface').click();
  36 |   const editor = scheduled(page).first().locator('.cm-content');
  37 |   await editor.press('Home');
  38 |   for (let i = 0; i < 4; i++) await editor.press('ArrowRight');
  39 |   for (let i = 0; i < 3; i++) await editor.press('Shift+Enter');
  40 |   await expect(scheduled(page)).toHaveCount(2);
  41 |   const card = scheduled(page).nth(1);
  42 |   await expect(card.locator('.cm-content')).toBeFocused();
  43 |   return card;
  44 | };
  45 | 
  46 | const merge = async (page: Page) => {
  47 |   await add(page, 'head');
  48 |   await add(page, 'tail');
  49 |   await scheduled(page).nth(1).locator('.card-surface').click();
  50 |   const editor = scheduled(page).nth(1).locator('.cm-content');
  51 |   await editor.press('Home');
  52 |   await editor.press('Backspace');
  53 |   await expect(scheduled(page)).toHaveCount(1);
  54 |   const card = scheduled(page).first();
  55 |   await expect(card.locator('.cm-content')).toBeFocused();
  56 |   await expect(card.locator('.cm-content')).toHaveText('headtail');
  57 |   return card;
  58 | };
  59 | 
  60 | for (const [name, focus] of [
  61 |   ['split', split],
  62 |   ['merge', merge],
  63 | ] as const) {
  64 |   test(`${name} focus can leave by clicking another input and stays there while typing`, async ({
  65 |     page,
  66 |   }) => {
  67 |     const card = await focus(page);
  68 |     await page.keyboard.insertText('|');
  69 |     await field(page).click();
  70 |     await expect(card).toHaveAttribute('data-editing', 'false');
  71 |     await expect(field(page)).toBeFocused();
  72 |     await field(page).pressSequentially('another task');
  73 |     await expect(field(page)).toHaveValue('another task');
  74 |     await field(page).press('Enter');
  75 |     await expect(card).toHaveAttribute('data-editing', 'false');
  76 |     await expect(field(page)).toBeFocused();
  77 |     await reloadApp(page);
> 78 |     await expect(scheduled(page).filter({ hasText: 'another task' })).toHaveCount(1);
     |                                                                       ^ Error: expect(locator).toHaveCount(expected) failed
  79 |     await expect(scheduled(page).filter({ hasText: '|tail' })).toHaveCount(1);
  80 |   });
  81 | 
  82 |   test(`${name} focus can Tab through its actions and leave the card`, async ({ page }) => {
  83 |     const card = await focus(page);
  84 |     // Internal action focus must not relock/unmount the card before activation.
  85 |     const done = card.getByRole('button', { name: /^Move to Done:/ });
  86 |     await done.focus();
  87 |     await expect(card).toHaveAttribute('data-editing', 'true');
  88 |     await expect(done).toBeFocused();
  89 |     const remove = card.getByRole('button', { name: /^Remove this card:/ });
  90 |     await remove.focus();
  91 |     await remove.press('Tab');
  92 |     await expect(card).toHaveAttribute('data-editing', 'false');
  93 |     await expect(field(page)).toBeFocused();
  94 |     await field(page).press('Shift+Tab');
  95 |     await expect(remove).toBeFocused();
  96 |     await expect(card).toHaveAttribute('data-editing', 'false');
  97 |   });
  98 | }
  99 | 
```
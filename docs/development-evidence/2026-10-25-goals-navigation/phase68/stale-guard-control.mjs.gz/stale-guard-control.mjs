import {readFileSync} from 'node:fs';
import {build} from '/Users/thomasingalls/.codex/worktrees/7fda/done/node_modules/vite/dist/node/index.js';
let replacements=0;
await build({root:'/Users/thomasingalls/.codex/worktrees/7fda/done',build:{outDir:'/private/tmp/done-goals-implementation-2026-10-25/stale-guard-control-dist',emptyOutDir:true},plugins:[{name:'stale-guard-sensitivity-control',enforce:'pre',load(id){if(!id.endsWith('/src/ui/GoalsNavigation.tsx'))return;const code=readFileSync(id,'utf8');const from='view.state.doc !== snapshot ||';if(!code.includes(from))throw Error('Stale guard mutation anchor missing');replacements++;return code.replace(from,'false ||');}}]});
if(replacements!==1)throw Error(`Expected one mutation, got ${replacements}`);
console.log('CONTROL: removed only menu document-identity guard, exactly once; no source file edited.');

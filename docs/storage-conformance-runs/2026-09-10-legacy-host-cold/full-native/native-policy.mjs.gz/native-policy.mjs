import { createRequire } from "node:module";
import assert from "node:assert/strict";
import { existsSync, mkdirSync, readFileSync, renameSync, rmSync, writeFileSync } from "node:fs";
import { extname, join } from "node:path";
import { spawn } from "node:child_process";
import { EventEmitter } from "node:events";
import { createHash } from "node:crypto";
import { createServer } from "node:http";
//#region scripts/legacy-cleanup/diagnostics.mjs
var HarnessTimeout = class extends Error {
	constructor(label, ms) {
		super(`${label} exceeded ${ms} ms`);
		this.name = "HarnessTimeout";
		this.code = "HARNESS_TIMEOUT";
	}
};
const atomicJSON = (path, value) => {
	const temp = `${path}.${process.pid}.tmp`;
	writeFileSync(temp, JSON.stringify(value, null, 2) + "\n");
	renameSync(temp, path);
};
const within = async (label, ms, operation) => {
	let timer;
	try {
		return await Promise.race([Promise.resolve().then(operation), new Promise((_, reject) => {
			timer = setTimeout(() => reject(new HarnessTimeout(label, ms)), ms);
		})]);
	} finally {
		clearTimeout(timer);
	}
};
//#endregion
//#region scripts/legacy-host/cdp.mjs
/** Separate debugger connection: no automation library silently resumes quarantined targets. */
var CDP = class CDP extends EventEmitter {
	constructor(socket, timeout) {
		super();
		this.socket = socket;
		this.timeout = timeout;
		this.next = 0;
		this.pending = /* @__PURE__ */ new Map();
		this.disconnected = false;
		socket.addEventListener("message", ({ data }) => {
			const message = JSON.parse(data);
			if (message.id) {
				const pending = this.pending.get(message.id);
				if (!pending) return;
				this.pending.delete(message.id);
				if (message.error) pending.reject(/* @__PURE__ */ new Error(`CDP ${pending.method}: ${message.error.message}`));
				else pending.resolve(message.result);
			} else this.emit(message.method, message.params, message.sessionId);
		});
		socket.addEventListener("close", () => {
			this.disconnected = true;
			for (const pending of this.pending.values()) pending.reject(/* @__PURE__ */ new Error("CDP disconnected"));
			this.pending.clear();
			this.emit("disconnected");
		});
	}
	static async connect(url, timeout = 15e3) {
		const socket = new WebSocket(url);
		await within("debugger connection", timeout, () => new Promise((resolve, reject) => {
			socket.addEventListener("open", resolve, { once: true });
			socket.addEventListener("error", () => reject(/* @__PURE__ */ new Error("Debugger connection failed")), { once: true });
		}));
		return new CDP(socket, timeout);
	}
	async send(method, params = {}, sessionId) {
		const id = ++this.next;
		try {
			return await within(`CDP ${method}`, this.timeout, () => new Promise((resolve, reject) => {
				if (this.disconnected) {
					reject(/* @__PURE__ */ new Error("CDP disconnected"));
					return;
				}
				this.pending.set(id, {
					method,
					resolve,
					reject
				});
				this.socket.send(JSON.stringify({
					id,
					method,
					params,
					...sessionId ? { sessionId } : {}
				}));
			}));
		} finally {
			this.pending.delete(id);
		}
	}
	async evaluate(sessionId, expression) {
		const result = await this.send("Runtime.evaluate", {
			expression,
			awaitPromise: true,
			returnByValue: true
		}, sessionId);
		if (result.exceptionDetails) throw new Error(`Fixture evaluation: ${result.exceptionDetails.exception?.description ?? result.exceptionDetails.text}`);
		return result.result.value;
	}
	async close() {
		if (this.socket.readyState === WebSocket.CLOSED) return;
		await within("debugger close", this.timeout, () => new Promise((resolve) => {
			this.socket.addEventListener("close", resolve, { once: true });
			this.socket.close();
		}));
	}
};
const eventually = async (label, read, predicate = Boolean, ms = 1e4) => within(label, ms, async () => {
	for (;;) {
		const value = await read();
		if (predicate(value)) return value;
		await new Promise((resolve) => setTimeout(resolve, 25));
	}
});
//#endregion
//#region scripts/legacy-host-cold/checks.mjs
async function poll(label, read, predicate = Boolean, ms = 1e4) {
	const deadline = Date.now() + ms;
	while (Date.now() < deadline) {
		const value = await within(label, Math.max(1, deadline - Date.now()), read);
		if (predicate(value)) return value;
		await new Promise((resolve) => setTimeout(resolve, Math.min(25, Math.max(1, deadline - Date.now()))));
	}
	throw Error(label + " timed out");
}
function denialConfig(text, { readonly, mandatory, beforeLaunch }) {
	assert.ok(readonly && mandatory && beforeLaunch, "denial-runtime-preconditions");
	assert.deepEqual(JSON.parse(text), { DefaultJavaScriptSetting: 2 }, "denial-exact-global-policy");
}
//#endregion
//#region scripts/legacy-host-cold/browser.mjs
async function launch(output, name, startup = "about:blank", connect = true, { restore = false } = {}) {
	if (!/^[a-z0-9-]+$/u.test(name)) throw Error("profile-name");
	const profile = join(output, "profiles", name);
	mkdirSync(profile, { recursive: true });
	const portFile = join(profile, "DevToolsActivePort");
	if (existsSync(portFile)) rmSync(portFile);
	const args = [
		"--headless=new",
		"--no-first-run",
		"--no-default-browser-check",
		"--disable-background-networking",
		"--disable-component-update",
		"--disable-sync",
		"--disable-extensions",
		"--disable-default-apps",
		"--password-store=basic",
		"--remote-debugging-port=0",
		"--enable-automation",
		`--user-data-dir=${profile}`,
		...restore ? ["--restore-last-session"] : [],
		startup
	];
	const child = spawn("/usr/bin/chromium", args, {
		detached: true,
		stdio: [
			"ignore",
			"ignore",
			"pipe"
		]
	});
	process.send?.({
		type: "browser-start",
		pid: child.pid
	});
	let exited = false, stderr = "";
	child.stderr.on("data", (chunk) => {
		stderr = (stderr + chunk).slice(-4e3);
	});
	const exit = new Promise((resolve, reject) => {
		child.once("error", reject);
		child.once("exit", (code, signal) => {
			exited = true;
			process.send?.({
				type: "browser-exit",
				pid: child.pid
			});
			resolve({
				code,
				signal
			});
		});
	});
	let cdp;
	const kill = () => {
		try {
			process.kill(-child.pid, "SIGKILL");
		} catch (e) {
			if (e.code !== "ESRCH") throw e;
		}
	};
	const browser = {
		child,
		profile,
		args,
		exit,
		get cdp() {
			return cdp;
		},
		get exited() {
			return exited;
		},
		async connect() {
			const [port, path] = await eventually("browser endpoint", () => {
				if (exited) throw Error("browser-start-failed: " + stderr);
				return existsSync(portFile) ? readFileSync(portFile, "utf8").trim().split("\n") : null;
			}, (x) => x?.length === 2);
			cdp = await CDP.connect(`ws://127.0.0.1:${port}${path}`);
			return cdp;
		},
		async disconnect() {
			await cdp?.close();
			cdp = null;
		},
		async stop(force = false) {
			try {
				if (!exited) if (force || !cdp) kill();
				else await cdp.send("Browser.close").catch(kill);
				await within("browser exit", 1e4, () => exit);
			} finally {
				if (!exited) kill();
				await cdp?.close().catch(() => {});
				cdp = null;
			}
		}
	};
	try {
		if (connect) await browser.connect();
		return browser;
	} catch (e) {
		await browser.stop(true);
		throw e;
	}
}
async function page(browser, url) {
	const { targetId } = await browser.cdp.send("Target.createTarget", { url });
	await eventually("page navigation", async () => {
		const { targetInfos } = await browser.cdp.send("Target.getTargets");
		return targetInfos.some((t) => t.targetId === targetId && t.url === url);
	});
	const { sessionId } = await browser.cdp.send("Target.attachToTarget", {
		targetId,
		flatten: true
	});
	try {
		await frameReady(browser, sessionId, url);
	} finally {
		await browser.cdp.send("Target.detachFromTarget", { sessionId }).catch(() => {});
	}
	return targetId;
}
async function frameReady(browser, sessionId, url) {
	return poll("committed frame", async () => {
		try {
			return (await browser.cdp.send("Page.getFrameTree", {}, sessionId)).frameTree.frame;
		} catch (e) {
			if (e.message.includes("Not attached to an active page")) return null;
			throw e;
		}
	}, (f) => f?.url === url && Boolean(f.loaderId));
}
async function inertPage(browser, origin) {
	const id = await page(browser, "about:blank");
	const { sessionId } = await browser.cdp.send("Target.attachToTarget", {
		targetId: id,
		flatten: true
	});
	try {
		await browser.cdp.send("Network.enable", {}, sessionId);
		await browser.cdp.send("Network.setBypassServiceWorker", { bypass: true }, sessionId);
		await browser.cdp.send("Page.navigate", { url: origin + "/inert" }, sessionId);
		await frameReady(browser, sessionId, origin + "/inert");
	} catch (e) {
		await browser.cdp.send("Target.closeTarget", { targetId: id }).catch(() => {});
		throw e;
	}
	return id;
}
async function policyTable(browser) {
	const id = await page(browser, "chrome://policy/");
	const { sessionId } = await browser.cdp.send("Target.attachToTarget", {
		targetId: id,
		flatten: true
	});
	const flatten = (node) => [
		node.nodeType === 3 ? node.nodeValue : "",
		...(node.children ?? []).flatMap(flatten),
		...(node.shadowRoots ?? []).flatMap(flatten),
		...node.contentDocument ? flatten(node.contentDocument) : []
	];
	try {
		return await eventually("effective policy DOM", async () => {
			const { root } = await browser.cdp.send("DOM.getDocument", {
				depth: -1,
				pierce: true
			}, sessionId);
			const rows = [];
			const walk = (node) => {
				if (node.localName === "policy-row") rows.push(flatten(node).filter(Boolean));
				for (const child of [...node.children ?? [], ...node.shadowRoots ?? []]) walk(child);
			};
			walk(root);
			return {
				rows: rows.filter((r) => !r.includes("Not set.")),
				text: flatten(root).filter(Boolean).filter((t) => t === "DefaultJavaScriptSetting")
			};
		}, (result) => result.text.some((t) => t.includes("DefaultJavaScriptSetting")));
	} finally {
		await browser.cdp.send("Target.closeTarget", { targetId: id }).catch(() => {});
	}
}
//#endregion
//#region scripts/legacy-host-cold/fixtures.mjs
const origin = "http://127.0.0.1:43101";
const sentinel = (id) => `cold.sentinel.${id}`;
function fixtureServer(assets) {
	const hits = [];
	const write = (id) => `localStorage.setItem(${JSON.stringify(sentinel(id))},'ran');fetch('/hit?id='+encodeURIComponent(${JSON.stringify(id)}));`;
	const workerWrite = (id) => `new Promise((resolve,reject)=>{const r=indexedDB.open('cold-worker',1);r.onupgradeneeded=()=>r.result.createObjectStore('events');r.onerror=()=>reject(r.error);r.onsuccess=()=>{const d=r.result,t=d.transaction('events','readwrite');t.onabort=()=>reject(t.error);t.objectStore('events').put('ran',${JSON.stringify(id)});t.oncomplete=()=>{d.close();fetch(${JSON.stringify("http://127.0.0.1:43101/hit?id=")}+encodeURIComponent(${JSON.stringify(id)})).then(resolve,reject)}}})`;
	const handler = (req, res) => {
		const u = new URL(req.url, origin), id = u.searchParams.get("id") ?? "default";
		hits.push({
			path: u.pathname,
			id,
			...u.pathname === "/error" ? { message: u.searchParams.get("message")?.slice(0, 1e3) } : {}
		});
		res.setHeader("Cache-Control", "no-store");
		if (u.pathname === "/hit") {
			res.end("ok");
			return;
		}
		if (u.pathname === "/worker.js") {
			res.setHeader("Content-Type", "text/javascript");
			res.end(workerWrite(id) + ";self.onconnect=()=>{};");
			return;
		}
		if (u.pathname === "/sentinel-sw.js") {
			res.setHeader("Content-Type", "text/javascript");
			res.setHeader("Service-Worker-Allowed", "/");
			res.end(`self.addEventListener('install',e=>e.waitUntil(self.skipWaiting()));self.addEventListener('activate',e=>e.waitUntil(self.clients.claim()));self.addEventListener('fetch',e=>{if(new URL(e.request.url).pathname==='/sw-trigger'){e.waitUntil(${workerWrite("sw-fetch")})}});self.addEventListener('sync',e=>{e.waitUntil(${workerWrite("sw-sync")})});`);
			return;
		}
		res.setHeader("Content-Type", "text/html");
		if (["/inert", "/sw-trigger"].includes(u.pathname)) {
			res.end("<title>Inert storage context</title>");
			return;
		}
		if (u.pathname === "/deferred") {
			res.end(`<meta http-equiv="refresh" content="1;url=/probe?id=${encodeURIComponent(id)}">`);
			return;
		}
		if (u.pathname === "/probe") {
			res.end(`<title>First script probe</title><script>${write(id)}addEventListener('pageshow',e=>localStorage.setItem('cold.history.'+${JSON.stringify(id)},e.persisted?'bfcache':'load'))<\/script>`);
			return;
		}
		if (u.pathname === "/embed") {
			const kind = u.searchParams.get("kind"), url = "http://127.0.0.1:43101/probe?id=" + encodeURIComponent(id);
			if (kind === "srcdoc") res.end(`<iframe srcdoc="&lt;script&gt;${write(id).replaceAll("\"", "&quot;")}&lt;/script&gt;"></iframe>`);
			else if (kind === "blank") res.end(`<iframe id="f" src="about:blank"></iframe><script>f.contentDocument.write(${JSON.stringify("<script>" + write(id) + "<\/script>").replaceAll("</", "<\\/")})<\/script>`);
			else res.end(`<iframe src="${url}"></iframe>`);
			return;
		}
		if (u.pathname === "/spawn") {
			const kind = u.searchParams.get("kind"), url = "http://127.0.0.1:43101/worker.js?id=" + encodeURIComponent(id);
			const expression = kind === "shared" ? `new SharedWorker(${JSON.stringify(url)}).port.start()` : kind === "blob" ? `new Worker(URL.createObjectURL(new Blob([${JSON.stringify(`importScripts(${JSON.stringify(url)})`)}],{type:'text/javascript'})))` : `new Worker(${JSON.stringify(url)})`;
			res.end(`<script>const w=${expression};if(w)w.onerror=e=>fetch('/error?id='+encodeURIComponent(${JSON.stringify(id)})+'&message='+encodeURIComponent(e.message));<\/script>`);
			return;
		}
		if (u.pathname === "/old-asset") {
			const entry = readFileSync(join(assets, "old-dist/index.html"), "utf8").match(/src="([^"]+\.js)"/u)?.[1];
			res.end(`<div id="root"></div><script type="module" src="${entry}"><\/script>`);
			return;
		}
		const path = u.pathname === "/" ? "index.html" : decodeURIComponent(u.pathname.slice(1));
		if (path.split("/").includes("..")) {
			res.writeHead(400).end();
			return;
		}
		for (const dir of ["fixture-dist", "old-dist"]) try {
			const bytes = readFileSync(join(assets, dir, path));
			res.setHeader("Content-Type", {
				".js": "text/javascript",
				".css": "text/css",
				".json": "application/json",
				".wasm": "application/wasm",
				".svg": "image/svg+xml",
				".webmanifest": "application/manifest+json"
			}[extname(path)] ?? "text/html");
			res.end(bytes);
			return;
		} catch {}
		res.writeHead(404).end();
	};
	const servers = [createServer(handler), createServer(handler)];
	for (const server of servers) server.on("upgrade", (req, socket) => {
		hits.push({
			path: "websocket-upgrade",
			url: req.url
		});
		socket.end("HTTP/1.1 503 Service Unavailable\r\nConnection: close\r\nContent-Length: 0\r\n\r\n");
	});
	return {
		hits,
		async start() {
			await Promise.all(servers.map((s, i) => new Promise((r) => s.listen(43101 + i, "127.0.0.1", r))));
		},
		async close() {
			await Promise.all(servers.map((s) => new Promise((r) => {
				s.closeAllConnections();
				s.close(r);
			})));
		}
	};
}
//#endregion
//#region scripts/legacy-host-cold/observer.mjs
const methods = /* @__PURE__ */ new Set([
	"Browser.getVersion",
	"Browser.getBrowserCommandLine",
	"Target.getTargets",
	"Target.attachToTarget",
	"Target.detachFromTarget",
	"Page.getFrameTree",
	"Storage.getStorageKeyForFrame",
	"DOMStorage.enable",
	"DOMStorage.getDOMStorageItems",
	"IndexedDB.enable",
	"IndexedDB.requestDatabaseNames",
	"IndexedDB.requestDatabase",
	"IndexedDB.getMetadata",
	"IndexedDB.requestData",
	"CacheStorage.requestCacheNames",
	"CacheStorage.requestEntries",
	"CacheStorage.requestCachedResponse",
	"Runtime.getProperties",
	"Runtime.releaseObject",
	"Runtime.releaseObjectGroup"
]);
const hash = (value) => createHash("sha256").update(JSON.stringify(value)).digest("hex");
function readerChannel(cdp) {
	return Object.freeze({ send(method, params, sessionId) {
		if (!methods.has(method)) throw Error("observer-command-forbidden");
		return cdp.send(method, params, sessionId);
	} });
}
const maxRows = 4096;
const maxValueBytes = 65536;
const maxTotalBytes = 16 * 1024 * 1024;
const refuse = (reason) => {
	throw Error(reason);
};
/** No previews, calls, getters or source-string evaluation. Only supported primitive/byte values. */
async function decodeValue(channel, session, value) {
	if (value.type === "number" && Number.isFinite(value.value)) return value.value;
	if (value.type === "string" && typeof value.value === "string") {
		if (Buffer.byteLength(value.value) > maxValueBytes) refuse("observer-value-bound");
		return value.value;
	}
	if (value.type === "boolean" && typeof value.value === "boolean") return value.value;
	if (value.type === "object" && value.subtype === "null") return null;
	if (value.type !== "object" || value.subtype !== "typedarray" || value.className !== "Uint8Array" || typeof value.objectId !== "string") refuse("observer-value-unsupported");
	try {
		const match = /^Uint8Array\((0|[1-9][0-9]*)\)$/u.exec(value.description ?? "");
		if (!match) refuse("observer-byte-length-unavailable");
		const length = Number(match[1]);
		if (length > maxValueBytes) refuse("observer-value-bound");
		const properties = await channel.send("Runtime.getProperties", {
			objectId: value.objectId,
			ownProperties: true,
			generatePreview: false
		}, session);
		if (properties.exceptionDetails) refuse("observer-property-exception");
		const bytes = Array.from({ length }), seen = /* @__PURE__ */ new Set();
		for (const entry of properties.result) {
			if (entry.get || entry.set || !entry.value || entry.isOwn === false) refuse("observer-accessor");
			if (!/^(0|[1-9][0-9]*)$/u.test(entry.name)) refuse("observer-byte-property");
			const index = Number(entry.name), byte = entry.value.value;
			if (index >= length || seen.has(index) || entry.value.type !== "number" || !Number.isInteger(byte) || byte < 0 || byte > 255) refuse("observer-byte-property");
			seen.add(index);
			bytes[index] = byte;
		}
		if (seen.size !== length) refuse("observer-byte-truncation");
		return { bytes };
	} finally {
		await channel.send("Runtime.releaseObject", { objectId: value.objectId }, session);
	}
}
async function readInventory(cdp, targetId, expectedOrigin, { pageSize = 7 } = {}) {
	if (!Number.isInteger(pageSize) || pageSize < 1 || pageSize > 128) refuse("observer-page-bound");
	const channel = readerChannel(cdp);
	const { sessionId } = await channel.send("Target.attachToTarget", {
		targetId,
		flatten: true
	});
	try {
		const { frameTree } = await channel.send("Page.getFrameTree", {}, sessionId);
		const frame = frameTree.frame;
		if (new URL(frame.url).origin !== expectedOrigin) refuse("observer-origin-mismatch");
		const { storageKey } = await channel.send("Storage.getStorageKeyForFrame", { frameId: frame.id }, sessionId);
		const binding = [
			frame.id,
			frame.loaderId,
			frame.url,
			storageKey
		];
		await channel.send("DOMStorage.enable", {}, sessionId);
		const { entries } = await channel.send("DOMStorage.getDOMStorageItems", { storageId: {
			storageKey,
			isLocalStorage: true
		} }, sessionId);
		const local = entries.sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0);
		if (local.length > maxRows || new Set(local.map(([k]) => k)).size !== local.length) refuse("observer-local-bound");
		let total = Buffer.byteLength(JSON.stringify(local));
		if (total > maxTotalBytes) refuse("observer-total-bound");
		await channel.send("IndexedDB.enable", {}, sessionId);
		const names = await channel.send("IndexedDB.requestDatabaseNames", { storageKey }, sessionId);
		if (names.databaseNames.length > 32 || new Set(names.databaseNames).size !== names.databaseNames.length) refuse("observer-database-bound");
		const databases = [];
		for (const databaseName of names.databaseNames.sort()) {
			const { databaseWithObjectStores: schema } = await channel.send("IndexedDB.requestDatabase", {
				storageKey,
				databaseName
			}, sessionId);
			if (schema.name !== databaseName || schema.objectStores.length > 32) refuse("observer-schema-bound");
			const stores = [];
			for (const store of schema.objectStores.sort((a, b) => a.name.localeCompare(b.name))) {
				const params = {
					storageKey,
					databaseName,
					objectStoreName: store.name
				};
				const metadata = await channel.send("IndexedDB.getMetadata", params, sessionId);
				if (!Number.isSafeInteger(metadata.entriesCount) || metadata.entriesCount < 0 || metadata.entriesCount > maxRows) refuse("observer-row-bound");
				const rows = [], seen = /* @__PURE__ */ new Set();
				for (;;) {
					const page = await channel.send("IndexedDB.requestData", {
						...params,
						skipCount: rows.length,
						pageSize
					}, sessionId);
					if (page.objectStoreDataEntries.length > pageSize || page.hasMore && !page.objectStoreDataEntries.length) refuse("observer-pagination");
					for (const entry of page.objectStoreDataEntries) {
						const key = await decodeValue(channel, sessionId, entry.primaryKey);
						if (typeof key !== "number" && typeof key !== "string") refuse("observer-key-unsupported");
						if (seen.has(JSON.stringify(key))) refuse("observer-duplicate-row");
						seen.add(JSON.stringify(key));
						const value = await decodeValue(channel, sessionId, entry.value);
						total += Buffer.byteLength(JSON.stringify([key, value]));
						if (total > maxTotalBytes || rows.length >= maxRows) refuse("observer-total-bound");
						rows.push([key, value]);
					}
					if (!page.hasMore) break;
				}
				if (rows.length !== metadata.entriesCount) refuse("observer-pagination");
				const lastMetadata = await channel.send("IndexedDB.getMetadata", params, sessionId);
				if (hash(lastMetadata) !== hash(metadata)) refuse("observer-storage-changed: " + JSON.stringify({
					databaseName,
					store: store.name,
					before: metadata,
					after: lastMetadata
				}));
				stores.push({
					name: store.name,
					schema: store,
					rows,
					metadata
				});
			}
			databases.push({
				name: databaseName,
				version: schema.version,
				stores
			});
		}
		const caches = [];
		const cacheNames = await channel.send("CacheStorage.requestCacheNames", { storageKey }, sessionId);
		if (cacheNames.caches.length > 32) refuse("observer-cache-bound");
		for (const cache of cacheNames.caches.sort((a, b) => a.cacheName.localeCompare(b.cacheName))) {
			const entries = [], seen = /* @__PURE__ */ new Set();
			for (let skipCount = 0;;) {
				const page = await channel.send("CacheStorage.requestEntries", {
					cacheId: cache.cacheId,
					skipCount,
					pageSize: 128
				}, sessionId);
				for (const entry of page.cacheDataEntries) {
					const key = JSON.stringify([
						entry.requestURL,
						entry.requestMethod,
						entry.requestHeaders
					]);
					if (seen.has(key)) refuse("observer-cache-pagination");
					seen.add(key);
					const result = await channel.send("CacheStorage.requestCachedResponse", {
						cacheId: cache.cacheId,
						requestURL: entry.requestURL,
						requestHeaders: entry.requestHeaders
					}, sessionId);
					const bytes = Buffer.from(result.response.body, "base64");
					total += bytes.length;
					if (total > maxTotalBytes || entries.length >= maxRows) refuse("observer-total-bound");
					entries.push({
						...entry,
						url: entry.requestURL,
						method: entry.requestMethod,
						bodyHash: createHash("sha256").update(bytes).digest("hex")
					});
				}
				skipCount += page.cacheDataEntries.length;
				if (skipCount === page.returnCount) break;
				if (!page.cacheDataEntries.length || skipCount > page.returnCount) refuse("observer-cache-pagination");
			}
			caches.push({
				name: cache.cacheName,
				entries: entries.sort((a, b) => a.url.localeCompare(b.url))
			});
		}
		const last = (await channel.send("Page.getFrameTree", {}, sessionId)).frameTree.frame;
		const lastKey = await channel.send("Storage.getStorageKeyForFrame", { frameId: last.id }, sessionId);
		if (hash([
			last.id,
			last.loaderId,
			last.url,
			lastKey.storageKey
		]) !== hash(binding)) refuse("observer-context-changed");
		return {
			local,
			databases,
			caches
		};
	} finally {
		await channel.send("Runtime.releaseObjectGroup", { objectGroup: "indexeddb" }, sessionId).catch(() => {});
		await channel.send("Target.detachFromTarget", { sessionId }).catch(() => {});
	}
}
//#endregion
//#region scripts/legacy-host-cold/native-policy.mjs
if (!globalThis.WebSocket) globalThis.WebSocket = createRequire(import.meta.url)("undici").WebSocket;
const [output, assets, policy] = process.argv.slice(2);
assert.ok([
	"missing",
	"malformed",
	"ignored",
	"exception",
	"recommended"
].includes(policy));
mkdirSync(output, { recursive: true });
const path = join(output, `policy-control-${policy}.json`);
assert.equal(existsSync(path), false);
const report = {
	policy,
	role: "intentional invalid-policy canary; never opens a source profile",
	passed: false
};
const server = fixtureServer(assets);
let browser;
try {
	try {
		denialConfig(readFileSync("/etc/chromium/policies/managed/denial.json", "utf8"), {
			readonly: true,
			mandatory: policy !== "recommended",
			beforeLaunch: true
		});
	} catch (error) {
		report.launcherRefused = true;
		report.refusal = error.message;
	}
	assert.equal(report.launcherRefused, true, "invalid-policy-must-refuse-before-source-launch");
	if (policy === "recommended") {
		const profile = join(output, "profiles", "control-" + policy, "Default");
		mkdirSync(profile, { recursive: true });
		atomicJSON(join(profile, "Preferences"), { profile: { default_content_setting_values: { javascript: 1 } } });
	}
	await server.start();
	browser = await launch(output, "control-" + policy, "http://127.0.0.1:43101/probe?id=invalid-policy");
	report.browser = await browser.cdp.send("Browser.getVersion");
	if (policy === "recommended") {
		report.effectivePolicy = await policyTable(browser);
		const row = report.effectivePolicy.rows.find((r) => r[0] === "DefaultJavaScriptSetting");
		assert.equal(row?.[4], "Recommended", "recommended-control-effective-level");
		report.controlKind = "configuration-refusal; user-override execution coverage unproven";
	} else await poll("invalid policy native positive write", () => server.hits.some((h) => h.path === "/hit" && h.id === "invalid-policy"));
	const id = await inertPage(browser, origin);
	report.inventory = await readInventory(browser.cdp, id, origin);
	report.positiveWrite = report.inventory.local.find(([k]) => k === sentinel("invalid-policy"))?.[1] === "ran";
	if (policy !== "recommended") assert.equal(report.positiveWrite, true, "false-denial-acknowledgement-caught");
	assert.deepEqual(report.inventory.databases, [], "absent-database-not-created");
	assert.deepEqual((await readInventory(browser.cdp, id, origin)).databases, [], "repeat-read-absent-database-not-created");
	report.passed = true;
} catch (error) {
	report.error = error.stack;
	process.exitCode = 1;
} finally {
	await browser?.stop();
	await server.close();
	atomicJSON(path, report);
	console.log(JSON.stringify(report));
}
//#endregion
export {};

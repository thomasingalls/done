#!/bin/sh
# Root creates isolated network/mount namespaces; all browser/controller code runs as probe.
set -eu
[ "$(id -u)" = 0 ]
[ "$#" -ge 2 ]
policy="$1"
shift
case "$policy" in deny|allow|origin) ;; *) exit 64 ;; esac
mount --make-rprivate /
ip link set lo up
mount --bind "/opt/done-cold/policies/$policy" /etc/chromium/policies/managed
mount -o remount,bind,ro /etc/chromium/policies/managed
exec runuser -u probe -- /usr/bin/node "$@"

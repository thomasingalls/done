# Goals

Keep the visible writing.
journal-only ✔

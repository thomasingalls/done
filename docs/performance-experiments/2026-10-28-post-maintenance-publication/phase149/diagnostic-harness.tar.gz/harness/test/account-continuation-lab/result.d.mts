export function preserveResult(path:string,result:any,cleanup:()=>Promise<void>):Promise<void>;

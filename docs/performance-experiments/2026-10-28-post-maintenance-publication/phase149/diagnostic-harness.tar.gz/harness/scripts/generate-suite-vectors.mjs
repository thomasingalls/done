/**
 * Test vectors for the algorithm suite and its agility rule (TRD §15 row 1, §13.2, §13.10).
 *
 * The selection is specified in docs/selections/row-1-algorithm-suite.md. This
 * script is the executable half of that document. It emits
 * test/vectors/algorithm-suite.json, which carries three kinds of thing:
 *
 *   - The *primitive KATs*, copied from their standards and never generated.
 *     They prove the implementation is the named primitive and nothing else.
 *     A KAT produced by the code it checks proves only self-consistency.
 *   - The *suite and carrier registry*, which is the agility mechanism itself:
 *     a carrier version selects a whole suite, so there is no per-record
 *     algorithm field to negotiate and therefore none to downgrade.
 *   - The *separation check*, which is TRD §13.2's rule made executable. If a
 *     later edit reuses one primitive across the asynchronous and synchronous
 *     paths, this script fails rather than the reviewer catching it.
 *
 * Each generator under scripts/ is deliberately self-contained, including its
 * copy of `lp`. A reviewer opens one file and reads a construction end to end;
 * a shared helper would buy deduplication at the cost of that property, and
 * drift between copies is caught by the vectors themselves.
 *
 * Usage: node scripts/generate-suite-vectors.mjs [--check]
 */

import { writeFileSync, readFileSync, readdirSync } from 'node:fs';
import { webcrypto as crypto } from 'node:crypto';

import { reportAudit } from './lib/aad-coverage.mjs';
import { claims, falsifies } from './lib/traceability.mjs';

const OUT = new URL('../test/vectors/algorithm-suite.json', import.meta.url);
const TRD = new URL('../docs/TRD.md', import.meta.url);

const utf8 = (s) => new TextEncoder().encode(s);
const hex = (u) => Buffer.from(u).toString('hex');
const unhex = (s) => new Uint8Array(Buffer.from(s, 'hex'));

const concat = (...parts) => {
  const out = new Uint8Array(parts.reduce((n, p) => n + p.length, 0));
  let at = 0;
  for (const p of parts) {
    out.set(p, at);
    at += p.length;
  }
  return out;
};

/** Length-prefixed field: uint16be(byteLength) || utf8. Injective, so no field can shift another. */
const lp = (s) => {
  const bytes = utf8(s);
  if (bytes.length > 0xffff) throw new Error(`Field too long to length-prefix: ${bytes.length}`);
  return concat(new Uint8Array([bytes.length >> 8, bytes.length & 0xff]), bytes);
};

// --- suite 1 -------------------------------------------------------------------

/**
 * One suite, every role. `path` is the load-bearing column: TRD §13.2 forbids
 * one primitive key crossing the asynchronous/synchronous boundary and §13.10
 * states the criterion as no primitive shared between the two paths. The
 * stronger reading is the one checked below.
 */
const SUITE_1 = {
  'content-store-aead': {
    primitive: 'AES-256-GCM',
    provider: 'WebCrypto',
    path: 'async',
    nonce: '96-bit, random per record',
    why: 'Native and hardware-accelerated, so it adds no bundle. Forced to differ from the journal by §13.2.',
  },
  'local-key-envelope-aead': {
    primitive: 'AES-256-GCM',
    provider: 'WebCrypto',
    path: 'async',
    nonce: '96-bit, random per envelope',
    why: 'Same path, same primitive; L_local is a non-extractable AES-GCM CryptoKey (§13.3).',
  },
  'network-envelope-aead': {
    primitive: 'AES-256-GCM',
    provider: 'WebCrypto',
    path: 'async',
    nonce: '96-bit, random per envelope',
    why: 'Named here so the suite is complete. Its wire format is row 4 and review 3b.',
  },
  'journal-aead': {
    primitive: 'XChaCha20-Poly1305',
    provider:
      'audited RustCrypto chacha20poly1305 crate, compiled to an inlined wasm module (wasm/journal-seal), instantiated synchronously',
    path: 'sync',
    nonce: '192-bit, random per record',
    why: 'Selected by row 2. The only primitive the platform does not supply, and the only one on the crash path.',
  },
  'subkey-derivation': {
    primitive: 'HKDF-SHA-256',
    provider: 'WebCrypto deriveBits',
    path: 'async',
    why: 'Derivation happens once at open, where async is free. Labels are what keep §13.2 separation real.',
  },
  'mutation-signature': {
    primitive: 'Ed25519',
    provider: 'WebCrypto',
    path: 'async',
    why: 'Small, fast, widely reviewed. Availability is now broad enough that the fallback path §13.10 anticipated is a compatibility question, not a design one.',
  },
  'account-credential-signature': {
    primitive: 'ES256 (ECDSA P-256 with SHA-256)',
    provider: 'WebAuthn authenticator; verified in WebCrypto',
    path: 'async',
    also_accepted: 'Ed25519, already selected above for mutation-signature',
    why: "Selected by row 12, and the one role this suite does not choose: WebAuthn credential creation is a negotiation and the authenticator picks from the offered list. The offer is [-8 Ed25519, -7 ES256] and is frozen at creation inside a service-signed binding, so nothing renegotiates afterwards. ES256 is the addition; it meets §13.10's criteria and is async-path only, so §13.2 is untouched. No KAT here: its verification is exercised end to end by row 12's vectors, whose keypair checks its own halves.",
  },
  'public-key-wrap': {
    primitive: 'HPKE base mode, DHKEM(X25519, HKDF-SHA256) / HKDF-SHA256 / AES-256-GCM',
    provider: 'library, unselected',
    path: 'async',
    ids: { kem: '0x0020', kdf: '0x0001', aead: '0x0002' },
    why: 'RFC 9180 with the most widely implemented ciphersuite. Covers the R_pub and per-reader wrap cases uniformly (§13.2).',
  },
  'credential-stretching': {
    primitive: 'None. HKDF-SHA-256 only',
    provider: 'WebCrypto',
    path: 'none',
    why: 'Selected by rows 13 and 14, and §13.10 answers it as one row for both: the recovery code and the device-lock code are generated at 125 bits, so the entropy deficit a work factor exists to cover does not exist. It rests on the invariant that such a code is never user-chosen, user-extended or truncated (§13.10).',
  },
  'slot-verifier-stretching': {
    primitive: 'None, and nothing to stretch',
    provider: '—',
    path: 'none',
    why: 'Selected by row 12, on a stronger argument than the two above: the verifier checks a signature rather than a secret, so there is no secret in the profile to grind (§13.9).',
  },
  hash: {
    primitive: 'SHA-256',
    provider: 'WebCrypto',
    // Was `both` (S0-1, f-3bea0e6-suite-separation-ignores-both-path). `path`
    // says where a primitive EXECUTES, and nothing on the synchronous path
    // hashes -- the seal is XChaCha20-Poly1305 and base64. `both` also entered
    // neither bucket below, so it was published as separated for the whole life
    // of a check written to prevent exactly that.
    path: 'async',
    why: 'One hash everywhere HKDF, signatures and commitments need one.',
  },
};

/** Roles this row deliberately does not fill, each with the row that owns it. */
/**
 * Roles named in §13.10 but not selected by row 1.
 *
 * **Empty, and it was not always.** It carried the recovery-code stretching,
 * the slot verifier and the device-lock derivation, each pointing at the §15
 * row that owned it. All three of those rows have since been answered, and
 * their answers are in SUITE_1 above -- but nothing here noticed, so this file
 * went on publishing three roles as unfilled after they were filled. That is
 * the same drift row 2's provider name had, in the same file, and it is the
 * reason `checkCoverage` below now reads §15 rather than trusting the owner
 * string to stay true.
 */
const DEFERRED = {};
// --- the carrier registry, which is the agility mechanism ----------------------

/**
 * The rule: a carrier's version selects an entire suite. There is no per-record
 * algorithm identifier, so there is nothing to negotiate and nothing to
 * downgrade. Every carrier that has associated data puts its own version in it,
 * so a renumbered record fails authentication rather than selecting a weaker
 * suite -- fail-closed by construction rather than by a remembered check.
 */
const CARRIERS = [
  {
    name: 'content-record',
    version: 1,
    encoding: 'StoredRecord.v (a structured-clone field)',
    suite: 1,
    label: 'done/store/v1',
    selected_by: 'row 3',
    in_aad: true,
  },
  {
    name: 'journal-entry',
    version: 2,
    encoding: 'the "2:" string prefix on the localStorage value',
    suite: 1,
    label: 'done/jrnl/v1',
    selected_by: 'row 2',
    in_aad: true,
    note: 'Version 2 under suite 1 is not an inconsistency. The leading integer is the carrier framing, which counted from 1 when the journal was plaintext; the trailing v1 in the label is the suite. §4 of the row 1 document explains why both axes exist.',
  },
  {
    name: 'local-key-envelope',
    version: 1,
    encoding: 'KeyEnvelope.v (a structured-clone field)',
    suite: 1,
    label: 'done/keyenv/v1',
    selected_by: 'row 3',
    in_aad: true,
  },
  {
    name: 'network-envelope',
    version: 1,
    encoding: "the clear header's `v` field (row 4 §3)",
    suite: 1,
    label: 'done/env/v1',
    selected_by: 'row 4',
    in_aad: true,
    note: 'This row read "unselected" for as long as row 4 was open, and stayed that way after row 4 closed. The registry is the suite\'s inventory of every carrier, so an entry that is stale in the safe-looking direction is the one worth guarding: `checkCarriers` lets a null suite through on the strength of a named owner, which is exactly what a closed row no longer needs.',
  },
];

/** What a reader does with each (carrier, version) it might meet. */
const ACCEPTANCE = [
  {
    carrier: 'content-record',
    version: 1,
    verdict: 'accept',
    why: 'The only version this suite defines.',
  },
  {
    carrier: 'content-record',
    version: 0,
    verdict: 'refuse-and-report',
    why: 'No version 0 was ever written. A record claiming one is malformed or hostile.',
  },
  {
    carrier: 'content-record',
    version: 2,
    verdict: 'refuse-and-report',
    why: 'Above what this reader knows. A newer writer touched this store; guessing at its framing is how a store gets corrupted.',
  },
  { carrier: 'journal-entry', version: 2, verdict: 'accept', why: 'The encrypted journal.' },
  {
    carrier: 'journal-entry',
    version: 1,
    verdict: 'refuse-and-report',
    why: 'A plaintext entry from a pre-encryption build. Replaying it means shipping a plaintext reader, which §6.1 forbids and §11.1 tests for.',
  },
  {
    carrier: 'local-key-envelope',
    version: 1,
    verdict: 'accept',
    why: 'The only version this suite defines.',
  },
  {
    carrier: 'local-key-envelope',
    version: 2,
    verdict: 'refuse-and-report',
    why: 'Above what this reader knows. Refusing a key envelope closes the workspace; opening it wrongly loses it.',
  },
  {
    carrier: 'network-envelope',
    version: 1,
    verdict: 'accept',
    why: 'The only version this suite defines.',
  },
  {
    carrier: 'network-envelope',
    version: 0,
    verdict: 'refuse-and-report',
    why: 'No version 0 was ever minted. The relay validates the clear header (§7.2), so a malformed version is refused before any content key is involved.',
  },
  {
    carrier: 'network-envelope',
    version: 2,
    verdict: 'refuse-and-report',
    why: 'Above what this reader knows. Row 4 binds `v` in both the AAD and the signature, so a receiver that guessed at a newer framing would be authenticating bytes it cannot parse.',
  },
];

// --- primitive KATs, copied not generated --------------------------------------

const PRIMITIVE_KATS = [
  {
    role: 'content-store-aead / local-key-envelope-aead / network-envelope-aead',
    primitive: 'AES-256-GCM',
    source: 'McGrew & Viega, "The Galois/Counter Mode of Operation (GCM)", Test Case 16',
    key: 'feffe9928665731c6d6a8f9467308308feffe9928665731c6d6a8f9467308308',
    iv: 'cafebabefacedbaddecaf888',
    aad: 'feedfacedeadbeeffeedfacedeadbeefabaddad2',
    plaintext:
      'd9313225f88406e5a55909c5aff5269a86a7a9531534f7da2e4c303d8a318a721c3c0c95956809532fcf0e2449a6b525b16aedf5aa0de657ba637b39',
    ciphertext:
      '522dc1f099567d07f47f37a32a84427d643a8cdcbfe5c0c97598a2bd2555d1aa8cb08e48590dbb3da7b08b1056828838c5f61e6393ba7a0abcc9f662',
    tag: '76fc6ece0f4e1768cddf8853bb2d551b',
  },
  {
    role: 'subkey-derivation',
    primitive: 'HKDF-SHA-256',
    source: 'RFC 5869 Appendix A, Test Case 1',
    ikm: '0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b',
    salt: '000102030405060708090a0b0c',
    info: 'f0f1f2f3f4f5f6f7f8f9',
    length_bytes: 42,
    okm: '3cb25f25faacd57a90434f64d0362f2a2d2d0a90cf1a5a4c5db02d56ecc4c5bf34007208d5b887185865',
  },
  {
    role: 'mutation-signature',
    primitive: 'Ed25519',
    source: 'RFC 8032 §7.1, TEST 1',
    seed: '9d61b19deffd5a60ba844af492ec2cc44449c5697b326919703bac031cae7f60',
    public_key: 'd75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a',
    message: '',
    signature:
      'e5564300c360ac729086e2cc806e828a84877f1eb8e5d974d873e065224901555fb8821590a33bacc61e39701cf9b46bd25bf5f0595bbe24655141438e7a100b',
  },
  {
    role: 'hash',
    primitive: 'SHA-256',
    source: 'FIPS 180-4, one-block message "abc"',
    message_utf8: 'abc',
    digest: 'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad',
  },
];

/** The PKCS#8 prefix for a raw Ed25519 seed, so WebCrypto can import RFC 8032's test key. */
const ED25519_PKCS8_PREFIX = '302e020100300506032b657004220420';

const checkPrimitiveKats = async () => {
  for (const kat of PRIMITIVE_KATS) {
    if (kat.primitive === 'AES-256-GCM') {
      const k = await crypto.subtle.importKey('raw', unhex(kat.key), 'AES-GCM', false, ['encrypt']);
      const out = new Uint8Array(
        await crypto.subtle.encrypt(
          { name: 'AES-GCM', iv: unhex(kat.iv), additionalData: unhex(kat.aad), tagLength: 128 },
          k,
          unhex(kat.plaintext),
        ),
      );
      if (hex(out.slice(0, -16)) !== kat.ciphertext || hex(out.slice(-16)) !== kat.tag) {
        throw new Error('AES-256-GCM KAT failed.');
      }
    } else if (kat.primitive === 'HKDF-SHA-256') {
      const ikm = await crypto.subtle.importKey('raw', unhex(kat.ikm), 'HKDF', false, [
        'deriveBits',
      ]);
      const okm = new Uint8Array(
        await crypto.subtle.deriveBits(
          { name: 'HKDF', hash: 'SHA-256', salt: unhex(kat.salt), info: unhex(kat.info) },
          ikm,
          kat.length_bytes * 8,
        ),
      );
      if (hex(okm) !== kat.okm) throw new Error('HKDF-SHA-256 KAT failed.');
    } else if (kat.primitive === 'Ed25519') {
      const priv = await crypto.subtle.importKey(
        'pkcs8',
        unhex(ED25519_PKCS8_PREFIX + kat.seed),
        'Ed25519',
        false,
        ['sign'],
      );
      const sig = new Uint8Array(await crypto.subtle.sign('Ed25519', priv, unhex(kat.message)));
      if (hex(sig) !== kat.signature) throw new Error('Ed25519 KAT failed.');
      const pub = await crypto.subtle.importKey('raw', unhex(kat.public_key), 'Ed25519', false, [
        'verify',
      ]);
      if (!(await crypto.subtle.verify('Ed25519', pub, sig, unhex(kat.message)))) {
        throw new Error('Ed25519 KAT verified false.');
      }
    } else if (kat.primitive === 'SHA-256') {
      const d = new Uint8Array(await crypto.subtle.digest('SHA-256', utf8(kat.message_utf8)));
      if (hex(d) !== kat.digest) throw new Error('SHA-256 KAT failed.');
    } else {
      throw new Error(`No check implemented for KAT primitive ${kat.primitive}.`);
    }
  }
};

/**
 * TRD §13.2's separation rule, executable.
 *
 * §13.2 states it about keys ("one primitive key must not be reused across the
 * asynchronous and synchronous constructions") and §13.10 states it about
 * primitives ("no primitive reused across the asynchronous and synchronous
 * paths"). Those are not the same sentence, and the suite satisfies the
 * stronger one -- which is what this asserts, so a later edit that satisfies
 * only the weaker one fails here rather than at the review.
 */
/**
 * The three values `path` may take, and what they mean (`S0-1`, TRD §13.10).
 *
 * **`path` says where a primitive EXECUTES**, not what its output is later used
 * for. HKDF-SHA-256 derives the journal subkey -- a key consumed synchronously
 * -- and is `async` because the derivation runs at open. Writing that down is
 * not pedantry: *it produces something the sync path uses* is a live reading,
 * and it is how a fourth value gets added.
 */
const PATHS = new Set(['async', 'sync', 'none']);

/**
 * Separation, as a TOTAL classification rather than a filter.
 *
 * **The filter was the defect, not the value it missed.** This selected each
 * bucket with `filter(r => r.path === want)`, so a role whose label matched
 * neither entered neither -- and a role in no bucket cannot be in the
 * intersection. `hash` carried `both` for the whole life of the check and was
 * published as separated throughout. `'Async'`, `'sync '` and `'shared'` would
 * have passed identically: **a classification that drops what it does not
 * recognise can only pass.**
 */
const checkSeparation = () => {
  falsifies('checkSeparation', ['f-3bea0e6-suite-separation-ignores-both-path']);
  const asyncPath = new Set();
  const syncPath = new Set();
  for (const [role, r] of Object.entries(SUITE_1)) {
    switch (r.path) {
      case 'async':
        asyncPath.add(r.primitive);
        break;
      case 'sync':
        syncPath.add(r.primitive);
        break;
      case 'none':
        // Otherwise `none` is the next `both`: a way to hold a real primitive
        // where the separation check cannot see it.
        if (!/^none\b/iu.test(r.primitive)) {
          throw new Error(
            `Role "${role}" is path "none" but names the primitive "${r.primitive}". ` +
              '"none" means this role selects no primitive; a role that selects one has a path.',
          );
        }
        break;
      case 'both':
        throw new Error(
          `Role "${role}" is path "both". TRD §13.10 forbids a primitive on both paths, so this ` +
            'label asserts the violation rather than describing a state the suite may be in.',
        );
      default:
        throw new Error(
          `Role "${role}" has path "${r.path}", which is not one of ${[...PATHS].join(', ')}. ` +
            'An unclassified role is an unchecked one.',
        );
    }
  }
  const shared = [...asyncPath].filter((p) => syncPath.has(p));
  if (shared.length > 0) {
    throw new Error(
      `TRD §13.10 violated: primitive(s) shared across the async and sync paths: ${shared.join(', ')}`,
    );
  }
  if (syncPath.size === 0)
    throw new Error('No synchronous primitive in the suite; row 2 should supply one.');
  return { async: [...asyncPath].toSorted(), sync: [...syncPath].toSorted(), shared };
};

/** Every carrier must name a defined suite, or be explicitly unselected with an owner. */
const SELECTIONS = new URL('../docs/selections/', import.meta.url);

/**
 * An unselected carrier's owning row, read from the selection record rather than
 * from this file.
 *
 * A carrier may legitimately sit unselected while the row that owns it is still
 * open. What it may not do is stay that way after the row closes — and that is
 * not a hypothetical: `network-envelope` read "unselected, row 4" for the whole
 * interval after row 4 was selected, and every check in this file passed the
 * entire time, because the null branch below asks only whether an owner is
 * *named*. Naming an owner is not a reason; the owner still being open is. So
 * the reason is now checked against the owner's own status line.
 */
const ownerRowIsClosed = (selectedBy) => {
  const row = /row (\d+)/u.exec(selectedBy ?? '')?.[1];
  if (!row) return false;
  const file = readdirSync(SELECTIONS).find((n) => n.startsWith(`row-${row}-`));
  if (!file) return false; // no selection record: the row is genuinely open
  return /^\*\*Status:\*\*\s*selected/mu.test(readFileSync(new URL(file, SELECTIONS), 'utf8'));
};

const checkCarriers = () => {
  falsifies('checkCarriers', ['f-992bc91-network-carrier-registry-stale']);
  for (const c of CARRIERS) {
    if (c.suite === null) {
      if (!c.selected_by)
        throw new Error(`Carrier ${c.name} is unselected and names no owning row.`);
      if (ownerRowIsClosed(c.selected_by))
        throw new Error(
          `Carrier ${c.name} is still marked unselected, but ${c.selected_by} is selected. ` +
            `Fill in its version, suite, label and AAD binding from that row.`,
        );
      continue;
    }
    if (c.suite !== 1)
      throw new Error(`Carrier ${c.name} names suite ${c.suite}, which is not defined.`);
    if (!c.label?.endsWith(`/v${c.suite}`)) {
      throw new Error(`Carrier ${c.name}'s label ${c.label} does not end in its suite version.`);
    }
    if (!c.in_aad) throw new Error(`Carrier ${c.name} does not authenticate its own version.`);
  }
  for (const a of ACCEPTANCE) {
    const carrier = CARRIERS.find((c) => c.name === a.carrier);
    if (!carrier) throw new Error(`Acceptance row names unknown carrier ${a.carrier}.`);
    const shouldAccept = carrier.version === a.version;
    if (shouldAccept !== (a.verdict === 'accept')) {
      throw new Error(
        `Acceptance row ${a.carrier}/${a.version} says "${a.verdict}" but the registry says otherwise.`,
      );
    }
  }
};

/** Every role is either selected in the suite or deferred to a named row. Nothing falls through. */
const checkCoverage = () => {
  const roles = [...Object.keys(SUITE_1), ...Object.keys(DEFERRED)];
  const dupes = roles.filter((r, i) => roles.indexOf(r) !== i);
  if (dupes.length > 0) throw new Error(`Role selected and deferred at once: ${dupes.join(', ')}`);

  // A deferral is a claim about §15, so it is checked against §15 rather than
  // against the owner string, which stays true-looking forever. Naming a row is
  // not enough: the row has to still be open. A deferral that outlives its row
  // publishes a role as unfilled after it was filled, and the only reader who
  // would catch it is the reviewer this file exists to inform.
  const trd = readFileSync(TRD, 'utf8');
  const selected = new Set(
    [
      ...trd
        .slice(trd.indexOf('### 15.1 Selected'), trd.indexOf('### 15.2 Unselected'))
        .matchAll(/^\| (\d+) \|/gmu),
    ].map((m) => m[1]),
  );
  if (selected.size === 0) throw new Error('§15.1 has no rows; the register cannot be read.');

  for (const [role, d] of Object.entries(DEFERRED)) {
    const row = /row (\d+)/u.exec(d.owner)?.[1];
    if (row === undefined) throw new Error(`Deferred role ${role} names no owning row.`);
    if (selected.has(row)) {
      throw new Error(
        `Deferred role ${role} points at §15 row ${row}, which is selected.\n` +
          '  The deferral has outlived its row: this file publishes the role as unfilled\n' +
          '  while §15.1 says it is answered. Move it into SUITE_1 or into the row that took it.',
      );
    }
  }
};

const ROW_1 = new URL('../docs/selections/row-1-algorithm-suite.md', import.meta.url);

/**
 * The suite's paths, checked against the two documents that state them
 * (`S0-1`, `P-5`'s `RC-8C`).
 *
 * **`SUITE_1` is the home of this fact and both documents restate it**, so the
 * agreement needs checking in both directions rather than assuming the data is
 * right. It was not: `hash` was `both` in the data while row 1 §3 listed SHA-256
 * on the asynchronous path and §13.10's table printed an em-dash. Three
 * representations, three answers, and every check green -- because the only
 * check that existed read the data and never a document.
 */
const checkSuiteDocuments = ({ async: asyncSet, sync: syncSet }) => {
  falsifies('checkSuiteDocuments', ['f-3bea0e6-suite-separation-ignores-both-path']);
  const row1 = readFileSync(ROW_1, 'utf8');
  // A `·`-separated cell rather than a prose list: the HPKE ciphersuite carries
  // its own commas, so a comma-separated sentence cannot hold the suite the
  // rows have grown it into. That is why this stopped being a sentence.
  const cell = (want) => {
    const m = new RegExp(`^\\|\\s*\\*\\*${want}\\*\\*\\s*\\|([^|]+)\\|`, 'mu').exec(row1);
    return m === null
      ? null
      : m[1]
          .split('·')
          .map((x) => x.trim())
          .filter(Boolean)
          .toSorted();
  };
  const statedAsync = cell('asynchronous');
  const statedSync = cell('synchronous');
  if (statedAsync === null || statedSync === null) {
    throw new Error('row 1 §3 no longer states the two path sets as a table; the cross-check cannot run.');
  }
  const differs = (a, b) => a.length !== b.length || a.some((x, i) => x !== b[i]);
  if (differs(statedAsync, asyncSet)) {
    throw new Error(
      `row 1 §3 lists the asynchronous set as {${statedAsync.join(', ')}} and SUITE_1 computes ` +
        `{${asyncSet.join(', ')}}. One of them is describing a suite that does not exist.`,
    );
  }
  if (differs(statedSync, syncSet)) {
    throw new Error(
      `row 1 §3 lists the synchronous set as {${statedSync.join(', ')}} and SUITE_1 computes ` +
        `{${syncSet.join(', ')}}.`,
    );
  }

  // TRD §13.10's own table. Its role names are coarser than SUITE_1's -- one row
  // covers three AEAD uses -- so what is compared is the Path column's vocabulary
  // and the one row the separation argument rests on.
  const trd = readFileSync(TRD, 'utf8');
  const table = trd.slice(trd.indexOf('### 13.10'), trd.indexOf('### 13.11'));
  const rows = [...table.matchAll(/^\|(?!\s*(?:Role|-))([^|]+)\|([^|]+)\|([^|]+)\|\s*$/gmu)].map(
    (m) => ({ role: m[1].trim(), selected: m[2].trim(), path: m[3].trim() }),
  );
  if (rows.length === 0) throw new Error('TRD §13.10 has no role table; the cross-check cannot run.');
  for (const r of rows) {
    if (!PATHS.has(r.path)) {
      throw new Error(
        `TRD §13.10 row "${r.role}" has path "${r.path}", which is not one of ` +
          `${[...PATHS].join(', ')}. The document and SUITE_1 must speak the same vocabulary.`,
      );
    }
  }
  const syncRows = rows.filter((r) => r.path === 'sync');
  if (syncRows.length !== 1) {
    throw new Error(
      `TRD §13.10 marks ${syncRows.length} roles "sync"; the separation argument rests on exactly one.`,
    );
  }
  for (const primitive of syncSet) {
    if (!syncRows[0].selected.includes(primitive)) {
      throw new Error(
        `SUITE_1 puts ${primitive} on the synchronous path and TRD §13.10's sync row does not name it.`,
      );
    }
  }
  return { statedAsync, statedSync, trdRoles: rows.length };
};

const main = async () => {
  await checkPrimitiveKats();
  const separation = checkSeparation();
  checkCarriers();
  checkCoverage();
  checkSuiteDocuments(separation);

  // No AAD composition lives in this file -- it carries published KATs and the
  // carrier-version table -- but it reports that emptiness rather than staying
  // silent, because scripts/check-aad-coverage.mjs discovers generators instead
  // of being given a list, and cannot tell "no AAD" from "forgot to report".
  reportAudit();

  const doc = {
    $schema: 'https://done.invalid/vectors/algorithm-suite/1',
    generated_by: 'scripts/generate-suite-vectors.mjs',
    selection: 'docs/selections/row-1-algorithm-suite.md',
    trd_row: 1,
    falsifies: claims(),
    rule: {
      statement:
        'A carrier version selects an entire suite. There is no per-record algorithm identifier, no negotiation, and therefore nothing to downgrade.',
      reader:
        'A reader knows a fixed compiled-in set of (carrier, version) pairs, accepts exactly those, and refuses everything else including versions above its own.',
      refusal:
        'Refusal is reported and the carrier is left intact. Never skipped silently, never deleted by the read path.',
      binding:
        'Every carrier authenticates its own version in its associated data, so a renumbered record fails to open rather than selecting a weaker suite.',
      label:
        'done/<carrier>/v<suite> -- the trailing integer is the suite, not the carrier framing.',
    },
    suites: { 1: { roles: SUITE_1, deferred: DEFERRED } },
    carriers: CARRIERS,
    acceptance: ACCEPTANCE,
    separation_check: separation,
    domain_labels: Object.fromEntries(
      CARRIERS.filter((c) => c.label).map((c) => [
        c.label,
        { lp_hex: hex(lp(c.label)), carrier: c.name },
      ]),
    ),
    primitive_kats: PRIMITIVE_KATS,
  };

  const json = JSON.stringify(doc, null, 2) + '\n';

  if (process.argv.includes('--check')) {
    const existing = readFileSync(OUT, 'utf8');
    if (existing !== json) {
      console.error(
        'test/vectors/algorithm-suite.json is stale. Run: node scripts/generate-suite-vectors.mjs',
      );
      process.exit(1);
    }
    console.log(
      'algorithm-suite.json is current; primitive KATs and the §13.2 separation check pass.',
    );
    return;
  }

  writeFileSync(OUT, json);
  console.log(
    `Wrote suite 1 (${Object.keys(SUITE_1).length} roles, ${Object.keys(DEFERRED).length} deferred), ` +
      `${CARRIERS.length} carriers, ${ACCEPTANCE.length} acceptance rows and ${PRIMITIVE_KATS.length} primitive KATs.`,
  );
};

await main();

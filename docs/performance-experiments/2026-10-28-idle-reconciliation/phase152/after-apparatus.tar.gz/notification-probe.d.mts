export function installNotificationProbe(options: { withhold: boolean }): void;

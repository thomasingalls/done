from pathlib import Path
import json,subprocess,sys,shutil
s=Path(__file__).parent;d=s/'analyzer-controls';d.mkdir(exist_ok=False);shutil.copyfile(s/'analyze-case.py',d/'analyze-case.py')
source=Path('/private/tmp/done-input-investigation-20261028/baseline-repair-1-C-normal/result.json');rows=[]
for fault in ['none','false-marker','missing-key','missing-guard','bad-clock']:
 x=json.loads(source.read_text());name=fault;case={'name':name,'variant':'R','mode':'late','withhold':False};q=d/name;q.mkdir()
 if fault=='false-marker':x['probes'][0]['markers'][0]+=10000
 if fault=='missing-key':x['offers']=[o for o in x['offers']if not(o['kind']=='key'and o['index']==113)]
 if fault=='missing-guard':del x['guards']['bothOfflineColdProfilesExact']
 if fault=='bad-clock':x['clocks'][0]['rows'][0][0]['renderer']+=10000
 (q/'result.json').write_text(json.dumps(x));p=subprocess.run([sys.executable,str(d/'analyze-case.py'),json.dumps(case)],capture_output=True,text=True);(q/'console.log').write_text(p.stdout+p.stderr)
 if fault=='none':assert p.returncode==0;assert json.loads((q/'analysis.json').read_text())['accepted']
 elif fault=='false-marker':assert not json.loads((q/'analysis.json').read_text())['accepted']
 else:assert p.returncode!=0
 rows.append({'control':fault,'expectedOutcome':True,'exit':p.returncode})
(s/'analyzer-controls.json').write_text(json.dumps({'retainedPassingCaseBoundsReconstructed':True,'fourFaultsRefused':True,'rows':rows},indent=2)+'\n');print('Retained passing bounds and four fault controls pass')

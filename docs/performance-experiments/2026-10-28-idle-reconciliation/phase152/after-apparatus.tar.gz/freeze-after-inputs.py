from pathlib import Path
import subprocess,json,hashlib
s=Path(__file__).parent;r=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');tree='9f124c6992e64db2785b5af1af2718be6abeb54a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();items=[]
for b in subprocess.check_output(['git','ls-tree','-r','-z',tree],cwd=r).split(b'\0'):
 if not b:continue
 a,path=b.split(b'\t');mode,kind,oid=a.decode().split();path=path.decode()
 if(s/'source-C'/path).is_file():items.append((path,mode,oid))
batch=subprocess.run(['git','cat-file','--batch'],cwd=r,input=('\n'.join(v[2]for v in items)+'\n').encode(),stdout=subprocess.PIPE,check=True).stdout;at=0;files={}
for path,mode,oid in items:
 end=batch.index(b'\n',at);header=batch[at:end].split();size=int(header[2]);blob=batch[end+1:end+size+1];at=end+size+2;p=s/'source-C'/path;assert p.read_bytes()==blob,path;assert bool(p.stat().st_mode&0o111)==(mode=='100755');files[path]=sha(p)
for prefix in ['src','test','account-service','account-protocol','scripts','vite','private','vendor-patches']:
 for p in(s/'source-C'/prefix).rglob('*'):
  if p.is_file():assert str(p.relative_to(s/'source-C'))in files
changes=subprocess.check_output(['git','diff','--name-only','74244a0369d66a67e276e6dcb71d1d28f7934b2d',tree,'--','src','account-service','account-protocol','vite','vite.config.ts','Dockerfile'],cwd=r).decode().splitlines();assert changes==['src/crdt/accountReceive.ts','src/crdt/accountSyncDriver.ts'],changes
server={}
for prefix in ['account-service','account-protocol']:
 for p in(s/'source-C'/prefix).rglob('*'):
  if p.is_file():path=str(p.relative_to(s/'source-C'));assert p.read_bytes()==(Path('/private/tmp/done-publication-latch-20261027/source-R')/path).read_bytes();server[path]=sha(p)
client=json.loads((s/'C-client-identity.json').read_text());assert client['flags']=={'VITE_ACCOUNT_RETENTION_AUTO':'1','VITE_ACCOUNT_RETENTION_RESUME':'1','VITE_ACCOUNT_HISTORY_AUTO':'0','VITE_ACCOUNT_BATCH':'coordinated-2000'}
for path,h in client['assets'].items():assert sha(s/'source-C/dist'/path)==h
assert(s/'source-R/tsconfig.app.json').read_bytes()==(s/'source-C/tsconfig.app.json').read_bytes()
apparatus={str(p.relative_to(s)):sha(p)for p in(s/'harness').rglob('*')if p.is_file()and'node_modules'not in p.parts}
for n in ['run.py','run-plan.json','analyze-case.py','analyzer-controls.py','read-request.mjs','read-request.d.mts','notification-probe.mjs','notification-probe.d.mts','container-service.mjs','observer.mjs','container-image.json','playwright-storage-source.txt','audit-lib.mjs','audit-native.mjs','maintenance-probe.txt','build-clients.mjs','protocol.md','freeze-after-inputs.py']:
 apparatus[n]=sha(s/n)
private={}
for name in ['private-fixture','prepared-fixture']:
 f=s/name/'fixture.json';x=json.loads(f.read_text());private[name]={'fixtureSha256':sha(f),'serverStateHashes':{str(p.relative_to(Path(x['state']))):sha(p)for p in Path(x['state']).rglob('*')if p.is_file()}}
prior=Path('/private/tmp/done-publication-selection-monotonic-20261028/maintenance-3-C-withheld/result.json')
(s/'after-input-identity.json').write_text(json.dumps({'sourceTree':tree,'exportedFilesMatchGitBothDirections':files,'onlyRuntimeChanges':changes,'client':client,'unchangedServerAndProtocol':server,'apparatus':apparatus,'privateInputs':private,'existingBeforeCaseSha256':sha(prior),'beforeCaseIsFailedFunctionalEvidence':True,'beforeRerun':False,'serviceAutomationOff':True},indent=2)+'\n');print('Exact after source',len(files),'apparatus',len(apparatus),'server/protocol',len(server))

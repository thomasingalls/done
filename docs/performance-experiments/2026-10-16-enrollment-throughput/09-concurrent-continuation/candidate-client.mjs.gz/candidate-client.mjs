//#region src/account/privateAccess.ts
const isPrivateAccess = (value) => typeof value === "function" || typeof value === "string" && /^[A-Za-z0-9_-]{43}$/.test(value);
var PrivateServiceUnavailable = class extends Error {
	constructor() {
		super("This step needs a connection to the account service. Your saved progress has been kept.");
	}
};
/** Retry only an HTTP denial, once, with the identical already-prepared body. */
async function privateServiceFetch(pin, access, path, init) {
	const url = new URL(path, pin.origin);
	if (url.origin !== pin.origin || !isPrivateAccess(access)) throw Error("Invalid private access");
	const signal = AbortSignal.any([...init.signal ? [init.signal] : [], AbortSignal.timeout(1e4)]);
	try {
		for (const refresh of [false, true]) {
			signal.throwIfAborted();
			const token = typeof access === "string" ? access : await access(refresh, signal);
			signal.throwIfAborted();
			if (typeof token !== "string" || !/^[A-Za-z0-9_-]{43}$/.test(token)) throw Error("Invalid private access");
			const headers = new Headers(init.headers);
			headers.set("Authorization", "Bearer " + token);
			const response = await fetch(url, {
				...init,
				headers,
				credentials: "omit",
				cache: "no-store",
				redirect: "error",
				signal
			});
			if (response.status !== 403 || typeof access === "string" || refresh) return response;
			await response.body?.cancel();
		}
	} catch (cause) {
		if (cause instanceof TypeError || signal.aborted && !init.signal?.aborted) throw new PrivateServiceUnavailable();
		throw cause;
	}
	throw Error("Private access unavailable");
}
//#endregion
//#region src/account/accountHttp.ts
const isAccountAccess = (value) => isPrivateAccess(value) || !!value && typeof value === "object" && "kind" in value && value.kind === "scoped-account" && "fetch" in value && typeof value.fetch === "function";
function accountServiceFetch(pin, access, path, init) {
	if (typeof access === "object") {
		if (JSON.stringify(access.pin) !== JSON.stringify(pin)) throw Error("Account transport pin changed");
		return access.fetch(path, init);
	}
	return privateServiceFetch(pin, access, path, init);
}
Array.from({ length: 256 }, (_, byte) => byte.toString(16).padStart(2, "0"));
//#endregion
//#region src/account/scopedTransport.ts
var NetworkSignInRequired = class extends Error {
	constructor(message = "Reconnect sync with your account passkey to continue. Your progress is saved.") {
		super(message);
	}
};
var NetworkAuthorityChanged = class extends Error {
	constructor() {
		super("Account authorization refused: authority-changed");
	}
};
var NetworkThrottled = class extends Error {
	constructor() {
		super("The account service is busy. Saved progress can be retried.");
	}
};
//#endregion
//#region account-protocol/diagnostics.ts
/** Unsigned diagnostic vocabulary. None of these observations grants protocol authority. */
const SERVICE_HINTS = [
	"ledger-integrity",
	"invalid-request",
	"envelope-size",
	"unavailable",
	"unsupported-epoch",
	"out-of-order",
	"parent-required",
	"unissued-parent",
	"removal-pending",
	"state-changed",
	"storage-unavailable"
];
const PROMOTION_REFUSALS = [
	"malformed",
	"unknown-attempt",
	"operation-mismatch",
	"cancelled",
	"expired",
	"proof-conflict",
	"invalid-proof",
	"credential-in-use",
	"account-not-active",
	"account-not-pending",
	"recovery-conflict",
	"already-finished",
	"storage-unavailable"
];
const fields = (input, keys) => {
	if (!input || typeof input !== "object" || Array.isArray(input)) return null;
	const descriptors = Object.getOwnPropertyDescriptors(input);
	if (Reflect.ownKeys(input).length !== keys.length || keys.some((k) => !descriptors[k] || !("value" in descriptors[k]))) return null;
	return Object.fromEntries(keys.map((k) => [k, descriptors[k].value]));
};
function serviceHint(input) {
	const value = fields(input, [
		"v",
		"kind",
		"reason"
	]);
	return value?.["v"] === 1 && value["kind"] === "unknown" && SERVICE_HINTS.includes(value["reason"]) ? value["reason"] : null;
}
const DIAGNOSTIC_OPERATIONS = [
	"delivery-audit",
	"submit",
	"read",
	"read-v2",
	"promotion-begin",
	"promotion-challenge",
	"promotion-finish",
	"account-transaction",
	"enrollment",
	"successor",
	"discovery",
	"http"
];
const DIAGNOSTIC_PHASES = [
	"request",
	"storage",
	"verify",
	"commit",
	"response",
	"stream"
];
const DIAGNOSTIC_CODES = [
	...SERVICE_HINTS,
	...PROMOTION_REFUSALS,
	"invalid-token",
	"network-unavailable",
	"response-invalid",
	"response-too-large",
	"inbound-size",
	"aborted",
	"timeout",
	"http-denied",
	"unexpected-failure",
	"storage-busy",
	"crypto-failure"
];
/** No identifiers, raw exception messages, URLs, tokens, factors or writing. Never persisted. */
function createDiagnostics() {
	const rows = [];
	return {
		record(event) {
			if (!DIAGNOSTIC_OPERATIONS.includes(event.operation) || !DIAGNOSTIC_PHASES.includes(event.phase) || !DIAGNOSTIC_CODES.includes(event.code)) return;
			if (rows.length === 32) rows.shift();
			rows.push(Object.freeze({
				operation: event.operation,
				phase: event.phase,
				code: event.code
			}));
		},
		read: () => rows.map((row) => ({ ...row })),
		clear: () => {
			rows.length = 0;
		}
	};
}
function reportDiagnostic(sink, event) {
	try {
		sink?.(event);
	} catch {}
}
//#endregion
//#region src/account/privateDeliveryHttp.ts
const diagnostics = createDiagnostics();
const PRIVATE_DELIVERY_TIMEOUT_MS = 1e4;
const readPrivateTransportDiagnostics = diagnostics.read;
const clearPrivateTransportDiagnostics = diagnostics.clear;
const recordPrivateTransportDiagnostic = diagnostics.record;
/** Closed, count-bounded observation from the receive owner; never request bytes or authority. */
const recordPrivateReceiveExpiry = (phase) => reportDiagnostic(diagnostics.record, {
	operation: "read-v2",
	phase,
	code: "expired"
});
async function privateDeliveryPost(pin, token, path, body, limit, signal, observe = diagnostics.record, propagateAuthorization = false, unsupported) {
	const note = (phase, code) => reportDiagnostic(observe, {
		operation: path === "read-v2-batch" ? "read-v2" : path,
		phase,
		code
	});
	if (!isAccountAccess(token)) {
		note("request", "invalid-token");
		return null;
	}
	const stopped = AbortSignal.any([signal, AbortSignal.timeout(PRIVATE_DELIVERY_TIMEOUT_MS)]);
	const interrupted = () => signal.aborted ? "aborted" : "timeout";
	try {
		stopped.throwIfAborted();
		const response = await accountServiceFetch(pin, token, "/account/delivery/" + path, {
			method: "POST",
			headers: { "Content-Type": "application/octet-stream" },
			body,
			credentials: "omit",
			cache: "no-store",
			redirect: "error",
			signal: stopped
		});
		if (path === "read-v2-batch" && response.status === 404 && unsupported) {
			await response.body?.cancel();
			stopped.throwIfAborted();
			return await unsupported();
		}
		const hint = response.status === 409 && response.headers.get("content-type") === "application/json";
		if (stopped.aborted || !hint && (response.status !== 200 || response.headers.get("content-type") !== "application/octet-stream") || !response.body) {
			await response.body?.cancel();
			note("response", stopped.aborted ? interrupted() : response.status === 403 ? "http-denied" : "response-invalid");
			return null;
		}
		const responseLimit = hint ? 512 : limit;
		const declared = response.headers.get("content-length");
		if (declared !== null && (!/^\d+$/.test(declared) || Number(declared) > responseLimit)) {
			await response.body.cancel();
			note("response", "response-too-large");
			return null;
		}
		const reader = response.body.getReader(), chunks = [];
		let length = 0;
		let cancellation;
		const cancel = () => {
			cancellation ??= reader.cancel().catch(() => {});
		};
		stopped.addEventListener("abort", cancel, { once: true });
		try {
			for (;;) {
				stopped.throwIfAborted();
				const { done, value } = await reader.read();
				stopped.throwIfAborted();
				if (done) break;
				length += value.length;
				if (length > responseLimit) {
					cancel();
					note("stream", "response-too-large");
					return null;
				}
				chunks.push(new Uint8Array(value));
			}
			if (declared !== null && Number(declared) !== length) {
				note("stream", "response-invalid");
				return null;
			}
			const bytes = new Uint8Array(length);
			let at = 0;
			for (const chunk of chunks) {
				bytes.set(chunk, at);
				at += chunk.length;
			}
			if (hint) {
				try {
					note("response", serviceHint(JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes))) ?? "response-invalid");
				} catch {
					note("response", "response-invalid");
				} finally {
					bytes.fill(0);
				}
				return null;
			}
			return bytes;
		} catch {
			cancel();
			note("stream", stopped.aborted ? interrupted() : "response-invalid");
			return null;
		} finally {
			stopped.removeEventListener("abort", cancel);
			await cancellation;
			reader.releaseLock();
			for (const chunk of chunks) chunk.fill(0);
		}
	} catch (cause) {
		if (propagateAuthorization && (cause instanceof NetworkAuthorityChanged || cause instanceof NetworkSignInRequired || cause instanceof NetworkThrottled)) throw cause;
		note("request", stopped.aborted ? interrupted() : "network-unavailable");
		return null;
	}
}
"00".repeat(32);
const READ_REQUEST_LIMIT = 4096;
const READ_PAGE_LIMIT = 10 * 1024 * 1024;
const requestTag = new TextEncoder().encode("done/private-read-batch/v1\0");
const pageTag = new TextEncoder().encode("done/private-read-pages/v1\0");
const overhead = (tag) => tag.length + 4 + 16;
const INBOUND_BATCH_REQUEST_LIMIT = overhead(requestTag) + 4 * READ_REQUEST_LIMIT;
overhead(pageTag) + READ_PAGE_LIMIT;
//#endregion
//#region src/account/historyReadRetry.ts
const EXTRA_ATTEMPTS = 4;
const BACKOFF_MS = 200;
function pause(signal) {
	return new Promise((resolve, reject) => {
		const abort = () => {
			clearTimeout(timer);
			signal.removeEventListener("abort", abort);
			reject(signal.reason);
		};
		const timer = setTimeout(() => {
			signal.removeEventListener("abort", abort);
			resolve();
		}, BACKOFF_MS);
		signal.addEventListener("abort", abort, { once: true });
		if (signal.aborted) abort();
	});
}
/** One transient snapshot load. Hints schedule bounded read work, never progress or authority. */
function createHistoryReadRetry(signal) {
	let remaining = EXTRA_ATTEMPTS, active = false;
	return async (body, post) => {
		if (active) throw Error("Overlapping history read");
		if (!body.length || body.length > INBOUND_BATCH_REQUEST_LIMIT) throw Error("Invalid history read size");
		const captured = new Uint8Array(body), stopped = AbortSignal.any([signal, AbortSignal.timeout(PRIVATE_DELIVERY_TIMEOUT_MS)]);
		active = true;
		try {
			for (;;) {
				stopped.throwIfAborted();
				let changed = false;
				const outgoing = new Uint8Array(captured);
				let answer;
				try {
					answer = await post(outgoing, stopped, (event) => {
						recordPrivateTransportDiagnostic(event);
						if (event.operation === "read-v2" && event.phase === "response" && event.code === "state-changed") changed = true;
					});
				} finally {
					outgoing.fill(0);
				}
				if (stopped.aborted) {
					answer?.fill(0);
					return null;
				}
				if (answer !== null || !changed || !remaining) return answer;
				remaining--;
				await pause(stopped);
			}
		} catch (cause) {
			if (stopped.aborted) return null;
			throw cause;
		} finally {
			captured.fill(0);
			active = false;
		}
	};
}
//#endregion
export { PRIVATE_DELIVERY_TIMEOUT_MS, clearPrivateTransportDiagnostics, createHistoryReadRetry, privateDeliveryPost, readPrivateTransportDiagnostics, recordPrivateReceiveExpiry, recordPrivateTransportDiagnostic };

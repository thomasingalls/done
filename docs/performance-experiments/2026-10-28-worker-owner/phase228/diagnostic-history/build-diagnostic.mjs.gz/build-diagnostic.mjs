import{build}from'/Users/thomasingalls/.codex/worktrees/7fda/done/node_modules/vite/dist/node/index.js';import{readFileSync,writeFileSync}from'node:fs';import{createHash}from'node:crypto';
const root='/private/tmp/done-worker-conversion-20261028/native228',observed=[];const sha=s=>createHash('sha256').update(s).digest('hex');
const observer={name:'disposable-readonly-mirror-observer',enforce:'pre',transform(code,id){
 let next=code;
 if(id.endsWith('/src/crdt/accountWorkerClient.ts')){const anchor='return workspaceSchedulingStatus(composedController.workspace.status);';if(code.split(anchor).length!==2)throw Error('Observer client anchor drift');next=code.replace(anchor,"window.dispatchEvent(new CustomEvent('disposable-mirror-observer',{detail:{workspace:composedController.workspace,sync:()=>session?.ports.sync}}));\n"+anchor);}
 if(id.endsWith('/src/crdt/admissionQueue.ts')){const anchor='const block = (error: unknown) => {';if(code.split(anchor).length!==2)throw Error('Observer admission anchor drift');next=code.replace(anchor,anchor+"\n {const chain=[];let item=error;for(let i=0;i<4&&item;i++){chain.push({name:item.name,code:item.code,message:String(item.message??'').slice(0,256),stack:String(item.stack??'').split('\\n').slice(0,5).join('\\n')});item=item.cause;}console.warn('done/experiment/disposable-admission '+JSON.stringify(chain));}\n");}
 if(next!==code){observed.push({path:id,source:sha(code),observed:sha(next),permissionChange:false});return {code:next,map:null};}
}};
await build({configFile:'/Users/thomasingalls/.codex/worktrees/7fda/done/vite.config.ts',plugins:[observer],build:{outDir:root+'/frontend-diagnostic',emptyOutDir:true,sourcemap:true},logLevel:'warn'});writeFileSync(root+'/diagnostic-transforms.json',JSON.stringify(observed,null,2)+'\n');

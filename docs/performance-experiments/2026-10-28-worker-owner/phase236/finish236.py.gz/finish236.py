from pathlib import Path
import subprocess,json,hashlib,gzip,re
r=Path(__file__).parent;repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');prior=Path('/private/tmp/done-phase235-replay-1p6nsrwg');p=repo/'docs/performance-experiments/2026-10-28-worker-owner/phase236';sha=lambda b:hashlib.sha256(b).hexdigest()
assert '3 passed' in(r/'236-packaged-after.log').read_text()
assets=json.loads((repo/'docs/performance-experiments/2026-10-28-worker-owner/phase235/build-assets.json').read_text());assert assets=={str(f.relative_to(r/'validation229/dist')):sha(f.read_bytes())for f in(r/'validation229/dist').rglob('*')if f.is_file()}
# Independent adversarial classification: only two exact hashed public-JS families are exempt.
allowed=re.compile(r'^/assets/(?:privateDeliveryHttp|recoveryOwner\.worker)-[A-Za-z0-9_-]+\.js$');blocked=['/private.html','/recovery.html','/migration.html','/assets/recoveryOwner.worker-A.js.map','/assets/privateDeliveryHttp-A.js.map','/assets/privateSomething-A.js','/assets/recoveryOwner.worker-A.json','/assets/other-binding-A.js'];assert all(not allowed.search(x)for x in blocked)
p.mkdir();(p/'review.json').write_text(json.dumps({'runtimeChanges':[],'artifactExact235':True,'oldTests':'three original cases, all original file/body-byte/offline/protection checks and deadlines retained','exemptions':['hashed privateDeliveryHttp JavaScript','hashed recoveryOwner.worker JavaScript'],'refusedExamples':blocked,'newCases':0},indent=2)+'\n')
for f in[*r.glob('236-*.log'),r/'finish236.py']:(p/(f.name+'.gz')).write_bytes(gzip.compress(f.read_bytes(),mtime=0))
(p/'README.md').write_text('''# Phase236 — packaged Worker asset and offline compatibility

2026-10-29. Existing precache test flags two new legitimate public modules by substring:
privateDeliveryHttp and recoveryOwner.worker. Narrow only those two hashed /assets/*.js families.
Original existing-file, HTTP200, exact-byte, manifest/icon, private-page/tooling and map checks remain.
Independent rejected examples cover private/recovery/migration pages, both source-map counterparts,
unrelated private/binding modules and non-JS suffixes. No production change or build change235.

Before one failed/two passed; after all three original cases pass. Protected Local writing accepts,
locks, cold reopens offline, admits another edit and cold reopens that edit at both public entries.
Same deadlines/cases; no old assertions removed. No qualification or performance credit. Remaining
old native outcomes and final boundary review next, then original16ms/2.5s/30s measurements.
No real staging/sign/push, preview8443, release/deploy, service automation, CUA/phone/real data.
''')
link='performance-experiments/2026-10-28-worker-owner/phase236/README.md'
for file,text in [('decisions.md','Exempt only two exact hashed public JavaScript filename families from the old private-tooling substring check; keep pages/maps and unrelated private modules excluded.'),('completed.md','Packaged precache exact bytes and both protected offline cold-write flows pass all three unchanged cases/deadlines after narrow filename fixture repair. Artifact exact235; before failure retained.'),('product-backlog.md','Phase236 packaged Worker chunks and protected offline writing verified. Continue original native compatibility outcomes and final boundary audit before performance measurements.')]:
 with(repo/'docs'/file).open('a')as f:f.write('\n\n## 2026-10-29 — phase236: packaged offline Worker assets\n\n'+text+' [Evidence]('+link+').\n')
print('236 closed; completed before backlog')

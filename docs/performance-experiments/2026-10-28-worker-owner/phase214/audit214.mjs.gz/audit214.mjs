import{readFileSync,existsSync}from'node:fs';import{execFileSync}from'node:child_process';import{parseSync}from'/Users/thomasingalls/.codex/worktrees/7fda/done/node_modules/@babel/core/lib/index.js';import assert from'node:assert/strict';
const repo='/Users/thomasingalls/.codex/worktrees/7fda/done',r='/private/tmp/done-worker-conversion-20261028',prior=readFileSync(r+'/213-freeze.log','utf8').match(/Replay: (.+)/)[1],old=p=>existsSync(prior+'/'+p)?readFileSync(prior+'/'+p):execFileSync('git',['show','HEAD:'+p],{cwd:repo}),clean=v=>Array.isArray(v)?v.map(clean):v&&typeof v==='object'?Object.fromEntries(Object.entries(v).filter(([k])=>!['start','end','loc','comments','leadingComments','trailingComments','innerComments','extra','range'].includes(k)).map(([k,v])=>[k,clean(v)])):v,parse=b=>clean(parseSync(b.toString(),{filename:'source.ts',babelrc:false,configFile:false,parserOpts:{plugins:['typescript']}}).program.body),walk=(v,op)=>{if(!v||typeof v!=='object')return;op(v);for(const x of Object.values(v))if(Array.isArray(x))x.forEach(y=>walk(y,op));else if(x&&typeof x==='object')walk(x,op)},fn=(p,n,b)=>parse(b??readFileSync(repo+'/'+p)).find(v=>v.declaration?.id?.name===n).declaration,member=n=>n?.object?.name==='setup';
for(const[p,name]of[['src/crdt/accountWorkerOwner.ts','startAccountWorkerOwner'],['src/crdt/accountWorkerClient.ts','openAccountWorkerSession'],['src/crdt/workerAccountHandoff.ts','createWorkerAccountHandoff']]){
 const a=fn(p,name),b=fn(p,name,old(p));a.params=b.params;
 walk(a,n=>{
  if(Array.isArray(n.body)){
   const body=[];for(let i=0;i<n.body.length;i++){const s=n.body[i];
    if(s.type==='VariableDeclaration'&&s.declarations.length===1&&['setup','nativePasskey'].includes(s.declarations[0].id.name))continue;
    if(s.type==='ExpressionStatement'&&member(s.expression?.callee)){if(s.expression.callee.property.name==='composed'){assert.equal(n.body[i+1]?.expression?.callee?.name,'live');i++}continue}
    if(s.type==='ExpressionStatement'&&s.expression?.type==='AssignmentExpression'&&s.expression.left?.name==='setupActor')continue;
    body.push(s);
   }n.body=body;
  }
  if(n.type==='VariableDeclaration')n.declarations=n.declarations.filter(d=>d.id.name!=='setupActor');
  if(n.type==='LogicalExpression'&&n.operator==='??'&&n.left?.object?.name==='setup'){const replacement=n.right;for(const k of Object.keys(n))delete n[k];Object.assign(n,replacement)}
  if(n.type==='Identifier'&&n.name==='nativePasskey')n.name='passkey';
  if(n.type==='ObjectExpression')n.properties=n.properties.filter(v=>!['setupActorName','setupActorRename'].includes(v.key?.name));
  if(n.type==='CallExpression'&&n.callee.name==='startAccountWorkerOwner')n.arguments.pop();
 });assert.deepEqual(a,b,p+' default implementation AST after subtracting optional native context/display additions');
}
for(const p of ['src/crdt/writeSession.ts','src/crdt/custody.ts','src/crdt/accountWorkerRuntime.ts','src/crdt/accountReceive.ts','src/account/promotionOpening.ts','src/account/recoveryOpening.ts','src/account/networkLogin.ts','src/crdt/workerCeremonyOpening.ts','src/crdt/windowAccountMirror.ts','src/account/firstDeviceSetup.ts'])assert(readFileSync(repo+'/'+p).equals(old(p)),p);
console.log('Independent audit: default original Account entry/client/handoff AST exact after subtracting optional same-realm context and explicit canonical actor effects. Original approval WeakMaps, native permission/crypto/authority/history/login/canonical journal bodies byte unchanged213. Context is callback routing only, one scoped composition; real native verification remains unchanged.');

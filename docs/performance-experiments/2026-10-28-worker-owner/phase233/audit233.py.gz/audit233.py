from pathlib import Path
import json,hashlib,subprocess
r=Path(__file__).parent;repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');prior=Path('/private/tmp/done-phase232-replay-r6na3hvf');changed=[];sha=lambda b:hashlib.sha256(b).hexdigest();tracked=set(subprocess.check_output(['git','ls-files'],cwd=repo,text=True).splitlines())
for f in(repo/'src').rglob('*'):
 if not f.is_file():continue
 rel=str(f.relative_to(repo));old=(prior/rel).read_bytes()if(prior/rel).is_file()else(subprocess.check_output(['git','show','HEAD:'+rel],cwd=repo)if rel in tracked else None)
 if f.read_bytes()!=old:changed.append(rel)
assert set(changed)=={'src/ui/windowCeremonyUi.ts','src/ui/firstDeviceSetupWorker.ts'},changed
matched={};bad=[]
for f in(r/'validation229/dist').rglob('*.map'):
 m=json.loads(f.read_text())
 for src,body in zip(m['sources'],m.get('sourcesContent',[])):
  rel='src/'+src.split('/src/',1)[1]if'/src/'in src else'account-protocol/'+src.split('account-protocol/',1)[1]if'account-protocol/'in src else None
  if rel and(repo/rel).is_file():
   if sha(body.encode())!=sha((repo/rel).read_bytes()):bad.append(rel)
   else:matched[rel]=sha(body.encode())
assert not bad,bad
for rel in['test/packaged-account/recovery.spec.ts','test/packaged-account/devices.ts']:
 assert (repo/rel).read_bytes()==subprocess.check_output(['git','show','HEAD:'+rel],cwd=repo)
(r/'233-audit-second.json').write_text(json.dumps({'changes':changed,'nativeCryptoHistoryTaskJournalBodies':'byte identical232','oldTestsChanged':[],'exactBuildBodies':matched,'mismatches':bad,'oldFixtureReview':'none'},indent=2)+'\n');print(len(matched),'exact bodies')

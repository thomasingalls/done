import{build}from'/Users/thomasingalls/.codex/worktrees/7fda/done/node_modules/vite/dist/node/index.js';
import{writeFileSync}from'node:fs';
const changes=[];function transform(s,id){const p=id.split('?')[0].split('/src/')[1];if(!p)return;let next=s;
const add=(anchor,line)=>{if(!next.includes(anchor))throw Error(p+' missing '+anchor);next=next.replace(anchor,anchor+`\nconsole.info('D230:${p}:${line}');\n`);changes.push({p,anchor,line});};
if(p==='ui/windowCeremonyUi.ts'){add('const fail = () => {','fail');add('const close = () => {','close');add('} catch (cause) {','open-catch');}
if(p==='crdt/accountWorkerOwner.ts'){add('const close = () => {','close');add('await opening?.catch(() => {});','opening-drained');add('await owner?.carrier.close();','carrier-drained');}
if(p==='account/firstDeviceSetup.ts'){add('const close = () => {','close');}
return next===s?undefined:{code:next,map:null};}
// Window only diagnostic markers, no source changes. Worker transforms use same plugin factory.
const plugin=()=>({name:'disposable230',enforce:'pre',transform});
try{await build({root:'/Users/thomasingalls/.codex/worktrees/7fda/done',plugins:[plugin()],worker:{plugins:()=>[plugin()]},build:{outDir:'/private/tmp/done-worker-conversion-20261028/validation229/dist',emptyOutDir:true,sourcemap:true}});}finally{writeFileSync('/private/tmp/done-worker-conversion-20261028/230-diagnostic-transforms.json',JSON.stringify(changes,null,2));}

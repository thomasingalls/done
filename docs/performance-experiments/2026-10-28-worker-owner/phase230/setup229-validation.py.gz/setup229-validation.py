from pathlib import Path
import shutil,json,hashlib
r=Path(__file__).parent;repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');root=r/'validation229';root.mkdir();(root/'test').mkdir()
for name in ['packaged-account','geometry','device-enrollment']:
 shutil.copytree(repo/'test'/name,root/'test'/name,ignore=shutil.ignore_patterns('node_modules','test-results'))
for name in ['node_modules','scripts','src','account-service','account-protocol','docs','vite','public']:(root/name).symlink_to(repo/name,target_is_directory=True)
for name in ['package.json','tsconfig.json']:
 if(repo/name).exists():shutil.copy2(repo/name,root/name)
shutil.copytree(r/'native228/frontend',root/'dist')
(root/'playwright.config.ts').write_text("""import{defineConfig}from'@playwright/test';export default defineConfig({testDir:'./test/packaged-account',outputDir:'./artifacts',timeout:120000,workers:1,retries:0,reporter:[['list'],['json',{outputFile:'./results.json'}]],use:{baseURL:'http://localhost:53221',viewport:{width:1400,height:1000},headless:true,trace:'off',screenshot:'off',video:'off',launchOptions:{executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'}}});""")
files={str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest()for f in(root/'test').rglob('*')if f.is_file()};files['playwright.config.ts']=hashlib.sha256((root/'playwright.config.ts').read_bytes()).hexdigest();(r/'229-original-validation-inputs.json').write_text(json.dumps({'copiedInputs':files,'frontendInputs':json.loads((r/'228-frontend-source-review.json').read_text()),'oldTestBodyChanges':[]},indent=2)+'\n');print(root)

from pathlib import Path
import subprocess,json,hashlib,gzip,re
r=Path(__file__).parent;repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');prior=Path('/private/tmp/done-phase234-replay-_0ozb3x9');p=repo/'docs/performance-experiments/2026-10-28-worker-owner/phase235';sha=lambda b:hashlib.sha256(b).hexdigest();tracked=set(subprocess.check_output(['git','ls-files'],cwd=repo,text=True).splitlines());changed=[]
def old(rel):return(prior/rel).read_bytes()if(prior/rel).is_file()else subprocess.check_output(['git','show','HEAD:'+rel],cwd=repo)if rel in tracked else None
for f in(repo/'src').rglob('*'):
 if f.is_file()and f.read_bytes()!=old(str(f.relative_to(repo))):changed.append(str(f.relative_to(repo)))
assert changed==['src/crdt/ownedCredentialPrompt.ts'],changed
for f in(repo/'test').rglob('*'):
 if f.is_file():
  rel=str(f.relative_to(repo));assert rel=='test/credentialCancellation.test.ts'or f.read_bytes()==old(rel),rel
assert '12 passed' in(r/'235-compatibility-after.log').read_text();assert '36 passed' in(r/'235-focus.log').read_text();assert 'pass 99' in(r/'235-metadata.log').read_text();assert not(r/'235-types.log').read_text();assert 'Found 0 warnings and 0 errors' in(r/'235-lint.log').read_text()or not(r/'235-lint.log').read_text()
matched={}
for f in(r/'validation229/dist').rglob('*.map'):
 m=json.loads(f.read_text())
 for src,body in zip(m['sources'],m.get('sourcesContent',[])):
  rel='src/'+src.split('/src/',1)[1]if'/src/'in src else'account-protocol/'+src.split('account-protocol/',1)[1]if'account-protocol/'in src else None
  if rel and(repo/rel).is_file():assert body.encode()==(repo/rel).read_bytes(),rel;matched[rel]=sha(body.encode())
p.mkdir();(p/'independent-review.json').write_text(json.dumps({'sourceChanges':changed,'oldTestsChanged':[],'buildBodies':matched,'originalNativeCredentialVerification':'unchanged','genericChannel':'unchanged','lifetime':'withdrawal checked before cancellation mapping'},indent=2)+'\n')
for f in[*r.glob('235-*.log'),*r.glob('235-*.json'),r/'finish235.py']:
 b=re.sub(rb'(?<![A-Z0-9])[A-Z0-9]{5}(?:-[A-Z0-9]{5}){4}(?![A-Z0-9])',b'[disposable code redacted]',f.read_bytes());(p/(f.name+'.gz')).write_bytes(gzip.compress(b,mtime=0))
(p/'build-assets.json').write_text(json.dumps({str(f.relative_to(r/'validation229/dist')):sha(f.read_bytes())for f in(r/'validation229/dist').rglob('*')if f.is_file()},indent=2)+'\n')
(p/'README.md').write_text('''# Phase235 — preserve live passkey cancellation across the Worker boundary

2026-10-29. A live provider NotAllowedError/AbortError becomes one fixed credential-specific
transport code, reconstructed as the native cancellation DOMException. No raw provider message
crosses the port. Root/Task/prompt withdrawal wins over a late response, disposal remains unconditional,
and malformed or generic replies remain refusals. Original credential consumers/cryptographic checks,
Task authority, storage and generic channel are unchanged234. No old test edits.

Before: six new controlled cases have three failures; original twelve compatibility cases have one
failure (cancelled setup reports a generic error). After:36 focused,99 metadata,type/lint and all12
UNCHANGED browser cases pass. Original offline Local access, same resumable setup, altered assertion
refusal, provider JSON compatibility and automatic deletion/legacy preservation assertions remain.
Clean source-map bodies match checkout. No profiles, factors or error-context files archived.

Remaining boundary/offline/mixed checks and open182/187/205 review precede unchanged16ms input,
2.5s peer/all-marker and30s delivery measurements. This is functional evidence, not qualification or
performance acceptance. New tests required/uncredited; qualification paused. No real staging/sign/
push, preview8443, release/deploy, service automation, computer use or physical-device access.
''')
link='performance-experiments/2026-10-28-worker-owner/phase235/README.md'
for file,text in [('decisions.md','Use a fixed cancellation code only for a live browser prompt; native lifetime withdrawal wins over late provider replies. Original credential verification and generic channel unchanged.'),('completed.md','Cancellation transport repaired: six new cases,36 focused,99 metadata/type/lint and all12 unchanged browser compatibility cases pass. Before failures preserved; no old test edits.'),('product-backlog.md','Phase235 closes cancellation/offline/resume compatibility. Continue remaining Worker boundary/lifecycle checks and explicit older failure review, then unchanged performance gates.')]:
 with(repo/'docs'/file).open('a')as f:f.write('\n\n## 2026-10-29 — phase235: live credential cancellation\n\n'+text+' [Evidence]('+link+').\n')
print('235 closed; completed before backlog; exact bodies',len(matched))

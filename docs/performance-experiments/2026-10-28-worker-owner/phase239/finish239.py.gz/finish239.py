from pathlib import Path
import subprocess,json,hashlib,gzip,re
r=Path(__file__).parent;repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');p=repo/'docs/performance-experiments/2026-10-28-worker-owner/phase239';sha=lambda b:hashlib.sha256(b).hexdigest()
assert '2734 passed' in(r/'239-final-unit.log').read_text();assert '1 skipped' in(r/'239-final-unit.log').read_text();assert 'pass 99' in(r/'239-final-metadata.log').read_text();assert not(r/'239-types.log').read_text();assert not(r/'239-lint.log').read_text();assert all(v['exit']==0 for v in json.loads((r/'239-contract-checks.json').read_text()));assert 'no literal remote URL' in(r/'239-origin.log').read_text();assert 'budget exceeded'not in(r/'239-budget.log').read_text()
f=(r/'239-format.log').read_text();assert 'test/packaged-account/devices.ts'in f and 'above 1 files'in f
v=json.loads((r/'native237/admission-diagnostic-05/composed-context/result.json').read_text());d=v['coldDiagnostic'];a=d['admission'];assert a['status']['state']=='active'and a['status']['durable']and a['status']['pendingItems']==0 and a['durable']['ok'];assert any(x['shell']for x in d['rows'])
assets=json.loads((repo/'docs/performance-experiments/2026-10-28-worker-owner/phase235/build-assets.json').read_text());assert assets=={str(f.relative_to(r/'validation229/dist')):sha(f.read_bytes())for f in(r/'validation229/dist').rglob('*')if f.is_file()}
p.mkdir();paths=[*r.glob('239-*.log'),r/'239-contract-checks.json',r/'finish239.py',r/'cpu-pilot.mjs',r/'cpu-pilot.json',r/'cpu-pilot.log',r/'cpu-pilot-corrected.log',r/'native237/run-cold.py',r/'native237/run-admission.py',r/'native237/harness/test/account-continuation-lab/diagnostic-cold.spec.ts',r/'native237/harness/test/account-continuation-lab/diagnostic-admission.spec.ts']
for run in ['cold-diagnostic-04','admission-diagnostic-05']:
 for f in(r/'native237'/run).rglob('*'):
  if f.is_file()and f.name in ['console.log','result.json','receipt.json','services.log','container-identity.json','docker-command.json']:paths.append(f)
for f in paths:
 dest=p/(str(f.relative_to(r))+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);b=re.sub(rb'(?<![A-Z0-9])[A-Z0-9]{5}(?:-[A-Z0-9]{5}){4}(?![A-Z0-9])',b'[disposable code redacted]',f.read_bytes());dest.write_bytes(gzip.compress(b,mtime=0))
(p/'README.md').write_text('''# Phase239 — Worker conversion placement complete; functional closure and measurement limits

2026-10-29. Normal public Local/startup/setup/enrollment/recovery/Account coordination now use actual
Dedicated Workers. Window retains canonical Yjs/Undo/rendering, synchronous encrypted narrow-key
journal admission, browser provider prompts and metadata/removal UI. Explicit legacy private-service
Page compatibility remains, never a Worker-failure fallback. No background service-worker autonomy,
remember-me, shared memory, native-proof serialization or relaxed original authority/lifetime checks.
Phase237's hashed boundary map and preceding native regressions describe this completed placement.

Current complete unit run2734pass/one existing skip;99 metadata,type,scoped lint, seven original
contract checks,301.3KiB initial bundle/350KiB limit and origin-isolation checks pass. Formatter flags
only the original retained poll line in devices.ts (phase234 independently proved it pre-existing).
No old formatting repair. No all-suite/release qualification claim; broader qualification paused.

Read-only diagnostics retain the unchanged15s public cold-open failures. The editor becomes visible
at approximately20.6/21.1s after entry begins. The second observation reads actual canonical workspace
status:active,durable,no pending items/pressure; its ordinary whenDurable succeeds. The warning from
the first rendered frame is not a persistent admission block in this reproduction. This narrows205
to a cold-opening latency failure here; original failed receipts remain failed, not reclassified passes.
187's real saved preparation/cold-resume/removal and input/Undo now complete before that same late
public opening.182 deep joined30s remains open with authenticated progress, not bypassed.
No extra delay earned a passing guard and no production changes were made in this diagnosis.

Disposable CPU pilot: page medians33.2ms at1x/140.2ms at4x; dedicated Worker34.9/34.4ms.
Chrome's page throttle is MAIN-ONLY. The next actual-account workload calibrates both real realms,
labels this limit and cannot claim physical Android equivalence. Prior hidden/frozen lifecycle coverage
also remains unestablished unless actual native events/paused timers demonstrate it; no synthetic
lifecycle dispatch. The first pilot import path failed before browser launch; preserved, then corrected.

Next run original779-character/seven-sentence trusted150ms independent-offer Goals workload and
whole-client two-receiver catch-up with editing, normal and withheld hints. Keep16ms input,2.5s
peer/every-marker and30s final delivery unchanged; preserve failures. Both clients use exact candidate
assets. Do not restore old Page-private maintenance-owner hooks into the Worker product for a benchmark.
This completes conversion placement/functional audit, not performance acceptance or release readiness.
No real staging/sign/push, preview8443, release/deploy, service automation, CUA or physical-device work.
''')
link='performance-experiments/2026-10-28-worker-owner/phase239/README.md'
for file,text in [('decisions.md','Conversion completion means normal public heavy owners are in actual Workers, with intentional Window and explicit legacy boundaries documented; it does not imply latency acceptance. Main-only CDP throttling must not be reported as mobile hardware equivalence.'),('completed.md','Worker placement complete.2734unit cases pass/one existing skip;99metadata/type/lint/contracts/bundle/origin checks pass. Cold15s guard still fails but editor appears~21s with active durable canonical owner. Deep joined30s remains open. Begin unchanged performance measurements.'),('product-backlog.md','Phase239: conversion complete on normal public paths; remaining work is measured performance/latency debt. Cold public entry~21s misses15s and deep joined catch-up misses30s. Run seven-sentence Goals input and whole-client peer cases with unchanged gates; no release preparation.')]:
 with(repo/'docs'/file).open('a')as f:f.write('\n\n## 2026-10-29 — phase239: Worker placement complete, measure next\n\n'+text+' [Evidence]('+link+').\n')
print('239 closed; completed before backlog; performance next')

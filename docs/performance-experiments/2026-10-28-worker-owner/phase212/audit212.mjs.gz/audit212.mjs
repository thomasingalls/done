import{readFileSync,existsSync}from'node:fs';import{execFileSync}from'node:child_process';import assert from'node:assert/strict';
const repo='/Users/thomasingalls/.codex/worktrees/7fda/done',r='/private/tmp/done-worker-conversion-20261028',prior=readFileSync(r+'/211-freeze.log','utf8').match(/Replay: (.+)/)[1];
const edits={
 'src/crdt/nativeCoordination.ts':s=>s.replace("    ceremonyReservation: slot + '/worker-ceremony-supervisor',\n",''),
 'src/crdt/accountWorkerCohort.ts':s=>s.replace("kind === 'ceremony' ? n.ceremonyReservation : n.reservation",'n.reservation'),
 'src/crdt/ceremonyWorkerLifetime.ts':s=>s.replace('names.ceremonyReservation','names.reservation')
};
for(const[p,undo]of Object.entries(edits))assert.equal(undo(readFileSync(repo+'/'+p,'utf8')),readFileSync(prior+'/'+p,'utf8'),p);
for(const p of ['src/crdt/accountWorkerJoin.ts','src/crdt/localWorkerLifetime.ts','src/crdt/writeSession.ts','src/crdt/custody.ts','src/crdt/ceremonyEnvironment.ts','src/crdt/protectionEnvironment.ts','src/crdt/workerAccountHandoff.ts','src/crdt/accountWorkerOwner.ts','src/account/firstDeviceSetup.ts','src/account/promotionOpening.ts','src/account/recoveryOpening.ts'])assert(readFileSync(repo+'/'+p).equals((existsSync(prior+'/'+p)?readFileSync(prior+'/'+p):execFileSync('git',['show','HEAD:'+p],{cwd:repo}))),p);
console.log('Independent audit: exactly three reservation-name substitutions; all original Account/Local native joins, SC03 shared/exclusive tasks, key/crypto/authority, genuine-root checks, cleanup/member barriers, original approval WeakMaps and handoff byte unchanged211. Ceremony holds no editing lease and cannot satisfy either editing role.');

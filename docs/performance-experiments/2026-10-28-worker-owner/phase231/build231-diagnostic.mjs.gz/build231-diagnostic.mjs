import{build}from'/Users/thomasingalls/.codex/worktrees/7fda/done/node_modules/vite/dist/node/index.js';
import{writeFileSync}from'node:fs';
const changes=[];function transform(s,id){const p=id.split('?')[0].split('/src/')[1];if(!p)return;let next=s;
const add=(anchor,line)=>{if(!next.includes(anchor))throw Error(p+' missing '+anchor);next=next.replace(anchor,anchor+`\nconsole.info('D231:${p}:${line}');\n`);changes.push({p,anchor,line});};
if(p==='ui/AccountEnrollmentApp.tsx'){
add('const close = useCallback(async () => {','screen-close');
add('const entered = code;', 'submit');
next=next.replace("console.info('D231:ui/AccountEnrollmentApp.tsx:submit');", "console.info('D231:submit',entered.length,life.current.signal.aborted,foreground.current);");
add('const run = useCallback(async (action: () => Promise<void>, background = false) => {','run');
next=next.replace("console.info('D231:ui/AccountEnrollmentApp.tsx:run');", "console.info('D231:run',life.current.signal.aborted,foreground.current);");
next=next.replace('owner.current = await createUiAccountEnrollment(', "console.info('D231:create'); owner.current = await createUiAccountEnrollment("); next=next.replace('const active = owner.current;', "console.info('D231:created'); const active = owner.current;");
}
return next===s?undefined:{code:next,map:null};}
// Window only diagnostic markers, no source changes. Worker transforms use same plugin factory.
const plugin=()=>({name:'disposable231',enforce:'pre',transform});
try{await build({root:'/Users/thomasingalls/.codex/worktrees/7fda/done',plugins:[plugin()],worker:{plugins:()=>[plugin()]},build:{outDir:'/private/tmp/done-worker-conversion-20261028/validation229/dist',emptyOutDir:true,sourcemap:true}});}finally{writeFileSync('/private/tmp/done-worker-conversion-20261028/231-diagnostic-transforms.json',JSON.stringify(changes,null,2));}

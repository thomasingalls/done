from pathlib import Path
import shutil,json,hashlib
r=Path(__file__).parent;src=r/'native228';dst=r/'native237';repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');dst.mkdir()
for file in ['build.mjs','run.py','container-service.mjs','container-image.json']:
 (dst/file).write_bytes((src/file).read_bytes().replace(str(src).encode(),str(dst).encode()))
shutil.copytree(src/'lab',dst/'lab',symlinks=True);shutil.copytree(src/'harness',dst/'harness',symlinks=True,ignore=shutil.ignore_patterns('test-results','results.json','artifacts','node_modules'))
(dst/'harness/node_modules').symlink_to(repo/'node_modules',target_is_directory=True);(dst/'node_modules').symlink_to(repo/'node_modules',target_is_directory=True)
for f in list((dst/'lab').rglob('*'))+list((dst/'harness').rglob('*')):
 if f.is_file()and not f.is_symlink()and f.suffix in ['.mjs','.ts','.html','.json']:
  b=f.read_bytes();n=b.replace(str(src).encode(),str(dst).encode())
  if n!=b:f.write_bytes(n)
(dst/'frontend').symlink_to(r/'validation229/dist',target_is_directory=True)
# Original laboratory case assertions/deadlines retained; only absolute disposable-root relocation.
assert (dst/'harness/test/account-continuation-lab/worker-owner.spec.ts').read_bytes().replace(str(dst).encode(),str(src).encode())==(src/'harness/test/account-continuation-lab/worker-owner.spec.ts').read_bytes()
print(dst)

from pathlib import Path
import subprocess,json,hashlib,gzip,re
r=Path(__file__).parent;repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');p=repo/'docs/performance-experiments/2026-10-28-worker-owner/phase237';prior=Path('/private/tmp/done-phase236-replay-dn231m35');tracked=set(subprocess.check_output(['git','ls-files'],cwd=repo,text=True).splitlines());sha=lambda b:hashlib.sha256(b).hexdigest()
for folder in ['src','test']:
 for f in(repo/folder).rglob('*'):
  if f.is_file():
   rel=str(f.relative_to(repo));old=(prior/rel).read_bytes()if(prior/rel).is_file()else subprocess.check_output(['git','show','HEAD:'+rel],cwd=repo)if rel in tracked else None;assert f.read_bytes()==old,rel
assert '5 passed' in(r/'native237/compatibility-03/console.log').read_text();assert '3 failed' in(r/'native237/compatibility-03/console.log').read_text();assert '2731 passed' in(r/'237-full-unit.log').read_text();assert '3 failed' in(r/'237-full-unit.log').read_text()
p.mkdir();paths=[*[f for f in r.glob('237-*.log')if f.name!='237-cold-diagnostic.log'],r/'237-boundary-review.json',r/'setup237.py',r/'diagnose-cold.py',r/'finish237.py',r/'native237/build.mjs',r/'native237/build-identity.json']
for run in ['compatibility-01','compatibility-02','compatibility-03']:
 root=r/'native237'/run
 for f in root.rglob('*'):
  if f.is_file()and f.name in ['console.log','result.json','receipt.json','services.log','container-identity.json','docker-command.json']:paths.append(f)
for f in paths:
 rel=str(f.relative_to(r));dest=p/(rel+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);b=re.sub(rb'(?<![A-Z0-9])[A-Z0-9]{5}(?:-[A-Z0-9]{5}){4}(?![A-Z0-9])',b'[disposable code redacted]',f.read_bytes());dest.write_bytes(gzip.compress(b,mtime=0))
(p/'README.md').write_text('''# Phase237 — final runtime boundary and retained compatibility outcomes

2026-10-29. No runtime/test changes236. Boundary map binds actual public Local, first-device,
enrollment, recovery, same-realm Account handoff/composition and intentional Window endpoints.
Canonical Yjs/Undo/rendering, synchronous narrow-key encrypted journal sealing and browser credential
prompts remain Window. Public metadata and explicit destructive removal coordination remain Window;
no history/KDF replay there. Explicit legacy config.networkSessions=false retains its old Page owner;
this is never Worker-failure fallback. Dedicated workers do not promise autonomous background sync.

Original native matrix:5 pass/3 fail. Primary sender-closed receive, mixed old/new Local CRDT union,
Local and Account hard-worker-loss recovery and duplicate-bootstrap refusal pass. Deep joined
catch-up still misses unchanged30s, with valid progress431 and no authority failure. Original local
baseline install/rebind, subsequent synchronous input/Undo and resumable preparation/cold-resume/
actual history removal complete, but public UI cold-open after context/maintenance still misses its
unchanged15s. Thus182 remains open;187 preparation path advances beyond the old idle failure but full
case remains failed at cold UI;205 public cold-open remains open. No passing rerun erases old results.
A read-only cold trace retains original15s failure then observes status/locks/fixed message metadata;
any extra observation never earns a pass. Follow its result in the next repair record.

Full unit:2731 pass,3 fail,one existing skip. All three failures are exact privateAccess config-return
expectations missing the earlier public membership-change subscription function. Original pin,
no-bearer, no-fallback and retry checks remain; repair that fixture separately. No all-unit pass claim.

Apparatus mistakes retained: first lab build copied a symlink rather than dereferencing; corrected
without touching production artifact. Initial container lacked copied observer; restart began before
that failed run fully exited and overlapped its last case. Interrupted only this task's second
Playwright process; neither attempt earns credit. Third run starts after both exit. All original
case bodies/deadlines unchanged except absolute disposable-root relocation. No profiles, storage,
factors or error-context files archived. All42 current Chromium/Firefox cohort cases pass. The deliberate late-refusal case logs a
WorkerChannelError; preserve it. Cohort passes do not substitute for the three failed matrix cases.

Worker placement is implemented on normal public paths, but the cold-open boundary must be diagnosed
before functional closure. Then unchanged16ms/2.5s/all-marker/30s measurements. No qualification or
release acceptance, real staging/sign/push, preview8443, deploy, service automation, CUA or phone.
''')
link='performance-experiments/2026-10-28-worker-owner/phase237/README.md'
for file,text in [('decisions.md','Keep intentional Window canonical UI/journal/provider and explicit legacy compatibility boundaries visible; distinguish completed placement from failed latency/cold-entry outcomes.'),('completed.md','Runtime boundary mapped. Native matrix5pass/3fail; full units2731pass/3exact config fixture failures/one existing skip. Preserve deep30s and post-maintenance15s cold-open failures; read-only diagnosis next.'),('product-backlog.md','Phase237: public heavy owners execute in actual Workers. Cold public entry after native baseline/maintenance remains unresolved; repair three config-return expectations and diagnose cold boundary before performance acceptance.')]:
 with(repo/'docs'/file).open('a')as f:f.write('\n\n## 2026-10-29 — phase237: Worker boundary and inconvenient results\n\n'+text+' [Evidence]('+link+').\n')
print('237 evidence closed; completed before backlog')

from pathlib import Path
import subprocess,json,hashlib,gzip
r=Path(__file__).parent;repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');prior=Path('/private/tmp/done-phase237-replay-l8hnwbch');rel='test/privateAccess.test.ts';old=(prior/rel).read_bytes()if(prior/rel).is_file()else subprocess.check_output(['git','show','HEAD:'+rel],cwd=repo);actual=(repo/rel).read_bytes();assert actual.replace(b'    onMembershipContinuationChange: expect.any(Function),\n',b'')==old;assert actual.count(b'    onMembershipContinuationChange: expect.any(Function),\n')==4
assert '16 passed' in(r/'238-focused.log').read_text();p=repo/'docs/performance-experiments/2026-10-28-worker-owner/phase238';p.mkdir()
for f in[*r.glob('238-*.log'),r/'finish238.py']:(p/(f.name+'.gz')).write_bytes(gzip.compress(f.read_bytes(),mtime=0))
(p/'README.md').write_text('''# Phase238 — retain exact config expectations including the public subscription

2026-10-29. Four expected objects in three existing privateAccess cases now also require the
onMembershipContinuationChange function introduced earlier for live Worker capability hints.
Every pre-existing assertion/value/case/deadline is byte-identical237, including no bearer retention,
no private fallback, identical retry bytes and refusal on changed identity. No production change.
Before full run2731pass/3fail/one existing skip; targeted after16cases pass, including actual
subscription/disposal/order tests. Full candidate unit rerun follows after runtime repairs, not yet
claimed. No new tests or denominator changes; qualification remains paused. No performance credit,
real staging/sign/push, preview8443, release/deploy, service automation, CUA/physical-device work.
''')
link='performance-experiments/2026-10-28-worker-owner/phase238/README.md'
for file,text in [('decisions.md','Keep exact returned-config shape assertions, adding the public subscription function rather than weakening them to partial matching.'),('completed.md','Four config expectations repaired in three old tests; every other byte/assertion retained.16 focused private-access/config/subscription/order cases pass. No runtime change.'),('product-backlog.md','Phase238 resolves the three classified full-unit fixture failures; whole-suite rerun remains due after runtime closure. Post-baseline public cold entry trace next.')]:
 with(repo/'docs'/file).open('a')as f:f.write('\n\n## 2026-10-29 — phase238: exact configuration fixture\n\n'+text+' [Evidence]('+link+').\n')
print('238 closed; completed before backlog')

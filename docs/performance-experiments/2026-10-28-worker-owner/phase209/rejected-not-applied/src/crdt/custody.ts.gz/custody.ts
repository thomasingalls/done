import { observeInitialCeremonyJournal } from './ceremonyInitialJournal';
import { accountWorkerRuntime } from './accountWorkerRuntime';
import { eraseVerified } from './verifiedRecords';
import type { AccountBaselineRead } from './localBaselineShadow';
import { maintenanceTask } from './contentMaintenance';
import {
  captureCreationSeed,
  sealCreationSeed,
  openCreationSeed,
  eraseCreationSeed,
  type CreationSeed,
} from './creationSeed';
/**
 * Phase-two custody owner. No caller receives a root, generation key, or private
 * credential. Startup supplies verified identity and the cross-carrier census;
 * completing this component alone does not complete workspace genesis.
 */
import { openActiveRotation, openInitialAccount, eraseRotationKeys } from './rotationKeys';
import { assertNoLocalClear } from './localClearState';
import { assertNoPreactiveImport } from './legacyImportState';
import { validateContentUpdates, type ContentCompactionReceipt } from './contentCompaction';
export type { ContentCompactionReceipt } from './contentCompaction';
import { deriveStoreName } from './storeName';
import {
  deriveJournalKey,
  createJournalCodec,
  decodeJournal,
  journalPrefix,
  type JournalError,
} from './journalCodec';
import {
  createJournalOwner,
  eraseJournalSnapshot,
  isJournalChanged,
  type JournalAdmission,
  type JournalUpdate,
  type JournalFlushReceipt,
} from './journalStore';
export { JournalError, MAX_JOURNAL_UPDATE, JOURNAL_WATERMARK } from './journalCodec';
export type { JournalRefusal } from './journalCodec';
export type { JournalAdmission, JournalUpdate, JournalFlushReceipt } from './journalStore';
import {
  createContentOwner,
  type ContentCrypto,
  type ContentCreationOptions,
  type ContentReceipt,
} from './contentStore';
import {
  ContentError,
  copyBatch,
  parseStoredRecord,
  recordAAD,
  type ContentInput,
  type OpenedRecord,
  type StoredRecord,
} from './contentRecord';
export { ContentError } from './contentRecord';
export type { ContentRefusal, ContentInput, OpenedRecord } from './contentRecord';
export type { ContentCreationOptions, ContentReceipt } from './contentStore';
import {
  createCredential,
  sealPreparedCredential,
  fields,
  guardedSubtle,
  generateDeviceCode,
  hex,
  hkdf,
  normalizeDeviceCode,
  openCredential,
  openEnvelope,
  openFactor,
  random,
  sealEnvelope,
  sealFactor,
  utf8,
  type Bytes,
} from './custodyCrypto';
import {
  authenticateRecord,
  CustodyError,
  identity,
  openCustodyDb,
  SEAL_LIMIT,
  signRecord,
  transact,
  type CreationIntent,
  type CustodyRecord,
  type CustodyScope,
} from './custodyRecord';
import {
  requireExclusiveSessionTask,
  openWriteSession,
  type WriteSession,
  withExclusiveSlot,
  type SessionTask,
  type WriteSessionState,
} from './writeSession';
export { CustodyError } from './custodyRecord';
export type { CustodyRefusal, CustodyScope, CreationIntent } from './custodyRecord';

export interface CustodyAuthority {
  readonly slotId: string;
  readonly workspaceId: string;
  /** Reread/verify Local identity or Account binding under this granted permit. */
  resolvePrincipal(task: SessionTask): string | PromiseLike<string>;
}
export interface CustodyCreationOptions {
  /** Recovery-only keys/progress created before factor confirmation. Fresh roots only. */
  seed?: CreationSeed;
  signal?: AbortSignal;
  /**
   * Required owner of SC-06's OTHER carriers. Throw unless they are absent for
   * fresh creation, or match this authenticated intent on resume. Never a cached
   * earlier census. Runs under exclusion before this component changes custody.
   */
  checkCreation(
    task: SessionTask,
    scope: Readonly<CustodyScope>,
    intent: Readonly<CreationIntent>,
    mode: 'fresh' | 'resume',
  ): void | PromiseLike<void>;
}
export interface CustodyEnrollment {
  /** Display once, outside persistent app state. Null after confirm starts/cancel. */
  readonly displayCode: string | null;
  confirm(typedCode: string): Promise<CustodyDescriptor>;
  cancel(): void;
}
export interface CustodyDescriptor {
  readonly scope: Readonly<CustodyScope>;
  readonly storeId: string;
  readonly rootId: string;
  readonly generation: number;
  readonly publicCredentials: ReadonlyArray<{
    readonly role: 'wrapping' | 'signing';
    readonly id: string;
    readonly publicKey: Bytes;
  }>;
}
export interface CustodyContentRecord {
  v: 1;
  gen: number;
  seq: number;
  kind: 'update' | 'state' | 'heads' | 'outbound';
  nonce: Bytes;
  ct: Bytes;
}
export interface CustodyTask extends SessionTask {
  /** Authenticated read only. Allocated writes belong to ContentSession; admission and compaction use the journal-capable owner. */
  openRecord(record: CustodyContentRecord): Promise<Bytes>;
}
export interface CustodySession extends CustodyDescriptor {
  readonly state: WriteSessionState;
  readonly signal: AbortSignal;
  run<T>(operation: (task: CustodyTask) => T | PromiseLike<T>): Promise<T>;
  close(): Promise<void>;
}
const captureAuthority = (authority: CustodyAuthority) => {
  try {
    const { slotId, workspaceId, resolvePrincipal } = authority;
    identity(slotId);
    identity(workspaceId);
    if (typeof resolvePrincipal !== 'function') throw Error('Missing authority resolver');
    return { slotId, workspaceId, resolvePrincipal };
  } catch (cause) {
    throw new CustodyError('invalid-input', 'Custody requires an identity authority.', { cause });
  }
};
const resolveScope = async (
  task: SessionTask,
  a: CustodyAuthority,
  preactive = false,
): Promise<CustodyScope> => {
  await assertNoLocalClear(task, a.slotId);
  if (!preactive) await assertNoPreactiveImport(task, a.slotId);
  const principalId = await task.wait(() => a.resolvePrincipal(task));
  identity(principalId);
  return Object.freeze({ slotId: a.slotId, workspaceId: a.workspaceId, principalId });
};
const codeBytes = (code: string): Bytes => {
  try {
    return utf8(normalizeDeviceCode(code));
  } catch (cause) {
    throw new CustodyError('confirmation-required', 'Enter the generated device-lock code.', {
      cause,
    });
  }
};
const descriptor = (scope: CustodyScope, record: CustodyRecord): CustodyDescriptor =>
  Object.freeze({
    scope,
    storeId: record.store_id,
    rootId: record.root_id,
    generation: 1,
    publicCredentials: Object.freeze(
      record.credentials!.map((c) =>
        Object.freeze({ role: c.role, id: c.id, publicKey: c.publicKey.slice() }),
      ),
    ),
  });
const newIntent = (): CreationIntent =>
  Object.freeze({
    id: hex(random(16)),
    storeId: hex(random(16)),
    rootId: hex(random(16)),
    wrappingId: hex(random(16)),
    signingId: hex(random(16)),
  });

interface OwnedKeys {
  store: CryptoKey | null;
  generation?: number;
  previousStores?: Map<number, CryptoKey>;
  previousJournals?: Map<number, Bytes>;
  metadata?: CryptoKey | null;
  journal?: Bytes | null;
  wrapping: CryptoKey | null;
  signing: CryptoKey | null;
}
const clearKeys = (keys: OwnedKeys) => {
  keys.store = null;
  keys.previousStores?.clear();
  for (const key of keys.previousJournals?.values() ?? []) key.fill(0);
  keys.previousJournals?.clear();
  keys.metadata = null;
  keys.journal?.fill(0);
  keys.journal = null;
  keys.wrapping = null;
  keys.signing = null;
};
const loadKeys = async (
  task: SessionTask,
  scope: CustodyScope,
  record: CustodyRecord,
  root: Bytes,
  keys: OwnedKeys,
  content = false,
  journal = false,
): Promise<void> => {
  let generation: Bytes | undefined;
  try {
    await task.wait(async () => {
      generation = await openEnvelope(
        scope,
        root,
        record.envelope!,
        guardedSubtle(() => task.step(() => {})),
      );
    });
    if (generation!.length !== 32) throw Error('Invalid generation key');
    await task.wait(async () => {
      keys.store = await hkdf(
        generation!,
        new Uint8Array(),
        fields('done/store/v1', scope.workspaceId, record.store_id),
        { name: 'AES-GCM', length: 256 },
        content ? ['encrypt', 'decrypt'] : ['decrypt'],
        guardedSubtle(() => task.step(() => {})),
      );
    });
    if (content)
      await task.wait(async () => {
        keys.metadata = await hkdf(
          generation!,
          new Uint8Array(),
          fields(
            'done/content-metadata/v1',
            scope.slotId,
            scope.principalId,
            scope.workspaceId,
            record.store_id,
          ),
          { name: 'HMAC', hash: 'SHA-256', length: 256 },
          ['sign', 'verify'],
          guardedSubtle(() => task.step(() => {})),
        );
      });
    if (journal)
      await task.wait(async () => {
        keys.journal = await deriveJournalKey(
          generation!,
          scope.workspaceId,
          guardedSubtle(() => task.step(() => {})),
        );
      });
    keys.generation = 1;
    const initial = await task.wait(() =>
      openInitialAccount(
        scope,
        root,
        record,
        guardedSubtle(() => task.step(() => {})),
      ),
    );
    let active: Awaited<ReturnType<typeof openActiveRotation>> = null;
    try {
      active = await task.wait(() =>
        openActiveRotation(
          scope,
          root,
          record,
          guardedSubtle(() => task.step(() => {})),
        ),
      );
      const selected = active ?? initial;
      if (selected) {
        keys.previousStores = new Map([[1, keys.store!]]);
        keys.previousJournals = new Map(keys.journal ? [[1, keys.journal]] : []);
        for (const [generation, key] of new Map([
          ...(initial && initial.generation < selected.generation
            ? [[initial.generation, initial.key] as const]
            : []),
          ...(active?.previous ?? []),
        ])) {
          keys.previousStores.set(
            generation,
            await task.wait(() =>
              hkdf(
                key,
                new Uint8Array(),
                fields('done/store/v1', scope.workspaceId, record.store_id),
                { name: 'AES-GCM', length: 256 },
                content ? ['encrypt', 'decrypt'] : ['decrypt'],
                guardedSubtle(() => task.step(() => {})),
              ),
            ),
          );
          if (journal)
            keys.previousJournals.set(
              generation,
              await task.wait(() =>
                deriveJournalKey(
                  key,
                  scope.workspaceId,
                  guardedSubtle(() => task.step(() => {})),
                ),
              ),
            );
        }
        keys.store = await task.wait(() =>
          hkdf(
            selected.key,
            new Uint8Array(),
            fields('done/store/v1', scope.workspaceId, record.store_id),
            { name: 'AES-GCM', length: 256 },
            content ? ['encrypt', 'decrypt'] : ['decrypt'],
            guardedSubtle(() => task.step(() => {})),
          ),
        );
        if (journal)
          keys.journal = await task.wait(() =>
            deriveJournalKey(
              selected.key,
              scope.workspaceId,
              guardedSubtle(() => task.step(() => {})),
            ),
          );
        keys.generation = selected.generation;
      }
    } finally {
      eraseRotationKeys(active);
      initial?.key.fill(0);
    }
    await task.wait(async () => {
      keys.wrapping = await openCredential(
        scope,
        root,
        record.credentials![0],
        guardedSubtle(() => task.step(() => {})),
      );
    });
    await task.wait(async () => {
      keys.signing = await openCredential(
        scope,
        root,
        record.credentials![1],
        guardedSubtle(() => task.step(() => {})),
      );
    });
  } catch (cause) {
    if (task.signal.aborted) throw cause;
    throw new CustodyError('repair-required', 'A retained custody opener could not authenticate.', {
      cause,
    });
  } finally {
    generation?.fill(0);
  }
};

/** Reserve the entire next batch durably BEFORE any corresponding encryption. */
const finishCreation = async (
  db: IDBDatabase,
  task: SessionTask,
  scope: CustodyScope,
  initial: CustodyRecord,
  root: Bytes,
  factor: Bytes,
): Promise<CustodyRecord> => {
  const intent = initial.creation_intent!;
  if (initial.seal_reserved + 3 >= SEAL_LIMIT)
    throw new CustodyError(
      'seal-budget-exhausted',
      'This custody root cannot reserve another creation attempt.',
    );
  const reserved = await task.wait(() =>
    signRecord(
      root,
      { ...initial, seal_reserved: initial.seal_reserved + 3 },
      guardedSubtle(() => task.step(() => {})),
    ),
  );
  await task.wait(() => transact(db, task, scope, initial, reserved));
  const generation = random(32);
  let seed: CreationSeed | undefined;
  const verified: OwnedKeys = { store: null, wrapping: null, signing: null };
  try {
    if (initial.creation_seed) {
      seed = await task.wait(() =>
        openCreationSeed(
          initial.creation_seed!,
          scope,
          intent.id,
          factor,
          guardedSubtle(() => task.step(() => {})),
        ),
      );
      if (
        seed.credentials[0].id !== intent.wrappingId ||
        seed.credentials[1].id !== intent.signingId
      )
        throw Error('Prepared custody identity changed');
    }
    const envelope = await task.wait(() =>
      sealEnvelope(
        scope,
        root,
        1,
        generation,
        guardedSubtle(() => task.step(() => {})),
      ),
    );
    const wrapping = await task.wait(() =>
      seed
        ? sealPreparedCredential(
            scope,
            root,
            'wrapping',
            intent.wrappingId,
            seed.credentials[0],
            guardedSubtle(() => task.step(() => {})),
          )
        : createCredential(
            scope,
            root,
            'wrapping',
            intent.wrappingId,
            guardedSubtle(() => task.step(() => {})),
          ),
    );
    const signing = await task.wait(() =>
      seed
        ? sealPreparedCredential(
            scope,
            root,
            'signing',
            intent.signingId,
            seed.credentials[1],
            guardedSubtle(() => task.step(() => {})),
          )
        : createCredential(
            scope,
            root,
            'signing',
            intent.signingId,
            guardedSubtle(() => task.step(() => {})),
          ),
    );
    const { creation_seed: _seed, ...withoutSeed } = reserved;
    const completed = await task.wait(() =>
      signRecord(
        root,
        {
          ...withoutSeed,
          state: 'protected',
          creation_intent: null,
          envelope,
          credentials: [wrapping, signing],
        },
        guardedSubtle(() => task.step(() => {})),
      ),
    );
    await loadKeys(task, scope, completed, root, verified);
    await task.wait(() => transact(db, task, scope, reserved, completed));
    return completed;
  } finally {
    generation.fill(0);
    if (seed) eraseCreationSeed(seed);
    clearKeys(verified);
  }
};

const createOrResume = async (
  authority: CustodyAuthority,
  factor: Bytes,
  options: CustodyCreationOptions,
  mode: 'fresh' | 'resume',
  owned?: { task: SessionTask; installInitial?: InitialCustodyInstaller },
): Promise<CustodyDescriptor> => {
  const { checkCreation, signal } = options;
  let seed: CreationSeed | undefined;
  try {
    if (options.seed && mode !== 'fresh') throw Error('Cannot replace resumed credentials');
    if (typeof checkCreation !== 'function')
      throw new CustodyError('invalid-input', 'Creation requires the startup carrier check.');
    seed = options.seed ? captureCreationSeed(options.seed) : undefined;
  } catch (error) {
    factor.fill(0);
    throw error;
  }
  let db: IDBDatabase | undefined;
  let root: Bytes | undefined;
  const dispose = () => {
    factor.fill(0);
    if (seed) eraseCreationSeed(seed);
    root?.fill(0);
    root = undefined;
    db?.close();
    db = undefined;
  };
  const operation = async (task: SessionTask) => {
    const scope = await resolveScope(task, authority, Boolean(owned));
    await task.wait(async () => {
      db = await openCustodyDb();
    });
    let record = await task.wait(() => transact(db!, task, scope));
    if (mode === 'fresh') {
      if (record)
        throw new CustodyError(
          'locked-existing',
          'Custody already exists; unlock or resume its winning factor.',
        );
      const intent = Object.freeze({
        ...newIntent(),
        ...(seed ? { wrappingId: seed.credentials[0].id, signingId: seed.credentials[1].id } : {}),
      });
      await task.wait(() => checkCreation(task, scope, intent, 'fresh'));
      root = random(32);
      const seal = await task.wait(() =>
        sealFactor(
          scope,
          factor,
          root!,
          'code',
          'code',
          guardedSubtle(() => task.step(() => {})),
        ),
      );
      record = await task.wait(async () =>
        signRecord(
          root!,
          {
            v: 2,
            state: 'creating',
            ...(seed
              ? {
                  creation_seed: await sealCreationSeed(
                    seed,
                    scope,
                    intent.id,
                    factor,
                    guardedSubtle(() => task.step(() => {})),
                  ),
                }
              : {}),
            slot_id: scope.slotId,
            principal_id: scope.principalId,
            workspace_id: scope.workspaceId,
            store_id: intent.storeId,
            root_id: intent.rootId,
            seals: [seal],
            seal_reserved: 0,
            rotation_owed: false,
            creation_intent: intent,
            envelope: null,
            credentials: null,
            mac: new Uint8Array(32),
          },
          guardedSubtle(() => task.step(() => {})),
        ),
      );
      if (owned?.installInitial)
        await task.wait(() => owned.installInitial!(task, db!, scope, record!));
      else await task.wait(() => transact(db!, task, scope, null, record!));
    } else {
      if (!record)
        throw new CustodyError(
          'missing-custody',
          'Missing custody is not permission to create a replacement.',
        );
      if (record.state !== 'creating')
        throw new CustodyError(
          'locked-existing',
          'Creation already completed; use ordinary factor unlock.',
        );
      try {
        await task.wait(async () => {
          root = await openFactor(
            scope,
            factor,
            record!.seals[0],
            guardedSubtle(() => task.step(() => {})),
          );
        });
      } catch (cause) {
        if (task.signal.aborted) throw cause;
        throw new CustodyError(
          'unlock-failed',
          'The factor did not open custody; it may be wrong or the seal damaged.',
          { cause },
        );
      }
      await task.wait(() =>
        authenticateRecord(
          root!,
          record!,
          guardedSubtle(() => task.step(() => {})),
        ),
      );
      await task.wait(() =>
        checkCreation(task, scope, Object.freeze({ ...record!.creation_intent! }), 'resume'),
      );
    }
    const completed = await finishCreation(db!, task, scope, record, root!, factor);
    factor.fill(0);
    return descriptor(scope, completed);
  };
  try {
    return owned
      ? await operation(owned.task)
      : await withExclusiveSlot(authority.slotId, operation, {
          ...(signal ? { signal } : {}),
          dispose,
        });
  } finally {
    dispose();
  }
};

/** Internal composition seam: the genesis owner holds exclusion throughout all stages. */
export type InitialCustodyInstaller = (
  task: SessionTask,
  db: IDBDatabase,
  scope: CustodyScope,
  record: CustodyRecord,
) => Promise<void>;
export const createCustodyUnderPermit = (
  task: SessionTask,
  authority: CustodyAuthority,
  code: string,
  options: CustodyCreationOptions,
  mode: 'fresh' | 'resume',
  installInitial?: InitialCustodyInstaller,
): Promise<CustodyDescriptor> =>
  createOrResume(captureAuthority(authority), codeBytes(code), options, mode, {
    task,
    ...(installInitial ? { installInitial } : {}),
  });

/** Internal authenticated read/initialization, with keys disposed before returning to the owner. */
export const checkContentUnderPermit = async (
  task: SessionTask,
  authority: CustodyAuthority,
  code: string,
  creation?: ContentCreationOptions,
): Promise<CustodyDescriptor> => {
  const owner = prepareCustody(authority, code, true, false, true);
  try {
    await owner.initialize(task, creation);
    return owner.describe();
  } finally {
    owner.dispose();
  }
};

/** Only this generated-code ceremony can create fresh custody. No chosen-code setter. */
export const beginCustodyEnrollment = (
  input: CustodyAuthority,
  options: CustodyCreationOptions,
): CustodyEnrollment => {
  const authority = captureAuthority(input);
  const captured = { ...options };
  if (typeof captured.checkCreation !== 'function')
    throw new CustodyError('invalid-input', 'Creation requires the startup carrier check.');
  let display: string | null = generateDeviceCode();
  let expected: Bytes | null = codeBytes(display);
  let used = false;
  const controller = new AbortController();
  const erase = () => {
    used = true;
    display = null;
    expected?.fill(0);
    expected = null;
  };
  const detach = () => captured.signal?.removeEventListener('abort', cancel);
  const cancel = () => {
    erase();
    controller.abort();
    detach();
  };
  captured.signal?.addEventListener('abort', cancel, { once: true });
  if (captured.signal?.aborted) cancel();
  return {
    get displayCode() {
      return display;
    },
    cancel,
    confirm: async (typedCode) => {
      if (used || !expected)
        throw new CustodyError(
          'enrollment-closed',
          'Start a new ceremony or resume the saved creation.',
        );
      const typed = codeBytes(typedCode);
      if (!typed.every((b, i) => b === expected![i])) {
        typed.fill(0);
        throw new CustodyError(
          'confirmation-required',
          'The confirmation does not match the generated code.',
        );
      }
      // Consume the ceremony before the first await: two confirms cannot race it.
      erase();
      return createOrResume(
        authority,
        typed,
        { ...captured, signal: controller.signal },
        'fresh',
      ).finally(detach);
    },
  };
};
export const resumeCustodyCreation = (
  input: CustodyAuthority,
  code: string,
  options: CustodyCreationOptions,
): Promise<CustodyDescriptor> =>
  createOrResume(captureAuthority(input), codeBytes(code), { ...options }, 'resume');

/** Internal owner shared by read-only custody and the allocated content carrier. */
const prepareCustody = (
  input: CustodyAuthority,
  code: string,
  content: boolean,
  withJournal = false,
  preactive = false,
  validateRecords?: ContentCrypto['validate'],
  allowSpoolCounter?: true,
  reuseOpened?: true,
  recoveryJournal = false,
  warmLoads?: true,
  selectiveLoads?: true,
  baseline?: ContentCrypto['baseline'],
  readBaseline?: true,
  exactBaselineReuse?: true,
) => {
  const authority = captureAuthority(input),
    factor = codeBytes(code);
  const keys: OwnedKeys = { store: null, wrapping: null, signing: null };
  let db: IDBDatabase | undefined, root: Bytes | undefined;
  let scope!: CustodyScope, record!: CustodyRecord;
  let carrier: ReturnType<typeof createContentOwner> | undefined;
  let journal: ReturnType<typeof createJournalOwner> | undefined;
  let recoveryCodec: ReturnType<typeof createJournalCodec> | undefined;
  const priorRecoveryCodecs = new Map<number, ReturnType<typeof createJournalCodec>>();
  let recoveryPrefix = '';
  const openRecord = (task: SessionTask, inputRecord: StoredRecord): Promise<Bytes> => {
    const value = task.step(() => parseStoredRecord(inputRecord));
    const opener =
      value.gen === (keys.generation ?? 1) ? keys.store : keys.previousStores?.get(value.gen);
    if (!opener)
      throw new CustodyError('repair-required', 'No opener for this content generation.');
    return task.wait(async () => {
      try {
        return new Uint8Array(
          await crypto.subtle.decrypt(
            {
              name: 'AES-GCM',
              iv: value.nonce,
              tagLength: 128,
              additionalData: recordAAD({ ...scope, storeId: record.store_id }, value),
            },
            opener,
            value.ct,
          ),
        );
      } catch (cause) {
        throw new CustodyError('repair-required', 'Content authentication failed.', { cause });
      }
    });
  };
  return {
    authority,
    eraseFactor() {
      factor.fill(0);
    },
    describe: () => ({ ...descriptor(scope, record), generation: keys.generation ?? 1 }),
    /** Internal worker composition only. Export journal subkeys, never root/content/signing keys. */
    async copyMirrorJournalOpening(task: SessionTask) {
      if (!accountWorkerRuntime(authority.slotId))
        throw Error('Worker journal composition required');
      const dbName = await task.wait(() => deriveStoreName(scope.principalId, scope.workspaceId));
      return task.step(() => {
        if (!keys.journal || !journal || !carrier) throw Error('Journal owner is not initialized');
        return {
          scope: { ...scope, storeId: record.store_id, rootId: record.root_id },
          dbName,
          generation: keys.generation ?? 1,
          key: keys.journal.slice(),
          previous: [...(keys.previousJournals ?? [])].map(([g, k]) => [g, k.slice()] as const),
          ...(carrier.journalBinding()
            ? { binding: structuredClone(carrier.journalBinding()) }
            : {}),
        };
      });
    },
    get journal() {
      return journal!;
    },
    get carrier() {
      return carrier!;
    },
    openRecord,
    openRecoveryJournal(task: SessionTask, key: string, value: string): Bytes {
      return task.step(() => {
        if (!recoveryCodec || !key.startsWith(recoveryPrefix))
          throw new CustodyError(
            'invalid-input',
            'Recovery journal is outside this custody scope.',
          );
        const codec =
          decodeJournal(value).generation === (keys.generation ?? 1)
            ? recoveryCodec
            : priorRecoveryCodecs.get(decodeJournal(value).generation);
        if (!codec)
          throw new CustodyError('repair-required', 'No opener for this journal generation.');
        return codec.open(key, value).bytes;
      });
    },
    initialize: async (
      task: SessionTask,
      creation?: ContentCreationOptions,
      initialAccount = false,
    ) => {
      scope = await resolveScope(task, authority, preactive);
      await task.wait(async () => {
        db = await openCustodyDb();
      });
      const current = await task.wait(() => transact(db!, task, scope));
      if (!current)
        throw new CustodyError(
          'missing-custody',
          'No custody exists for this identity. Normal open never creates it.',
        );
      if (current.state !== 'protected')
        throw new CustodyError(
          'creation-pending',
          'Custody creation must resume before normal open.',
        );
      record = current;
      try {
        await task.wait(async () => {
          root = await openFactor(
            scope,
            factor,
            record.seals[0],
            guardedSubtle(() => task.step(() => {})),
          );
        });
      } catch (cause) {
        if (task.signal.aborted) throw cause;
        throw new CustodyError(
          'unlock-failed',
          'The factor did not open custody; it may be wrong or the seal damaged.',
          { cause },
        );
      }
      factor.fill(0);
      await task.wait(() =>
        authenticateRecord(
          root!,
          record,
          guardedSubtle(() => task.step(() => {})),
        ),
      );
      await loadKeys(task, scope, record, root!, keys, content, withJournal || recoveryJournal);
      root!.fill(0);
      root = undefined;
      db!.close();
      db = undefined;

      if (recoveryJournal) {
        recoveryPrefix = journalPrefix(
          await task.wait(() => deriveStoreName(scope.principalId, scope.workspaceId)),
        );
        recoveryCodec = task.step(() =>
          createJournalCodec(scope.workspaceId, keys.generation ?? 1, keys.journal!),
        );
        for (const [generation, key] of keys.previousJournals ?? [])
          priorRecoveryCodecs.set(
            generation,
            task.step(() => createJournalCodec(scope.workspaceId, generation, key)),
          );
      }

      const nameForInitial = initialAccount
        ? await task.wait(() => deriveStoreName(scope.principalId, scope.workspaceId))
        : undefined;
      if (content) {
        carrier = createContentOwner(
          { ...scope, storeId: record.store_id, rootId: record.root_id },
          keys.generation ?? 1,
          {
            ...(validateRecords ? { validate: validateRecords } : {}),
            ...(allowSpoolCounter ? { allowSpoolCounter } : {}),
            ...(reuseOpened ? { reuseOpened } : {}),
            ...(exactBaselineReuse ? { exactBaselineReuse } : {}),
            ...(warmLoads ? { warmLoads } : {}),
            ...(selectiveLoads ? { selectiveLoads } : {}),
            ...(baseline ? { baseline } : {}),
            ...(readBaseline ? { readBaseline } : {}),
            open: openRecord,
            seal: (task, header, plaintext) =>
              task.wait(async () => {
                const nonce = random(12);
                const ct = new Uint8Array(
                  await crypto.subtle.encrypt(
                    {
                      name: 'AES-GCM',
                      iv: nonce,
                      tagLength: 128,
                      additionalData: recordAAD({ ...scope, storeId: record.store_id }, header),
                    },
                    keys.store!,
                    plaintext,
                  ),
                );
                return { ...header, nonce, ct };
              }),
            sign: (task, payload) =>
              task.wait(
                async () =>
                  new Uint8Array(await crypto.subtle.sign('HMAC', keys.metadata!, payload)),
              ),
            verify: (task, payload, mac) =>
              task.wait(() => crypto.subtle.verify('HMAC', keys.metadata!, mac, payload)),
          },
        );
        const initialJournal =
          initialAccount && accountWorkerRuntime(authority.slotId)
            ? await task.wait(() =>
                accountWorkerRuntime(authority.slotId)!.journal.read(
                  journalPrefix(nameForInitial!),
                ),
              )
            : undefined;
        const ceremonyJournal =
          initialAccount && !initialJournal
            ? await observeInitialCeremonyJournal(
                task,
                authority.slotId,
                journalPrefix(nameForInitial!),
              )
            : undefined;
        await carrier.initialize(
          task,
          creation,
          initialAccount
            ? () => {
                if (!record.initial_account || record.active_rotation || !withJournal || creation)
                  throw Error('Initial account generation is not selected');
                const prefix = journalPrefix(nameForInitial!);
                if (initialJournal) {
                  const fresh = accountWorkerRuntime(authority.slotId)!.journal.pinned(prefix);
                  if (fresh.entries.length)
                    throw Error('Unfinished device installation has journalled edits');
                  return;
                }
                if (ceremonyJournal) {
                  ceremonyJournal();
                  return;
                }
                for (let i = 0; i < localStorage.length; i++)
                  if (localStorage.key(i)?.startsWith(prefix))
                    throw Error('Unfinished device installation has journalled edits');
              }
            : undefined,
        );
      }
      if (withJournal) {
        const name = await task.wait(() => deriveStoreName(scope.principalId, scope.workspaceId));
        journal = task.step(() =>
          createJournalOwner(
            { ...scope, storeId: record.store_id, rootId: record.root_id },
            name,
            keys.generation ?? 1,
            keys.journal!,
            keys.previousJournals,
            () => carrier?.journalBinding(),
          ),
        );
        // Erasure is cleanup and must also run if cancellation follows the successful read.
        eraseJournalSnapshot(await journal.readSnapshot(task));
      }
    },
    dispose: () => {
      factor.fill(0);
      root?.fill(0);
      root = undefined;
      clearKeys(keys);
      db?.close();
      db = undefined;
      carrier?.dispose();
      journal?.dispose();
      recoveryCodec?.dispose();
      for (const codec of priorRecoveryCodecs.values()) codec.dispose();
      priorRecoveryCodecs.clear();
    },
  };
};

/** Read-only salvage primitive. Caller owns exclusion and must authenticate its Local claim first.
 * No content owner, reservation, journal writer, credential export or whole-workspace success result. */
export const readRecoveryCustody = async <T>(
  task: SessionTask,
  authority: CustodyAuthority,
  code: string,
  read: (
    reader: CustodyDescriptor & {
      openRecord(record: StoredRecord): Promise<Bytes>;
      openJournal(key: string, value: string): Bytes;
    },
  ) => Promise<T>,
): Promise<T> => {
  const owner = prepareCustody(
    authority,
    code,
    false,
    false,
    false,
    undefined,
    undefined,
    undefined,
    true,
  );
  try {
    await owner.initialize(task);
    return await task.wait(() =>
      read({
        ...owner.describe(),
        openRecord: (record) => owner.openRecord(task, record),
        openJournal: (key, value) => owner.openRecoveryJournal(task, key, value),
      }),
    );
  } finally {
    owner.dispose();
  }
};

export const openCustodySession = async (
  input: CustodyAuthority,
  code: string,
  options: { signal?: AbortSignal } = {},
): Promise<CustodySession> => {
  const owner = prepareCustody(input, code, false);
  let live;
  try {
    live = await openWriteSession(owner.authority.slotId, {
      ...options,
      initialize: (task) => owner.initialize(task),
      dispose: owner.dispose,
    });
  } finally {
    owner.eraseFactor();
  }
  return Object.freeze({
    ...owner.describe(),
    get state() {
      return live.state;
    },
    signal: live.signal,
    close: () => live.close(),
    run: <T>(operation: (task: CustodyTask) => T | PromiseLike<T>): Promise<T> =>
      live.run((task) =>
        operation({
          ...task,
          openRecord: (input) => owner.openRecord(task, input),
        }),
      ),
  });
};

export interface ContentSession extends CustodyDescriptor {
  readonly state: WriteSessionState;
  readonly signal: AbortSignal;
  /** Exact immutable batch; receipt only after content transaction completion. */
  appendBatch(input: readonly ContentInput[]): Promise<ContentReceipt>;
  /** Every record in one disk snapshot authenticates, or no result is returned. */
  loadRecords(): Promise<OpenedRecord[]>;
  close(): Promise<void>;
}

/** Internal pre-active owner seam. Caller owns exclusion and verifies its import claim on this task.
 * No key, journal, transport or long-lived carrier escapes the callback. */
export const withPreactiveContentUnderPermit = async <T>(
  task: SessionTask,
  authority: CustodyAuthority,
  code: string,
  operation: (content: Pick<ContentSession, 'appendBatch' | 'loadRecords'>) => Promise<T>,
): Promise<T> => {
  const owner = prepareCustody(authority, code, true, false, true);
  try {
    await owner.initialize(task);
    return await operation({
      loadRecords: () => owner.carrier.load(task),
      appendBatch: async (input) => {
        const copied = task.step(() => copyBatch(input));
        try {
          return await owner.carrier.append(task, copied);
        } finally {
          for (const record of copied) record.bytes.fill(0);
        }
      },
    });
  } finally {
    owner.dispose();
  }
};

/** Local retirement-only data read, including after source content removal. No content initialization,
 * inferred Account era, application permission or keys escape. Caller must verify target coverage. */
export async function withLocalJournalUnderPermit<T>(
  task: SessionTask,
  input: CustodyAuthority,
  code: string,
  operation: (entries: readonly import('./journalStore').ObservedEntry[]) => Promise<T>,
): Promise<T> {
  const authority = captureAuthority(input);
  requireExclusiveSessionTask(task, authority.slotId);
  const owner = prepareCustody(authority, code, false, true);
  let opened: import('./journalStore').ObservedEntry[] | undefined;
  try {
    await owner.initialize(task);
    opened = await owner.journal.readSnapshot(task);
    requireExclusiveSessionTask(task, authority.slotId);
    const result = await task.wait(() => operation(opened!));
    requireExclusiveSessionTask(task, authority.slotId);
    return result;
  } finally {
    if (opened) eraseJournalSnapshot(opened);
    owner.dispose();
  }
}

/** Internal cold recovery under an already-held lifecycle permit. No writes or keys escape. */
export const withRecoveryUnderPermit = async <T>(
  task: SessionTask,
  authority: CustodyAuthority,
  code: string,
  operation: (recovery: JournalRecovery, baseline?: AccountBaselineRead) => Promise<T>,
  validation?: Pick<
    ContentCrypto,
    | 'validate'
    | 'allowSpoolCounter'
    | 'reuseOpened'
    | 'baseline'
    | 'readBaseline'
    | 'exactBaselineReuse'
  >,
): Promise<T> => {
  let validatedView: object | undefined;
  const validate = validation?.validate;
  const owner = prepareCustody(
    authority,
    code,
    true,
    true,
    false,
    validate && validation?.reuseOpened
      ? async (rows, scope, counter, view, baseline, localRetentionRevision) => {
          scope.step(() => {});
          // The carrier supplies the same identity only after a fresh authenticated read
          // matches both its counter and every sealed row. Never share it across owners.
          if (view && view === validatedView) return;
          validatedView = undefined;
          await scope.wait(() =>
            validate(rows, scope, counter, view, baseline, localRetentionRevision),
          );
          scope.step(() => {
            validatedView = view;
          });
        }
      : validate,
    validation?.allowSpoolCounter,
    validation?.reuseOpened,
    false,
    undefined,
    undefined,
    validation?.baseline,
    validation?.readBaseline,
    validation?.exactBaselineReuse,
  );
  let journal: JournalUpdate[] | undefined, records: OpenedRecord[] | undefined;
  let logical: Awaited<ReturnType<typeof owner.carrier.loadAccount>> | undefined;
  try {
    await owner.initialize(task);
    journal = await owner.journal.readSnapshot(task);
    logical = await owner.carrier.loadAccount(task);
    records = logical.records;
    return await operation(
      { records, journal },
      logical.kind === 'baseline-plus-suffix' ? logical : undefined,
    );
  } finally {
    validatedView = undefined;
    journal?.forEach((row) => row.bytes.fill(0));
    records?.forEach((row) => row.bytes.fill(0));
    if (logical?.kind === 'baseline-plus-suffix') eraseVerified(logical);
    owner.dispose();
  }
};

export const initializeContentStore = async (
  input: CustodyAuthority,
  code: string,
  options: ContentCreationOptions,
): Promise<CustodyDescriptor> => {
  if (typeof options?.checkCreation !== 'function')
    throw new ContentError(
      'invalid-input',
      'Content initialization requires the startup carrier check.',
    );
  const captured = { ...options },
    owner = prepareCustody(input, code, true);
  try {
    return await withExclusiveSlot(
      owner.authority.slotId,
      async (task) => {
        await owner.initialize(task, captured);
        return owner.describe();
      },
      { ...(captured.signal ? { signal: captured.signal } : {}), dispose: owner.dispose },
    );
  } finally {
    owner.eraseFactor();
  }
};

export const openContentSession = async (
  input: CustodyAuthority,
  code: string,
  options: { signal?: AbortSignal } = {},
): Promise<ContentSession> => {
  const owner = prepareCustody(input, code, true);
  let live;
  try {
    live = await openWriteSession(owner.authority.slotId, {
      ...options,
      initialize: (task) => owner.initialize(task),
      dispose: owner.dispose,
    });
  } finally {
    owner.eraseFactor();
  }
  return Object.freeze({
    ...owner.describe(),
    get state() {
      return live.state;
    },
    signal: live.signal,
    close: () => live.close(),
    appendBatch: (input: readonly ContentInput[]) => {
      // Capture before the caller can mutate its buffer or the task's first await.
      let copied: ContentInput[];
      try {
        copied = live.write(() => copyBatch(input));
      } catch (cause) {
        return Promise.reject(cause);
      }
      return live
        .run((task) => owner.carrier.append(task, copied))
        .finally(() => {
          for (const v of copied) v.bytes.fill(0);
        });
    },
    loadRecords: () => live.run((task) => owner.carrier.load(task)),
  });
};

export interface JournalRecovery {
  readonly records: OpenedRecord[];
  readonly journal: JournalUpdate[];
}
export interface JournalSession extends ContentSession {
  /** Private Account adapter: encode stable source capture once per prepared slice, before admission. */
  captureLocal?(
    update: Bytes,
    sources: readonly import('./sourceCapture').SourceUpdate[] | undefined,
  ): Bytes;
  /** Internal composed lifetime cleanup, after native drain and before permit release. */
  beforeRelease?(cleanup: () => void | Promise<void>): void;
  /** Explicit disk-union maintenance. Never accepts a caller snapshot or deletes journal/heads/outbound. */
  compactContent(interrupt?: AbortSignal): Promise<ContentCompactionReceipt>;
  /** Synchronous carrier result. No canonical mutation, timer, or implicit flush. */
  appendLocal(update: Bytes): JournalAdmission;
  /** Capture journal before content, so concurrent handoff cannot fall between reads. */
  loadRecovery(): Promise<JournalRecovery>;
  /** Commit the captured exact journal bytes, then attempt identity/value-matched cleanup. */
  flushJournal(): Promise<JournalFlushReceipt>;
  readonly observedJournalCharacters: number;
}
const openJournalOwner = async (
  input: CustodyAuthority,
  code: string,
  options: { signal?: AbortSignal } = {},
) => {
  const owner = prepareCustody(input, code, true, true);
  let live;
  try {
    live = await openWriteSession(owner.authority.slotId, {
      ...options,
      initialize: (task) => owner.initialize(task),
      dispose: owner.dispose,
    });
  } finally {
    owner.eraseFactor();
  }
  return { owner, live };
};
export const openJournalSession = async (
  input: CustodyAuthority,
  code: string,
  options: { signal?: AbortSignal } = {},
): Promise<JournalSession> => {
  const { owner, live } = await openJournalOwner(input, code, options);
  return attachJournal(owner, live);
};

/** Trusted Local Worker composition: identical native/factor initialization, journal subkeys only.
 * Root/content/private credential keys and live tasks never leave this realm. */
export const openLocalWorkerJournalSession = async (
  input: CustodyAuthority,
  code: string,
  options: { signal?: AbortSignal } = {},
) => {
  if (accountWorkerRuntime(input.slotId)?.kind !== 'local')
    throw Error('Local Worker journal composition required');
  const { owner, live } = await openJournalOwner(input, code, options);
  return Object.freeze({
    journal: attachJournal(owner, live),
    copyOpening: () => live.run((task) => owner.copyMirrorJournalOpening(task)),
    compactContent: (
      interrupt: AbortSignal,
      commit: (
        audited: import('./contentCompaction').DiskState,
        covered: StoredRecord[],
        observation: number,
      ) => Promise<boolean>,
    ) =>
      live
        .run(async (parent) => {
          const task = maintenanceTask(parent, interrupt);
          const checkJournal = async () => {
            const snapshot = await owner.journal.readSnapshot(task);
            try {
              task.step(() => validateContentUpdates(snapshot.map((e) => e.bytes)));
            } finally {
              eraseJournalSnapshot(snapshot);
            }
          };
          return owner.carrier.compact(
            task,
            () => {
              throw Error('Local Worker compaction requires an authenticated journal observation');
            },
            {
              checkJournal,
              removeCovered: (audited, covered) =>
                owner.journal.withObservation(task, async (id, entries) => {
                  task.step(() => validateContentUpdates(entries.map((e) => e.bytes)));
                  const result = await task.wait(() => commit(audited, covered, id));
                  task.step(() => {});
                  return result;
                }),
            },
          );
        })
        .catch(async (cause: unknown) => {
          if (cause instanceof ContentError && cause.code === 'missing-content')
            cause = new ContentError(
              'repair-required',
              'Initialized content metadata is missing.',
              { cause },
            );
          if (
            cause instanceof Error &&
            'code' in cause &&
            (cause.code === 'repair-required' || cause.code === 'generation-changed')
          )
            await live.close();
          throw cause;
        }),
    withJournalObservation: <T>(
      operation: (
        id: number,
        entries: readonly import('./journalStore').ObservedEntry[],
        task: SessionTask,
      ) => Promise<T>,
    ) =>
      live.run((task) =>
        owner.journal.withObservation(task, (id, entries) => operation(id, entries, task)),
      ),
  });
};
export const attachJournal = (
  owner: ReturnType<typeof prepareCustody>,
  live: WriteSession,
): JournalSession => {
  const withSnapshot = <T>(
    operation: (
      task: SessionTask,
      snapshot: ReturnType<typeof owner.journal.snapshot>,
    ) => Promise<T>,
  ): Promise<T> => {
    let snapshot: ReturnType<typeof owner.journal.snapshot> | undefined;
    let firstFailure: JournalError | undefined;
    try {
      // Preserve the existing invocation-time fast path, including the exact captured entry set.
      if (!owner.journal.asynchronous) snapshot = live.write(() => owner.journal.snapshot());
    } catch (cause) {
      if (!isJournalChanged(cause)) return Promise.reject(cause);
      firstFailure = cause;
    }
    return live
      .run(async (task) => {
        try {
          snapshot ??= await owner.journal.readSnapshot(task, firstFailure);
          return await operation(task, snapshot);
        } finally {
          if (snapshot) eraseJournalSnapshot(snapshot);
        }
      })
      .finally(() => {
        // run can reject before invoking its callback if close wins after the eager capture.
        if (snapshot) eraseJournalSnapshot(snapshot);
      });
  };
  return Object.freeze({
    ...owner.describe(),
    get state() {
      return live.state;
    },
    signal: live.signal,
    close: () => live.close(),
    get observedJournalCharacters() {
      return owner.journal.observedCharacters;
    },
    appendLocal: (update: Bytes) => live.write(() => owner.journal.append(update)),
    compactContent: (interrupt?: AbortSignal) =>
      live
        .run((task) =>
          owner.carrier.compact(maintenanceTask(task, interrupt), () => {
            const snapshot = owner.journal.snapshot();
            try {
              validateContentUpdates(snapshot.map((e) => e.bytes));
            } finally {
              eraseJournalSnapshot(snapshot);
            }
          }),
        )
        .catch(async (cause: unknown) => {
          // A known unreadable carrier closes ordinary use and drains owned work; persisted openers stay intact.
          if (cause instanceof ContentError && cause.code === 'missing-content')
            cause = new ContentError(
              'repair-required',
              'Initialized content metadata is missing.',
              { cause },
            );
          if (
            cause instanceof Error &&
            'code' in cause &&
            (cause.code === 'repair-required' || cause.code === 'generation-changed')
          )
            await live.close();
          throw cause;
        }),
    appendBatch: (input: readonly ContentInput[]) => {
      let copied: ContentInput[];
      try {
        copied = live.write(() => copyBatch(input));
      } catch (cause) {
        return Promise.reject(cause);
      }
      return live.run(async (task) => {
        try {
          return await owner.carrier.append(task, copied);
        } finally {
          for (const v of copied) v.bytes.fill(0);
        }
      });
    },
    loadRecords: () => live.run((task) => owner.carrier.load(task)),
    loadRecovery: () =>
      withSnapshot(async (task, snapshot) => {
        let records: OpenedRecord[] | undefined;
        try {
          records = await owner.carrier.load(task);
          return task.step(() => ({
            records: records!,
            journal: snapshot.map(({ key, generation, bytes }) => ({
              key,
              generation,
              bytes: bytes.slice(),
            })),
          }));
        } catch (cause) {
          if (records) for (const r of records) r.bytes.fill(0);
          throw cause;
        }
      }),
    flushJournal: () =>
      withSnapshot((task, snapshot) =>
        owner.journal.flush(task, snapshot, (task, bytes) =>
          owner.carrier.append(
            task,
            bytes.map((bytes) => ({ kind: 'update', bytes })),
          ),
        ),
      ),
  });
};

/** Internal Account composition seam; the Account owner authenticates before loading these caches. */
export const prepareAccountCustody = (
  input: CustodyAuthority,
  code: string,
  validateRecords?: ContentCrypto['validate'],
  allowSpoolCounter?: true,
  reuseOpened?: true,
  warmLoads?: true,
  selectiveLoads?: true,
  baseline?: ContentCrypto['baseline'],
  readBaseline?: true,
) =>
  prepareCustody(
    input,
    code,
    true,
    true,
    false,
    validateRecords,
    allowSpoolCounter,
    reuseOpened,
    false,
    warmLoads,
    selectiveLoads,
    baseline,
    readBaseline,
  );

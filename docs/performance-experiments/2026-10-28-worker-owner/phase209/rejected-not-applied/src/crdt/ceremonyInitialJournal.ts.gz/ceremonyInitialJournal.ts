/** Empty-journal observation for the original initial-generation commit under a REAL exclusive task.
 * This is neither a general pinned journal cache nor authority to initialize custody/content. */
import { ceremonyEnvironment } from './ceremonyEnvironment';
import { requireExclusiveSessionTask, type SessionTask } from './writeSession';
export async function observeInitialCeremonyJournal(
  task: SessionTask,
  slotId: string,
  prefix: string,
) {
  const environment = ceremonyEnvironment();
  if (!environment) return undefined;
  requireExclusiveSessionTask(task, slotId);
  environment.assertCurrent();
  if (!/^done\.pending-update\.done\.[a-f0-9]{32}\.$/u.test(prefix))
    throw Error('Initial journal scope changed');
  // The actual native exclusive old-slot grant prevents participating writers throughout this await
  // and the original synchronous IDB check. This observation expires WITH this exact task.
  const snapshot = await task.wait(() => environment.journal.read(prefix));
  const check = () => {
    requireExclusiveSessionTask(task, slotId);
    environment.assertCurrent();
    if (ceremonyEnvironment() !== environment) throw Error('Initial journal lifetime changed');
    if (snapshot.entries.length) throw Error('Unfinished device installation has journalled edits');
  };
  check();
  return check;
}

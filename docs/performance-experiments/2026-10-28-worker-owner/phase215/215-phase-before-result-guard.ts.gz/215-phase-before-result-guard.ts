/** Keep native setup work tracked, then yield only at its trusted final opening hook. */
import {
  requireCeremonyWorkerLifetime,
  type openCeremonyWorkerLifetime,
} from './ceremonyWorkerLifetime';
const deferred = <T>() => {
  let resolve!: (value: T | PromiseLike<T>) => void, reject!: (cause: unknown) => void;
  const promise = new Promise<T>((yes, no) => {
    resolve = yes;
    reject = no;
  });
  void promise.catch(() => {});
  return { promise, resolve, reject };
};
export function createWorkerCeremonyPhase(
  root: Awaited<ReturnType<typeof openCeremonyWorkerLifetime>>,
) {
  requireCeremonyWorkerLifetime(root);
  let current:
    | { yield: ReturnType<typeof deferred<void>>; released: ReturnType<typeof deferred<void>> }
    | undefined;
  let yielded = false;
  return Object.freeze({
    get handingOff() {
      return yielded;
    },
    run<T>(operation: () => Promise<T>): Promise<T> {
      requireCeremonyWorkerLifetime(root);
      if (current || yielded) throw Error('Ceremony phase unavailable');
      const flight = { yield: deferred<void>(), released: deferred<void>(), accepting: false },
        result = deferred<T>();
      current = flight;
      const job = root.run(async () => {
        const work = Promise.resolve().then(() => {
          flight.accepting = true;
          return operation();
        });
        void work.then(
          (value) => {
            flight.accepting = false;
            result.resolve(value);
          },
          (cause) => {
            flight.accepting = false;
            result.reject(cause);
          },
        );
        await Promise.race([
          work.then(
            () => {},
            () => {},
          ),
          flight.yield.promise,
        ]);
      });
      void job.then(
        () => flight.released.resolve(),
        (cause) => {
          result.reject(cause);
          flight.released.reject(cause);
        },
      );
      return result.promise.finally(() => {
        if (!yielded && current === flight) current = undefined;
      });
    },
    async yieldToAccount() {
      requireCeremonyWorkerLifetime(root);
      if (!current || !current.accepting || yielded)
        throw Error('Ceremony opening hook unavailable');
      const flight = current;
      yielded = true;
      flight.yield.resolve();
      await flight.released.promise;
      requireCeremonyWorkerLifetime(root);
    },
  });
}

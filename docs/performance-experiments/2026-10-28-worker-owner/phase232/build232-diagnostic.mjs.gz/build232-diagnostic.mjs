import{build}from'/Users/thomasingalls/.codex/worktrees/7fda/done/node_modules/vite/dist/node/index.js';
import{writeFileSync}from'node:fs';
const changes=[];function transform(s,id){const p=id.split('?')[0].split('/src/')[1];if(!p)return;let next=s;
const add=(anchor,line)=>{if(!next.includes(anchor))throw Error(p+' missing '+anchor);next=next.replace(anchor,anchor+`\nconsole.info('D232:${p}:${line}');\n`);changes.push({p,anchor,line});};
if(p==='crdt/admittedWorkspace.ts'){
add('const basis = accepted;', 'basis');next=next.replace("console.info('D232:crdt/admittedWorkspace.ts:basis');", "console.info('D232:basis',intent.command.kind,JSON.stringify(listActors(basis.history.doc).map(a=>a.name)));");
add('if (humanItem) {','prepared');next=next.replace("console.info('D232:crdt/admittedWorkspace.ts:prepared');", "console.info('D232:prepared',intent.command.kind,JSON.stringify(listActors(history.doc).map(a=>a.name)));");
add('verifiedRevision = event.revision;', 'publish');next=next.replace("console.info('D232:crdt/admittedWorkspace.ts:publish');", "console.info('D232:publish',event.source,JSON.stringify(listActors(accepted!.history.doc).map(a=>a.name)));");
}
if(p==='crdt/setupActorBridge.ts'){
add("fields(input, ['actorId']);",'read');next=next.replace("console.info('D232:crdt/setupActorBridge.ts:read');", "console.info('D232:actor-read',controller.workspace.read().actors.map(a=>a.name));");

next=next.replace("await controller.workspace.command({ kind: 'actor', patch: { name } }).accepted;", "console.info('D232:rename-before',name); await controller.workspace.command({ kind: 'actor', patch: { name } }).accepted; console.info('D232:rename-after',controller.workspace.read().actors.map(a=>a.name));");
}
return next===s?undefined:{code:next,map:null};}
// Window only diagnostic markers, no source changes. Worker transforms use same plugin factory.
const plugin=()=>({name:'disposable232',enforce:'pre',transform});
try{await build({root:'/Users/thomasingalls/.codex/worktrees/7fda/done',plugins:[plugin()],worker:{plugins:()=>[plugin()]},build:{outDir:'/private/tmp/done-worker-conversion-20261028/validation229/dist',emptyOutDir:true,sourcemap:true}});}finally{writeFileSync('/private/tmp/done-worker-conversion-20261028/232-diagnostic-transforms.json',JSON.stringify(changes,null,2));}

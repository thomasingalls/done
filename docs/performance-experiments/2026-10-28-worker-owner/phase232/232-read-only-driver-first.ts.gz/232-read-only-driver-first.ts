import {test,expect} from '@playwright/test';import {createdAccount} from '../device-enrollment/helpers';import {openMenuSection} from '../geometry/openApp';import {add} from './devices';import{startService,stopService}from './server';
test('read-only classification of first-write name regression',async({page},info)=>{
 test.setTimeout(60000);page.setDefaultTimeout(15000);const service=await startService(info.outputPath('service'),undefined,true,true);const result:any={};
 try{const first=await createdAccount(page);await add(page,'Name-test immediate writing');
 result.before=await page.evaluate(()=> (globalThis as any).__name232.read());
 result.persisted=await page.evaluate(async()=>{try{return await (globalThis as any).__name232.persisted();}catch(e){return{refused:(e as Error).name};}});
 await openMenuSection(page,'Account');await page.getByRole('button',{name:'Use another account',exact:true}).click();await expect(page.getByRole('heading',{name:'Choose an account',exact:true})).toBeVisible();result.chooser=await page.getByRole('button',{name:/^Unlock /}).allTextContents();
 await page.getByRole('button',{name:/^Unlock /}).first().click();await page.getByLabel('Unlock code',{exact:true}).fill(first.code);await page.getByRole('button',{name:'Confirm code and unlock with passkey',exact:true}).click();await expect(page.locator('.shell')).toBeVisible();result.cold=await page.evaluate(()=>(globalThis as any).__name232.read());
 }finally{console.log('NAME232',JSON.stringify(result));await info.attach('read-only-name-observation',{body:JSON.stringify(result),contentType:'application/json'});await stopService(service);}
});

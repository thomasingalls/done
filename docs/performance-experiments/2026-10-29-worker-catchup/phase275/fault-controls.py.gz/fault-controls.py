from pathlib import Path
import shutil,subprocess,os,json,hashlib
r=Path(__file__).parent;repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');src=r/'fault-source';assert src.is_dir();shutil.copytree(repo/'test',src/'test',dirs_exist_ok=True);shutil.copy2(repo/'test/unreducedBaselineExactReuse.test.ts',src/'test/unreducedBaselineExactReuse.test.ts');file=src/'src/crdt/contentStore.ts';original=(repo/'src/crdt/contentStore.ts').read_bytes();file.write_bytes(original);rows=[];node='/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node';env={**os.environ,'APP_BUILD_REVISION':'0ab9cbc8937e32c6542aaeeca697c87ba116c3be-dirty','APP_BUILD_DATE':'2026-10-30'}
faults=[('skip-chunk-bytes','snapshot.chunks.every((row, n) => equalStoredRecord(row, prior.baselineChunks![n]!))','true','changed same-shape chunk'),('skip-final-authority','openedView !== prior || forceFullRead || !prior.baselineMatches(baselineContext)','openedView !== prior || forceFullRead','authority change during the final'),('skip-final-lifetime','openedView !== prior || forceFullRead || !prior.baselineMatches(baselineContext)','forceFullRead || !prior.baselineMatches(baselineContext)','disposal during final authority')]
for name,needle,replacement,select in faults:
 assert original.decode().count(needle)==1, name
 file.write_text(original.decode().replace(needle,replacement))
 try:
  with(r/('fault-'+name+'.log')).open('w')as f:p=subprocess.run([node,str(src/'node_modules/vitest/vitest.mjs'),'run','test/unreducedBaselineExactReuse.test.ts','--testNamePattern',select],cwd=src,env=env,stdout=f,stderr=subprocess.STDOUT)
  log=(r/('fault-'+name+'.log')).read_text();assert p.returncode==1 and 'promise resolved'in log,(name,p.returncode,log[-1500:]);rows.append({'fault':name,'selection':select,'exit':p.returncode,'promisedGuardSensitive':True})
 finally:file.write_bytes(original)
 assert file.read_bytes()==original
(r/'fault-controls.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows))

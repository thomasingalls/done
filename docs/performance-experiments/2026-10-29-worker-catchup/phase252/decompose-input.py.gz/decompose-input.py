from pathlib import Path
import json,math
r=Path(__file__).parent;cases=[(Path('/private/tmp/done-due-send-yield-20261030'),'02-after-normal'),(Path('/private/tmp/done-due-send-yield-20261030'),'03-after-withheld'),(r,'01-enabled-normal'),(r,'02-enabled-withheld'),(r,'03-disabled-normal-control')];report=[]
def summary(values):
 s=sorted(values);return{'n':len(s),'p50':s[math.ceil(len(s)*.5)-1],'p95':s[math.ceil(len(s)*.95)-1],'max':max(s)}
for root,name in cases:
 x=json.loads((root/name/'result.json').read_text());offers=sorted(x['offers'],key=lambda v:v['at']);events=x['probes'][1]['events'];assert len(offers)==len(events)==123;clocks=[v for phase in x['clocks']for v in phase['rows'][1]];lo=max(v['renderer']-v['after']-1 for v in clocks);hi=min(v['renderer']-v['before']+1 for v in clocks);assert lo<=hi;rows=[];keyIndex=0
 for offer,event in zip(offers,events):
  assert offer['at']+lo-1<=event['at']<=offer['returnedAt']+hi+1,(name,offer,event)
  if offer['kind']!='key':continue
  keyIndex+=1;dom=next(v['at']for v in x['probes'][1]['counts']if v['count']>=x['baselines'][1]+keyIndex and v['at']>=offer['at']-5);rows.append({'index':offer['index'],'offeredToBeforeinputUpperMs':event['at']-lo-offer['at'],'beforeinputToDomMs':dom-event['at'],'offeredToDomUpperMs':dom-lo-offer['at']})
 out={'case':name,'queueUpper':summary([v['offeredToBeforeinputUpperMs']for v in rows]),'handlerToDom':summary([v['beforeinputToDomMs']for v in rows]),'totalUpper':summary([v['offeredToDomUpperMs']for v in rows]),'limits':'Beforeinput occurs after delivery/queue wait; short handler does not distinguish driver/CDP delay from renderer busy before dispatch. Actual event timing/long-task diagnostic needed.'};report.append(out)
(r/'input-decomposition.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))

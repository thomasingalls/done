from pathlib import Path
import json,collections,math,statistics
r=Path(__file__).parent;a=json.loads((r/'named-cost-analysis.json').read_text());out=[]
for row in a:
 x=json.loads((r/row['name']/'result.json').read_text());pubs=collections.defaultdict(list)
 for q in x.get('network',[]):
  for z in q.get('reads',[]):
   if not z.get('self'):pubs[z['publisherSha256']].append(z['after'])
 hot=max(pubs,key=lambda p:max(pubs[p]))if pubs else None
 live=max((p for p in pubs if p!=hot),key=lambda p:max(pubs[p])-min(pubs[p]),default=None)
 roles=lambda p:'backlog'if p==hot else'live-writer'if p==live else'quiet-peer'
 phases={'typing':(x.get('typingStartedAt'),x.get('typingFinishedAt'))}
 h1=next((c.get('completedAt')for c in x.get('catchups',[])if c['label']=='H1'and c.get('outcome')=='passed'),None)
 if h1 is not None:phases['H1-drain']=(x.get('startedAt'),h1)
 detail={}
 for phase,(start,end)in phases.items():
  if start is None or end is None:continue
  c=collections.Counter();http=collections.Counter();status=collections.Counter()
  for q in x.get('network',[]):
   if not(start<=q['at']<=end):continue
   label=q.get('label','unknown');http[label+':'+q['path']]+=1
   for z in q.get('reads',[]):
    role='self'if z.get('self')else roles(z['publisherSha256']);c[label+':'+role]+=1;status[label+':'+role+':'+str(q.get('status'))]+=1
  detail[phase]={'durationMs':end-start,'logicalReadFrames':dict(c),'logicalReadFramesPerSecond':{k:v/((end-start)/1000)for k,v in c.items()},'httpRequests':dict(http),'statuses':dict(status)}
 ev=[e for q in x.get('labAfter',[[]])[0]for e in(q.get('value')or{}).get('events',[])];arms=sorted([e for e in ev if e['kind']=='repairActivation'and e['at']>=x.get('typingStartedAt',math.inf)],key=lambda e:e['at']);intervals=[]
 for e in arms:
  s=max(e['at'],x['typingStartedAt']);t=min(e['until'],x['typingFinishedAt'])
  if t<=s:continue
  if intervals and s<=intervals[-1][1]:intervals[-1][1]=max(intervals[-1][1],t)
  else:intervals.append([s,t])
 coverage=sum(t-s for s,t in intervals);overflow=sum((q.get('value')or{}).get('eventOverflow',0)for q in x.get('labAfter',[[]])[0])
 row.update(readClassWindows=detail,repairObservedArmEvents=len(arms),repairTypingArmedMsObserved=coverage,repairTypingArmedFractionObserved=coverage/(x['typingFinishedAt']-x['typingStartedAt'])if x.get('typingFinishedAt')else None,readerEventOverflow=overflow,armCoverageComplete=overflow==0)
 out.append(row)
(r/'named-cost-analysis.json').write_text(json.dumps(out,indent=2)+'\n')
controls=[x for x in out if x['R']==0];d0=[x for x in out if x['R']==1 and x['D']==0];d1=[x for x in out if x['D']==1]
summary={'qualification':'Lab-only descriptive independent journey contrasts, mixed order. No causal certainty from 2 or3 runs. Tokens are logical budget units; arms/interval decisions are not actual timer firings. Raw failed runs retained.','groups':{}}
for key,rr in [('Roff-Doff',controls),('R1000-Doff',d0),('R1000-Don',d1)]:
 v=[]
 for x in rr:v.append({k:x.get(k)for k in ['name','drainMs','tokensTypingWindow','tokensThroughDelivery','peerMs','postDrainPeerMs','postBothDrainsPeerMs','realmCounterDeltas','readClassWindows','allMeasuredPredicates','cold','analysisError','repairTypingArmedFractionObserved','armCoverageComplete']})
 summary['groups'][key]=v
summary['pairs']=[{'pair':i,'rows':[{k:x.get(k)for k in ['name','D','drainMs','tokensTypingWindow','realmCounterDeltas','readClassWindows','peerMs','postDrainPeerMs','allMeasuredPredicates']}for x in out if x['pair']==i]}for i in [1,2,3]]
(r/'named-cost-contrasts.json').write_text(json.dumps(summary,indent=2)+'\n')
for x in out:print(json.dumps({k:x.get(k)for k in ['name','D','R','drainMs','tokensTypingWindow','realmCounterDeltas','peerMs','postDrainPeerMs','namedHintsActuallyObserved','allMeasuredPredicates','cold','readerEventOverflow','analysisError']}))

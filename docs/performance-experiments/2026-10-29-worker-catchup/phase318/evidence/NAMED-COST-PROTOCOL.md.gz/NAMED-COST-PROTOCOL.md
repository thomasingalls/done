# Declared named-hint pairs and normal repair controls

Declared before any D pair starts, at 2026-10-31T15:57:36.691759+00:00 while the four index3072 cells run. Source/build unchanged; no rebuild. All are the same fictional private1024 fixture, normal hints, G8, S1Y1, P1, V0, quiet750. R1000 remains the selected dose; R off uses bits10001. Exact mixed order is named-cost-plan.json. Three D off/on pairs plus two extra R-off/D-off normal controls. All eight runs retained with external5s CPU/top executable log. No credit.

Report H1/H2 drains, tokens, quiet reads, overall and post-drain peer p95, actual named exposure, R activation/armed windows, input and every original predicate. Compare the two R-off controls with the three D-off/R1000 arms on this fixture; preserve variability and pair/order caveats. The two earlier phase315 normal runs remain separate evidence, never replaced. No-backlog first-miss question remains out of scope.

No gate, deadline, assertion or safety guard changes. Any actual no-F cold failure stops immediately; all other failed runs remain and declared work continues.

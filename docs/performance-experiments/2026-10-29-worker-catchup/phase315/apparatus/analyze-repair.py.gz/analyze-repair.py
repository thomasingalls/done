from pathlib import Path
import json,math,statistics,urllib.parse
r=Path(__file__).parent;rows=json.loads((r/'repair-results.json').read_text());out=[]
def stat(v):
 s=sorted(v);return {'n':len(s),'p50':s[math.ceil(.5*len(s))-1],'p95':s[math.ceil(.95*len(s))-1],'max':s[-1]}if s else None
def counters(rows):return{k:sum(z.get('value',{}).get(k,0)for z in rows)for k in ['repairActivations','repairIntervals','quietReads','contentHints','namedHints']}
for row in rows:
 x=json.loads((r/row['name']/'result.json').read_text());data={**row,'metricPredicates':{},'postDrainExposure':'not measured','qualification':'Lab only, no credit. Each journey is one unit; keys are not independent runs. Conservative original clock-bracket upper latencies. Server-epoch token sums preserve clock uncertainty. No backlog first miss is outside scope.'}
 try:
  keys=[o for o in x['offers']if o['kind']=='key'];markers=[o for o in x['offers']if o['kind']=='marker'];assert len(keys)==120 and len(markers)==3
  vals=[];mv=[]
  for device,p in enumerate(x['probes']):
   b=[v for g in x['clocks']for v in g['rows'][device]];lo=max(q['renderer']-q['after']-1 for q in b);hi=min(q['renderer']-q['before']+1 for q in b);assert lo<=hi
   vals.append([next(q['at']for q in p['counts']if q['at']>=o['at']-5 and q['count']>=x['baselines'][device]+i)-o['at']-lo for i,o in enumerate(keys,1)]);mv.append([p['markers'][i]-o['at']-lo for i,o in enumerate(markers)])
  ev=x['probes'][1]['events'];trusted=len(ev)==123 and all(e['trusted']and e['focused']and e['visible']=='visible'for e in ev)
  before=[counters(z)for z in x['labBefore']];after=[counters(z)for z in x['labAfter']];delta=[{k:a[k]-b[k]for k in a}for a,b in zip(after,before)];drains={v['label']:v['completedAt']for v in x['catchups']if v.get('outcome')=='passed'};readerEnd=drains.get('H1');bothEnd=max(drains.values())if len(drains)==2 else None;post=[readerEnd is not None and o['at']>readerEnd for o in keys];postBoth=[bothEnd is not None and o['at']>bothEnd for o in keys]
  budget=x['budgetAfter']['budget']['events'];tokens=sum(e['units']for e in budget if x['typingStartedAt']<=e['at']<=x['typingFinishedAt']);tokensFinal=sum(e['units']for e in budget if x['typingStartedAt']<=e['at']<=x['newDeliveryAt']);doseUrls=sorted(set(z['realm']for a in x['labAfter']for z in a if z['realm']!='window'));doses=sorted(set(urllib.parse.parse_qs(urllib.parse.urlparse(u).query).get('labRepairMs',['missing'])[0]for u in doseUrls));assert doses==[str(row['repairMs'])],doses
  data.update(peerMs=stat(vals[0]),localMs=stat(vals[1]),perKeyPeerMs=vals[0],markerPeerMs=mv[0],tokensTypingWindow=tokens,tokensThroughDelivery=tokensFinal,realmCounterDeltas=delta,realmCountersBefore=before,realmCountersAfter=after,keysAfterReaderDrain=sum(post),keysAfterBothDrains=sum(postBoth),postDrainPeerMs=stat([v for v,t in zip(vals[0],post)if t]),postBothDrainsPeerMs=stat([v for v,t in zip(vals[0],postBoth)if t]),postDrainExposure='exposed'if any(post)else'NOT EXPOSED',observedDoses=doses,drainMs={k:v-x['startedAt']for k,v in drains.items()})
  data['metricPredicates']={'all120Keys':True,'input16ms':data['localMs']['p95']<=16,'peer2500ms':data['peerMs']['p95']<=2500,'everyMarker2500ms':max(mv[0])<=2500,'postDrainPeer2500ms':None if not any(post)else data['postDrainPeerMs']['p95']<=2500,'bothBacklogs600s':len(drains)==2 and max(drains.values())-x['startedAt']<=600000,'finalNewDelivery30s':x['newDeliveryAt']-max(o['returnedAt']for o in x['offers'])<=30000,'trustedFocusedVisible':trusted,'faultExposed':not row['withhold']or x['notifications'][0]['withheld']>0,'coldExact':x.get('guards',{}).get('bothOfflineColdProfilesExact',False),'functional':row['childExit']==0,'RexposedWhenWithheld':not row['withhold']or after[0]['repairActivations']>0}
 except Exception as e:data['analysisError']=repr(e)
 owners=[]
 for i,realms in enumerate(x.get('maintenanceTraceBeforeCold',[])):
  aa=[];ee=[]
  for realm in realms:
   v=realm.get('value')or{};aa+=v.get('attempts',[]);ee+=v.get('events',[])
  caps=[e for e in ee if e.get('kind')in ['PreparationCapacity','preparation-capacity']];complete=[a for a in aa if a.get('outcome',{}).get('kind')in ['removed','already-removed']];journals=[j for a in aa for j in a.get('journals',[])];saves=[e for e in ee if e.get('kind')=='checkpoint-saved'];owners.append({'role':['reader','writer'][i],'attempts':len(aa),'completions':len(complete),'capacity':len(caps),'mapPeakBytes':max((j.get('bytes',0)for j in journals),default=None),'durablePeakBytes':max((e['bytes']for e in saves),default=None),'firstStartAfterTypingMs':min((a['startedAt']-x['typingFinishedAt']for a in aa),default=None),'lastOutcome':aa[-1].get('outcome')if aa else None,'censoredAtOriginalCold':True,'interpretation':'No attempts means not exposed, not proof of no delay; original wait is unchanged'})
 data['maintenanceOwners']=owners;data['cold']=bool(x.get('guards',{}).get('bothOfflineColdProfilesExact'));data['allMeasuredPredicates']=not data.get('analysisError')and all(v is True for v in data['metricPredicates'].values());out.append(data)
(r/'repair-analysis.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps([{'name':x['name'],'all':x['allMeasuredPredicates'],'peer':x.get('peerMs'),'postKeys':x.get('keysAfterReaderDrain'),'postPeer':x.get('postDrainPeerMs'),'tokens':x.get('tokensTypingWindow'),'counters':x.get('realmCounterDeltas'),'maintenance':x.get('maintenanceOwners'),'error':x.get('analysisError')}for x in out],indent=2))

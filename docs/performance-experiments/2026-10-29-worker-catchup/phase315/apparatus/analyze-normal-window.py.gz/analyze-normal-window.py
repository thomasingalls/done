from pathlib import Path
import json,hashlib,gzip
r=Path(__file__).parent;out=[]
for name in ['repair-05-normal-R1000','repair-06-normal-R1000']:
 x=json.loads((r/name/'result.json').read_text());events=sorted([e for z in x['labAfter'][0]for e in z.get('value',{}).get('events',[])if e['kind']=='repairActivation'],key=lambda e:e['at']);spans=[]
 for e in events:
  a,b=e['at'],e['at']+30000
  if spans and a<=spans[-1][1]:spans[-1][1]=max(spans[-1][1],b)
  else:spans.append([a,b])
 start,end=x['typingStartedAt'],x['typingFinishedAt'];active=sum(max(0,min(b,end)-max(a,start))for a,b in spans);out.append({'name':name,'rearms':len(events),'episodes':len(spans),'typingWindowMs':end-start,'armedDuringTypingMs':active,'armedFraction':active/(end-start),'episodeOffsetsMs':[[a-start,b-start]for a,b in spans],'intervalSelections':sum(z.get('value',{}).get('repairIntervals',0)for z in x['labAfter'][0])-sum(z.get('value',{}).get('repairIntervals',0)for z in x['labBefore'][0]),'qualification':'Armed time inferred from approved30srearm rule and observer performance clock, not a count of fired timers/extra HTTPrequests. No matched normalR1500orRoffarm; incremental traffic remains unproven.'})
p=r/'normal-repair-coverage.json';p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
d=Path('/Users/thomasingalls/.codex/worktrees/7fda/done/docs/performance-experiments/2026-10-29-worker-catchup/phase315');index=json.loads((d/'evidence-index.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
for p,cat in [(r/'normal-repair-coverage.json','evidence'),(Path(__file__),'apparatus')]:
 b=p.read_bytes();dest=d/cat/(str(p.relative_to(r))+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(gzip.compress(b,compresslevel=6,mtime=0));index['items'].append({'source':str(p),'copy':str(dest.relative_to(d)),'rawSha256':sha(b),'bytes':len(b),'gzipSha256':sha(dest.read_bytes())})
(d/'normal-repair-coverage.json').write_bytes((r/'normal-repair-coverage.json').read_bytes());(d/'evidence-index.json').write_text(json.dumps(index,indent=2)+'\n')
for i in index['items']:assert sha(gzip.decompress((d/i['copy']).read_bytes()))==i['rawSha256'];assert sha(Path(i['source']).read_bytes())==i['rawSha256']
(d/'evidence-check.json').write_text(json.dumps({'verifiedOriginalCopies':len(index['items']),'allExact':True},indent=2)+'\n')

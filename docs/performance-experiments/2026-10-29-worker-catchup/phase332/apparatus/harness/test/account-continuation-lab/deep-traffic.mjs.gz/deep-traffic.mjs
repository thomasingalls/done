import { decodeInboundRequest } from '/private/tmp/done-checkpoint-matched-lab-20261101/source-after/account-protocol/inboundTransport.ts';
import { decodeInboundBatch } from '/private/tmp/done-checkpoint-matched-lab-20261101/source-after/account-protocol/inboundBatch.ts';
// Observation only: no network response body, key, signature, token or writing is retained.
export function observeDeepTraffic(context, now = () => performance.timeOrigin + performance.now(), bound = 8192) {
  if (!Number.isSafeInteger(bound) || bound < 1 || bound > 8192) throw Error('Invalid traffic bound');
  const rows = [], held = new WeakMap();
  let dropped = 0, malformed = 0, active = true;
  const request = q => {
    const path = new URL(q.url()).pathname;
    if (!active || !path.startsWith('/account/')) return;
    if (rows.length === bound) { dropped++; return; }
    const row = { at: now(), path, method: q.method() };
    rows.push(row); held.set(q, row);
    if (!path.endsWith('/read-v2') && !path.endsWith('/read-v2-batch')) return;
    let parts = [];
    try {
      const bytes = q.postDataBuffer();
      if (!bytes) throw Error('Missing read body');
      parts = path.endsWith('/read-v2-batch') ? decodeInboundBatch(bytes) : [new Uint8Array(bytes)];
      row.reads = parts.map(b => { const r = decodeInboundRequest(b); return { publisher: r.publisher, after: r.after, limit: r.limit }; });
    } catch { malformed++; row.readShape = 'unavailable'; }
    finally { for (const b of parts) b.fill(0); }
  };
  const response = p => { const row = held.get(p.request()); if (active && row) { row.headersAt = now(); row.status = p.status(); } };
  const failed = q => { const row = held.get(q); if (active && row) { row.failedAt = now(); row.failed = true; } };
  context.on('request', request); context.on('response', response); context.on('requestfailed', failed);
  return { snapshot: () => structuredClone({ clock: 'Node epoch milliseconds: timeOrigin + performance.now', rows, dropped, malformed }), close() { active = false; context.off('request', request); context.off('response', response); context.off('requestfailed', failed); } };
}

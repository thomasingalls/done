import {defineConfig} from '@playwright/test';
export default defineConfig({testDir:'.',testMatch:['*330.spec.ts','*332.spec.ts'],workers:1,retries:0,timeout:1800000,reporter:[['list']],outputDir:process.env['FAIR_OUT']+'/artifacts',use:{actionTimeout:20000,trace:'off',screenshot:'off',video:'off'}});

import {expect,type Page} from '@playwright/test';
import {openMenuSection} from '../../geometry/openApp';
import {archiveIdentity} from '../common';
const observed=new WeakMap<Page,any>();
/** Read-only observation of the actual Export button's ZIP Blob. Native URL/click/revoke are unchanged. */
export async function exportedBlob332(p:Page){
 let record=observed.get(p);if(!record){record={exports:[],downloads:[]};observed.set(p,record);p.on('download',d=>record.downloads.push({at:performance.timeOrigin+performance.now(),suggestedFilename:d.suggestedFilename()}));}
 await openMenuSection(p,'Data');await p.evaluate(()=>{const real=URL.createObjectURL;const state:any={created:false,bytes:null,error:null};(window as any).__zip332=state;URL.createObjectURL=function(blob:Blob|MediaSource){const url=real.call(URL,blob);if(blob instanceof Blob&&blob.type==='application/zip'){URL.createObjectURL=real;state.created=true;state.size=blob.size;state.at=performance.timeOrigin+performance.now();state.promise=blob.arrayBuffer().then(b=>{state.bytes=Array.from(new Uint8Array(b));},e=>{state.error=String(e)});}return url;};});
 const before=record.downloads.length;await p.getByRole('button',{name:'Export markdown',exact:true}).click();await p.waitForFunction(()=>{const s=(window as any).__zip332;return !!s?.bytes||!!s?.error||[...document.querySelectorAll('#menu [role="alert"]')].some(e=>e.textContent?.includes('export could not be created'));},undefined,{timeout:20000});
 const got=await p.evaluate(()=>{const s=(window as any).__zip332;if(!s?.bytes)throw Error('Application export refusal: '+([...document.querySelectorAll('#menu [role="alert"]')].map(e=>e.textContent).join(' ')||s?.error||'no native ZIP'));const out={bytes:s.bytes,size:s.size,at:s.at};delete(window as any).__zip332;return out;});const bytes=Buffer.from(got.bytes),files:Record<string,string>={};let at=0;
 while(bytes.readUInt32LE(at)===0x04034b50){expect(bytes.readUInt16LE(at+8)).toBe(0);const size=bytes.readUInt32LE(at+18),n=bytes.readUInt16LE(at+26),extra=bytes.readUInt16LE(at+28),start=at+30+n+extra;files[bytes.toString('utf8',at+30,at+30+n)]=bytes.toString('utf8',start,start+size);at=start+size;}
 record.exports.push({at:got.at,zipBytes:got.size,archive:archiveIdentity(files),downloadEventsObservedByReadReturn:record.downloads.length-before});return files;
}
export async function exactBlob332(a:any,expected:any){const actual=await exportedBlob332(a.p);expect(actual).toEqual(expected);return archiveIdentity(actual);}
export function zipEvidence332(p:Page){return structuredClone(observed.get(p)??{exports:[],downloads:[]});}

from pathlib import Path
import sqlite3,json,hashlib,struct
r=Path(__file__).parent;fixture=json.loads((r/'private-fixture/fixture.json').read_text());states={'original':fixture['state'],'control':json.loads((r/'controlFixture332.json').read_text())['state'],'checkpoint':json.loads((r/'checkpointFixture330.json').read_text())['state']};out={}
for label,state in states.items():
 db=sqlite3.connect('file:'+state+'/account.sqlite?mode=ro&immutable=1',uri=True);families={}
 for table in ['delivery_decisions','publisher_decisions']:
  cols=[z[1]for z in db.execute('PRAGMA table_info('+table+')')];order=','.join(c for c in['account_id','credential_id','ordinal','position']if c in cols);rows=db.execute("SELECT * FROM "+table+" WHERE kind='accepted' ORDER BY "+order).fetchall();h=hashlib.sha256()
  for row in rows:
   for v in row:
    b=v if isinstance(v,bytes)else json.dumps(v,separators=(',',':')).encode();h.update(struct.pack('>Q',len(b)));h.update(b)
  families[table]={'acceptedRows':len(rows),'allColumnsSha256':h.hexdigest()}
 db.close();out[label]=families
assert out['control']==out['original']==out['checkpoint']
(r/'accepted-all-families332.json').write_text(json.dumps({'states':states,'families':out,'allAcceptedRowsByteIdentical':True,'bothPreparationsAddedZero':True,'totalAcceptedRows':sum(x['acceptedRows']for x in out['original'].values()),'qualification':'The in-spec acceptedRowsBefore/After fields count publisher_decisions only (7). This independent check also covers all1327 legacy delivery_decisions, including original A backlog, every column and exact submission/response bytes. No rows were changed.'},indent=2)+'\n');print(json.dumps(out,indent=2))

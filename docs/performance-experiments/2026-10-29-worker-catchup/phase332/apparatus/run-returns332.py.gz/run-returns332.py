from pathlib import Path
import json,subprocess,time,sys,os,signal,hashlib,datetime
r=Path(__file__).parent;node='/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node';key=sys.argv[1];plan=json.loads((r/(key+'-plan.json')).read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def files(base):return{str(p.relative_to(base)):sha(p)for p in base.rglob('*')if p.is_file()}
assetRoots={str(Path(c.get('dist',r/'combined-dist'))):files(Path(c.get('dist',r/'combined-dist')))for c in plan};sourceRoots={str(Path(c.get('source',r/'source'))):{str(p.relative_to(Path(c.get('source',r/'source')))):sha(p)for d in ['src','account-protocol']for p in(Path(c.get('source',r/'source'))/d).rglob('*')if p.is_file()}for c in plan}
frozen={'sourceRoots':sourceRoots,'assetRoots':assetRoots,'serverSources':files(r/'source-server'),'apparatus':{str(p.relative_to(r)):sha(p)for p in(r/'harness/test/account-continuation-lab').rglob('*')if p.is_file()},'support':{n:sha(r/n)for n in ['run-returns332.py','lab-context.mjs','observer.mjs','container-service.mjs','harness/tsconfig.json','playwright-storage-source.txt']},'plan':plan,'labOnly':True,'acceptanceCredit':False,'fixtures':{str(Path(c.get('fixture',r/'private-fixture/fixture.json'))):sha(Path(c.get('fixture',r/'private-fixture/fixture.json')))for c in plan}};(r/(key+'-inputs.json')).write_text(json.dumps(frozen,indent=2)+'\n');rows=[]
stateManifest=json.loads((r/'prepared-states332.json').read_text())
def assertStates():
 for n,v in stateManifest.items():
  assert sha(r/n)==v['metadataSha256']
  assert all(sha(Path(v['state'])/path)==h for path,h in v['files'].items())
assertStates();frozen['preparedStates']=stateManifest;(r/(key+'-inputs.json')).write_text(json.dumps(frozen,indent=2)+'\n')
subprocess.run(['docker','info','--format','{{.ServerVersion}}'],check=True,timeout=10)
for c in plan:
 assertStates()
 assert not(r/'STOP_ALL.json').exists();assert not(r/'STOP_FUNCTIONAL.json').exists()
 if c.get('pp')and(r/'STOP_P.json').exists():
  row={**c,'status':'SKIPPED after P cold failure','childExit':None,'coldFailure':False,'coldExact':False,'labOnly':True,'acceptanceCredit':False};rows.append(row);(r/(key+'-results.json')).write_text(json.dumps(rows,indent=2)+'\n');print('SKIP',c['name'],flush=True);continue
 assert all(sha(r/'source-server'/n)==h for n,h in frozen['serverSources'].items());source=Path(c.get('source',r/'source'));dist=Path(c.get('dist',r/'combined-dist'));assert all(sha(source/n)==h for n,h in frozen['sourceRoots'][str(source)].items());assert all(sha(dist/n)==h for n,h in frozen['assetRoots'][str(dist)].items());assert all(sha(r/n)==h for n,h in frozen['apparatus'].items());assert all(sha(r/n)==h for n,h in frozen['support'].items());fixture=Path(c.get('fixture',r/'private-fixture/fixture.json'));assert json.loads(fixture.read_text())['accounts'][0]['date']==datetime.datetime.now(datetime.timezone.utc).date().isoformat();assert sha(fixture)==frozen['fixtures'][str(fixture)]
 out=r/c['name'];out.mkdir(mode=0o700,exist_ok=False);env={k:v for k,v in os.environ.items()if not k.startswith(('FAIR_','RANGE_LAB_'))};env.update({'PATH':str(Path(node).parent)+':'+env['PATH'],'FAIR_OUT':str(out),'FAIR_DIST':str(dist),'FAIR_FIXTURE':str(fixture),'FAIR_LAB_BITS':c['bits'],'FAIR_SY_BITS':c.get('SY','1N'),'FAIR_REPAIR_MS':str(c.get('repairMs',1000)),'FAIR_QUIET_OFF':'1'if c.get('quietOff')else'0','FAIR_PP':'1'if c.get('pp')else'0','FAIR_KEY_MS':str(c.get('keyMs',500)),'FAIR_WRITERS':str(c.get('writers',1)),'FAIR_KEYS':str(c.get('keys',120)),'FAIR_EB':c.get('eb','11'),'FAIR_WORKER_PROFILE':'1'if c.get('workerProfile')else'0','FAIR_RTT':str(c.get('rtt',0)),'FAIR_PROFILE':'1'if c.get('profile')else'0','FAIR_VARIANT':'phase326-lab','QUIET_WITHHOLD':'1'if c.get('withhold')else'0','FAIR_IDLE_PAUSE':'1'if c.get('idlePause')else'0','FAIR_PREP_HIDDEN':'0','CHROMIUM_PATH':'/private/tmp/done-civil-gates-browser-20261030/Chrome.app/Contents/MacOS/Google Chrome'})
 env['FAIR_CHECKPOINT']='1'if c.get('checkpoint')else'0'
 if c.get('mobile')is not None:env['STALL_MOBILE']='1'if c['mobile']else'0'
 cmd=[node,'node_modules/@playwright/test/cli.js','test','--config','test/account-continuation-lab/'+c['config'],c['fileFilter']]
 if c.get('grep'):cmd+=['--grep',c['grep']]
 with(out/'list.log').open('w')as f:pre=subprocess.run(cmd+['--list'],cwd=r/'harness',env=env,stdout=f,stderr=subprocess.STDOUT)
 if pre.returncode or 'Total: 1 test in 1 file'not in(out/'list.log').read_text():print('LIST FAILED',c['name'],flush=True);sys.exit(4)
 load=out/'host-load.jsonl';sampler=subprocess.Popen([sys.executable,str(r/'host_load.py'),'--out',str(load)]);start=time.time()
 try:
  for i in range(500):
   if Path(str(load)+'.ready').exists():break
   if sampler.poll()is not None:raise RuntimeError('Sampler failed')
   time.sleep(.01)
  else:raise RuntimeError('Sampler not ready')
  print('START',c['name'],flush=True)
  with(out/'console.log').open('w')as f:p=subprocess.run(cmd,cwd=r/'harness',env=env,stdout=f,stderr=subprocess.STDOUT)
 finally:sampler.send_signal(signal.SIGTERM);sampler.wait(timeout=10)
 raw=out/c.get('result','result.json');raw=raw if raw.exists()else out/'partial-result.json';x=json.loads(raw.read_text())if raw.exists()else{};cold=bool(x.get('coldFailure'))or(bool(x.get('coldAttemptStarted'))and not any(x.get('guards',{}).get(g)for g in ['originalAccountReaderColdExact','bothOfflineColdProfilesExact','offlineColdProfileExact','originalJoinedColdReopen','originalJoinedPageColdReopenExact','actualPageColdReopenExact']))
 row={**c,'command':cmd,'childExit':p.returncode,'startedAt':start,'finishedAt':time.time(),'outcome':x.get('outcome'),'error':x.get('error'),'coldFailure':cold,'guards':x.get('guards',{}),'ownerObservation':x.get('ownerObservation',{}).get('terminal'),'ownerCold':x.get('ownerCold'),'positionsAt30':x.get('positionsAt30'),'timeTo700Ms':x.get('timeTo700Ms'),'timeTo1025Ms':x.get('timeTo1025Ms'),'deep30Pass':x.get('deep30Pass'),'externalLoadLog':'host-load.jsonl','labOnly':True,'acceptanceCredit':False};rows.append(row);(out/'receipt.json').write_text(json.dumps(row,indent=2)+'\n');(r/(key+'-results.json')).write_text(json.dumps(rows,indent=2)+'\n');print('RESULT',json.dumps(row),flush=True)
 if c.get('stopFunctional') and p.returncode:
  (r/('REVIEW_'+c['name']+'.json')).write_text(json.dumps({'case':row,'reason':'Nonzero child requires classification. Harness preconditions may be fixed/rerun with attempts retained; app functional failure stops.'},indent=2)+'\n');sys.exit(5)
 if cold:
  scope='P'if c.get('pp')else'ALL';(r/f'STOP_{scope}.json').write_text(json.dumps({'rule':'Phase326: P cold stops P only; non-P cold stops lane','case':row},indent=2)+'\n')
  if scope=='ALL':sys.exit(3)
print('All declared '+key+' outcomes retained',flush=True)

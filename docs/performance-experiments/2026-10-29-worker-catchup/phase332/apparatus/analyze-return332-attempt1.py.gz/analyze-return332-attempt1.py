from pathlib import Path
import json,math,statistics,csv
r=Path(__file__).parent
runs=json.loads((r/'returnFirst332-results.json').read_text())+json.loads((r/'returnRest332-results.json').read_text())
def stats(v):
 v=sorted(v);return {'n':len(v),'p50':v[math.ceil(.5*len(v))-1],'p95':v[math.ceil(.95*len(v))-1],'max':v[-1]}if v else{'n':0,'p50':None,'p95':None,'max':None}
result=[]
for run in runs:
 x=json.loads((r/run['name']/'result.json').read_text());o=x['beforeUndo'];p=o['probe'];br=o['clock'];lo=max(b['renderer']-b['after']-1 for b in br);hi=min(b['renderer']-b['before']+1 for b in br);assert lo<=hi;assert p['visibleAt']is not None
 events=o['fault']['events'];installs=[]
 for end in[e for e in events if e['kind']=='history-install-end330']:
  start=max((e for e in events if e['kind']=='history-install-start330'and e['at']<=end['at']),key=lambda e:e['at']);mid=[e for e in events if e['kind']=='history-install-result330'and start['at']<=e['at']<=end['at']];installs.append({'start':start['at'],'end':end['at'],'durationMs':end['at']-start['at'],'committed':end['committed'],'results':[m['result']for m in mid],'installBytes':start['bytes']})
 actual=next((z for z in installs if'installed'in z['results']),None);allKeys=[];during=[];missing=[]
 for i,offer in enumerate(x['offers'],1):
  found=next((z['at']for z in p['counts']if z['at']>=offer['at']-5 and z['count']>=i),None)
  if found is None:missing.append(i);continue
  value=found-offer['at']-lo;allKeys.append(value)
  if actual and actual['start']<=offer['at']+lo and offer['at']+hi<=actual['end']:during.append(value)
 assert not missing,(run['name'],missing)
 visible=p['visibleAt']-lo;end=max(visible,x['typingFinishedAt']);window=[q for q in x['network']if x['unlockSubmittedAt']<=q['at']<=visible];whole=[q for q in x['network']if x['unlockSubmittedAt']<=q['at']<=end];reads=lambda rows:[q for q in rows if'/delivery/read'in q['path']];units=lambda rows:sum(max(1,len(q.get('reads',[])))for q in reads(rows));positions=lambda rows:sum(z['entries']for q in reads(rows)for z in q.get('pages',[]));after=lambda rows:[q for q in rows if actual and q['at']+lo>=actual['end']];late=lambda rows:[q for q in rows if actual and q['at']+hi<actual['end']and q.get('headersAt',0)+lo>=actual['end']]
 snapshots=[q for q in x['network']if q['path']=='/account/history/v1/checkpoint'and q.get('payloadKind')=='latest'and q.get('checkpoint',{}).get('hasAdmission')];meta=snapshots[0]['checkpoint']if snapshots else None
 row={'name':run['name'],'checkpoint':run['checkpoint'],'rtt':run['rtt'],'replicate':run['replicate'],'childExit':run['childExit'],'unlockToEditorMs':x['editorUsableAt']-x['unlockSubmittedAt'],'unlockToAllVisibleMs':visible-x['unlockSubmittedAt'],'visibleClockOffsetBoundsMs':[lo,hi],'originalTargetObservedAt':p['visibleAt'],'fullArchiveExact':True,'coldExact':x['guards']['offlineColdExactAndUndo'],'Undo':x['guards']['nativeUndoExact'],'naturalHistoryRequired':any(e['kind']=='history-catalog-decision330'and e['historyRequired']for e in events),'actualCatalogReads':sum(q['path']=='/account/history/v1/checkpoint'and q.get('payloadKind')=='catalog'and q.get('status')==200 for q in whole),'install':actual,'otherInstalls':installs,'snapshot':meta,'latestBodyBytes':snapshots[0]['responseBytes']if snapshots else0,'snapshotDownloadCount':len(snapshots),'readUnitsToVisible':units(window),'positionsFetchedToVisible':positions(window),'readUnitsThroughInputEnd':units(whole),'positionsFetchedThroughInputEnd':positions(whole),'positionsFetchedAfterInstallToVisible':positions(after(window))if actual else None,'positionsFetchedAfterInstallThroughInputEnd':positions(after(whole))if actual else None,'latePrefetchPositionsThroughInputEnd':positions(late(whole))if actual else None,'historyRequestsToVisible':sum(q['path']=='/account/history/v1/checkpoint'for q in window),'inputWholeReturnMs':stats(allKeys),'inputDuringInstallMs':stats(during),'inputDuringInstallExposure':'exposed'if during else'not exposed','trustedFocusedVisible':all(e['trusted']and e['focused']and e['visible']=='visible'for e in p['events']if e['kind']=='beforeinput'),'inputBeforeEvents':sum(e['kind']=='beforeinput'for e in p['events']),'observationErrors':[q['observationError']for q in x['network']if q.get('observationError')],'streams':o['fault']['streams'],'interpretation':'Positions are decoded logical page entries, not units. After-install is request-start timing; late prefetched replies reported separately. Whole input end may extend beyond full-target visibility; install n0 is unexposed.'};result.append(row)
(r/'return332-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
fields=['name','checkpoint','rtt','replicate','unlockToEditorMs','unlockToAllVisibleMs','readUnitsToVisible','positionsFetchedToVisible','positionsFetchedAfterInstallToVisible','positionsFetchedAfterInstallThroughInputEnd','latePrefetchPositionsThroughInputEnd','snapshotCtBytes','snapshotJsonBytes','latestBodyBytes','inputP95Ms','installInputN','installInputP95Ms','coldExact','Undo','naturalHistoryRequired','actualCatalogReads']
with(r/'return332.csv').open('w',newline='')as f:
 w=csv.DictWriter(f,fieldnames=fields,lineterminator='\n');w.writeheader()
 for row in result:
  q={k:row.get(k)for k in fields};q.update(snapshotCtBytes=(row['snapshot']or{}).get('ciphertextBytes',0),snapshotJsonBytes=(row['snapshot']or{}).get('jsonBytes',0),inputP95Ms=row['inputWholeReturnMs']['p95'],installInputN=row['inputDuringInstallMs']['n'],installInputP95Ms=row['inputDuringInstallMs']['p95']);w.writerow(q)
for rtt in[0,50]:
 for cp in[False,True]:
  a=[x for x in result if x['rtt']==rtt and x['checkpoint']==cp];print(rtt,cp,'visible median',statistics.median(x['unlockToAllVisibleMs']for x in a),'install n',[x['inputDuringInstallMs']['n']for x in a],'input p95',[x['inputWholeReturnMs']['p95']for x in a],'read units',[x['readUnitsToVisible']for x in a],'positions after install',[x['positionsFetchedAfterInstallToVisible']for x in a])

from pathlib import Path
import json,math,csv,statistics
r=Path(__file__).parent
stages=['loadedReady332','loadedRetry332','loadedBlob332'];runs=[z for stage in stages for z in json.loads((r/(stage+'-results.json')).read_text())];out=[]
def stats(v):
 v=sorted(v);return {'n':len(v),'p50':v[math.ceil(.5*len(v))-1],'p95':v[math.ceil(.95*len(v))-1],'max':v[-1]}if v else {'n':0,'p50':None,'p95':None,'max':None}
for run in runs:
 x=json.loads((r/run['name']/'result.json').read_text());operations=[]
 for op in x['operations']:
  o=op.get('observation')
  if not o:continue
  lo=max(z['renderer']-z['after']-1 for z in o['clock']);hi=min(z['renderer']-z['before']+1 for z in o['clock']);assert lo<=hi
  ee=o['fault']['events'];command=op['command'];starts=[e for e in ee if e['kind']=='history-command-start330'and e['command']==command];a=starts[-1];b=next(e for e in ee if e['kind']=='history-command-end330'and e['command']==command and e['at']>=a['at']);s=next(e for e in ee if e['kind']=='history-storage-start330'and e['command']==command and e['at']>=a['at']);end=next(e for e in ee if e['kind']=='history-storage-end330'and e['command']==command and e['at']>=s['at']);vals=[];inside=[];missing=[]
  for i,key in enumerate(op['offers'],1):
   found=next((z['at']for z in o['probe']['counts']if z['at']>=key['at']-5 and z['count']>=i),None)
   if found is None:missing.append(i);continue
   value=found-key['at']-lo;vals.append(value)
   if s['at']<=key['at']+lo and key['at']+hi<=end['at']:inside.append(value)
  assert not missing,(run['name'],command,missing)
  operations.append({'device':op['device'],'command':command,'UICommandMs':op['finishedAt']-op['startedAt'],'nativeCommandMs':b['at']-a['at'],'nativeStorageTailMs':end['at']-s['at'],'beforeStorageMs':s['at']-a['at'],'offeredKeys':len(op['offers']),'inputAllMs':stats(vals),'inputDuringStorageMs':stats(inside),'trustedFocusedVisible':all(e['trusted']and e['focused']and e['visible']=='visible'for e in o['probe']['events']if e['kind']=='beforeinput'),'beforeInputEvents':sum(e['kind']=='beforeinput'for e in o['probe']['events']),'undoSteps':len(op.get('undoSteps',[])),'undoFullArchiveRestored':op.get('probeUndoRestoredFullArchive',False),'peerSawProbe':op.get('peerSawProbeBeforeUndo',False),'allObservedUndoArchivesExact':all(z['fullArchiveExact']for z in op.get('undoSteps',[])),'wholeProbeArchive':op.get('archive')})
 out.append({**run,'operations':operations,'cold':x.get('cold',[]),'guards':x.get('guards',{}),'primary':run['childExit']==0,'zipObservation':[{'device':z['device'],'nativeZIPs':len(z['evidence']['exports']),'downloadEvents':len(z['evidence']['downloads'])}for z in x.get('zipObservations',[])],'error':x.get('error'),'timingQualification':'Native storage/command wall intervals, not CPU samples. Input offered during native storage with conservative Page clock bounds; each event and every prior failed attempt retained. ZIP-data checks separate from natural download delivery.'})
(r/'loaded332-analysis.json').write_text(json.dumps(out,indent=2)+'\n')
rows=[]
for x in out:
 for o in x['operations']:rows.append({'name':x['name'],'primary':x['primary'],'rtt':x['rtt'],'replicate':x['replicate'],'device':o['device'],'command':o['command'],'UICommandMs':o['UICommandMs'],'nativeCommandMs':o['nativeCommandMs'],'nativeStorageTailMs':o['nativeStorageTailMs'],'beforeStorageMs':o['beforeStorageMs'],'offeredKeys':o['offeredKeys'],'storageInputN':o['inputDuringStorageMs']['n'],'storageInputP95Ms':o['inputDuringStorageMs']['p95'],'allInputP95Ms':o['inputAllMs']['p95'],'undoSteps':o['undoSteps'],'undoRestored':o['undoFullArchiveRestored'],'allUndoArchivesExact':o['allObservedUndoArchivesExact'],'coldBoth':len(x['cold'])==2 and all(z['archiveExact']and z['offlineEditUndoExact']for z in x['cold'])})
with(r/'loaded332.csv').open('w',newline='')as f:w=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows)
for rtt in[0,50]:
 for c in['create','verify']:
  a=[o for x in out if x['primary']and x['rtt']==rtt for o in x['operations']if o['command']==c];print(rtt,c,'UI median',statistics.median(o['UICommandMs']for o in a),'tail median',statistics.median(o['nativeStorageTailMs']for o in a),'input Ns',[o['inputDuringStorageMs']['n']for o in a],'input p95',[o['inputDuringStorageMs']['p95']for o in a])
print('all primary',sum(x['primary']for x in out),'prior failures',sum(not x['primary']for x in out));print('ZIP observation',[(x['name'],x['zipObservation'])for x in out if x['primary']])

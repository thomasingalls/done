# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: loadedRetry332.spec.ts >> native checkpoint creation on A and independent admission on C while each takes real Goals input
- Location: test/account-continuation-lab/phase330/loadedRetry332.spec.ts:3:1

# Error details

```
TimeoutError: page.waitForEvent: Timeout 20000ms exceeded while waiting for event "download"
=========================== logs ===========================
waiting for event "download"
============================================================
```

# Test source

```ts
  1  | import{openMenuSection}from'../geometry/openApp';
  2  | import{expect,type Page}from'@playwright/test';
  3  | import{readFileSync}from'node:fs';import{createHash}from'node:crypto';
  4  | export const root='/private/tmp/done-checkpoint-matched-lab-20261101';
  5  | export const sleep=(ms:number)=>new Promise(resolve=>setTimeout(resolve,ms));
  6  | export const digest=(b:string|Buffer)=>createHash('sha256').update(b).digest('hex');
  7  | export const card=(p:Page,label:string,second=false)=>p.locator('.day-panel[data-active="true"] .card').filter({hasText:`Fair ${label} ${second?'reverse':'target'}:`}).first();
  8  | export const edit=(p:Page)=>p.locator('.card[data-editing="true"] .cm-content');
  9  | export async function focus(p:Page,label:string,second=false){await card(p,label,second).locator('.card-surface').press('Enter');await edit(p).waitFor();await p.keyboard.press('ControlOrMeta+End');}
  10 | export async function lock(p:Page){await openMenuSection(p,'Account');await p.getByRole('button',{name:'Lock workspace',exact:true}).click();await expect(p.locator('.shell')).toHaveCount(0);}
  11 | export async function position(p:Page){await openMenuSection(p,'Sync');return Number((await p.getByText(/^Accepted position:/).innerText()).split(':').at(-1)!.trim());}
> 12 | export async function exported(p:Page){await openMenuSection(p,'Data');const wait=p.waitForEvent('download');await p.getByRole('button',{name:'Export markdown',exact:true}).click();const bytes=readFileSync((await(await wait).path())!),files:Record<string,string>={};let at=0;while(bytes.readUInt32LE(at)===0x04034b50){expect(bytes.readUInt16LE(at+8)).toBe(0);const size=bytes.readUInt32LE(at+18),n=bytes.readUInt16LE(at+26),extra=bytes.readUInt16LE(at+28),start=at+30+n+extra;files[bytes.toString('utf8',at+30,at+30+n)]=bytes.toString('utf8',start,start+size);at=start+size;}return files;}
     |                                                                                     ^ TimeoutError: page.waitForEvent: Timeout 20000ms exceeded while waiting for event "download"
  13 | export const archiveIdentity=(files:Record<string,string>)=>({sha256:digest(JSON.stringify(Object.entries(files).sort(([a],[b])=>a.localeCompare(b)))),files:Object.entries(files).map(([name,text])=>({name,bytes:Buffer.byteLength(text),characters:text.length}))});
  14 | export function installProbe(label:string){const now=()=>performance.timeOrigin+performance.now();const lengths:any[]=[],progress:any[]=[],events:any[]=[];let previous=-1,last='';const read=()=>{const c=[...document.querySelectorAll('.day-panel[data-active="true"] .card')].find(x=>x.textContent?.includes(`Fair ${label} target:`));const length=(c?.querySelector('.cm-content')??c?.querySelector('.card-surface'))?.textContent?.length??-1;if(length!==previous){previous=length;lengths.push({at:now(),length});}const status=document.querySelector('[aria-label="Sync status"]')?.textContent??'';const accepted=Number(/Accepted position:\s*(\d+)/.exec(status)?.[1]??-1),received=Number(/Received positions:\s*(\d+)/.exec(status)?.[1]??-1),stamp=accepted+':'+received;if(stamp!==last){last=stamp;progress.push({at:now(),accepted,received});}};new MutationObserver(read).observe(document,{subtree:true,childList:true,characterData:true});for(const kind of ['keydown','beforeinput'])addEventListener(kind,(e:Event)=>{if(!(e.target instanceof Element)||!e.target.closest('.card'))return;events.push({kind,at:now(),stampEpoch:performance.timeOrigin+e.timeStamp,trusted:e.isTrusted,focused:document.hasFocus(),visible:document.visibilityState});},true);Object.defineProperty(window,'__fairness',{value:{sample:read,read:()=>({lengths:structuredClone(lengths),progress:structuredClone(progress),events:structuredClone(events)})}});}
  15 | 
```
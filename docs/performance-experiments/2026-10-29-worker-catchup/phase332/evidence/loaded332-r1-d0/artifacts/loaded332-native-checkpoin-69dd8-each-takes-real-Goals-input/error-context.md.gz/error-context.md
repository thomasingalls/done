# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: loaded332.spec.ts >> native checkpoint creation on A and independent admission on C while each takes real Goals input
- Location: test/account-continuation-lab/phase330/loaded332.spec.ts:3:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

# Test source

```ts
  1  | import {test} from '@playwright/test';
  2  | import {out,fixture,account,now,start,control,resourceStop,expect,mkdirSync,cpSync,writeFileSync,join,actor330,unlock330,inspect330,goals330,keys330,exact330,snapshot330,cold330,close330,exported} from './common330';
  3  | test('native checkpoint creation on A and independent admission on C while each takes real Goals input',async()=>{
  4  |  mkdirSync(out,{recursive:true});const result:any={outcome:'starting',labOnly:true,acceptanceCredit:false,guards:{},operations:[],roots:[],network:[]},contexts:any[]=[];let A:any,C:any;const save=()=>writeFileSync(join(out,'partial-result.json'),JSON.stringify(result,null,2)+'\n');
  5  |  try{
  6  |   expect(account.backlog).toBe(1024);expect(account.date).toBe(new Date().toISOString().slice(0,10));const state=join(out,'state');cpSync(fixture.state,state,{recursive:true,errorOnExist:true});await start(state,process.env['FAIR_DIST']!);await control('start');A=await actor330(0,'A',result,contexts);C=await actor330(2,'C',result,contexts);await unlock330(A,result);await exact330(A,account.archive);await A.ctx.setOffline(false);await unlock330(C,result);result.cCatchupStartedAt=now();await C.ctx.setOffline(false);await expect.poll(()=>exported(C.p),{timeout:600000}).toEqual(account.archive);result.cCatchupFinishedAt=now();await exact330(C,account.archive);
  7  |   for(const [a,command,button,doneText]of [[A,'create','Create history snapshot','Snapshot saved. Verify it from another approved device.'],[C,'verify','Verify history snapshot','Verified snapshot 1 is saved.']]as any){
  8  |    const panel=await inspect330(a);await expect(panel.getByRole('button',{name:button,exact:true})).toBeVisible();const op:any={device:a.label,command,offers:[],startedAt:now()};result.operations.push(op);await panel.getByRole('button',{name:button,exact:true}).click();let finished=false,error:unknown;const done=Promise.race([expect(panel).toContainText(doneText,{timeout:600000}),panel.getByRole('alert').waitFor({state:'visible',timeout:600000}).then(async()=>{throw Error('Application history refusal: '+await panel.getByRole('alert').textContent())}),a.p.locator('.shell').waitFor({state:'hidden',timeout:600000}).then(()=>{throw Error('Application owner closed during history operation')})]).then(()=>{op.finishedAt=now();finished=true;},cause=>{error=cause;finished=true;});const prefix='\n Measurement330-'+a.label+': ';await goals330(a,prefix);op.typingStartedAt=now();await keys330(a,op.offers,4000,()=>!finished);op.typingFinishedAt=now();await done;if(error)throw error;await a.p.keyboard.press('Escape');const expected={...account.archive,'master.md':account.archive['master.md']+prefix+'x'.repeat(op.offers.length)};op.archive=await exact330(a,expected);op.observation=await snapshot330(a);save();for(const peer of[A,C])if(peer!==a)await expect.poll(()=>exported(peer.p),{timeout:60000}).toEqual(expected);op.peerSawProbeBeforeUndo=true;
  9  |    // Undo groups only after the observation window; no probe text is silently accepted as baseline.
> 10 |    await a.p.waitForTimeout(750);let restored=false;for(let i=0;i<8;i++){await a.p.locator('.goals .cm-content').click();await a.p.keyboard.press('ControlOrMeta+z');await a.p.keyboard.press('Escape');const archive=await exported(a.p);if(JSON.stringify(archive)===JSON.stringify(account.archive)){restored=true;break;}}expect(restored).toBe(true);op.probeUndoRestoredFullArchive=true;
     |                                                                                                                                                                                                                                                                                                                                                ^ Error: expect(received).toBe(expected) // Object.is equality
  11 |    // Both owners must converge to the exact original before the next command.
  12 |    for(const peer of[A,C])await expect.poll(()=>exported(peer.p),{timeout:60000}).toEqual(account.archive);op.convergedAfterUndoAt=now();save();
  13 |   }
  14 |   result.beforeCold=await Promise.all([A,C].map(a=>snapshot330(a)));for(const a of[A,C])await cold330(a,account.archive,result,contexts);result.guards.bothOfflineColdAndUndoExact=true;expect(resourceStop).toBeFalsy();result.metrics=(await control('end')as any).metrics;result.outcome='passed';
  15 |  }catch(error){result.outcome='failed';result.error=String(error);throw error;}finally{for(const [name,a]of[['A',A],['C',C]]as any){if(a)try{(result.final??={})[name]=await snapshot330(a);}catch{}}await close330(contexts);writeFileSync(join(out,'result.json'),JSON.stringify(result,null,2)+'\n');}
  16 | });
  17 | 
```
from pathlib import Path
import json
r=Path(__file__).parent;out=[]
for name in ['01-before','02-after','03-after','04-before']:
 x=json.loads((r/name/'result.json').read_text());clocks=[v for g in x['clocks']for v in g['rows'][0]];low=max(v['renderer']-v['after']-1 for v in clocks);readers={v['readerSha256']for q in x['network']if q['label']=='H2'for v in q.get('reads',[])};m=next(q for q in x['offers']if q['kind']=='marker'and q['index']==2);t=m['at'];visible=x['probes'][0]['markers'][2]-low;rows=[]
 for q in x['network']:
  if t-250<=q['at']<=visible+250:
   if q['label']=='H2'and'submit'in q['path']or q['label']=='H1':
    rows.append({'client':q['label'],'path':q['path'],'atMs':round(q['at']-t,3),'headersMs':round(q['headersAt']-t,3)if q.get('headersAt')else None,'status':q.get('status'),'writerReads':[{'after':v['after'],'limit':v['limit'],'self':v['self']}for v in q.get('reads',[])if v['publisherSha256']in readers]})
 row={'case':name,'markerAt':t,'peerVisibleMs':visible-t,'writerReaderHashes':sorted(readers),'network':rows};out.append(row);print(json.dumps(row,indent=2))
(r/'coarse-marker.json').write_text(json.dumps(out,indent=2)+'\n')

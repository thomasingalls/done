from pathlib import Path
import json,hashlib,difflib
r=Path(__file__).parent;src=r/'source-marker';base=r/'source-after';sha=lambda b:hashlib.sha256(b).hexdigest();edits=json.loads((r/'marker-edits.json').read_text());changed={e['file']for e in edits};assert changed=={'src/crdt/accountSyncDriver.ts','src/crdt/accountReceive.ts','src/crdt/receiveSelection.ts'}
inputs=json.loads((r/'after-source-inputs.json').read_text())['files'];patch=[]
for name,digest in inputs.items():
 b=(base/name).read_bytes();assert sha(b)==digest,name;s=(src/name).read_text()if name in changed else None
 if name in changed:
  for e in reversed(edits):
   if e['file']==name:
    assert s.count(e['new'])==1,(name,e['new']);s=s.replace(e['new'],e['old'])
  assert s.startswith("import { markerTrace } from './markerTrace';\n");s=s.split('\n',1)[1];assert s.encode()==b,name
  patch.extend(difflib.unified_diff(b.decode().splitlines(True),(src/name).read_text().splitlines(True),fromfile='a/'+name,tofile='b/'+name))
 else:assert(src/name).read_bytes()==b,name
helper='src/crdt/markerTrace.ts';patch.extend(difflib.unified_diff([],(src/helper).read_text().splitlines(True),fromfile='/dev/null',tofile='b/'+helper));(r/'marker-source.patch').write_text(''.join(patch))
matched=set()
for f in(r/'marker-dist').rglob('*.map'):
 m=json.loads(f.read_text())
 for path,body in zip(m['sources'],m.get('sourcesContent',[])):
  key=next((prefix+'/'+path.split('/'+prefix+'/',1)[1]for prefix in ['src','account-protocol','private','wasm']if'/'+prefix+'/'in path),None)
  if key and(src/key).is_file():assert body.encode()==(src/key).read_bytes(),key;matched.add(key)
assert changed|{helper}<=matched
h=r/'harness/test/account-continuation-lab';a=(h/'late.spec.ts').read_text();b=(h/'marker.spec.ts').read_text();prefix='result.ownerEvents=';start=b.index(prefix);end=b.index("result.clocks.push({phase:'after',rows:",start);assert b[:start]+b[end:]==a
rows={'baseSourceInputs':len(inputs),'changedFiles':sorted(changed),'addedTraceHelper':helper,'reverseEditsExact':True,'onlyHarnessChange':'collect numeric owner trace before same clock brackets; workload/assertions/deadlines exact','mapBodies':len(matched),'sourcePatchSha256':sha((r/'marker-source.patch').read_bytes()),'fixtureSha256':sha((r/'private-fixture/fixture.json').read_bytes()),'browserSha256':sha(Path('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome').read_bytes()),'traceBound':40000,'diagnosticOnly':True,'setupFailures':'Two exact-replacement guards stopped preparation before any build/journey: wake anchor included nonexistent publish; return publisher matched inner pick too. Incomplete copies retained. Final reverse QA exact.'}
(r/'marker-qa.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))

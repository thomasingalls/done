from pathlib import Path
import shutil,subprocess,json,hashlib,os,time
r=Path(__file__).parent;src=r/'source-marker';assert not src.exists();shutil.copytree(r/'source-after',src,symlinks=True)
changes=[]
def edit(name,old,new):
 p=src/name;s=p.read_text();assert s.count(old)==1,(name,old,s.count(old));p.write_text(s.replace(old,new));changes.append({'file':name,'old':old,'new':new})
helper="""/** Disposable phase243 trace: numeric scheduling metadata only, no account values. */
type Row = { at: number; tag: string; values: (number | string)[] };
const state = { rows: [] as Row[], dropped: 0 };
(globalThis as typeof globalThis & { __ownerTrace?: typeof state }).__ownerTrace = state;
export const markerTrace = (tag: string, values: (number | string)[] = []) => {
  if (state.rows.length >= 40000) { state.dropped++; return; }
  state.rows.push({ at: performance.timeOrigin + performance.now(), tag, values });
};
"""
(src/'src/crdt/markerTrace.ts').write_text(helper)
for name in ['accountSyncDriver.ts','accountReceive.ts','receiveSelection.ts']:
 p=src/'src/crdt'/name;p.write_text("import { markerTrace } from './markerTrace';\n"+p.read_text())
edit('src/crdt/accountSyncDriver.ts','    active = name;','    markerTrace("begin", [name, laneDue(name), batch?.due ?? -1]);\n    active = name;')
# Separate safe metadata helper, no new authority or scheduling call.
edit('src/crdt/accountSyncDriver.ts',"  const begin = () => {","  const laneDue = (name: SyncLane) => lanes[name].due ?? -1;\n  const begin = () => {")
edit('src/crdt/accountSyncDriver.ts','        if (stopped) return;\n        const position =','        markerTrace("result", [name, result.kind]);\n        if (stopped) return;\n        const position =')
edit('src/crdt/accountSyncDriver.ts','        active = undefined;\n        work = undefined;','        markerTrace("end", [active ?? "none"]);\n        active = undefined;\n        work = undefined;')
edit('src/crdt/accountSyncDriver.ts',"    arm();\n  };\n  options.signal", "    markerTrace('wake', [cause, active ?? 'none', batch?.due ?? -1, lanes.send.due ?? -1]);\n    arm();\n  };\n  options.signal")
edit('src/crdt/accountSyncDriver.ts','  let status = await ops.deliveryStatus();','  markerTrace("send-status-start");\n  let status = await ops.deliveryStatus();\n  markerTrace("send-status-end");')
edit('src/crdt/accountSyncDriver.ts','    const spool = await ops.spoolStatus();','    markerTrace("spool-start");\n    const spool = await ops.spoolStatus();\n    markerTrace("spool-end");')
edit('src/crdt/accountSyncDriver.ts','      const due = beforeNewEnvelope?.();','      const due = beforeNewEnvelope?.();\n      markerTrace("envelope-gate", [due ?? -1]);')
edit('src/crdt/accountSyncDriver.ts','      const prepared = await ops.prepareNextEnvelope();','      markerTrace("envelope-start");\n      const prepared = await ops.prepareNextEnvelope();\n      markerTrace("envelope-end");')
edit('src/crdt/accountSyncDriver.ts','    const submission = await ops.prepareSubmission(position);','    markerTrace("submission-start");\n    const submission = await ops.prepareSubmission(position);\n    markerTrace("submission-end");')
edit('src/crdt/accountSyncDriver.ts','  await ops.submitPending(token);','  markerTrace("submit-start");\n  await ops.submitPending(token);\n  markerTrace("submit-end");')
edit('src/crdt/receiveSelection.ts','      return publisher;','      markerTrace("pick", [publishers.indexOf(publisher), quiet.size, own?.peerBacklog ? 1 : 0]);\n      return publisher;')
edit('src/crdt/receiveSelection.ts','      const index = publishers.indexOf(publisher);','      const index = publishers.indexOf(publisher);\n      markerTrace("picked-complete", [index, progress ? 1 : 0]);')
edit('src/crdt/accountReceive.ts','    const { inbound: all, pendingSelf } = await readState(task, owner, (v) => ({','    markerTrace("read-state-start");\n    const { inbound: all, pendingSelf } = await readState(task, owner, (v) => ({')
edit('src/crdt/accountReceive.ts','    const publishers = base.history?.readers.map((r) => r.id) ?? [base.publisher.id];','    markerTrace("read-state-end");\n    const publishers = base.history?.readers.map((r) => r.id) ?? [base.publisher.id];')
edit('src/crdt/accountReceive.ts','    const s = publisherState(all, base, publisher),','    markerTrace("read-picked", [publishers.indexOf(publisher), publishers.length]);\n    const s = publisherState(all, base, publisher),')
edit('src/crdt/accountReceive.ts','        return outstanding.slice();','        markerTrace("read-prepared", [requests.length]);\n        return outstanding.slice();')
edit('src/crdt/accountReceive.ts','        const { request, page, requests, pages, oversized, quiet } = await fetchPage(operatorToken);','        markerTrace("receive-next");\n        const { request, page, requests, pages, oversized, quiet } = await fetchPage(operatorToken);\n        markerTrace("receive-fetched", [pages.length]);')
edit('src/crdt/accountReceive.ts',"          const authority = await refreshAuthority(operatorToken ?? '');","          markerTrace('authority-start');\n          const authority = await refreshAuthority(operatorToken ?? '');\n          markerTrace('authority-end', [authority.kind]);")
edit('src/crdt/accountReceive.ts','            if (await receiveHistory()) {','            markerTrace("history-start");\n            if (await receiveHistory()) {')
edit('src/crdt/accountReceive.ts','          for (let remaining = publisherCount(); ; remaining--) {','          markerTrace("history-end");\n          for (let remaining = publisherCount(); ; remaining--) {')
edit('src/crdt/accountReceive.ts',"            const step = await driveReceiveStep(result, operatorToken ?? '', gate);","            markerTrace('receive-step-start', [remaining]);\n            const step = await driveReceiveStep(result, operatorToken ?? '', gate);\n            markerTrace('receive-step-end', [remaining, step.kind]);")
edit('src/crdt/accountReceive.ts',"            wake: (event) => {\n              if (event !== 'content')", "            wake: (event) => {\n              markerTrace('notification', [event]);\n              if (event !== 'content')")
(r/'marker-edits.json').write_text(json.dumps(changes,indent=2)+'\n')
(r/'marker-helper.ts').write_text(helper)
# Disposable harness adds collection only, never changes workload/assertions/deadlines.
h=r/'harness/test/account-continuation-lab';original=(h/'late.spec.ts').read_text();anchor="result.clocks.push({phase:'after',rows:";assert original.count(anchor)==1
addition="result.ownerEvents=await Promise.all([reader,writer].map(async a=>({label:'H'+a.index,realms:[await a.p.evaluate(()=>structuredClone((window as any).__ownerTrace??{rows:[],dropped:0})),...await Promise.all(a.p.workers().map(w=>w.evaluate(()=>structuredClone((self as any).__ownerTrace??{rows:[],dropped:0}))))]})));"
(h/'marker.spec.ts').write_text(original.replace(anchor,addition+anchor));(h/'marker.config.ts').write_text((h/'late.config.ts').read_text().replace('late.spec.ts','marker.spec.ts'))
node='/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node';env={**os.environ,**json.loads((r/'build-flags.json').read_text()),'PATH':str(Path(node).parent)+':'+os.environ['PATH'],'APP_BUILD_REVISION':'0ab9cbc8937e32c6542aaeeca697c87ba116c3be','APP_BUILD_DATE':'2026-10-29'};cmd=[node,str(src/'node_modules/vite/bin/vite.js'),'build','--outDir',str(r/'marker-dist'),'--emptyOutDir','--sourcemap'];start=time.time_ns()//1000000
with(r/'marker-build.log').open('w')as f:p=subprocess.run(cmd,cwd=src,env=env,stdout=f,stderr=subprocess.STDOUT)
assert p.returncode==0,p.returncode
sha=lambda b:hashlib.sha256(b).hexdigest();assets={str(f.relative_to(r/'marker-dist')):sha(f.read_bytes())for f in(r/'marker-dist').rglob('*')if f.is_file()};(r/'marker-assets.json').write_text(json.dumps(assets,indent=2)+'\n');(r/'marker-build-receipt.json').write_text(json.dumps({'baseCommit':'0ab9cbc8937e32c6542aaeeca697c87ba116c3be','command':cmd,'startedAt':start,'finishedAt':time.time_ns()//1000000,'exit':p.returncode,'assets':len(assets)},indent=2)+'\n');print('Diagnostic build complete',len(assets))

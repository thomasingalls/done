/** Disposable phase243 trace: numeric scheduling metadata only, no account values. */
type Row = { at: number; tag: string; values: (number | string)[] };
const state = { rows: [] as Row[], dropped: 0 };
(globalThis as typeof globalThis & { __ownerTrace?: typeof state }).__ownerTrace = state;
export const markerTrace = (tag: string, values: (number | string)[] = []) => {
  if (state.rows.length >= 40000) { state.dropped++; return; }
  state.rows.push({ at: performance.timeOrigin + performance.now(), tag, values });
};

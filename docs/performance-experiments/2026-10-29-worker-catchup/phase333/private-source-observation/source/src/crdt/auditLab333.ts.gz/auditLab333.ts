// Disposable lab-only scheduling and observation. No retained proof or payload cache.
export const auditIdle333 = (()=>{try{return new URL(location.href).searchParams.get('labAuditIdle')==='1';}catch{return false;}})();
const rows:Record<string,unknown>[]=[];let overflow=0,serial=0;
export function auditLog333(v:Record<string,unknown>){if(!auditIdle333)return;if(rows.length<131072)rows.push({at:performance.timeOrigin+performance.now(),...v});else overflow++;}
export const auditId333=()=>++serial;
export function auditDelay333(now:number,last:number,pending:number,added:number){if(added>=1024)return 0;return Math.max(0,1000-(now-last),pending>0?50:0);}
if(auditIdle333)(globalThis as any).__auditLab333={read:()=>({enabled:true,overflow,rows:rows.slice()})};

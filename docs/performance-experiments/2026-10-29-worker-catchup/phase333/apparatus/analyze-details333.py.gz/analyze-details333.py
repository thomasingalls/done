from pathlib import Path
import json,csv,collections,math,statistics
r=Path(__file__).parent

def stats(v):
 s=sorted(v);return {'n':len(s),'p50':s[math.ceil(len(s)*.5)-1],'p95':s[math.ceil(len(s)*.95)-1],'max':s[-1]}if s else None

def writecsv(name,rows):
 keys=list(dict.fromkeys(k for z in rows for k in z))
 with(r/name).open('w',newline='')as f:
  w=csv.DictWriter(f,fieldnames=keys,lineterminator='\n');w.writeheader()
  for z in rows:w.writerow({k:json.dumps(v,separators=(',',':'))if isinstance(v,(list,dict))else v for k,v in z.items()})

runs=[]
for n in ['pairedFirstRetry333-results.json','pairedRest333-results.json']:runs+=json.loads((r/n).read_text())
audits=[];slices=[];turns=[];jobsout=[];owners=[];allmarkers=[]
lat=json.loads((r/'paired333-analysis.json').read_text())
for run in runs:
 x=json.loads((r/run['name']/'result.json').read_text());start=x['typingStartedAt'];last=x['typingFinishedAt'];visible=x['newDeliveryAt']
 base={k:run[k]for k in ['name','policy','replicate','rtt']}
 for d in next(a for a in lat if a['name']==run['name'])['directions']:
  for i,v in enumerate(d['markerLatency']['peer']):allmarkers.append({**base,'stream':d['stream'],'toDevice':2 if d['stream']==0 else 1,'marker':i,'peerMs':v,'pass2500':v is not None and v<=2500})
 for f in x['audit333Files']:
  actor=f['actor'];v=json.loads((r/run['name']/f['file']).read_text());ev=v['rows'];assert v['overflow']==0
  b={**base,'actor':actor};starts={z['id']:z for z in ev if z['kind']=='semanticAuditStart'};ends={z['id']:z for z in ev if z['kind']=='semanticAuditEnd'}
  comp=[z for z in ev if z['kind']=='semanticCompare']
  for aid,z in starts.items():
   end=ends.get(aid);cs=[q for q in comp if z['at']<=q['at']<=(end or{'at':math.inf})['at']]
   audits.append({**b,'id':aid,'start':z['at'],'end':end.get('at')if end else None,'ms':end['at']-z['at']if end else None,'startRows':z['rows'],'compareRows':[q['rows']for q in cs],'added':z.get('added'),'startedDuringTyping':start<=z['at']<=last,'startAfterLastKeyMs':z['at']-last,'outcome':end.get('outcome')if end else'open'})
  ss={z['id']:z for z in ev if z['kind']=='auditSliceStart'};se={z['id']:z for z in ev if z['kind']=='auditSliceEnd'}
  for sid,z in ss.items():
   end=se.get(sid);slices.append({**b,**z,'end':end.get('at')if end else None,'ms':end['at']-z['at']if end else None,'duringTyping':start<=z['at']<=last,'outcome':end.get('outcome')if end else'open'})
  js={z['id']:z for z in ev if z['kind']=='jobStart'};je={z['id']:z for z in ev if z['kind']=='jobEnd'}
  jsrows=[]
  for z in ev:
   if z['kind']!='jobQueued':continue
   st=js.get(z['id']);en=je.get(z['id']);a={**b,**z,'start':st.get('at')if st else None,'end':en.get('at')if en else None,'queueWaitMs':st.get('queueWaitMs')if st else None,'operationMs':en['at']-st['at']if st and en else None};jobsout.append(a);jsrows.append(a)
  ts={z['id']:z for z in ev if z['kind']=='readTurnStart'};tf={z['id']:z for z in ev if z['kind']=='readTurnFetch'};te={z['id']:z for z in ev if z['kind']=='readTurnEnd'};commits=[z for z in ev if z['kind']=='inboundCommit']
  for tid,z in ts.items():
   en=te.get(tid);fe=tf.get(tid);end=(en or{'at':math.inf})['at'];cs=[q for q in commits if z['at']<=q['at']<=end];jq=[q for q in jsrows if z['at']<=q['at']<=end];rq=[q for q in jq if q['name'].startswith('accountReceive.ts:')or q['name'].startswith('receive')]
   ad=[a for a in audits if a['name']==run['name']and a['actor']==actor and a['start']<end and(a['end']or math.inf)>z['at']]
   turns.append({**b,'id':tid,'start':z['at'],'end':en.get('at')if en else None,'ms':end-z['at']if en else None,'inMeasurement':start<=z['at']<=visible,'duringTyping':start<=z['at']<=last,'quiet':fe.get('quiet')if fe else None,'requests':fe.get('requests')if fe else None,'outcome':en.get('outcome')if en else'open','committedPositions':sum(q['positions']for q in cs),'commitSizes':[{'positions':q['positions'],'physicalRows':q['physicalRows'],'physicalReceipts':q['physicalReceipts']}for q in cs],'queuedWithinTurn':[{k:q[k]for k in ['id','name','queueWaitMs','preparation','audit']}for q in jq],'readTaggedQueueWaitMs':sum(q['queueWaitMs']or 0 for q in rq),'readTaggedJobs':len(rq),'semanticAuditOverlap':len(ad),'queueAttribution':'read-tagged jobs queued inside this turn; other concurrent queued jobs listed separately; not every overlapping job is caused by read'})
  maint=next(z for z in x['maintenanceOutcomes']if z['actor']==actor);diag=maint['value']['diagnostics'];cold=next(z for z in x['cold']if z['actor']==actor)
  owners.append({**b,'overflow':v['overflow'],'semanticAudits':sum(a['name']==run['name']and a['actor']==actor for a in audits),'semanticDuringTyping':sum(a['name']==run['name']and a['actor']==actor and a['startedDuringTyping']for a in audits),'slicesDuringTyping':sum(start<=z['at']<=last for z in ss.values()),'hardCapSlices':sum(bool(z.get('hardCap'))for z in ss.values()),'hardCapSlicesDuringTyping':sum(bool(z.get('hardCap'))and start<=z['at']<=last for z in ss.values()),'deferredDuringTyping':sum(z['kind']=='auditDeferred'and start<=z['at']<=last for z in ev),'maintenanceAttempts':diag['attempts'],'maintenanceInterruptions':diag['interruptions'],'maintenanceCompletions':diag['completions'],'maintenanceObservedAfterLastKeyMs':maint['observedAt']-last,'coldArchiveExact':cold['archiveExact'],'coldOfflineEditUndoExact':cold['offlineEditUndoExact']})
writecsv('audit333-semantic.csv',audits);writecsv('audit333-slices.csv',slices);writecsv('read333-turns.csv',turns);writecsv('storage333-jobs.csv',jobsout);writecsv('owners333.csv',owners);writecsv('markers333.csv',allmarkers)
summary={'runs':len(runs),'owners':owners,'semanticAudits':audits,'readTurns':len(turns),'measurementReadTurns':sum(z['inMeasurement']for z in turns),'readQueueWaitByPolicy':{p:stats([z['readTaggedQueueWaitMs']for z in turns if z['inMeasurement']and z['policy']==p])for p in set(z['policy']for z in turns)},'allObservedColdExact':all(z['coldArchiveExact']and z['coldOfflineEditUndoExact']for z in owners),'allBuffersExact':all(z['overflow']==0 for z in owners),'markerPredicates':[z for z in allmarkers if not z['pass2500']],'latencyMissDoesNotStop':True,'acceptanceCredit':False,'limitations':['no contemporaneous baseline; compare frozen329 with added local observation overhead','the1.422s old reference miss is outside these two policies','physical cap scheduling unit controls are not evidence of uninterrupted audit completion under infinite input','queuedWithinTurn is temporal attribution; readTaggedQueueWaitMs includes only named read jobs']};(r/'details333-analysis.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items()if k not in ['owners','semanticAudits','markerPredicates']},indent=2))

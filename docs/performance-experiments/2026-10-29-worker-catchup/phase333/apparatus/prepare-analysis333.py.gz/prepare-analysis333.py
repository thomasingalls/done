from pathlib import Path
r=Path(__file__).parent;old=Path('/private/tmp/done-retained-scope-lab-20261101');t=(old/'analyze-paired329.py').read_text().replace("['pairedFirst329-results.json','pairedRest329-results.json']","['pairedFirstRetry333-results.json','pairedRest333-results.json']").replace('329','333');(r/'analyze-paired333.py').write_text(t)

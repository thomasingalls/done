from pathlib import Path
import subprocess,os,shutil
r=Path(__file__).parent;b=r/'build'
for policy in ['coordinated-2000','immediate-inflight']:
 with(r/('build-'+policy+'.log')).open('w')as f:p=subprocess.run(['python3',str(b/'build-lab.py')],cwd=b,env={**os.environ,'LAB_BATCH_POLICY':policy},stdout=f,stderr=subprocess.STDOUT)
 if p.returncode:raise SystemExit(p.returncode)
 d=r/policy;d.mkdir();shutil.move(str(b/'combined-dist'),d/'combined-dist')
 for n in ['build-identity.json','build-flags.json','frontend-build.log','lab-build.log']:shutil.copy2(b/n,d/n)
 print('Built',policy,flush=True)

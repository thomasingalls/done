from pathlib import Path
import json,statistics
r=Path(__file__).parent;before=json.loads(Path('/private/tmp/done-retained-scope-lab-20261101/paired329-analysis.json').read_text());after=json.loads((r/'paired333-analysis.json').read_text());out=[]
for policy in ['coordinated-2000','immediate-inflight']:
 for rtt in [0,50]:
  for stream in [0,1]:
   a=[x for x in before if x['policy']==policy and x['rtt']==rtt];b=[x for x in after if x['policy']==policy and x['rtt']==rtt];assert len(a)==len(b)==3
   def facts(xs):
    rows=[x['directions'][stream]for x in xs];return{'peerP50':[d['latency']['peer']['p50']for d in rows],'peerP95':[d['latency']['peer']['p95']for d in rows],'inputP95':[d['latency']['local']['p95']for d in rows],'positions100':[d['positionsPer100Keys']for d in rows],'anyPeerP50In12000To15000':any(12000<=d['latency']['peer']['p50']<=15000 for d in rows),'anyPeerP95AtLeast12000':any(d['latency']['peer']['p95']>=12000 for d in rows),'anyInputP95AtLeast1422':any(d['latency']['local']['p95']>=1422 for d in rows),'anyInputP95Over16':any(d['latency']['local']['p95']>16 for d in rows)}
   out.append({'policy':policy,'rtt':rtt,'stream':stream,'before':facts(a),'after':facts(b),'qualification':'descriptive frozen329 contrast, not contemporaneous matched instrumentation; no credit'})
(r/'contrast333.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))

const auditIdle=process.env.FAIR_AUDIT_IDLE==='1';
const pp=process.env.FAIR_PP==='1';
const bits=process.env.FAIR_LAB_BITS??'0000',hidden=process.env.FAIR_PREP_HIDDEN==='1',idlePause=process.env.FAIR_IDLE_PAUSE==='1',sy=process.env.FAIR_SY_BITS??'00',repairMs=process.env.FAIR_REPAIR_MS??'1500',eb=process.env.FAIR_EB??'00',quietOff=process.env.FAIR_QUIET_OFF==='1';
const configured = new WeakSet();
export const configureLabContext=async(ctx,offline=false)=>{
 if(configured.has(ctx))return ctx;configured.add(ctx);
 await ctx.addInitScript(({bits,hidden,offline,idlePause,sy,repairMs,eb,quietOff,pp,auditIdle})=>{
  sessionStorage.setItem('done.lab.fault327','1');sessionStorage.setItem('done.lab.pp',pp?'1':'0');sessionStorage.setItem('done.lab.quietOff',quietOff?'1':'0');sessionStorage.setItem('done.lab.eb',eb);sessionStorage.setItem('done.lab.bits',bits);sessionStorage.setItem('done.lab.sy',sy);sessionStorage.setItem('done.lab.idlePause',idlePause?'1':'0');
  if(hidden)Object.defineProperty(document,'visibilityState',{configurable:true,get:()=> 'hidden'});
  globalThis.__fault327External={workers:[]};
  const Original=Worker;globalThis.Worker=class extends Original{constructor(url,options){const u=new URL(url,location.href);u.searchParams.set('labAuditIdle',auditIdle?'1':'0');u.searchParams.set('labFault327','1');u.searchParams.set('labPP',pp?'1':'0');if(quietOff)u.searchParams.set('labQuietOff','1');u.searchParams.set('labEB',eb);u.searchParams.set('lab',bits);u.searchParams.set('labSY',sy);u.searchParams.set('labRepairMs',repairMs);if(idlePause)u.searchParams.set('labIdlePause','1');u.searchParams.sort();super(u,options);const trace={id:globalThis.__fault327External.workers.length+1,url:u.href,batches:0,lastBatch:0,gaps:0,received:0,workerDropped:0,tail:[],critical:[]};globalThis.__fault327External.workers.push(trace);this.addEventListener('message',e=>{const m=e.data;if(m?.__doneFault327===1&&Array.isArray(m.events)){if(m.batch!==trace.lastBatch+1)trace.gaps++;trace.lastBatch=m.batch;trace.batches++;trace.workerDropped=m.dropped;for(const event of m.events){trace.tail[trace.received%8192]=event;trace.received++;if(event.faultCritical&&trace.critical.length<32768)trace.critical.push(event);}}if(e.data?.kind==='rangeLabMaintenance'){const v=e.data.value;globalThis.__maintenanceRead=()=>structuredClone(v);globalThis.__maintenanceOwner={devices:{automaticHistory:v.serviceAutomationPortPresent?{available:true}:undefined}};}})}};
  globalThis.__rangeLabCacheReady=offline?Promise.resolve():navigator.serviceWorker.ready.then(async()=>{
   let count=0;for(const key of await caches.keys()){
    const cache=await caches.open(key);for(const request of await cache.keys()){
     const u=new URL(request.url);if(!/\.worker-[^/]+\.js$/.test(u.pathname)||u.search)continue;
     u.searchParams.set('labAuditIdle',auditIdle?'1':'0');u.searchParams.set('labFault327','1');u.searchParams.set('labPP',pp?'1':'0');if(quietOff)u.searchParams.set('labQuietOff','1');u.searchParams.set('labEB',eb);u.searchParams.set('lab',bits);u.searchParams.set('labSY',sy);u.searchParams.set('labRepairMs',repairMs);if(idlePause)u.searchParams.set('labIdlePause','1');u.searchParams.sort();if(await cache.match(u.href))continue;
     const original=await cache.match(request);if(original){await cache.put(u.href,new Response(await original.arrayBuffer(),{status:original.status,statusText:original.statusText,headers:original.headers}));count++;}
    }
   }globalThis.__rangeLabCacheAliases=count;
  });
 },{bits,hidden,offline,idlePause,sy,repairMs,eb,quietOff,pp,auditIdle});
 const set=ctx.setOffline.bind(ctx);ctx.setOffline=async value=>{if(value&&!offline){for(const page of ctx.pages())if(!page.isClosed())await page.evaluate(async()=>await globalThis.__rangeLabCacheReady);}return set(value)};return ctx;
};

from pathlib import Path
import json,hashlib,subprocess,gzip,collections
r=Path(__file__).parent;repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');sha=lambda b:hashlib.sha256(b).hexdigest();inp=json.loads((r/'inputs334.json').read_text());links=[]
indices=[]
for phase in[329,333]:
 d=repo/f'docs/performance-experiments/2026-10-29-worker-catchup/phase{phase}';idx=json.loads((d/'evidence-index.json').read_text());indices +=[(d,z)for z in idx['items']]
for row in inp['inputs']:
 p=Path(row['path']);assert sha(p.read_bytes())==row['sha256'];matches=[(d,z)for d,z in indices if z['source']==str(p)];assert len(matches)==1,(str(p),len(matches));d,z=matches[0];assert z['rawSha256']==row['sha256'];gz=d/z['copy'];assert sha(gz.read_bytes())==z['gzipSha256'];assert sha(gzip.decompress(gz.read_bytes()))==row['sha256'];links.append({**row,'existingHome':str(gz.relative_to(repo)),'gzipSha256':z['gzipSha256']})
for row in inp['source']:assert sha(Path(row['path']).read_bytes())==row['sha256']
# Separate raw-native accounting; does not import or consume the derived timing tables.
root=Path('/private/tmp/done-idle-warm-audit-lab-20261101');runs=json.loads((root/'paired333-analysis.json').read_text());checks=[]
for run in runs:
 x=json.loads((root/run['name']/'result.json').read_text());start=x['typingStartedAt'];end=x['newDeliveryAt'];row={'name':run['name'],'owners':[]};assert x['guards']['bothOfflineColdProfilesExact']and x['guards']['fullArchivePlusBothOfferedStreams']
 for owner in[1,2]:
  f=next(z['file']for z in x['audit333Files']if z['actor']==owner);raw=json.loads((root/run['name']/f).read_text());ev=raw['rows'];assert raw['overflow']==0;own=x['serverBefore'][owner-1]['publisherSha256'];peer=x['serverBefore'][2-owner]['publisherSha256'];starts={z['id']:z for z in ev if z['kind']=='readTurnStart'};ends={z['id']:z for z in ev if z['kind']=='readTurnEnd'};fetches={z['id']:z for z in ev if z['kind']=='readTurnFetch'};cs=[z for z in ev if z['kind']=='inboundCommit'];peerRows=[];readIntervals=[]
  for i,z in starts.items():
   if i not in ends or i not in fetches:continue
   stop=ends[i]['at'];assert stop>=z['at'];readIntervals.append((z['at'],stop));fe=fetches[i];req=fe['requests'][0]if fe['requests']else None
   if req and hashlib.sha256(req['publisher'].encode()).hexdigest()==peer and start<=z['at']<=end:
    credit=sum(c['positions']for c in cs if z['at']<=c['at']<=stop);assert 0<=credit<=8;peerRows.append((z['at'],req['after'],credit))
  readIntervals.sort();assert all(a[1]<=b[0]for a,b in zip(readIntervals,readIntervals[1:]));peerRows.sort();assert all(a[1]+a[2]==b[1]for a,b in zip(peerRows,peerRows[1:])),(run['name'],owner,'peer cursor/credit mismatch')
  total=sum(z[2]for z in peerRows);expected=x['serverAfter'][2-owner]['tip']-x['serverBefore'][2-owner]['tip'];assert total==expected,(run['name'],owner,total,expected)
  submits=[z for z in x['network']if z['actor']==owner and z['path']=='/account/delivery/submit'and start<=z['at']<=x['settledCountsAt']];assert all(z['status']==200 for z in submits);assert all(a['headersAt']<=b['at']for a,b in zip(submits,submits[1:]));assert len(submits)==x['serverAfter'][owner-1]['tip']-x['serverBefore'][owner-1]['tip'];row['owners'].append({'owner':owner,'allReadFlightsDisjoint':True,'allPeerCursorAdvancesEqualNativeCredit':True,'allNativeCreditsWithinG8':True,'peerPositionTotal':total,'matchesExactFinalPeerTipAdvance':True,'submitsSingleFlight':True,'complete200CallsEqualFinalAcceptedAdvance':True})
 checks.append(row)
seq=json.loads((r/'signed-241-333.json').read_text());parent=seq['base'];allowed='/private/tmp/done-worker-catchup-matched-20261029/sign-241-333/allowed-signers'
with(r/'verify-signatures334.log').open('w')as log:
 for z in seq['commits']:
  assert z['parent']==parent;actual=subprocess.check_output(['git','show','-s','--format=%P%n%T',z['commit']],cwd=repo,text=True).splitlines();assert actual==[parent,z['tree']];subprocess.run(['git','-c','gpg.ssh.allowedSignersFile='+allowed,'verify-commit',z['commit']],cwd=repo,stdout=log,stderr=subprocess.STDOUT,check=True);parent=z['commit']
assert parent==inp['head']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();assert subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True)==''
can=json.loads(Path('/private/tmp/done-idle-warm-audit-lab-20261101/canonical-start.json').read_text());assert all(sha((repo/n).read_bytes())==h for n,h in can['files'].items())
result={'inputHomes':links,'allInputHashesAndExistingInertCopiesMatch':True,'nativeAccounting':checks,'signedCommitsReverified':len(seq['commits']),'allTreesAndParentsMatch':True,'head':parent,'canonicalBuildInputsUnchanged':len(can['files']),'cleanTreeBeforeDocumentation':True,'noNewTimedRun':True,'acceptanceCredit':False};(r/'independent334.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k not in ['inputHomes','nativeAccounting']},indent=2))

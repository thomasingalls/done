from pathlib import Path
import json,hashlib,subprocess,tempfile,shutil
r=Path(__file__).parent;repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');out=Path('/private/tmp/done-worker-catchup-matched-20261029');sha=lambda b:hashlib.sha256(b).hexdigest();seq=json.loads((out/'PATCHES.json').read_text());assert seq['sequence'][-1]['phase']==333
for z in seq['sequence']:assert sha((out/z['patch']).read_bytes())==z['sha256']
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();assert head=='2c92793c23fab59781c5fa327ec7500c79356681';assert subprocess.check_output(['git','diff','--cached','--name-only'],cwd=repo,text=True)==''
record=json.loads((r/'signed-241-333.json').read_text());assert record['commits'][-1]['commit']==head;assert record['commits'][-1]['tree']==subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=repo,text=True).strip()
tracked=subprocess.check_output(['git','diff','--name-only'],cwd=repo,text=True).splitlines();assert set(tracked)=={'docs/completed.md','docs/decisions.md','docs/product-backlog.md'}
new=subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=repo).decode().rstrip('\0').split('\0');assert all(n.startswith('docs/performance-experiments/2026-10-29-worker-catchup/phase334/')for n in new)
work=Path(tempfile.mkdtemp(prefix='done-signed333-phase334-replay-',dir='/private/tmp'))
def g(*a):return subprocess.check_output(['git',*a],cwd=work)
g('init','--quiet')
for n in tracked:
 p=work/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(subprocess.check_output(['git','show',head+':'+n],cwd=repo))
def inv():return{str(p.relative_to(work)):sha(p.read_bytes())for p in work.rglob('*')if p.is_file()and'.git'not in p.relative_to(work).parts}
prior=inv();g('add','--all')
for n in tracked+new:
 p=work/n;p.parent.mkdir(parents=True,exist_ok=True);assert(repo/n).is_file()and not(repo/n).is_symlink();shutil.copy2(repo/n,p)
g('add','--intent-to-add',*new);patch=out/'334-slow-direction-prefix-and-scheduler-trace-evidence.patch';assert not patch.exists();patch.write_bytes(g('diff','--binary','--no-ext-diff'));candidate=inv();names=g('diff','--name-only').decode().splitlines();assert set(names)=={n for n in set(prior)|set(candidate)if prior.get(n)!=candidate.get(n)}
for n,h in candidate.items():assert sha((repo/n).read_bytes())==h
g('apply','--reverse','--check',str(patch));g('apply','--reverse',str(patch));assert inv()==prior;g('apply','--check',str(patch));g('apply',str(patch));assert inv()==candidate;assert subprocess.check_output(['git','diff','--cached','--name-only'],cwd=repo,text=True)==''
meta={'phase':334,'baseCommit':seq['baseCommit'],'signedPredecessor':head,'signedPredecessorTree':record['commits'][-1]['tree'],'requires':seq['sequence'][-1]['patch'],'patch':patch.name,'patchSha256':sha(patch.read_bytes()),'files':len(names),'scope':'Evidence/docs only:30existingjourneys, prefix instrumentation limitations, native receiver backlog/read-send coupling,93signedcommitmapping; no new app run/default/source change','checks':['immutable93predecessorpatchhashes','93signedtrees/parentsverifiedindependently','patch333cumulativecommittedtreeispatch334base','onlyscopepathsdirty','exactscopebytes','forward/reverse replay','realindexempty']};(out/'334-manifest.json').write_text(json.dumps(meta,indent=2)+'\n');seq['sequence'].append({'phase':334,'patch':patch.name,'sha256':meta['patchSha256']});(out/'PATCHES.json').write_text(json.dumps(seq,indent=2)+'\n');print(json.dumps(meta,indent=2));print('Replay',work)

from pathlib import Path
import json,math,hashlib,collections,csv,statistics
r=Path(__file__).parent;p329=Path('/private/tmp/done-retained-scope-lab-20261101');p333=Path('/private/tmp/done-idle-warm-audit-lab-20261101');sha=lambda s:hashlib.sha256(s.encode()).hexdigest()
def stats(v):
 s=sorted(v);return {'n':len(s),'sum':sum(s),'p50':s[math.ceil(len(s)*.5)-1],'p95':s[math.ceil(len(s)*.95)-1],'max':s[-1]}if s else None
def overlap(a,b,l,h):return max(0,min(b,h)-max(a,l))
def dump(n,v):(r/n).write_text(json.dumps(v,indent=2)+'\n')
def csvout(n,rows):
 keys=list(dict.fromkeys(k for z in rows for k in z))
 with(r/n).open('w',newline='')as f:
  w=csv.DictWriter(f,fieldnames=keys,lineterminator='\n');w.writeheader()
  for row in rows:w.writerow({k:json.dumps(v,separators=(',',':'))if isinstance(v,(list,dict))else v for k,v in row.items()})
def worker(realms):
 rows=[z['value']for z in realms if 'prefixComparisonCalls'in(z.get('value')or{})];assert len(rows)==1;return rows[0]
def intervals(ev,startKind,endKind,key='id'):
 starts={z[key]:z for z in ev if z['kind']==startKind};ends={z[key]:z for z in ev if z['kind']==endKind};return[{**z,'end':ends[k]['at']if k in ends else None,'endEvent':ends.get(k)}for k,z in starts.items()]
def drivers(ev):
 out=[];current=None
 for z in ev:
  if z['kind']=='driverTurnStart':assert current is None;(current:=z)
  elif z['kind']=='driverTurnEnd':
   if current is not None:
    assert current['lane']==z['lane'];out.append({'lane':z['lane'],'start':current['at'],'end':z['at'],'outcome':z['outcome']});current=None
 if current:out.append({'lane':current['lane'],'start':current['at'],'end':None,'outcome':'open'})
 return out
counterNames=['prefixComparisonCalls','prefixComparisonMs','appendPrefixComparisonCalls','appendPrefixComparisonMs','warmRecordViews','fullPhysicalLoads','fullLedgerChecks','full1024Audits','prepareGroupTotalCalls','prepareGroupTotalMs','fetchNetworkTotalCalls','fetchNetworkTotalMs','receivePageCalls','receivePageMs','receiveGroupCalls','receiveGroupMs','emptyCheckCalls','emptyCheckMs','inboundCommits','inboundPositions','quietReads','eventOverflow']
aggregates=[];native=[];allturns=[];allreads=[];allgaps=[];storage=[];sampling=[];submitMaps=[]
for phase,root,afile in[(329,p329,'paired329-analysis.json'),(333,p333,'paired333-analysis.json')]:
 for run in json.loads((root/afile).read_text()):
  base=root/run['name'];x=json.loads((base/'result.json').read_text());assert x['outcome']=='passed';t0=x['typingStartedAt'];t1=x['typingFinishedAt'];t2=x['newDeliveryAt'];b={k:run[k]for k in ['name','policy','rtt','replicate']};b['phase']=phase
  for idx in[0,1]:
   before=worker(x['labBefore'][idx]);after=worker(x['labAfter'][idx]);diff={k:after.get(k,0)-before.get(k,0)for k in counterNames};assert all(v>=-1e-6 for v in diff.values());ev=after['events'];early=[z for z in ev if t0<=z['at']<=t2];prefix=[z for z in early if z['kind']=='prefixComparison'];aggregate={**b,'device':idx+1,**diff,'typingMs':t1-t0,'visibilityWindowMs':t2-t0,'prefixInstrumentedUsPerCall':1000*diff['prefixComparisonMs']/diff['prefixComparisonCalls'],'storedEventCount':len(ev),'storedEventsLastAfterTypingMs':ev[-1]['at']-t0,'prefixEventsInVisibilityWindow':len(prefix),'prefixEventMsInVisibilityWindow':sum(z['ms']for z in prefix),'comparisonCallsDoNotMeanWholeLedgerPasses':True,'metric':'before/after snapshots; instrumented elapsed spans including cooperative waits, not CPU; event cap excludes later events'};aggregates.append(aggregate)
  if phase!=333:continue
  peerpub=[z['publisherSha256']for z in x['serverBefore']]
  # Ordinal submit mapping only where the complete successful-call count reconciles exactly.
  sm={}
  for idx in[0,1]:
   qs=sorted([q for q in x['network']if q['actor']==idx+1 and q['path']=='/account/delivery/submit'and t0<=q['at']<=x['settledCountsAt']],key=lambda q:q['at']);delta=x['serverAfter'][idx]['tip']-x['serverBefore'][idx]['tip'];ok=len(qs)==delta and all(q.get('status')==200 and q.get('headersAt')is not None for q in qs)
   # Driver admits one position per monotonic single-flight submit. Preserve explicit qualification.
   mapping=[{'position':x['serverBefore'][idx]['tip']+j+1,'sentAt':q['at'],'replyAt':q['headersAt']}for j,q in enumerate(qs)]if ok else[];sm[idx]=mapping;submitMaps.append({**b,'device':idx+1,'calls':len(qs),'acceptedTipDelta':delta,'reconciles':ok,'positionTimes':mapping,'meaning':'ordinal inference under checked single-flight monotonic sender and no external writer;200 alone is not acceptance proof'})
  for idx in[0,1]:
   actor=idx+1;f=next(z['file']for z in x['audit333Files']if z['actor']==actor);raw=json.loads((base/f).read_text());assert raw['overflow']==0;ev=raw['rows'];ds=drivers(ev);rstarts=intervals(ev,'readTurnStart','readTurnEnd');fetch={z['id']:z for z in ev if z['kind']=='readTurnFetch'};commits=[z for z in ev if z['kind']=='inboundCommit'];qjobs=intervals(ev,'jobQueued','jobEnd');jstarts={z['id']:z for z in ev if z['kind']=='jobStart'};own=peerpub[idx];peer=peerpub[1-idx]
   for z in ds:
    allturns.append({**b,'device':actor,**z,'typingOverlapMs':overlap(z['start'],z['end']or t2,t0,t1),'visibilityOverlapMs':overlap(z['start'],z['end']or t2,t0,t2)})
   qlist=[]
   for q in qjobs:
    s=jstarts.get(q['id']);end=q['end'];start=s['at']if s else None
    if start is not None and end is not None and start<=t2 and end>=t0:qlist.append({**b,'device':actor,'id':q['id'],'name':q['name'],'queued':q['at'],'start':start,'end':end,'queueWaitMs':s['queueWaitMs'],'operationMs':end-start,'typingOperationMs':overlap(start,end,t0,t1),'visibilityOperationMs':overlap(start,end,t0,t2)})
   storage+=qlist
   reads=[]
   for z in rstarts:
    fe=fetch.get(z['id']);end=z['end'];req=fe.get('requests',[])if fe else[];primary=req[0]if req else None;pub=sha(primary['publisher'])if primary else None;role='activePeer'if pub==peer else'self'if pub==own else'other'if pub else'none';cc=[c for c in commits if z['at']<=c['at']<=(end or math.inf)];positions=sum(c['positions']for c in cc);driver=next((d for d in ds if d['start']<=z['at']<=(d['end']or math.inf)),None);quiet=bool(fe and 'quiet'in fe and fe['quiet']is not None and fe['quiet']is not False)
    row={**b,'device':actor,'id':z['id'],'start':z['at'],'end':end,'fetchAt':fe['at']if fe else None,'ms':end-z['at']if end else None,'role':role,'publisherSha256':pub,'after':primary['after']if primary else None,'requestedLimit':primary['limit']if primary else None,'quietTokenPresent':quiet,'outcome':z['endEvent'].get('outcome')if z['endEvent']else'open','positions':positions,'physicalRows':sum(c['physicalRows']for c in cc),'physicalReceipts':sum(c['physicalReceipts']for c in cc),'duringTyping':t0<=z['at']<=t1,'inVisibilityWindow':t0<=z['at']<=t2,'driverStart':driver['start']if driver else None,'driverOutcome':driver['outcome']if driver else None,'wireExtents':[{'publisherSha256':sha(q['publisher']),'after':q['after'],'limit':q['limit']}for q in req]}
    if role=='activePeer'and sm[1-idx]and primary:
     accepted=[q for q in sm[1-idx]if q['replyAt']<=z['at']];tip=max([x['serverBefore'][1-idx]['tip']]+[q['position']for q in accepted]);oldest=next((q for q in accepted if q['position']==primary['after']+1),None);row.update(acceptedTipReplyBound=tip,backlogLowerBound=max(0,tip-primary['after']),oldestAcceptedWaitLowerBoundMs=z['at']-oldest['replyAt']if oldest else None)
    reads.append(row);allreads.append(row)
   pr=[z for z in reads if z['role']=='activePeer'and z['inVisibilityWindow']];pg=[]
   for a,c in zip(pr,pr[1:]):
    between=[z for z in reads if a['start']<z['start']<c['start']];sends=[z for z in ds if z['lane']=='send'and a['start']<=z['start']<c['start']];gap={**b,'device':actor,'start':a['start'],'nextStart':c['start'],'gapMs':c['start']-a['start'],'firstAfter':a['after'],'nextAfter':c['after'],'firstPositions':a['positions'],'betweenReads':len(between),'betweenPrimaryRoles':dict(collections.Counter(z['role']for z in between)),'betweenOutcomes':dict(collections.Counter(z['outcome']for z in between)),'sendTurns':len(sends),'sendMs':sum(overlap(z['start'],z['end']or c['start'],a['start'],c['start'])for z in sends),'maxBacklogLowerBound':c.get('backlogLowerBound'),'nextOldestAcceptedWaitLowerBoundMs':c.get('oldestAcceptedWaitLowerBoundMs'),'beganDuringTyping':a['duringTyping']};allgaps.append(gap);pg.append(gap)
   for label,end in [('typing',t1),('visibility',t2)]:
    selected=[z for z in ds if z['start']<=end and(z['end']or math.inf)>=t0];rm=[z for z in reads if t0<=z['start']<=end];q=[z for z in qlist if z['start']<=end and z['end']>=t0];success=[q for q in x['network']if q['actor']==actor and q['path']=='/account/delivery/submit'and t0<=q['at']<=end];net=[q for q in x['network']if q['actor']==actor and q['path'].startswith('/account/delivery/read')and t0<=q['at']<=end];active=sum(overlap(z['start'],z['end']or end,t0,end)for z in selected);assert active<=end-t0+1
    byname={name:{'n':sum(z['name']==name for z in q),'operationMs':sum(overlap(z['start'],z['end'],t0,end)for z in q if z['name']==name),'queueWaitMsSum':sum(z['queueWaitMs']for z in q if z['name']==name)}for name in set(z['name']for z in q)}
    item={**b,'device':actor,'window':label,'durationMs':end-t0,'driverSendMs':sum(overlap(z['start'],z['end']or end,t0,end)for z in selected if z['lane']=='send'),'driverReceiveMs':sum(overlap(z['start'],z['end']or end,t0,end)for z in selected if z['lane']=='receive'),'driverUnoccupiedMs':end-t0-active,'sendStarts':sum(t0<=z['start']<=end and z['lane']=='send'for z in selected),'receiveStarts':sum(t0<=z['start']<=end and z['lane']=='receive'for z in selected),'driverAlternationCount':sum(a['lane']!=c['lane']for a,c in zip(selected,selected[1:])),'readTurns':len(rm),'primaryCounts':dict(collections.Counter(z['role']for z in rm)),'quietTokenReads':sum(z['quietTokenPresent']for z in rm),'emptyReads':sum(z['outcome']=='empty'for z in rm),'peerProductiveCommits':sum(z['role']=='activePeer'and z['positions']>0 for z in rm),'peerPositions':sum(z['positions']for z in rm if z['role']=='activePeer'),'peerCommitWidth':stats([z['positions']for z in rm if z['role']=='activePeer'and z['positions']>0]),'peerRevisitGap':stats([z['gapMs']for z in pg if t0<=z['start']<=end]),'peerBacklogLowerBoundMax':max((z.get('backlogLowerBound',0)for z in rm if z['role']=='activePeer'),default=0),'peerOldestAcceptedWaitLowerBoundMs':stats([z['oldestAcceptedWaitLowerBoundMs']for z in rm if z.get('oldestAcceptedWaitLowerBoundMs')is not None]),'submitCalls':len(success),'submitStatuses':dict(collections.Counter(str(z.get('status'))for z in success)),'submitStartIntervals':stats([c['at']-a['at']for a,c in zip(success,success[1:])]),'submitRequestToHeadersMs':stats([z['headersAt']-z['at']for z in success if z.get('headersAt')]),'networkReadHttpCalls':len(net),'networkReadRequestToHeadersMs':stats([z['headersAt']-z['at']for z in net if z.get('headersAt')]),'storageJobsByName':byname};native.append(item)
  print('analyzed',phase,run['name'],flush=True)
dump('prefix334.json',aggregates);dump('native334.json',native);dump('submit-maps334.json',submitMaps);csvout('prefix334.csv',aggregates);csvout('driver-turns334.csv',allturns);csvout('read-turns334.csv',allreads);csvout('peer-revisit-gaps334.csv',allgaps);csvout('storage-jobs334.csv',storage)
# Concise policy-level descriptive rows retain each run in the JSON tables.
policy=[]
for p in ['coordinated-2000','immediate-inflight']:
 for delay in[0,50]:
  for device in[1,2]:
   rows=[z for z in native if z['policy']==p and z['rtt']==delay and z['device']==device and z['window']=='typing'];ag=[z for z in aggregates if z['phase']==333 and z['policy']==p and z['rtt']==delay and z['device']==device];assert len(rows)==len(ag)==3
   out={'policy':p,'rtt':delay,'device':device,'n':3,'prefixCalls':[z['prefixComparisonCalls']for z in ag],'prefixMs':[z['prefixComparisonMs']for z in ag],'prefixRowsPerViewProxy':[z['prefixComparisonCalls']/z['warmRecordViews']for z in ag]}
   for key in ['sendStarts','receiveStarts','readTurns','emptyReads','peerProductiveCommits','peerPositions','driverSendMs','driverReceiveMs','driverUnoccupiedMs','peerBacklogLowerBoundMax'] :out[key]=[z[key]for z in rows]
   for key in ['peerRevisitGap','submitStartIntervals','submitRequestToHeadersMs','peerOldestAcceptedWaitLowerBoundMs']:out[key]=[z[key]for z in rows]
   policy.append(out)
dump('summary334.json',{'policy':policy,'allSubmissionMappingsReconcile':all(z['reconciles']for z in submitMaps),'sourceHead':'2c92793c23fab59781c5fa327ec7500c79356681','noNewRun':True,'acceptanceCredit':False,'limitations':['prefix high-volume event cap truncates after early typing; counters continue','prefix spans are instrumented elapsed time, not CPU and omit instrumentation outside span','per-key→submitted-envelope mapping absent; ordinal submit mapping explicitly qualified','native333 log complete but detailed source tag is not unique causal context for every background status job','frozen329 versus333 is not contemporaneous quiet-host causal estimate']})
print('COMPLETE',len(aggregates),'counter owners',len(native),'native windows',len(allreads),'read turns',flush=True)

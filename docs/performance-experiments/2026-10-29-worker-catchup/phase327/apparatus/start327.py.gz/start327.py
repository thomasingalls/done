from pathlib import Path
import shutil,json,hashlib
old=Path('/private/tmp/done-page-reuse-repair-lab-20261101');r=Path('/private/tmp/done-owner-fault-trace-lab-20261101');r.mkdir(mode=0o700)
for src,dst in [('sender-source','source'),('source-server','source-server'),('harness','harness')]:shutil.copytree(old/src,r/dst,symlinks=True)
(r/'source-R').symlink_to(r/'source-server',target_is_directory=True);(r/'source-after').symlink_to(r/'source-server',target_is_directory=True);(r/'node_modules').symlink_to(old/'node_modules',target_is_directory=True)
for n in ['run-stage.py','host_load.py','lab-context.mjs','observer.mjs','container-service.mjs','read-request.mjs','notification-probe.mjs','fixture-roles.mjs','playwright-storage-source.txt','tsconfig.sender326.json','canonical-start.json']:
 p=r/n;p.write_bytes((old/n).read_bytes())
for p in [*(r/'harness').rglob('*'),*(r/'source').rglob('*'),*(r.glob('*.py')),*(r.glob('*.mjs'))]:
 if p.is_file()and not p.is_symlink()and p.suffix in ['.ts','.tsx','.mjs','.py','.json']:
  try:s=p.read_text()
  except UnicodeError:continue
  if str(old)in s:p.write_text(s.replace(str(old),str(r)))
(r/'sender-short-fixture').symlink_to(old/'sender-short-fixture',target_is_directory=True)
b=r/'build';b.mkdir();(b/'source').symlink_to(r/'source',target_is_directory=True);shutil.copytree(old/'sender-build/lab',b/'lab',symlinks=True)
for p in(b/'lab').rglob('*'):
 if p.is_file()and p.suffix in ['.mjs','.html','.ts']:p.write_text(p.read_text().replace(str(old/'sender-build'),str(b)).replace(str(old),str(r)))
for n in ['build-lab.py','build.mjs','release-flags.json']:
 (b/n).write_text((old/'sender-build'/n).read_text().replace(str(old/'sender-build'),str(b)).replace(str(old),str(r)))
t=json.loads((old/'tsconfig.sender326.json').read_text());t['extends']='./source/tsconfig.app.json';t['include']=[v.replace('sender-source/','source/',1)for v in t['include']if 'labImmediate326'not in v];t['include']+=['source/test/labFault327.test.ts'];(r/'tsconfig.lab327.json').write_text(json.dumps(t,indent=2)+'\n')
(r/'PROTOCOL327.md').write_text('''# Phase327 — observation-only owner failure trace

Lab only, fictional profiles, no credit, no landing/hardening. Phase326 is frozen separately; no prior failure is regraded. Drop the flush timing clue: the operator observes open flush in4/8 traced closures, plausibly a close consequence. Preserve the operator\'s evidence against server rate/active limits and simple send counts, without making a causal claim.

Instrument every windowCeremonyUi fail origin, including root/control reason, Worker error, Worker lifetime, session cohort abort, closed notice, activity failure and command rejection. Stream the original Worker trace to the page while alive with bounded batches, plus immediate critical diagnostics; no RPC slot is used, no extra await is added to lifetime/commit, and any truncation/sequence gap must be visible. Both sides of every workerChannel record per-channel incoming/outgoing high-water marks, queue-bound refusal and original handler rejection before code narrowing. Include Worker-initiated calls. Keep caps at8, return/throw codes and every authority/journal/commit check unchanged. Streamed evidence never authorizes work.

After focused controls and strict TS, build matched reference and coordinated-2000 diagnostics. Predeclare one full paired150/0ms failing reproduction and one coordinated control on the same fresh-short-card fixture, same300keys/device, original deadlines/cold/exact/gates and5s external host logs. Run reference first; retain failure and original cold stop semantics. The first question is the exact initiating fail path, not a latency comparison or a fix. Any further replicas will be declared before running. No default or security behavior changes.
''')
print(r)

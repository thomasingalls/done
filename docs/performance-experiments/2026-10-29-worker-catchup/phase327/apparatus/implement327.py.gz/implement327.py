from pathlib import Path
r=Path('/private/tmp/done-owner-fault-trace-lab-20261101');s=r/'source/src'
p=s/'crdt/faultTrace327.ts';p.write_text('''/** FICTIONAL LAB ONLY: observation cannot authorize, wait for, or suppress application work. */
const query=new URL(globalThis.location?.href??'http://lab.invalid').searchParams;
export const fault327Enabled=query.get('labFault327')==='1'||(typeof sessionStorage!=='undefined'&&sessionStorage.getItem('done.lab.fault327')==='1');
const workerRealm=typeof document==='undefined'&&typeof globalThis.postMessage==='function';
const rows:any[]=[],streams:any[]=[],queue:any[]=[];let channel=0,serial=0,batch=0,dropped=0,timer:ReturnType<typeof setTimeout>|undefined;
const stamp=()=>performance.timeOrigin+performance.now();
export function fault327Reason(cause:unknown){if(!cause||typeof cause!=='object')return{type:typeof cause};const d=Object.getOwnPropertyDescriptors(cause);const name=d.name?.value??(cause instanceof Error?cause.name:undefined),code=d.code?.value,stack=d.stack?.value;return{name:typeof name==='string'?name.slice(0,80):undefined,code:typeof code==='string'?code.slice(0,80):undefined,frames:typeof stack==='string'?stack.split('\\n').filter(x=>/^\\s*at /.test(x)).slice(0,6).map(x=>x.replace(/\\?[^): ]*/g,'').slice(0,240)):[]};}
export function flush327(){if(!fault327Enabled||!workerRealm||!queue.length)return;clearTimeout(timer);timer=undefined;const events=queue.splice(0,128);try{globalThis.postMessage({__doneFault327:1,batch:++batch,dropped,events});}catch{dropped+=events.length;}if(queue.length)timer=setTimeout(flush327,0);}
export function stream327(event:Record<string,unknown>,critical=false){if(!fault327Enabled||!workerRealm)return;const item={...event,traceSeq:++serial};if(queue.length>=512){queue.shift();dropped++;}queue.push(item);if(critical)flush327();else timer??=setTimeout(flush327,25);}
export function fault327(event:Record<string,unknown>){if(!fault327Enabled)return;const item={...event,at:stamp()};if(rows.length<32768)rows.push(item);else dropped++;stream327(item,true);}
export const channel327=()=>fault327Enabled?++channel:0;
export function attach327(worker:Worker){if(!fault327Enabled)return;const workerId=streams.length+1,state:any={workerId,lastBatch:0,lastSeq:0,gaps:0,dropped:0,events:[]};streams.push(state);worker.addEventListener('message',event=>{const m=event.data;if(m?.__doneFault327!==1||!Number.isSafeInteger(m.batch)||!Array.isArray(m.events)||m.events.length>128)return;if(m.batch!==state.lastBatch+1)state.gaps++;state.lastBatch=m.batch;state.dropped=m.dropped;for(const e of m.events){if(!e||!Number.isSafeInteger(e.traceSeq))continue;if(e.traceSeq!==state.lastSeq+1)state.gaps++;state.lastSeq=e.traceSeq;if(state.events.length<300000)state.events.push(e);else state.dropped++;}});}
Object.assign(globalThis,{__fault327:{read:()=>({enabled:fault327Enabled,realm:workerRealm?'worker':'page',rows:structuredClone(rows),streams:structuredClone(streams),dropped}),flush:flush327}});
''')
# Stream original lab trace without using the RPC ports; preserve original local log cap/count.
p=s/'crdt/rangeLab.ts';v=p.read_text();v="import{stream327,attach327}from'./faultTrace327';\n"+v;v=v.replace("if(labEvents.length<250000)labEvents.push({...event,at:performance.timeOrigin+performance.now()});else labCount('eventOverflow');", "const item={...event,at:performance.timeOrigin+performance.now()};if(labEvents.length<250000)labEvents.push(item);else labCount('eventOverflow');stream327(item);")
v=v.replace('super(u,options);','if(query.get(\'labFault327\')===\'1\'||(typeof sessionStorage!==\'undefined\'&&sessionStorage.getItem(\'done.lab.fault327\')===\'1\'))u.searchParams.set(\'labFault327\',\'1\');super(u,options);attach327(this);');p.write_text(v)
# Channel observations cover every channel in both realms, including Worker-originated requests.
p=s/'crdt/workerChannel.ts';v=p.read_text();v="import{fault327,channel327,fault327Reason}from'./faultTrace327';\n"+v
v=v.replace('const methods = Object.freeze({ ...handlers });',"const methods = Object.freeze({ ...handlers });\n  const traceId=channel327(),incoming=new Map<number,string>();let outPeak=0,inPeak=0;\n  const trace=(kind:string,extra:Record<string,unknown>={})=>fault327({kind,channel:traceId,pending:pending.size,active,outPeak,inPeak,outgoing:[...pending].map(([id,p])=>({id,method:p.method})),incoming:[...incoming].map(([id,method])=>({id,method})),...extra});")
v=v.replace('if (closed) return;\n    closed = true;',"if (closed) return;\n    trace('channel-close',{reason:fault327Reason(reason),notify});\n    closed = true;",1)
v=v.replace("      if (\n        m.kind !== 'call'", "      if(m.kind==='call'&&active>=WORKER_PENDING_CALLS)trace('channel-queue-full',{direction:'incoming',method:m.method,wireId:m.id,originalCode:'message-order'});\n      if (\n        m.kind !== 'call'")
v=v.replace('active++;',"active++;incoming.set(m.id,m.method);if(active>inPeak){inPeak=active;trace('channel-high-water',{direction:'incoming',method:m.method});}",1)
v=v.replace('          (cause) => {\n            if (!closed)',"          (cause) => {\n            trace('channel-handler-refused',{method:m.method,wireId:m.id,reason:fault327Reason(cause)});\n            if (!closed)")
v=v.replace('active--;\n          eraseWorkerMessage', 'active--;incoming.delete(m.id);\n          eraseWorkerMessage')
v=v.replace("if (pending.size >= WORKER_PENDING_CALLS)\n        return Promise.reject(new WorkerChannelError('queue-full'));", "if (pending.size >= WORKER_PENDING_CALLS){trace('channel-queue-full',{direction:'outgoing',method,originalCode:'queue-full'});\n        return Promise.reject(new WorkerChannelError('queue-full'));}")
v=v.replace('pending.set(id, { method, resolve: (v) => resolve(v as T), reject });',"pending.set(id, { method, resolve: (v) => resolve(v as T), reject });if(pending.size>outPeak){outPeak=pending.size;trace('channel-high-water',{direction:'outgoing',method});}")
p.write_text(v)
# Label each actual fail() origin; do not catch/skip or change a shutdown guard.
p=s/'ui/windowCeremonyUi.ts';v=p.read_text();v="import{fault327,fault327Reason}from'../crdt/faultTrace327';\n"+v;v=v.replace('const fail = () => {',"const fail = (origin='unlabelled',reason?:unknown) => {\n    fault327({kind:'ceremony-fail',origin,reason:fault327Reason(reason),closed,needsReboot,poisoned:!!poisoned,handingOff,explicitlyClosed,ended});")
v=v.replace('if (!handingOff) fail();',"if (!handingOff) fail('root-channel',reason);")
v=v.replace("      () => {\n        if (!handingOff) fail('root-channel',reason);", "      (reason) => {\n        fault327({kind:'ceremony-root-close',reason:fault327Reason(reason),handingOff});\n        if (!handingOff) fail('root-channel',reason);")
v=v.replace('if (!needsReboot) fail();',"if (!needsReboot) fail('session-cohort-abort',session?.cohort.signal.reason);",1)
v=v.replace('      fail,\n    );',"      (reason)=>fail('control-channel',reason),\n    );")
v=v.replace('if (!handingOff || !v.ok) fail();',"if (!handingOff || !v.ok) fail('worker-closed-notice',{code:v.kind});")
v=v.replace("        () => {\n          reject(Error('Setup Worker failed'));\n          fail();", "        (event) => {\n          fault327({kind:'ceremony-worker-error',message:event.message?.slice(0,240),filename:event.filename,line:event.lineno,column:event.colno,reason:fault327Reason(event.error)});\n          reject(Error('Setup Worker failed'));\n          fail('worker-error',event.error);")
v=v.replace('      fail();\n    });',"      fail('worker-lifetime',{released});\n    });",1)
v=v.replace('      failed: fail,',"      failed: (reason)=>fail('activity-forwarder',reason),")
v=v.replace('void command(input).catch(() => {\n      if (!needsReboot) fail();',"void command(input).catch((reason) => {\n      if (!needsReboot) fail('command-rejection',reason);")
assert ' fail();'not in v
p.write_text(v)
# Preserve original exceptions before local cleanup can trigger remote termination.
for file in ['workerWorkspaceQueues.ts','windowWorkspaceQueues.ts']:
 p=s/'crdt'/file;v=p.read_text();v="import{fault327,fault327Reason}from'./faultTrace327';\n"+v
 if file.startswith('worker'):
  v=v.replace('          config.failed();',"          fault327({kind:'worker-workspace-failure',phase:phaseOf(f),flightKind:f.kind,reason:fault327Reason(cause)});\n          config.failed();")
 else:v=v.replace('const fail = (cause: unknown) => {',"const fail = (cause: unknown) => {\n    fault327({kind:'window-workspace-failure',reason:fault327Reason(cause)});")
 p.write_text(v)
print('Private observation sources prepared')

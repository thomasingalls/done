from pathlib import Path
import argparse,ctypes as c,json,os,time,signal,threading,subprocess,resource
p=argparse.ArgumentParser();p.add_argument('--out',required=True);p.add_argument('--period',type=float,default=5);p.add_argument('--samples',type=int,default=0);a=p.parse_args();assert a.period>0
system=c.CDLL('/usr/lib/libSystem.B.dylib');system.mach_host_self.restype=c.c_uint32;host=system.mach_host_self();system.host_statistics.argtypes=[c.c_uint32,c.c_int,c.POINTER(c.c_int),c.POINTER(c.c_uint32)]
def seconds(text):
 days=0
 if '-'in text:day,text=text.split('-',1);days=int(day)
 parts=list(map(float,text.split(':')));assert len(parts)in(2,3)
 return days*86400+sum(v*60**i for i,v in enumerate(reversed(parts)))
def snapshot():
 ticks=(c.c_uint32*4)();count=c.c_uint32(4);code=system.host_statistics(host,3,c.cast(ticks,c.POINTER(c.c_int)),c.byref(count));assert code==0,(code,count.value)
 before=resource.getrusage(resource.RUSAGE_CHILDREN);began=time.monotonic_ns();q=subprocess.run(['/bin/ps','-A','-o','pid=,time=,comm='],capture_output=True,text=True,check=True);after=resource.getrusage(resource.RUSAGE_CHILDREN);rows={}
 for line in q.stdout.splitlines():
  parts=line.strip().split(None,2)
  if len(parts)!=3:continue
  pid,text,name=parts;rows[int(pid)]=(Path(name).name,seconds(text))
 return time.monotonic_ns(),list(ticks),rows,{'psWallMs':(time.monotonic_ns()-began)/1e6,'psChildCpuMs':1000*((after.ru_utime+after.ru_stime)-(before.ru_utime+before.ru_stime))}
stop=threading.Event();signal.signal(signal.SIGTERM,lambda *_:stop.set());signal.signal(signal.SIGINT,lambda *_:stop.set());path=Path(a.out);path.parent.mkdir(parents=True,exist_ok=True)
with path.open('x')as f:
 def emit(v):f.write(json.dumps(v,separators=(',',':'))+'\n');f.flush()
 emit({'kind':'method','revision':2,'periodSeconds':a.period,'host':'Mach HOST_CPU_LOAD_INFO interval deltas','processes':'ps pid,time,comm cumulative CPU seconds interval deltas; executable basename only, NEVER arguments/environment; includes protected/system process CPU','processTimeResolutionSeconds':.01,'topCount':15,'percentMeaning':'Process100percent=one core; host percentages aggregate all cores','newProcesses':'TotalCPU since birth used for newly observed PID; PID reset/name change marked','clock':'Unix epoch milliseconds plus monotonic interval','samplerPid':os.getpid(),'cpuCount':os.cpu_count(),'calibration':'Earlier libproc trial had Mach-tick units and incomplete root coverage; retained separately and not used for timed runs'})
 old=snapshot();Path(str(path)+'.ready').write_text('ready\n');samples=0
 while not stop.wait(a.period):
  cpu=time.process_time_ns();now=snapshot();elapsed=(now[0]-old[0])/1e9;diff=[(x-y)&0xffffffff for x,y in zip(now[1],old[1])];total=sum(diff);rows=[]
  for pid,(name,used_seconds)in now[2].items():
   before=old[2].get(pid);reset=before is None or before[0]!=name or used_seconds<before[1];used=used_seconds if reset else used_seconds-before[1];rows.append({'pid':pid,'name':name,'cpuPercent':100*used/elapsed,'newOrReset':reset})
  rows.sort(key=lambda z:z['cpuPercent'],reverse=True);emit({'kind':'load','at':time.time_ns()/1e6,'monotonicNs':now[0],'intervalSeconds':elapsed,'hostPercent':{k:100*v/total if total else 0 for k,v in zip(['user','system','idle','nice'],diff)},'top':rows[:15],'observedProcesses':len(now[2]),'samplerCpuMs':(time.process_time_ns()-cpu)/1e6,**now[3]});old=now;samples+=1
  if a.samples and samples>=a.samples:break
 emit({'kind':'end','at':time.time_ns()/1e6,'samples':samples,'stopped':stop.is_set()})

import type {Page}from'@playwright/test';
export async function captureMaintenanceTrace(p:Page){const rows:any[]=[];try{rows.push({realm:'window',value:await p.evaluate(()=>(globalThis as any).__maintenanceTraceLab?.read())});}catch{}for(const w of p.workers())try{rows.push({realm:w.url(),value:await w.evaluate(()=>(globalThis as any).__maintenanceTraceLab?.read())});}catch{}return rows;}

import{test,expect,chromium}from'@playwright/test';import{cpSync,readFileSync,mkdirSync,writeFileSync}from'node:fs';
import{configureLabContext}from'../../../lab-context.mjs';
import{start,stop}from'./runtime.mjs';import{seedProfile}from'./seed-profile';import{restoreAuthenticator,openSaved}from'./devices';
const root='/private/tmp/done-owner-fault-trace-lab-20261101',out=process.env['FAIR_OUT']!;
test('actual public owner activates the selected lab treatment',async()=>{
 const fixture=JSON.parse(readFileSync(root+'/private-fixture/fixture.json','utf8')),account=fixture.accounts.find((v:any)=>v.label==='H'),seed=account.actors[1];let ctx:any;const result:any={outcome:'starting',observations:[]};mkdirSync(out,{recursive:true,mode:0o700});
 const read=()=>{const lab=(globalThis as any).__rangeLab;if(!lab)return null;const s=lab.read();return{bits:lab.bits,positions:s.inboundPositions??0,maxGroup:Math.max(0,...s.events.filter((e:any)=>e.kind==='inboundCommit').map((e:any)=>e.positions)),externalPages:s.externalPages,keyImportHits:s.keyImportHits??0,url:location.href}};
 try{
 cpSync(fixture.state,out+'/state',{recursive:true,errorOnExist:true});await start(out+'/state',root+'/combined-dist');ctx=await configureLabContext(await chromium.launchPersistentContext(out+'/private-profile',{executablePath:process.env['CHROMIUM_PATH'],baseURL:'http://localhost:53781',viewport:{width:1440,height:1000},timezoneId:'UTC'}));
 await seedProfile(ctx,seed.storage);const p=ctx.pages()[0]??await ctx.newPage();await restoreAuthenticator(p,seed.credentials);await p.goto('/');await p.evaluate(()=>navigator.serviceWorker.ready);await p.reload();await openSaved(p,seed.code,true);
 for(let i=0;i<40;i++){
  const all=[{realm:'Window',value:await p.evaluate(read)},...await Promise.all(p.workers().map(async(w:any)=>({realm:w.url(),value:await w.evaluate(read).catch(()=>null)})))];result.observations.push(all);
  const active=all.filter((v:any)=>v.value?.positions>=16);
  if(active.length){result.active=active;expect(active.every((v:any)=>v.value.bits==='0010111')).toBe(true);expect(active.some((v:any)=>v.value.maxGroup===8&&v.value.externalPages>0&&v.value.keyImportHits>0)).toBe(true);result.outcome='passed';break;}
  await p.waitForTimeout(200);
 }
 expect(result.outcome).toBe('passed');
 }catch(error){result.outcome='failed';result.error=String(error);throw error}finally{writeFileSync(out+'/result.json',JSON.stringify(result,null,2)+'\n');await ctx?.close().catch(()=>{});await stop();}
});

from pathlib import Path
import subprocess,shutil,os,json,hashlib
r=Path(__file__).parent;s=r/'source';b=r/'build';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();inputs={str(p.relative_to(s)):sha(p)for folder in ['src','account-protocol','test']for p in(s/folder).rglob('*')if p.is_file()};(r/'source327-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
for policy in ['reference','coordinated-2000']:
 with(r/f'build327-{policy}.log').open('w')as f:result=subprocess.run(['python3',str(b/'build-lab.py')],cwd=b,env={**os.environ,'LAB_BATCH_POLICY':policy},stdout=f,stderr=subprocess.STDOUT)
 if result.returncode:raise SystemExit(result.returncode)
 dest=r/('sender-'+policy);dest.mkdir(mode=0o700);shutil.move(str(b/'combined-dist'),dest/'combined-dist')
 for name in ['build-flags.json','build-identity.json','frontend-build.log','lab-build.log']:shutil.copy2(b/name,dest/name)
 assert all(sha(s/n)==h for n,h in inputs.items());print('Built',policy,flush=True)

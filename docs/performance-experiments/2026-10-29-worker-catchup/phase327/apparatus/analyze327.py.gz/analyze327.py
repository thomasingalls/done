from pathlib import Path
import json,csv,hashlib,statistics,subprocess
r=Path(__file__).parent;repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cases=[];events=[];queues=[]
for key in['traceFirstReady327','traceControlReady327','traceTagged327']:
 inp=json.loads((r/(key+'-inputs.json')).read_text())
 for root,files in{**inp['sourceRoots'],**inp['assetRoots']}.items():
  for n,h in files.items():assert sha(Path(root)/n)==h,(root,n)
 for n,h in inp['serverSources'].items():assert sha(r/'source-server'/n)==h,n
 for n,h in inp['fixtures'].items():assert sha(Path(n))==h,n
 for n,h in inp['apparatus'].items():assert sha(r/n)==h,n
 for n,h in inp['support'].items():assert sha(r/n)==h,n
 for row in json.loads((r/(key+'-results.json')).read_text()):
  out=r/row['name'];x=json.loads((out/'result.json').read_text());start=x['typingStartedAt'];summary={**row,'closureAfterTypingMs':[],'owners':[],'observedNon200':[(q['path'],q['status'])for q in x['network']if q.get('status')is not None and q['status']!=200]}
  for actor in[1,2]:
   p=out/f'fault327-before-cold-page-{actor}.json'
   if not p.exists():p=out/f'fault327-page-{actor}.json'
   z=json.loads(p.read_text());groups=[('page',z['fault']['rows'],None)]+[(w['url'],w['critical'],w)for w in z['external']['workers']];owner={'actor':actor,'failCalls':[],'nativeTerminal':[],'transport':[],'queueFull':[],'channels':[]}
   for realm,rows,worker in groups:
    if worker:owner['transport'].append({'realm':realm,'received':worker['received'],'workerDropped':worker['workerDropped'],'batchGaps':worker['gaps'],'tailEvents':len(worker['tail']),'lastTailAt':max((e['at']for e in worker['tail']),default=None)})
    channels=sorted(set(e['channel']for e in rows if'channel'in e))
    for channel in channels:
     entries=[e for e in rows if e.get('channel')==channel];q={'case':row['name'],'actor':actor,'realm':realm,'channel':channel,'outgoingHighWater':max(e['outPeak']for e in entries),'incomingHighWater':max(e['inPeak']for e in entries),'queueFull':sum(e['kind']=='channel-queue-full'for e in entries),'limit':8};queues.append(q);owner['channels'].append(q)
    for e in rows:
     if e['at']<start:continue
     if e['kind']=='ceremony-fail':owner['failCalls'].append(e)
     if e['kind']=='native-owner-terminal-close':owner['nativeTerminal'].append(e)
     if e['kind']=='channel-queue-full':owner['queueFull'].append(e)
     if e['kind']!='channel-high-water':events.append({'case':row['name'],'actor':actor,'realm':realm,'kind':e['kind'],'afterTypingMs':e['at']-start,'origin':e.get('origin'),'code':(e.get('reason')or{}).get('code'),'closed':e.get('closed'),'explicitlyClosed':e.get('explicitlyClosed'),'traceName':e.get('traceName'),'channel':e.get('channel'),'pending':e.get('pending'),'active':e.get('active'),'outPeak':e.get('outPeak'),'inPeak':e.get('inPeak')})
   terminal=[e['at']for _,rs,_ in groups for e in rs if e['kind']=='channel-close'and e['at']>=start];owner['firstChannelCloseAfterTypingMs']=min(terminal)-start if terminal else None;owner['firstActionableCeremonyFail']=next((e for e in owner['failCalls']if not e['closed']and not e['needsReboot']and not e['poisoned']),None);summary['owners'].append(owner)
  loads=[json.loads(z)for z in(out/'host-load.jsonl').read_text().splitlines()if '"kind":"load"'in z];summary['hostBusyMedian']=statistics.median(100-z['hostPercent']['idle']for z in loads);summary['hostBusyMax']=max(100-z['hostPercent']['idle']for z in loads);cases.append(summary)
(r/'trace327-summary.json').write_text(json.dumps(cases,indent=2)+'\n')
for name,vals in [('trace327-events.csv',events),('trace327-queues.csv',queues)]:
 with(r/name).open('w',newline='')as f:w=csv.DictWriter(f,fieldnames=list(vals[0]),lineterminator='\n');w.writeheader();w.writerows(vals)
start=json.loads((r/'canonical-start.json').read_text());assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==start['head'];assert subprocess.check_output(['git','diff','--cached','--name-only'],cwd=repo,text=True)==''
for n,h in start['files'].items():assert sha(repo/n)==h,n
(r/'independent327-check.json').write_text(json.dumps({'canonicalFilesUnchanged':len(start['files']),'head':start['head'],'realIndexEmpty':True,'frozenStagesVerified':3,'bothSourceVariantsServerAssetsHarnessAndFixtureHashesMatch':True,'cases':[{'name':c['name'],'childExit':c['childExit'],'coldFailure':c['coldFailure']}for c in cases],'observationOnly':True,'noLandingOrCredit':True},indent=2)+'\n')
print(json.dumps([{'name':c['name'],'functional':c['childExit']==0,'owners':[{'actor':o['actor'],'firstClose':o['firstChannelCloseAfterTypingMs'],'terminal':o['nativeTerminal'],'queueFull':len(o['queueFull']),'actionableWindowFail':o['firstActionableCeremonyFail']}for o in c['owners']]}for c in cases],indent=2))

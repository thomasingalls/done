from pathlib import Path
import json,gzip,hashlib,subprocess,shutil
r=Path(__file__).parent;repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');d=repo/'docs/performance-experiments/2026-10-29-worker-catchup/phase327';d.mkdir(exist_ok=False);items=[];seen=set();sha=lambda b:hashlib.sha256(b).hexdigest()
def keep(p,cat='evidence'):
 if not p.is_file()or p.is_symlink():return
 dest=d/cat/(str(p.relative_to(r))+'.gz')
 if str(dest)in seen:return
 seen.add(str(dest));raw=p.read_bytes();packed=gzip.compress(raw,compresslevel=6,mtime=0);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(packed);items.append({'source':str(p),'copy':str(dest.relative_to(d)),'rawSha256':sha(raw),'bytes':len(raw),'gzipSha256':sha(packed)})
for p in sorted(r.iterdir()):
 if p.is_file()and not p.is_symlink()and p.suffix in['.json','.jsonl','.log','.md','.csv','.py','.mjs','.txt','.diff']:keep(p,'apparatus'if p.suffix in['.py','.mjs']else'evidence')
for p in sorted(r.glob('*327-inputs.json')):
 x=json.loads(p.read_text())
 if'plan'not in x:continue
 for c in x['plan']:
  out=r/c['name']
  for glob in ['*.json','*.jsonl','*.log','artifacts/**/error-context.md']:
   for f in out.glob(glob):keep(f)
for p in(r/'harness/test/account-continuation-lab').rglob('*'):
 if p.is_file():keep(p,'apparatus')
for root in ['source','source-tagged']:
 for p in(r/root/'test').glob('labFault*327*.ts'):keep(p,'apparatus')
for folder in ['sender-reference','sender-coordinated-2000','tagged-reference']:
 for n in['build-identity.json','build-flags.json','frontend-build.log','lab-build.log']:keep(r/folder/n)
for left,right,name in [(Path('/private/tmp/done-page-reuse-repair-lab-20261101/sender-source'),r/'source','observation327.diff'),(r/'source',r/'source-tagged','native-tag327.diff')]:
 paths=set()
 for sub in['src','test']:
  paths|={str(p.relative_to(left))for p in(left/sub).rglob('*')if p.is_file()}|{str(p.relative_to(right))for p in(right/sub).rglob('*')if p.is_file()}
 chunks=[]
 for n in sorted(paths):
  a=left/n;b=right/n
  if a.exists()and b.exists()and a.read_bytes()==b.read_bytes():continue
  q=subprocess.run(['git','diff','--no-index','--binary','--',str(a)if a.exists()else'/dev/null',str(b)if b.exists()else'/dev/null'],capture_output=True);assert q.returncode in[0,1];chunks.append(q.stdout)
 p=r/name;p.write_bytes(b''.join(chunks));keep(p,'apparatus')
for name in ['PROTOCOL327.md','trace327-summary.json','trace327-events.csv','trace327-queues.csv','independent327-check.json']:shutil.copy2(r/name,d/name)
index={'labRoot':str(r),'labOnly':True,'acceptanceCredit':False,'noApplicationPatch':True,'compiledBuildsBrowserProfilesCredentialsDatabasesNotCopied':True,'items':items};(d/'evidence-index.json').write_text(json.dumps(index,indent=2)+'\n')
for x in items:assert gzip.decompress((d/x['copy']).read_bytes())==Path(x['source']).read_bytes();assert sha((d/x['copy']).read_bytes())==x['gzipSha256']
(d/'evidence-check.json').write_text(json.dumps({'copiesVerified':len(items),'allRawAndCompressedHashesMatch':True},indent=2)+'\n');print('Preserved',len(items),'exact evidence files')

# Isolated lab screen — operator approved, no landing or acceptance credit

Question: which components are worth hardening to improve the existing deep joined range4 catch-up?
One experimental unit is a fresh fictional joined-reader30s journey against the exact same copied
service fixture. All requests/auth clocks stay real; sourceaccepted before senderclosed as original.
Neither1024positions nor individual samples/requests are independent experimental replicates.
Main outcome: actual successful native inbound positions committed no later than start+30000ms.
Secondary: charged budgetunits(net acquire+reserve-refund), native commits, Window port messages,
ledger plaintext and retained ciphertext growth, each per committed position. Preserve raw counts,
time boundaries, scopes, invalid/refused work, failures and toggle exposures. No fallback to a
favorable rerun. Missing/failed rows stay in the table with observed progress/censoring.

Plain artifact enables development range writer explicitly, networkwidth4/nativeallowance4;
all seven lab toggles off, default16/session64/process and all other existing byte/policy limits.
One WorkerCPU diagnostic runs plain, sampling only the actual owner target after startup.
Separate sampled JSCPU from idle/await/native crypto wall spans; report profiler overhead/no credit.
Measure bytes/position and report where the ~28ms productive/~46ms empty wall estimates go without
pretending a JS sampler accounts for asynchronous CPU. Initial cold-open/fixture creation excluded.

Single build runtime A..G bits:
A empty reply still authenticated by the same owner/verifier, omit Window preparation for emptyonly.
B signed quiet-peer requests batched with the selected read, originals cached raw/unverified,
  freshly consumed under current owner/authority/cursor/expiry; discard nonempty speculativeextra.
C quiet budget3s only inside existing known-backlog-draining selection branch.
D actual per-publisher notification extension and targeted invalidation; ready/control staysglobal.
  Count exposure. Closed sender may cause zero named events: no unsupported D-effect claim.
E parallel request/page signatures and entry decision/envelope, cache public verify-key imports.
F UNSAFE page-once reference in process-local table, full originals still verified in this realm.
  Never persisted trust/real data. A cold owner losing its table MUST fail original reopening guard;
  retain external page bytes separately from apparent ledger savings. Cannot land as designed.
G native turn8; download remains4, two originalpages may share one native commit/turn. Labonly.

Eight-run saturated two-level L8: independent bitsx,y,z, factors[x,y,z,x^y,x^z,y^z,x^y^z].
Includes one plain row plus TWO additional plain repeats (three plain journeys total).
Fixed seeded randomized eight-cell order, plain repeats bracket that order; no reordering from
intermediate outcomes. ResolutionIII: main effects aliased with interactions, not seven identified
causal effects or significance tests. Report simple descriptive +/-mean contrasts and observed
plain spread; no within-journey pseudoreplicate CI. Target is hypothesis/candidate selection only.

Choose highest observed30spositions among rows with no native receive failure, ties by actual
completiontimeif1024reached, then fewerbudgetunits, then fixed lexicalbits. Large contributor for
ablation: positive aliased screening contrast exceeding max(10%plainmean, maxplain-minplain).
Rerun bestobserved stack once with each qualifying enabled contributor removed, preserving all
runs and acknowledging selection/noise. If nonequalify, ablate each enabled factor rather than
claiming no contributors. When allhitceiling, use completiontimecontrast and plain time spread.
Finally run that exact selected labstack through ONE frozen original-gate set. All existing16ms/
2.5speerp95 ANDeverymarker/30sdeep/600sbacklog/15scold/deadlines/native/durability checks unchanged.
Labgate pass never qualifies unsafeformat or cryptographic changes for landing. Any durableformat/
verification candidate is separately hardened alone, with patches/faultcontrols/manifest obligations.

No labcode/build lands. No signing/push/merge/deploy/releaseprep/preview/real profiles/computeruse.
Landing checkout prepared306default-off writer stays untouched by lab prototypes. Every failure
includingfrozen302input/304marker/305fairness/deep4/8/Page64and306full-unitred is retained.
22.378s v3installLocalBaseline publication is a lab state absent a shippedcaller. Separately measure
sameonepublication after actual v5retention, never by forging a counter or calling installLocalBaseline.

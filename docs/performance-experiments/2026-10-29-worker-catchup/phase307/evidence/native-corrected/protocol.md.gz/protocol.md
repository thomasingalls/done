# Frozen lab-best stack original-gate run — no acceptance or landing credit

Select exact observed C/E/F/G=0010111, same606asset artifact as eight-cell/two-repeat screen.
Unsafe F is retained deliberately; cold loss must fail, never hide it or substitute the safer ablation.
Original source, assertion bodies, deadlines and absolute gates remain. No retries or heavy parallel
work during measurements. All cells continue on independent fresh fixture/state after classified
lab failures; no failed cell disappears. Functional pass and timing acceptance remain distinct.

Coverage: original native public cold/context15s + resumable-maintenance cold/input/Undo; original
deepjoined30s/native/Undo/cold; two-receiver normal and hintwithheld16ms/2.5sp95/everymarker/30sfinal/
600sbacklog; actual maintenance+typing+catch-up normal/withheld; original unequal10device fairness
16ms/2.5sp95/600sbacklog/durablepending/isolation/Undo/cold; original7sentence80wpmGoals/refocus
desktop and4xmobile lab16ms diagnostic.900s/1200soriginal case bounds retained. No Page/WorkerABBA.

Runtime bits are fixture parameters. Context hook sets only lab sessionStorage and WorkerURL
query bits, noauth or writing. Because lab query variants are absent from ordinary precache, before
first offline transition it caches byte-identical existing Worker responses under those query
URLs. It changes no app/SWbytes or IndexedDB and does no offline reinjection. Existing source/SW
hash guards and original offline same-profile assertions remain. Failure after aliasing stays.

Late/fairness use the exact real-app2026-10-30fixture297/298 andUTC/editability preflight. Native
master-only cases retain their pinned original fixture. Maintenance prepared writer2is produced
by original signed0abclient replaying currentcivil fixture through real sync with PREP ONLY
discretionary reduction suppressed via hiddenvisibility; counter2/fullarchive/device factors
are independently checked. No storage data edits/fake epoch/auth clock. Measurement has normal
visibility and exact best stack. Preserve preparation errors rather than weaken census/guards.

No original gate raised or qualified by lab. No source/build lands, no crypto/format hardening
credit. v2development-only/default-off landing flag, stale-tab/rollback and release holds remain.

Before timing: the original maintenance fixture expected Page-only private observer globals.
Only maintenance cells use a separately identified observation artifact: same exact optimization
source, with one read-only native maintenance status/diagnostic insertion forwarded to the fixture.
Native diagnostic facts remain native; no counters inferred or relabelled. Every other cell uses
the exact606asset screening artifact. Original metric/guard bodies and deadlines are retained.
The maintenance old153ratio is computed as originally coded if reachable, but its historical
reference is not matched to this new civil fixture; it cannot earn nonregression credit. The
normal Page/Worker comparison remains held, no paired relative-effect claim.

Corrected apparatus before timing: the first attempt did not activate G/F in public clients
(only one read perHTTP and all cold checks passed). Keep every old result and mark public
cells invalid treatment, not best-stack acceptance. Install labcontext explicitly on each
actual returned context rather than mutating the imported BrowserType facade. Require an
active native admission realm with exactbits, max8position commits, Fpage table and Ekeycache
in a fresh disposable preflight before freezing. Original observers/gates remain. Split the
two native test bodies into separate Node processes; the old cleanup fallback timer refers
to dynamic FAIR_OUT and can stop the following test's container. No test body/assertion/deadline
change or favorable performance rerun. Gate set restarts only after treatment preflight passes.

Treatment preflight01refused: Worker constructor target had?lab=0010111but actualWorkerLocation
was canonical withoutquery; bits0000000/maxgroup4/Fpage0/Ecache0. Cache aliasing a native Response
retains its originalURL, causing that canonical Worker location. Reconstruct alias Response with
the exact original body/headers/status and empty responseURL so the requestURL/params remain.
Failed preflight and old adapter retained; require actual native bits/exposure proof afterward.

Native-only apparatus correction: the explicit-context AST wrapper joined the original token
await(conditionalBrowser).launchPersistentContext into awaitconfigureLabContext(...). All three
native bodies failed ReferenceError before setup; preserve them as invalid, not product failures.
Insert only the missing token separator in this adapter copy. Original app assets, optimizer
bits, native guard/test bodies, factor settings and deadlines remain exact. Run only those three
invalid cells in fresh individual processes after the other frozen cells finish. No retry of an
app/timing failure. Runtime exposures remain independently proved by treatment preflight02.

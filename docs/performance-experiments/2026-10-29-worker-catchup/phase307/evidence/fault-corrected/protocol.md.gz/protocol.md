# Frozen lab-best stack original-gate run — no acceptance or landing credit

Select exact observed C/E/F/G=0010111, same606asset artifact as eight-cell/two-repeat screen.
Unsafe F is retained deliberately; cold loss must fail, never hide it or substitute the safer ablation.
Original source, assertion bodies, deadlines and absolute gates remain. No retries or heavy parallel
work during measurements. All cells continue on independent fresh fixture/state after classified
lab failures; no failed cell disappears. Functional pass and timing acceptance remain distinct.

Coverage: original native public cold/context15s + resumable-maintenance cold/input/Undo; original
deepjoined30s/native/Undo/cold; two-receiver normal and hintwithheld16ms/2.5sp95/everymarker/30sfinal/
600sbacklog; actual maintenance+typing+catch-up normal/withheld; original unequal10device fairness
16ms/2.5sp95/600sbacklog/durablepending/isolation/Undo/cold; original7sentence80wpmGoals/refocus
desktop and4xmobile lab16ms diagnostic.900s/1200soriginal case bounds retained. No Page/WorkerABBA.

Runtime bits are fixture parameters. Context hook sets only lab sessionStorage and WorkerURL
query bits, noauth or writing. Because lab query variants are absent from ordinary precache, before
first offline transition it caches byte-identical existing Worker responses under those query
URLs. It changes no app/SWbytes or IndexedDB and does no offline reinjection. Existing source/SW
hash guards and original offline same-profile assertions remain. Failure after aliasing stays.

Late/fairness use the exact real-app2026-10-30fixture297/298 andUTC/editability preflight. Native
master-only cases retain their pinned original fixture. Maintenance prepared writer2is produced
by original signed0abclient replaying currentcivil fixture through real sync with PREP ONLY
discretionary reduction suppressed via hiddenvisibility; counter2/fullarchive/device factors
are independently checked. No storage data edits/fake epoch/auth clock. Measurement has normal
visibility and exact best stack. Preserve preparation errors rather than weaken census/guards.

No original gate raised or qualified by lab. No source/build lands, no crypto/format hardening
credit. v2development-only/default-off landing flag, stale-tab/rollback and release holds remain.

Before timing: the original maintenance fixture expected Page-only private observer globals.
Only maintenance cells use a separately identified observation artifact: same exact optimization
source, with one read-only native maintenance status/diagnostic insertion forwarded to the fixture.
Native diagnostic facts remain native; no counters inferred or relabelled. Every other cell uses
the exact606asset screening artifact. Original metric/guard bodies and deadlines are retained.
The maintenance old153ratio is computed as originally coded if reachable, but its historical
reference is not matched to this new civil fixture; it cannot earn nonregression credit. The
normal Page/Worker comparison remains held, no paired relative-effect claim.

Corrected apparatus before timing: the first attempt did not activate G/F in public clients
(only one read perHTTP and all cold checks passed). Keep every old result and mark public
cells invalid treatment, not best-stack acceptance. Install labcontext explicitly on each
actual returned context rather than mutating the imported BrowserType facade. Require an
active native admission realm with exactbits, max8position commits, Fpage table and Ekeycache
in a fresh disposable preflight before freezing. Original observers/gates remain. Split the
two native test bodies into separate Node processes; the old cleanup fallback timer refers
to dynamic FAIR_OUT and can stop the following test's container. No test body/assertion/deadline
change or favorable performance rerun. Gate set restarts only after treatment preflight passes.

Treatment preflight01refused: Worker constructor target had?lab=0010111but actualWorkerLocation
was canonical withoutquery; bits0000000/maxgroup4/Fpage0/Ecache0. Cache aliasing a native Response
retains its originalURL, causing that canonical Worker location. Reconstruct alias Response with
the exact original body/headers/status and empty responseURL so the requestURL/params remain.
Failed preflight and old adapter retained; require actual native bits/exposure proof afterward.


Supplemental invalid-fault replacement only: original06had200notification requests but Window-only
probe saw zero frames in both clients. It cannot count as hint-withheld. Keep that result.
This root runs ONLY06with unchanged best artifact and measurement/guard/deadline bodies.
Fault injection now filters actual authenticated server SSE hint/content writes, scoped to H1's
existing public credential. The role is derived by phase298semantic helper before any browser
starts; control refuses malformed/repeated target. Ready/heartbeat/other-device frames pass.
Native observed frame counts are read through a separate control message; the old >0withheld
assertion consumes that fact rather than inferred Window counts. No service authorization,
writing, storage, budget or optimization byte changes. Old Window probe stays but no longer
provides fault evidence. All native/screen/frozen original results remain separate and retained.


Fault adapter attempt1refused before any browser opened: phase298's helper describes the
later joined reading.candidate shape, while readerH1holds an older v1signed admission.
Keep that result. Lab-only role extraction also accepts that explicitv1admission's
admittingCredential, which the native verifier compares to its readerID. Require one exact
32hex target as before. No storage or authority edits. Same one-cell plan and artifact.


Correction retained: attempt2also refused before opening a browser because the lab adapter
incorrectly assumed admission.v=1. The actual content admission isv2with selfAdmitted0;
account-protocol/membershipCheckpoint.ts extracts admittingCredential and
src/crdt/membershipReading.ts compares it to readerID. Use that exact observed shape.
The two rejected pre-setup attempts earn no timing/fault evidence and stay preserved.

# Phase272 — original native after-walkthrough on exact cumulative candidate

2026-10-30. Verify271leadinglogicalstatezero repair against actual native/browser paths. Build
exactcumulative runtime from0ab+existing248yield+271streamfix, no other source changes. Production
settings/warmunset, noLEDGER_PROFILE or failure/CPU hooks, original16/session64/process limits,
same actual Nodeimage/caps/native crypto/factors/cohort/strict storage/authority/history/journal.
Independent396source-map bodies/125frontendasset closure and allsourcebytesmatchcandidate.

Four original260casebodies/helpers/assertions/deadlines, relocated roots only, once fresh/serial:
1 senderclosedactor0/realreceive/Undo/originalcold;2 deepjoinedactor1/original30scatchup;3 actual
journal-era install/rebind/inputUndo/publiccold15s;4 actualresumablepreparation/savedslicecoldresume/
coveredhistoryremoval/subsequentinputUndo/publiccold15s. Fullcase180s retained. No diagnosticextra
observation, retry, changedexpected writing/factors or assertion removal. Failure retained and
classified; no laterpasserasesbefore261/265/267/269. Specifically repairclaimneeds fullcase4exact
archive/cold afterrealremoval, not just unittransport or partialmaintenance success. Case3 still
has measured repeatedbaseline cost; onepass cannotestablishno slowopening or physicalphone result.

Beforetiming require discovery4cases, actualstartup16/session64/process policy and readiness/
shutdown smoke. Freeze source/harness/asset/browser/fixture inputs before running. No otherheavy
hostwork/build/profile duringmeasurements. Prioroperatorquietcoordination carriesforward; OS/cache/
thermal variation remains. Wholecasesareunits, oneeach; no poweredpopulationcausal/runtimegainclaim.
This is not120key/markerlatency campaign andearns no broader16ms/2.5s/allmarker/600sacceptance.
Originalnative30s/15schecksremainbinding. No oldtestedit, sign/push/releaseprep/deploy/preview/
serviceautomation/CUA/phone/realdata. LaternormalPageWorkerhigherbudgetcompare stillrequiresvalid
civilfixture; repeatedbaselineproof reuse/yielddecision remain separate bounded work.

from pathlib import Path
import json,hashlib,re
r=Path(__file__).parent;baseline=r;src=r/'source-after';sha=lambda b:hashlib.sha256(b).hexdigest();identity=json.loads((r/'source-inputs.json').read_text());assert all(sha((src/p).read_bytes())==h for p,h in identity['files'].items());release=json.loads((r/'release-flags.json').read_text());assert json.loads((r/'build-flags.json').read_text())==release['expected'];assert not list((r/'lab').glob('.env*'));actualRelease=release['compiledGateReads'][0]['flags'];matched={};flags=[]
for f in(r/'combined-dist').rglob('*.map'):
 m=json.loads(f.read_text())
 for name,body in zip(m['sources'],m.get('sourcesContent',[])):
  key=next((prefix+'/'+name.split('/'+prefix+'/',1)[1]for prefix in ['src','account-protocol','private','wasm']if'/'+prefix+'/'in name),None)
  if key and(src/key).is_file():assert body.encode()==(src/key).read_bytes(),key;matched[key]=sha(body.encode())
for f in(r/'combined-dist').rglob('*.js'):
 for m in re.finditer(r'\{[^{}]*VITE_ACCOUNT_[^{}]*\}',f.read_text()):
  d=dict(re.findall(r'(VITE_ACCOUNT_\w+):[`"]([^`"]*)[`"]',m[0]))
  if 'VITE_ACCOUNT_BASELINE_READ'in d:assert d==actualRelease,(f,d);flags.append({'file':str(f.relative_to(r/'combined-dist')),'flags':d})
assert flags and 'src/crdt/accountCapture.ts'in matched
frontendAssets={str(f.relative_to(r/'frontend')):sha(f.read_bytes())for f in(r/'frontend').rglob('*')if f.is_file()};assert all(sha((r/'combined-dist'/p).read_bytes())==h for p,h in frontendAssets.items())
report={'commit':identity['baseCommit'],'sourceBodies':len(matched),'publicFrontendExactAssets':len(frontendAssets),'compiledFlagObjects':flags,'warmLoads':'unset/default-on','explicitFixtureExceptions':{'labPreparationIdentity':'originalzero retained','diagnosticHooks':False,'candidate':'exact current271runtime'},'originalCases':['sender-closed actor0','deep joined sender-closed actor1 with original30s','context/journal-rebind publiccold with original15s','resumable reduction publiccold with original15s']};(r/'qa.json').write_text(json.dumps(report,indent=2)+'\n');print({k:v for k,v in report.items()if k!='compiledFlagObjects'})
files=[f for f in(r/'harness').rglob('*')if f.is_file()and not f.is_symlink()and 'node_modules'not in f.parts];files +=[f for f in(r/'lab').iterdir()if f.is_file()and not f.is_symlink()];files +=[f for f in(r/'test-inputs').rglob('*')if f.is_file()];files +=[r/'source-after'/n for n in identity['files']];files +=[r/n for n in ['run.py','build.mjs','build-flags.json','release-flags.json','protocol.md','source-inputs.json','build-receipt.json','container-image.json','container-service.mjs','observer.mjs','build-identity.json','qa.json']]
(r/'frozen-inputs.json').write_text(json.dumps({str(f.relative_to(r)):sha(f.read_bytes())for f in files},indent=2)+'\n')

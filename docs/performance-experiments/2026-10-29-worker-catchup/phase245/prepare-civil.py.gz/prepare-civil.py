from pathlib import Path
import json,hashlib,datetime
r=Path(__file__).parent;h=r/'harness/test/account-continuation-lab';s=(h/'late.spec.ts').read_text();assert s.count('viewport:{width:1440,height:1000}')==2;s=s.replace('viewport:{width:1440,height:1000}',"viewport:{width:1440,height:1000},timezoneId:'UTC'")
anchor=" const open=async(index:number)=>";assert s.count(anchor)==1
helper=""" const captureDiagnostic=async()=>{if(result.ownerEvents)return;const events:any[]=[],clocks:any[]=[];for(const[index,ctx]of contexts.slice(0,2).entries()){const p=ctx.pages()[0];if(!p||p.isClosed())continue;const workers=p.workers();events.push({label:'H'+(index+1),realms:[await p.evaluate(()=>structuredClone((window as any).__ownerTrace??{rows:[],dropped:0})),...await Promise.all(workers.map(w=>w.evaluate(()=>structuredClone((self as any).__ownerTrace??{rows:[],dropped:0}))))]});const rows=[];for(const w of workers){const bracket=[];for(let i=0;i<5;i++){const before=performance.timeOrigin+performance.now();const renderer=await w.evaluate(()=>performance.timeOrigin+performance.now());const after=performance.timeOrigin+performance.now();bracket.push({before,renderer,after});}rows.push(bracket);}clocks.push({label:'H'+(index+1),rows});}result.ownerEvents=events;result.workerClocks=clocks;result.diagnosticProbes=await Promise.all(contexts.slice(0,2).map(async c=>{const p=c.pages()[0];return p&&!p.isClosed()?await p.evaluate(()=>({probe:(window as any).__late.read(),cards:[...document.querySelectorAll('.card')].filter(c=>c.textContent?.includes('Fair H reverse:')).map(c=>({frozen:c.getAttribute('data-frozen'),editing:c.getAttribute('data-editing')})),civilDate:[new Date().getFullYear(),new Date().getMonth()+1,new Date().getDate()],timezone:Intl.DateTimeFormat().resolvedOptions().timeZone})):null;}));};
"""
s=s.replace(anchor,helper+anchor)
anchor='const offerMarker=async()=>{const i=';assert s.count(anchor)==1;s=s.replace(anchor,"const offerMarker=async()=>{await expect(card(writer.p,'H',true)).toHaveAttribute('data-frozen','false');await expect(card(writer.p,'H',true)).toHaveAttribute('data-editing','true');const i=")
anchor="result.clocks.push({phase:'after',rows:";assert s.count(anchor)==1;s=s.replace(anchor,'await captureDiagnostic();'+anchor)
anchor=' finally{await Promise.all(contexts.map';assert s.count(anchor)==1;s=s.replace(anchor," finally{try{await captureDiagnostic();}catch(e){result.diagnosticCaptureError=String(e);}await Promise.all(contexts.map")
(h/'marker-civil.spec.ts').write_text(s);(h/'marker-civil.config.ts').write_text((h/'late.config.ts').read_text().replace('late.spec.ts','marker-civil.spec.ts'))
# Preserve independent original harness diff rather than claiming byte identity for new guards/timezone.
import difflib
(r/'marker-civil-harness.patch').write_text(''.join(difflib.unified_diff((h/'late.spec.ts').read_text().splitlines(True),s.splitlines(True),fromfile='a/late.spec.ts',tofile='b/marker-civil.spec.ts')))
# Real epoch stays real; only locale-based calendar interpretation changes.
assert datetime.datetime.now(datetime.timezone.utc).date().isoformat()=='2026-10-29'
print('Civil diagnostic prepared; added guards + failure-safe trace and actual Worker clock brackets, real epoch unchanged')

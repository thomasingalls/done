# Phase258 — production-flag Page/Worker baseline

2026-10-30. Before Page8d6d42c1c723f3dff7c7822b2358a813dc8c16e6, after Worker
0ab9cbc8937e32c6542aaeeca697c87ba116c3be. Both rebuilt from exact signed source.
The phase248 publisher-yield repair is excluded. Server fixed to signed0ab in all cases.
The question is whether the conversion has a >1.10 whole-journey catch-up ratio on this fixture
at released build settings, rather than the earlier conditional WARM_LOADS=0 setting.

Fixed normal-hint ABBA order: Page, Worker, Worker, Page. Four fresh independent services/profile
populations; no retries. Journey, not key/publisher, is the analysis unit. Primary measure is the
maximum of the two original receivers' complete-backlog duration. Pair02/01 and03/04; both>1.10
is the predeclared investigation signal. Both<=1.10 fails to reproduce that signal; mixed is
inconclusive. Report all absolute outcomes, differences, ratios and geometric mean descriptively;
two pairs on one synthetic account cannot estimate population precision or physical-phone behavior.

Actual build settings equal released compiled-flags.expected; strip inherited VITE_ACCOUNT_*;
no .env files. WARM_LOADS remains UNSET. Compiled gate dictionaries must independently equal the
actual release's compiled reads, and every emitted source-map body and selected source/asset hash
must match. Default ledger incremental and text direct come from actual Vite config, not overrides.
Before each case check flags/harness/assets/browser/fixture hashes and own resource cleanup.

Everything else retains phase241's workload/observers/server caps/browser/guards, with the already
recorded civil-only Etc/GMT+12 interpretation needed for fixtureOct27 to remain editable onOct29.
No epoch/auth clock override. Before each900s case require current and +900s civil dateOct29;
assert actual browser date/editability. Original120native keys500ms/3markers33/513/993, normal
notifications in Page and real Workers. No CPU/stage/input diagnostic profiling in this baseline.
Original16ms inputp95,2.5s peerp95 AND everymarker,30s final-delivery,600s backlog,15s openSaved,
exact archive/cold/no-reinjection/crypto/native storage/journal/fencing guards remain binding.
Absolute timing misses do not stop later fixed cases; functional failure is retained and stops
for classification. Censored time is not successful zero. No favorable reruns or extended deadlines.

Operator confirms “Host is quiet now” before this block. Run serially with no other work/builds/
scans while timing; this coordinates workload but does not establish perfect OS/thermal isolation.
Same physical host, current browser, identical fictional fixture and fresh profiles control several
confounders; OS caches and temperature can drift, hence opposite-order pairs. No claims about
historic100s/200s values across dates. Raw observations and independent reconstruction are retained.
Source/flags and real native archives establish comparability; the fixed workload is not exhaustive
security qualification. All native authority/history/ledger/witness/fresh-commit checks are actual.

Freeze inputs before timing; readiness/discovery smoke first. Keep any failed preparation separate
from timed results. Preserve prior warm-off results and reported contaminated measurements257.
Close with raw reconstruction, cleanup and durable records before any next mechanism. If>1.10
signal repeats, attribute work/counts/profile before repair. Original public cold and deep joined
cases at production flags follow separately; baseline's offline guard is not a substitute for them.
No signing/push/release prep/deploy/preview/service automation/CUA/phone/real profiles.

from pathlib import Path
import shutil,json,hashlib,subprocess,os,time,re
m=Path(__file__).parent;old=Path('/private/tmp/done-due-send-yield-20261030');r=Path('/private/tmp/done-production-worker-baseline-20261030');repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');r.mkdir();sha=lambda b:hashlib.sha256(b).hexdigest()
for variant in ['before','after']:
 shutil.copytree(m/('source-'+variant),r/('source-'+variant),symlinks=True)
 (r/(variant+'-source-inputs.json')).write_bytes((m/(variant+'-source-inputs.json')).read_bytes())
(r/'source-R').symlink_to(r/'source-after',target_is_directory=True);(r/'private-fixture').symlink_to(old/'private-fixture',target_is_directory=True)
for name in ['container-image.json','container-service.mjs','observer.mjs','notification-probe.mjs','notification-probe.d.mts','read-request.mjs','read-request.d.mts','playwright-storage-source.txt','analyze-case.py','run.py','smoke.mjs']:
 (r/name).write_bytes((old/name).read_bytes().replace(str(old).encode(),str(r).encode()))
(r/'compare.py').write_bytes((m/'compare.py').read_bytes());(r/'run-plan.json').write_bytes((m/'run-plan.json').read_bytes())
shutil.copytree(old/'harness',r/'harness',symlinks=True,ignore=shutil.ignore_patterns('node_modules','test-results','artifacts'));(r/'harness/node_modules').symlink_to(repo/'node_modules',target_is_directory=True)
for f in(r/'harness').rglob('*'):
 if f.is_file()and not f.is_symlink()and f.suffix in ['.mjs','.ts','.json']:
  b=f.read_bytes();f.write_bytes(b.replace(str(old).encode(),str(r).encode()))
p=r/'harness/test/account-continuation-lab/runtime.mjs';s=p.read_text();assert "source='"+str(r/'source-before')+"'"in s;s=s.replace("source='"+str(r/'source-before')+"'","source='"+str(r/'source-after')+"'");p.write_text(s)
release=json.loads((repo/'docs/development-evidence/2026-10-28-resumable-sync-release/compiled-flags.json').read_text());flags=release['expected'];assert 'VITE_ACCOUNT_WARM_LOADS'not in flags;(r/'release-flags.json').write_text(json.dumps(release,indent=2)+'\n');(r/'build-flags.json').write_text(json.dumps(flags,indent=2)+'\n')
# Rebuild both exact signed client populations. No inherited VITE_ACCOUNT_* or .env override.
node='/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node';rows=[]
for variant in ['before','after']:
 src=r/('source-'+variant);identity=json.loads((r/(variant+'-source-inputs.json')).read_text());assert all(sha((src/p).read_bytes())==h for p,h in identity['files'].items());assert not list(src.glob('.env*'))
 cleaned={k:v for k,v in os.environ.items()if not k.startswith('VITE_ACCOUNT_')};env={**cleaned,**flags,'PATH':str(Path(node).parent)+':'+os.environ['PATH'],'APP_BUILD_REVISION':identity['commit'],'APP_BUILD_DATE':'2026-10-30'}
 actual={k:v for k,v in env.items()if k.startswith('VITE_ACCOUNT_')};assert actual==release['expected']and 'VITE_ACCOUNT_WARM_LOADS'not in actual
 cmd=[node,str(src/'node_modules/vite/bin/vite.js'),'build','--outDir',str(r/(variant+'-dist')),'--emptyOutDir','--sourcemap'];start=time.time_ns()//1000000
 with(r/(variant+'-build.log')).open('w')as f:proc=subprocess.run(cmd,cwd=src,env=env,stdout=f,stderr=subprocess.STDOUT)
 assert proc.returncode==0,(variant,proc.returncode);assets={str(f.relative_to(r/(variant+'-dist'))):sha(f.read_bytes())for f in(r/(variant+'-dist')).rglob('*')if f.is_file()};(r/(variant+'-assets.json')).write_text(json.dumps(assets,indent=2)+'\n');rows.append({'variant':variant,'sourceCommit':identity['commit'],'flags':actual,'removedInheritedKeys':sorted(k for k in os.environ if k.startswith('VITE_ACCOUNT_')),'noEnvFiles':True,'warmLoads':'unset: default enabled by actual source','startedAt':start,'finishedAt':time.time_ns()//1000000,'command':cmd,'assetCount':len(assets)});print(variant,'production flags built',len(assets),'assets',flush=True)
(r/'build-receipts.json').write_text(json.dumps(rows,indent=2)+'\n')
print('Production baseline prepared, fixed signed Worker server; original source248 repair excluded')

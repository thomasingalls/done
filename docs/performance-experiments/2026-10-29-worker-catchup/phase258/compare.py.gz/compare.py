from pathlib import Path
import json,math,hashlib
r=Path(__file__).parent;plan=json.loads((r/'run-plan.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest();rows=[]
for c in plan:
 p=r/c['name'];x=json.loads((p/'result.json').read_text());a=json.loads((p/'analysis.json').read_text())
 assert x['outcome']=='passed'and all(x['guards'].values()),c['name']
 assert len(x['offers'])==123 and len(x['catchups'])==2 and all(v['outcome']=='passed'for v in x['catchups'])
 assert all(root['workerSha256']==json.loads((r/(c['variant']+'-assets.json')).read_text())['sw.js']for root in x['roots'])
 keys=sorted((q for q in x['offers']if q['kind']=='key'),key=lambda q:q['index']);markers=sorted((q for q in x['offers']if q['kind']=='marker'),key=lambda q:q['index']);assert [q['index']for q in keys]==list(range(120));assert [q['index']for q in markers]==[0,1,2]
 p95=[];markerTimes=[]
 for device,probe in enumerate(x['probes']):
  clocks=[v for phase in x['clocks']for v in phase['rows'][device]];low=max(v['renderer']-v['after']-1 for v in clocks);high=min(v['renderer']-v['before']+1 for v in clocks);assert low<=high
  arrivals=[]
  for index,offer in enumerate(keys,1):
   matches=[q['at']for q in probe['counts']if q['count']>=x['baselines'][device]+index and q['at']>=offer['at']-5];assert matches;arrivals.append(matches[0]-offer['at']-low)
  p95.append(sorted(arrivals)[math.ceil(.95*len(arrivals))-1]);markerTimes.append([probe['markers'][i]-q['at']-low for i,q in enumerate(markers)])
 assert math.isclose(p95[0],a['peerUpperMs']['p95'],abs_tol=1e-8);assert math.isclose(p95[1],a['localUpperMs']['p95'],abs_tol=1e-8);assert markerTimes[0]==a['markerPeerUpperMs']
 expected={'local16ms':p95[1]<=16,'peer2500ms':p95[0]<=2500,'everyMarker2500ms':max(markerTimes[0])<=2500,'finalNewDelivery30s':x['newDeliveryAt']-max(v['returnedAt']for v in x['offers'])<=30000}
 assert all(a['gates'][k]==v for k,v in expected.items())
 assert all(v['ready']>0 for v in x['notifications']);assert not x['withhold']
 limits=x['metrics']['cgroupAfter'];assert limits['cpu.max']=='100000 100000'and limits['memory.max']=='1073741824'and limits['pids.max']=='128';events=dict(line.split()for line in limits['memory.events'].splitlines());assert all(events[k]=='0'for k in ['oom','oom_kill','oom_group_kill'])
 endpoints={}
 for q in x['network']:
  key=q['path']+' '+str(q.get('status','missing'));endpoints[key]=endpoints.get(key,0)+1
 rows.append({'case':c['name'],'variant':c['variant'],'backlogSeconds':a['backlogMs']/1000,'receiversSeconds':{v['label']:(v['completedAt']-x['startedAt'])/1000 for v in x['catchups']},'localP95ms':p95[1],'peerP95ms':p95[0],'markersMs':markerTimes[0],'gates':a['gates'],'accepted':a['accepted'],'serviceRequests':x['metrics']['requests'],'serviceCpuMicros':x['metrics']['cpu'],'requestCounts':endpoints,'resultSha256':sha((p/'result.json').read_bytes())})
pairs=[]
for before,after in [(rows[0],rows[1]),(rows[3],rows[2])]:
 pairs.append({'before':before['case'],'after':after['case'],'ratio':after['backlogSeconds']/before['backlogSeconds'],'differenceSeconds':after['backlogSeconds']-before['backlogSeconds']})
ratios=[v['ratio']for v in pairs];decision='reproducible slowdown signal'if all(v>1.10 for v in ratios)else'no substantial slowdown reproduced'if all(v<=1.10 for v in ratios)else'inconclusive opposite-order pairs'
report={'beforeCommit':'8d6d42c1c723f3dff7c7822b2358a813dc8c16e6','afterCommit':'0ab9cbc8937e32c6542aaeeca697c87ba116c3be','server':'fixed after source','rows':rows,'pairs':pairs,'geometricMeanRatio':math.sqrt(math.prod(ratios)),'decision':decision,'scope':'Two pairs of complete journeys on one retained synthetic fixture; no population precision or one-function causal claim','acceptance':'Every original absolute gate remains independently binding'}
(r/'comparison.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k!='rows'},indent=2))

# R screen — every run, no credit

|Run|R|Peerp95s|Localp95ms|Keysafterreaderdrain|Repair activations Δ(reader)|Quietreads Δ(reader)|Tokens typing|Worstmarkers|Cold|
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|
|late-withheld-1-R0|0|17.928|3.718|67|0|159|1023|0.901|pass|
|late-withheld-2-R1|1|2.384|3.986|59|49|248|1175|1.343|pass|
|late-withheld-3-R1|1|2.407|3.107|69|47|235|1116|1.187|pass|
|late-withheld-4-R0|0|19.038|4.263|67|0|167|1025|1.565|pass|
|idle-withheld-R0|0|17.586|3.352|120|0|51|228|15.054|pass|
|idle-withheld-R1|1|12.773|3.190|120|24|139|341|15.633|pass|
|late-normal-R0|0|1.055|3.548|34|0|603|1483|1.008|pass|
|late-normal-R1|1|1.089|3.591|35|7|601|1476|0.814|pass|

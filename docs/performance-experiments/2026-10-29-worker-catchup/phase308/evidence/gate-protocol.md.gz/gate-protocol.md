Original gate order/count/deadlines were declared in PROTOCOL before deep timing.
Best explored stackG/V/R, D0/Coff, exact same runtime/artifact as screen. Lab-only/no credit.
Thirty independent runs (10cells×3), fresh profiles/state/services each. Native original specs
have NOscreenhold and original marker/Undo/15scold/30sdeep code. Late same original bodies and
serverfault, with post-drain exposure/counter observations. Maintenance same old preparedfixture
and every assertion; >=60predicate remains in original analyzer. All original analyzers retained
including old153relative comparison, though unmatched reference cannot earn a causal comparison.
Any failedreplicate fails its cell; no average, no favorable retry. Every run retained. STOPon
ANYnoFcold failure. A functional or timing failure otherwise stays visible and later declared
replicates still run. Dates checked before civil cases; expiredfixture refuses before timing.
HistoricalvariantC is just the old fixture label, NOTfactorC; runtimequiet750, sourcepinned.
GoalsrAFdiagnostic has no substitute16msgate/phone credit. All absolute16ms/2.5s/eachmarker/
30s/600s/15s/native/security/limits preserved. No source change/qualification from this apparatus.

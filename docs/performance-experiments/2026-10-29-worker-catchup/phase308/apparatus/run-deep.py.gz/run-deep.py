from pathlib import Path
import os,json,subprocess,time,hashlib,sys
r=Path(__file__).parent;node='/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();plan=json.loads((r/'deep-plan.json').read_text());assert len(plan)==8
sources={str(p.relative_to(r/'source')):sha(p)for p in(r/'source').rglob('*')if p.is_file()and not p.is_symlink()and'node_modules'not in p.parts and p.suffix not in ['.tsbuildinfo']};assets={str(p.relative_to(r/'combined-dist')):sha(p)for p in(r/'combined-dist').rglob('*')if p.is_file()};assert assets==json.loads((r/'build-identity.json').read_text())['files'];assert not(r/'lab-types.log').read_text().strip()
inputs={'sources':sources,'assets':assets,'plan':plan,'protocolSha256':sha(r/'PROTOCOL.md'),'deepSpecSha256':sha(r/'harness/test/account-continuation-lab/worker-owner.spec.ts'),'labOnly':True,'acceptanceCredit':False};(r/'deep-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n');rows=[]
for cell in plan:
 assert all(sha(r/'source'/n)==h for n,h in sources.items());assert all(sha(r/'combined-dist'/n)==h for n,h in assets.items());assert sha(r/'harness/test/account-continuation-lab/worker-owner.spec.ts')==inputs['deepSpecSha256']
 out=r/cell['name'];out.mkdir(mode=0o700,exist_ok=False);env={**os.environ,'PATH':str(Path(node).parent)+':'+os.environ['PATH'],'FAIR_OUT':str(out),'FAIR_DIST':str(r/'combined-dist'),'FAIR_LAB_BITS':cell['bits'],'RANGE_LAB_BITS':cell['bits'],'FAIR_VARIANT':'GV','QUIET_WITHHOLD':'0','CHROMIUM_PATH':'/private/tmp/done-civil-gates-browser-20261030/Chrome.app/Contents/MacOS/Google Chrome'};cmd=[node,'node_modules/@playwright/test/cli.js','test','--config','test/account-continuation-lab/'+cell['config'],'--grep',cell['grep']]
 if not rows:
  with(r/'deep-list.log').open('w')as f:p=subprocess.run(cmd+['--list'],cwd=r/'harness',env=env,stdout=f,stderr=subprocess.STDOUT)
  assert p.returncode==0,'List preflight failed before browser cells'
 print('START',cell['name'],flush=True);start=time.time()
 with(out/'console.log').open('w')as f:p=subprocess.run(cmd,cwd=r/'harness',env=env,stdout=f,stderr=subprocess.STDOUT)
 x=json.loads((out/'deep-gv/result.json').read_text())if(out/'deep-gv/result.json').exists()else{};row={**cell,'exit':p.returncode,'startedAt':start,'finishedAt':time.time(),'command':cmd,'outcome':x.get('outcome'),'error':x.get('error'),'timeTo700Ms':x.get('timeTo700Ms'),'timeTo1025Ms':x.get('timeTo1025Ms'),'positionsAt30':x.get('positionsAt30'),'deep30Pass':x.get('deep30Pass',False),'coldFailure':bool(x.get('coldFailure')),'guards':x.get('guards',{}),'labOnly':True,'acceptanceCredit':False};(out/'receipt.json').write_text(json.dumps(row,indent=2)+'\n');rows.append(row);(r/'deep-results.json').write_text(json.dumps(rows,indent=2)+'\n');print('RESULT',json.dumps(row),flush=True)
 if row['coldFailure']or(x.get('coldAttemptStarted')and not x.get('guards',{}).get('originalAccountReaderColdExact')):
  (r/'STOP.json').write_text(json.dumps({'rule':'Any no-F cold failure stops immediately','case':row},indent=2)+'\n');print('STOP: no-F cold failure; later work is withheld',flush=True);sys.exit(3)
print('ALL EIGHT DEEP CELLS RETAINED',flush=True)

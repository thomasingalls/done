from pathlib import Path
import json
r=Path(__file__).parent; rows=json.loads((r/'gate-results.json').read_text());assert len(rows)==30;out=[]
for row in rows:
 p=r/row.get('artifactDir',row['name']);a=json.loads((p/'analysis.json').read_text())if(p/'analysis.json').exists()else None;data={**row,'functionalPass':row['functionalExit']==0,'qualification':'Lab-only challenge; no acceptance credit.'}
 if row.get('mode'):
  data.update({'inputP95ms':a['localUpperMs']['p95'],'peerP95ms':a['peerUpperMs']['p95'],'worstMarkerMs':max(a['markerPeerUpperMs']),'backlogMs':a['backlogMs'],'failedPredicates':[k for k,v in a['gates'].items()if not v],'allOriginalPredicates':all(a['gates'].values()),'keysDuringBacklog':a.get('keysDuringBacklog')})
 elif row['cell']=='fairness':
  q=a['runs'][0];data.update({'inputP95ms':q['localMs']['p95'],'peerP95ms':q['peerObservedSubsetMs']['p95'],'allOriginalPredicates':q['primaryAcceptance'],'failedPredicates':[k for k,v in q['gates'].items()if not v],'longestBackgroundMs':max(c['completedAt']-c['startedAt']for c in q['backgroundReplay']),'allDataGuards':all(q['guards'].values())})
 elif row['cell'].startswith('goals'):
  data.update({'allOriginalPredicates':row.get('diagnosticAnalysisExit')==0,'paragraphBeforeinputP95ms':a['offerToBeforeinputUpperMs']['p95'],'paragraphRafP95ms':a['offerToRafUpperMs']['p95'],'paragraphRafMaxMs':a['offerToRafUpperMs']['max'],'paragraphRafOver100ms':a['offerToRafUpperMs']['over100ms'],'allDataGuards':all(a['guards'].values()),'qualification':'Goals diagnostic, not the existing local mutation16ms or peer gate; rAF tails retained.'})
 else:
  q=json.loads(next(p.glob('*/result.json')).read_text());data.update({'allOriginalPredicates':q['outcome']=='passed'and all(q['guards'].values()),'nativeGuards':q['guards']})
  if row['cell']=='native-deep':data['deepMs']=q['catchupWaitMs']
 out.append(data)
(r/'gate-analysis.json').write_text(json.dumps(out,indent=2)+'\n');lines=['# Original-gate challenge — all thirty journeys','', 'One failed replicate fails its cell. Every lab run earns no credit. Goals paragraph rAF is a diagnostic, not the16ms mutation gate.','', '|Journey|Functional|Original predicates|Input p95 ms|Peer p95 ms|Worst marker ms|Deep ms / overlap keys|Failure|','|---|---|---|---:|---:|---:|---|---|']
for x in out:
 f=lambda k: '-'if x.get(k)is None else f"{x[k]:.3f}"
 lines.append('|'+ '|'.join([x['name'],'pass'if x['functionalPass']else'FAIL','pass'if x['allOriginalPredicates']else'FAIL',f('inputP95ms'),f('peerP95ms'),f('worstMarkerMs'),str(x.get('deepMs',x.get('keysDuringBacklog','-'))),','.join(x.get('failedPredicates',[]))])+'|')
(r/'GATES.md').write_text('\n'.join(lines)+'\n');print('30 retained;',sum(not x['allOriginalPredicates']for x in out),'failed-predicate journeys')

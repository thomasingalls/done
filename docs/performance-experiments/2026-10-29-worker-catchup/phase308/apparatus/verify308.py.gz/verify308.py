from pathlib import Path
import json,gzip,hashlib,re,math,subprocess
repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');r=Path('/private/tmp/done-range-vgr-lab-20261030');out=repo/'docs/performance-experiments/2026-10-29-worker-catchup/phase308';load=lambda p:json.loads(p.read_text());sha=lambda b:hashlib.sha256(b).hexdigest();idx=load(out/'evidence-index.json');assert not(r/'STOP.json').exists()
for x in idx['files']:
 raw=gzip.decompress((out/x['artifact']).read_bytes());assert sha(raw)==x['sourceSha256'];assert sha((out/x['artifact']).read_bytes())==x['artifactSha256'];assert raw==Path(x['source']).read_bytes(),x['source']
refs={x['source']for x in idx['files']};journeys=1
assert str(r/'step1-idle-diagnostic/run01/result.json')in refs
for lane,count in [('deep',8),('r',8),('gate',30),('grown',6),('named',6),('named-wired',6)]:
 p=load(r/(lane+'-plan.json'));a=load(r/(lane+'-results.json'));assert len(a)==len(p)==count;assert {q['name']for q in a}=={q['name']for q in p}
 for q in a:
  d=r/q.get('artifactDir',q['name']);files=list(d.glob('result.json'))+list(d.glob('*/result.json'));assert len(files)==1,(d,files);assert str(files[0])in refs;z=load(files[0]);assert not z.get('coldFailure')
 journeys+=count
assert journeys==65
# Independent native-event accumulation verifies uncapped milestones and first-crossing bins.
for q in load(out/'deep-analysis.json'):
 x=load(r/q['name']/'deep-gv/result.json');n=0;cross={0:x['startedAt']};positions30=0
 for e in x['worker']['events']:
  if e['kind']!='inboundCommit'or e['at']<x['startedAt']:continue
  old=n;n+=e['positions'];
  if e['at']<=x['startedAt']+30000:positions30+=e['positions']
  for k in [*range(100,1001,100),700,1025]:
   if old<k<=n and k not in cross:cross[k]=e['at']
 assert n==1025 and positions30==q['positionsAt30'];assert abs(q['timeTo700Ms']-(cross[700]-cross[0]))<.001;assert abs(q['timeTo1025Ms']-(cross[1025]-cross[0]))<.001
 for b in q['msPer100']:assert abs(b['elapsedMs']-(cross[b['throughPosition']]-cross[b['fromPositionExclusive']]))<.001
# Independent raw-probe threshold selection; no use of stored per-key latency arrays.
latencyRuns=0
for name in ['r-analysis.json','grown-analysis.json','named-analysis.json','named-wired-analysis.json']:
 for q in load(out/name):
  x=load(r/q['name']/'result.json');offers=[z for z in x['offers']if z['kind']=='key'];assert len(offers)==120
  for device,metric in [(0,'peerMs'),(1,'localMs')]:
   probes=x['probes'][device]['counts'];bounds=[z for g in x['clocks']for z in g['rows'][device]];lower=max(z['renderer']-z['after']-1 for z in bounds);upper=min(z['renderer']-z['before']+1 for z in bounds);assert lower<=upper;values=[]
   for i,o in enumerate(offers,1):
    observed=min(z['at']for z in probes if z['count']>=x['baselines'][device]+i and z['at']>=o['at']-5);values.append(observed-o['at']-lower)
   values.sort();assert abs(values[math.ceil(.95*len(values))-1]-q[metric]['p95'])<.001
  latencyRuns+=1
for q in load(out/'grown-analysis.json'):assert q['keysDuringBacklog']>=60 and q['maintenanceCompletions']==0 and q['counterVersionAfterFailure']==2 and q['cold']=='not reached'and not q['accepted']
for q in load(out/'named-analysis.json'):assert not q['namedHintsActuallyObserved']
for q in load(out/'named-wired-analysis.json'):assert q['namedHintsActuallyObserved']==bool(q['D'])and q['functionalExit']==0 and q['analysisExit']==0
# Bidirectional direct-reader inventory, checked against actual source and published note.
actual=set()
for p in(repo/'src/crdt').glob('*.ts'):
 if re.search(r'\b(decodeInboundRecord|verifyStoredInbound|isInboundRecordTag)\b',p.read_text()):actual.add(str(p.relative_to(repo)))
rows=load(out/'receipt-readers.json')['directReaderFiles'];assert actual=={q['path']for q in rows}and len(actual)==10
for q in rows:assert sha((repo/q['path']).read_bytes())==q['sha256']and Path(q['path']).name in(out/'RECEIPT-DESIGN.md').read_text()
for p in out.glob('*.md'):
 for target in re.findall(r'\]\(([^)]+)\)',p.read_text()):
  if target.startswith(('http:','https:','#')):continue
  assert (p.parent/target.split('#')[0]).exists(),(p.name,target)
text=re.sub(r'\x1b\[[0-9;]*m','',(r/'step0-full-units/console.log').read_text());assert re.search(r'Test Files\s+283 passed',text)and re.search(r'Tests\s+2855 passed\s*\|\s*1 skipped',text)
unit=load(r/'step0-full-units/inputs.json');assert all(sha((repo/n).read_bytes())==h for n,h in unit['files'].items());assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=repo,text=True)
result={'rawArtifactsVerified':len(idx['files']),'rawCopiesAndOriginalsMatch':True,'applicationJourneys':journeys,'plansAndResultsAgreeBothDirections':True,'nativeDeepMilestonesIndependentlyRecomputed':8,'rawLatencyRunsIndependentlyRecomputed':latencyRuns,'directReceiptReaderInventoryBothDirections':10,'canonicalUnitInputsUnchanged':len(unit['files']),'unitSummaryGreenButChildExitNotCaptured':True,'markdownLinksExist':True,'realIndexEmpty':True,'labOnly':True,'acceptanceCredit':False};(out/'evidence-check.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

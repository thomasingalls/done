from pathlib import Path
import json,subprocess,os,time,hashlib,datetime,sys
r=Path(__file__).parent;node='/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();frozen=json.loads((r/'deep-inputs.json').read_text());plan=json.loads((r/'gate-plan.json').read_text());assert len(plan)==30 and all(sum(c['cell']==key for c in plan)==3 for key in set(c['cell']for c in plan));rows=json.loads((r/'gate-results.json').read_text());done={x['name']for x in rows};plan=[c for c in plan if c['name']not in done]
inputs={str(p.relative_to(r)):sha(p)for p in(r/'harness').rglob('*')if p.is_file()and not p.is_symlink()and'node_modules'not in p.parts};(r/'gate-resume-inputs.json').write_text(json.dumps({'plan':plan,'apparatusFiles':inputs,'sourceFrozenAt':'deep-inputs.json','sourceAndArtifactUnchanged':True,'threeReplicatesPerCell':True,'anyFailFailsCell':True,'labOnly':True,'acceptanceCredit':False},indent=2)+'\n')
for c in plan:
 assert all(sha(r/'source'/n)==h for n,h in frozen['sources'].items());assert all(sha(r/'combined-dist'/n)==h for n,h in frozen['assets'].items());assert all(sha(r/n)==h for n,h in inputs.items())
 if c.get('mode')or c['cell']=='fairness':assert json.loads((r/'private-fixture/fixture.json').read_text())['accounts'][0]['date']==datetime.datetime.now(datetime.timezone.utc).date().isoformat(),'Civil fixture expired before next cell'
 out=r/(c['name']+('-fixed-input'if(r/c['name']).exists()else''));out.mkdir(mode=0o700,exist_ok=False);env={k:v for k,v in os.environ.items()if not k.startswith('RANGE_LAB_')and not k.startswith('FAIR_PREP_')};env.update({'PATH':str(Path(node).parent)+':'+env['PATH'],'FAIR_OUT':str(out),'FAIR_DIST':str(r/'combined-dist'),'FAIR_LAB_BITS':'1110','FAIR_VARIANT':'C','QUIET_WITHHOLD':'1'if c.get('withhold')else'0','STALL_MOBILE':'1'if c.get('mobile')else'0','STALL_PROFILE':'0','CHROMIUM_PATH':'/private/tmp/done-civil-gates-browser-20261030/Chrome.app/Contents/MacOS/Google Chrome'});cmd=[node,'node_modules/@playwright/test/cli.js','test','--config','test/account-continuation-lab/'+c['config']]
 if c.get('grep'):cmd+=['--grep',c['grep']]
 with(out/'list.log').open('w')as f:p=subprocess.run(cmd+['--list'],cwd=r/'harness',env=env,stdout=f,stderr=subprocess.STDOUT)
 if p.returncode:print('List preflight refused',c['name'],flush=True);sys.exit(4)
 print('START',c['name'],flush=True);start=time.time()
 with(out/'console.log').open('w')as f:p=subprocess.run(cmd,cwd=r/'harness',env=env,stdout=f,stderr=subprocess.STDOUT)
 row={**c,'artifactDir':out.name,'command':cmd,'functionalExit':p.returncode,'startedAt':start,'finishedAt':time.time(),'labOnly':True,'acceptanceCredit':False};(out/'receipt.json').write_text(json.dumps(row,indent=2)+'\n')
 if c.get('mode'):
  with(out/'analysis.log').open('w')as f:a=subprocess.run([sys.executable,str(r/'analyze-case.py'),json.dumps({'name':out.name,'variant':'C','mode':c['mode'],'withhold':c.get('withhold',False)})],stdout=f,stderr=subprocess.STDOUT)
  row['analysisExit']=a.returncode
 elif c['cell']=='fairness':
  with(out/'analysis.log').open('w')as f:a=subprocess.run([sys.executable,str(r/'analyze-fairness.py'),str(out)],stdout=f,stderr=subprocess.STDOUT)
  row['analysisExit']=a.returncode
 elif c['cell'].startswith('goals'):
  with(out/'analysis.log').open('w')as f:a=subprocess.run([sys.executable,'/private/tmp/done-goals-stall-20261028/analyze.py',str(out)],stdout=f,stderr=subprocess.STDOUT)
  row['diagnosticAnalysisExit']=a.returncode
 rows.append(row);(r/'gate-results.json').write_text(json.dumps(rows,indent=2)+'\n');print('RESULT',json.dumps(row),flush=True)
 results=list(out.glob('result.json'))+list(out.glob('*/result.json'));cold=False
 for path in results:
  x=json.loads(path.read_text());err=x.get('error','');guards=x.get('guards',{})or{}
  cold|=bool(x.get('coldFailure'))or bool(x.get('coldAttemptStarted')and not guards.get('bothOfflineColdProfilesExact'))
  cold|=bool(x.get('closedPeerProfile')and not guards.get('offlinePeerColdProfile')and x.get('outcome')=='failed')
  cold|=bool('openSaved'in err and('locator' in err or '.shell'in err))
  if c['cell']=='native-deep':cold|=bool(guards.get('peerExcludedFromLocalUndo')and not guards.get('originalAccountReaderColdExact')and x.get('outcome')=='failed')
 if cold:
  (r/'STOP.json').write_text(json.dumps({'rule':'Any no-F cold failure stops immediately','case':row},indent=2)+'\n');print('STOP: no-F cold failure; later cells withheld',flush=True);sys.exit(3)
print('ALL THIRTY ORIGINAL GATE REPLICATES RETAINED',flush=True)

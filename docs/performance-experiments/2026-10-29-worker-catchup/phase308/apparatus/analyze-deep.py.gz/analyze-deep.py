from pathlib import Path
import json,math,statistics
r=Path(__file__).parent;rows=json.loads((r/'deep-results.json').read_text())
def stats(v):
 s=sorted(v);return{'n':len(s),'mean':statistics.mean(s),'p50':s[math.ceil(.5*len(s))-1],'p95':s[math.ceil(.95*len(s))-1]}if s else{'n':0}
for row in rows:
 x=json.loads((r/row['name']/'deep-gv/result.json').read_text());t0=x['startedAt'];events=x['worker']['events'];commits=[e for e in events if e['kind']=='inboundCommit'and e['at']>=t0];total=0;cross={0:t0}
 for e in commits:
  before=total;total+=e['positions']
  for n in list(range(100,1001,100))+[341,342,683,684,700,1025]:
   if before<n<=total and n not in cross:cross[n]=e['at']
 assert total==1025
 bins=[];last=0
 for n in list(range(100,1001,100))+[1025]:bins.append({'fromPositionExclusive':last,'throughPosition':n,'elapsedMs':cross[n]-cross[last],'msPerPosition':(cross[n]-cross[last])/(n-last)});last=n
 # Disjoint union of timestamped native spans within consecutive crypto:sign bounds.
 # ClientValidation is inclusive in raw data; priority makes the reported partition non-overlapping.
 spans=[]
 for e in events:
  if e.get('ms')is None:continue
  a,b=e['at']-e['ms'],e['at'];kind=e['kind']
  if kind=='clientValidation':spans.append((a,b,'clientValidation',0))
  elif kind=='receiveGroup':
   cs=[q['at']for q in commits if a<=q['at']<=b];split=cs[-1]if cs else b;spans.extend([(a,split,'nativeBeforeCommitOther',1),(split,b,'nativeAfterCommitOther',1)])
  elif kind=='emptyCheck':spans.append((a,b,'emptyFlightOther',2))
  elif kind=='receivePage':spans.append((a,b,'singlePageEnvelopeOther',3))
 signs=[e['at']for e in events if e['kind']=='crypto:sign'and t0<=e['at']<=cross[1025]];bounds=[t0]+sorted(signs)+[cross[1025]];rounds=[]
 names=['clientValidation','nativeBeforeCommitOther','nativeAfterCommitOther','emptyFlightOther','singlePageEnvelopeOther','remainingPrepareFetchHandoff']
 for a,b in zip(bounds,bounds[1:]):
  if b<=a:continue
  touched=[q for q in commits if a<q['at']<=b];quiet=any(e['kind']=='emptyCheck'and a<e['at']<=b for e in events);kind='productive'if touched else'quiet'if quiet else'other'
  n=sum(e['positions']for e in commits if e['at']<=b);third='early'if n<=342 else'late'if n>683 else'middle'
  parts={k:0. for k in names};clipped=[(max(a,s),min(b,e),name,prio)for s,e,name,prio in spans if s<b and e>a];points=sorted({a,b,*[p for s,e,_,_ in clipped for p in[s,e]]})
  for left,right in zip(points,points[1:]):
   active=[q for q in clipped if q[0]<=left and q[1]>=right];name=min(active,key=lambda q:q[3])[2]if active else names[-1];parts[name]+=right-left
  assert abs(sum(parts.values())-(b-a))<.1
  rounds.append({'kind':kind,'third':third,'positionsThrough':n,'ms':b-a,'stagesMs':parts})
 stages={}
 for third in ['early','late']:
  stages[third]={}
  for kind in ['productive','quiet','other']:
   subset=[q for q in rounds if q['third']==third and q['kind']==kind];stages[third][kind]={'roundMs':stats([q['ms']for q in subset]),'stagesMeanMs':{n:statistics.mean(q['stagesMs'][n]for q in subset)if subset else None for n in names},'stagesTotalMs':{n:sum(q['stagesMs'][n]for q in subset)for n in names}}
 budget=x['budgetAt30']['budget'];ev=budget['events'];tokens30=sum(e['units']for e in ev if t0<=e['at']<=t0+30000);tokensDone=sum(e['units']for e in x['budgetAfter']['budget']['events']if t0<=e['at']<=cross[1025]);row.update(tokensAt30=tokens30,tokensThrough1025=tokensDone,msPer100=bins,stageThirds=stages,exposure={k:x['worker'].get(k,0)for k in ['warmRecordViews','fullPhysicalLoads','suffixPrefixReuses','full1024Audits','fullLedgerChecks','eventOverflow']},ledgerCipherBytesPerPosition=sum(e['cipherBytes']for e in commits)/1025)
 row['analysisQualification']='Descriptive independent journeys. Signature-bounded rounds include sign-only/partial rounds as other. Stages partition by priority: validation, native before/after commit, empty flight, single-page envelope, remainder. The remainder includes preparation/network/Window handoff and prefix copies; no exclusive Window claim. 100-position boundaries use first crossing commit (up to8positions/burst), not interpolated individual completion times. Budget events use server epoch timestamps; raw snapshots preserve offset uncertainty.'
(rowPath:=r/'deep-analysis.json').write_text(json.dumps(rows,indent=2)+'\n')
lines=['# G × V deep screen — all runs, no credit','', '|Run|G|V|Time700s|Time1025s|Positions30s|Tokens30s|Tokens to1025|Cold|','|---|---:|---:|---:|---:|---:|---:|---:|---|']
for x in rows:lines.append(f"|{x['name']}|{x['bits'][0]}|{x['bits'][1]}|{x['timeTo700Ms']/1000:.3f}|{x['timeTo1025Ms']/1000:.3f}|{x['positionsAt30']}|{x['tokensAt30']}|{x['tokensThrough1025']}|{'pass'if x['guards'].get('originalAccountReaderColdExact')else'FAIL'}|")
(r/'DEEP.md').write_text('\n'.join(lines)+'\n');print('\n'.join(lines))

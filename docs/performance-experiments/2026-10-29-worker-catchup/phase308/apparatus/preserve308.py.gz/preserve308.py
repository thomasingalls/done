from pathlib import Path
import json,gzip,hashlib,os,shutil,re
r=Path(__file__).parent;repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');out=repo/'docs/performance-experiments/2026-10-29-worker-catchup/phase308';out.mkdir(exist_ok=False);sha=lambda b:hashlib.sha256(b).hexdigest()
assert not(r/'STOP.json').exists()
keep={'result.json','partial-result.json','receipt.json','runner-receipt.json','runner.json','inputs.json','inputs-before-run.json','analysis.json','analysis.log','console.log','run.log','seed-check.json','container-identity.json','docker-command.json','protocol.md','recipe.json','preflight.log'}
prune={'node_modules','state','private-fixture','prepared-fixture','source','source-R','source-after','source-server','frontend','lab','harness','test-inputs','combined-dist','maintenance-dist','maintenance-source','test-results','artifacts','Chrome.app','test','dist','__pycache__'}
rows=[];excluded=[]
for folder,dirs,files in os.walk(r,followlinks=False):
 dirs[:]=[n for n in dirs if n not in prune and not n.startswith('private-profile')and not n.endswith('copied-profile')and not n.startswith('profile-')and not n.startswith('source')and not n.endswith('-dist')]
 for name in files:
  p=Path(folder)/name;rel=p.relative_to(r)
  if p.is_symlink():continue
  isroot=len(rel.parts)==1
  if not(name in keep or name.endswith('.log')or(isroot and p.suffix in('.json','.md'))):continue
  if name in('ACTIVE.md','receipt-design-research-draft.md'):continue
  raw=p.read_bytes()
  if name=='build-identity.json':
   x=json.loads(raw)
   if x.get('transforms')or not all(isinstance(v,str)and re.fullmatch('[0-9a-f]{64}',v)for v in x.get('labInputs',{}).values()):excluded.append({'source':str(p),'sha256':sha(raw),'reason':'Runtime transform/source text excluded; source and asset hashes preserved in deep-inputs'});continue
  dest=out/'evidence'/str(rel);dest=dest.with_name(dest.name+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(gzip.compress(raw,mtime=0));rows.append({'source':str(p),'artifact':str(dest.relative_to(out)),'sourceBytes':len(raw),'sourceSha256':sha(raw),'artifactSha256':sha(dest.read_bytes())})
# Test recipes and analysis/fault apparatus only, never app/service implementation or built JS.
app=['run-deep.py','run-r.py','run-gates.py','resume-gates.py','run-post.py','run-named-wired.py','continue-civil31.py','continue-civil31-before-syntax-check.py','analyze-deep.py','analyze-r.py','analyze-case.py','analyze-fairness.py','analyze-gates.py','analyze-grown.py','analyze-named.py','analyze-named-wired.py','header-probe.mjs','inspect-failed-metadata.mjs','lab-context.mjs','notification-probe.mjs','read-request.mjs','fixture-roles.mjs','observer.mjs','container-service.mjs','gateway-before-named-optin.mjs']
app+=['grown-preparation/run.py','grown-preparation/test/extend.spec.ts','grown-preparation/test/config.ts','civil31-fixture/run.py','civil31-grown/run.py','civil31-grown/test/extend.spec.ts','civil31-grown/test/config.ts']
app+=[str(p.relative_to(r))for p in(r/'harness/test/account-continuation-lab').iterdir()if p.is_file()and p.suffix in('.ts','.mjs')]
app+=['harness/scripts/lib/account-gateway.mjs']
for n in sorted(set(app)):
 p=r/n
 if not p.exists()or p.is_symlink():continue
 raw=p.read_bytes();dest=out/'apparatus'/(n+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(gzip.compress(raw,mtime=0));rows.append({'source':str(p),'artifact':str(dest.relative_to(out)),'sourceBytes':len(raw),'sourceSha256':sha(raw),'artifactSha256':sha(dest.read_bytes()),'kind':'Non-executing test/analysis/fault apparatus'})
for n in ['deep-analysis.json','r-analysis.json','gate-analysis.json','grown-analysis.json','named-analysis.json','named-wired-analysis.json','receipt-readers.json','normal-r-activation-detail.json','civil-cohort-transition.json','named-wiring-repair.json','DEEP.md','GATES.md','GROWN.md','NAMED.md','NAMED-WIRED.md','V-design-note.md','R-design-note.md','RECEIPT-DESIGN.md','PROTOCOL.md']:
 shutil.copy2(r/n,out/n)
index={'labOnly':True,'acceptanceCredit':False,'sourceRootRetained':str(r),'applicationJourneys':65,'preparationJourneys':3,'metadataOnlyProfileCopies':6,'excluded':'No experimental app/service source, built assets, profiles, fixture secrets or databases enter the landing tree. Complete isolated originals remain at sourceRootRetained. Test/analysis/fault apparatus is archived as non-executing evidence.','excludedIdentityPayloads':excluded,'files':rows};(out/'evidence-index.json').write_text(json.dumps(index,indent=2)+'\n');print('Preserved',len(rows),'artifacts,',sum((out/x['artifact']).stat().st_size for x in rows),'compressed bytes; runtime-source identities excluded:',len(excluded))

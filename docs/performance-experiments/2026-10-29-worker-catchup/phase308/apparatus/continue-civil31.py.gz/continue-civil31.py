from pathlib import Path
import json,subprocess,time,datetime,hashlib,sys
r=Path(__file__).parent; sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert len(json.loads((r/'gate-results.json').read_text()))==30 and not(r/'STOP.json').exists()
print('Waiting for the real next civil date and the existing preparation to finish; no measured cell active.',flush=True)
while datetime.datetime.now(datetime.timezone.utc).date().isoformat()<'2026-10-31' or not(r/'grown-preparation/run01/receipt.json').exists():time.sleep(10)
assert datetime.datetime.now(datetime.timezone.utc).date().isoformat()=='2026-10-31'
print('Original preparation retained:',(r/'grown-preparation/run01/receipt.json').read_text(),flush=True)
for label,cmd in [('fresh-seed',[sys.executable,str(r/'civil31-fixture/run.py')]),('fresh-grow',[sys.executable,str(r/'civil31-grown/run.py')])]:
 print('START APPARATUS',label,flush=True)
 with(r/(label+'.log')).open('w')as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 print('APPARATUS EXIT',label,p.returncode,flush=True)
 if p.returncode:sys.exit(p.returncode)
new={'private-fixture':r/'civil31-fixture/private-fixture','prepared-fixture':r/'civil31-grown/prepared-fixture'};transition={'reason':'Previous civil cohort expired; no clock or freeze override in measurements','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'allOriginalThirtyResultsRetained':True,'sourceAndArtifactUnchanged':True,'labOnly':True,'acceptanceCredit':False,'selectors':{}}
for name,dest in new.items():
 p=r/name;assert p.is_symlink();old=p.resolve();transition['selectors'][name]={'old':str(old),'oldFixtureSha256':sha(old/'fixture.json'),'new':str(dest),'newFixtureSha256':sha(dest/'fixture.json')}
# Both new fixtures refer to the same actual six H credentials; only accepted history and caught-up writer differ.
a=json.loads((new['private-fixture']/'fixture.json').read_text())['accounts'][0];b=json.loads((new['prepared-fixture']/'fixture.json').read_text())['accounts'][0];assert a['backlog']==1024 and b['backlog']==2048 and a['date']==b['date']=='2026-10-31';assert a['actors'][1]==b['actors'][1]
(r/'civil-cohort-transition.json').write_text(json.dumps(transition,indent=2)+'\n')
for name,dest in new.items():(r/name).unlink();(r/name).symlink_to(dest,target_is_directory=True)
p=r/'harness/test/account-continuation-lab/grown-maintenance.spec.ts';old=p.read_text();(r/'grown-maintenance-declared-civil30.spec.ts').write_text(old);assert old.count("root+'/grown-preparation/prepared-fixture/fixture.json'")==1;p.write_text(old.replace("root+'/grown-preparation/prepared-fixture/fixture.json'","root+'/civil31-grown/prepared-fixture/fixture.json'"))
for lane in ('grown','named'):
 p=r/(lane+'-plan.json');old=p.read_bytes();(r/(lane+'-plan-declared-civil30.json')).write_bytes(old);plan=json.loads(old)
 for c in plan:c.update({'civilCohort':'2026-10-31','fixtureBacklog':2048 if lane=='grown'else 1024})
 p.write_text(json.dumps(plan,indent=2)+'\n')
files=[r/'run-post.py',r/'grown-plan.json',r/'named-plan.json',r/'analyze-named.py',r/'continue-civil31.py',r/'harness/test/account-continuation-lab/grown-maintenance.spec.ts',r/'harness/test/account-continuation-lab/grown-maintenance.config.ts']
(r/'post-inputs-civil31.json').write_text(json.dumps({'files':{str(p.relative_to(r)):sha(p)for p in files},'sourceFrozenAt':'deep-inputs.json','sourceAndArtifactUnchanged':True,'originalAssertionsAndDeadlinesUnchanged':True,'originalOverlapPredicateUnchanged':True,'labOnly':True,'acceptanceCredit':False},indent=2)+'\n')
for lane in ('grown','named'):
 assert not(r/'STOP.json').exists();print('START SCREEN',lane,flush=True)
 with(r/(lane+'-run.log')).open('w')as f:p=subprocess.run([sys.executable,str(r/'run-post.py'),lane],stdout=f,stderr=subprocess.STDOUT)
 print('SCREEN EXIT',lane,p.returncode,flush=True)
 if p.returncode:sys.exit(p.returncode)
print('All remaining comparison cells retained.',flush=True)

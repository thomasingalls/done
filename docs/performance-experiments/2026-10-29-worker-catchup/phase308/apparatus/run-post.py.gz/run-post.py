from pathlib import Path
import json,subprocess,os,time,hashlib,datetime,sys
r=Path(__file__).parent; lane=sys.argv[1]; assert lane in ('grown','named'); assert not (r/'STOP.json').exists()
node='/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();frozen=json.loads((r/'deep-inputs.json').read_text());plan=json.loads((r/(lane+'-plan.json')).read_text());rows=[]
assert len(plan)==6
for c in plan:
 assert not (r/'STOP.json').exists()
 assert all(sha(r/'source'/n)==h for n,h in frozen['sources'].items());assert all(sha(r/'combined-dist'/n)==h for n,h in frozen['assets'].items())
 assert json.loads((r/'private-fixture/fixture.json').read_text())['accounts'][0]['date']==datetime.datetime.now(datetime.timezone.utc).date().isoformat(),'Civil fixture expired; do not fake clock'
 out=r/c['name'];out.mkdir(mode=0o700,exist_ok=False);env={k:v for k,v in os.environ.items() if not k.startswith('RANGE_LAB_') and not k.startswith('FAIR_PREP_')};env.update({'PATH':str(Path(node).parent)+':'+env['PATH'],'FAIR_OUT':str(out),'FAIR_DIST':str(r/'combined-dist'),'FAIR_LAB_BITS':c['bits'],'FAIR_VARIANT':'C','QUIET_WITHHOLD':'1'if c['withhold']else'0','CHROMIUM_PATH':'/private/tmp/done-civil-gates-browser-20261030/Chrome.app/Contents/MacOS/Google Chrome'});cmd=[node,'node_modules/@playwright/test/cli.js','test','--config','test/account-continuation-lab/'+c['config']]
 with(out/'list.log').open('w')as f:p=subprocess.run(cmd+['--list'],cwd=r/'harness',env=env,stdout=f,stderr=subprocess.STDOUT)
 if p.returncode:print('PREFLIGHT REFUSED',c['name'],flush=True);sys.exit(4)
 print('START',c['name'],flush=True);start=time.time()
 with(out/'console.log').open('w')as f:p=subprocess.run(cmd,cwd=r/'harness',env=env,stdout=f,stderr=subprocess.STDOUT)
 x=json.loads((out/'result.json').read_text())if(out/'result.json').exists()else{};row={**c,'artifactDir':out.name,'command':cmd,'functionalExit':p.returncode,'startedAt':start,'finishedAt':time.time(),'outcome':x.get('outcome'),'labOnly':True,'acceptanceCredit':False}
 with(out/'analysis.log').open('w')as f:a=subprocess.run([sys.executable,str(r/'analyze-case.py'),json.dumps({'name':out.name,'variant':'C','mode':c.get('mode','late'),'withhold':c['withhold']})],stdout=f,stderr=subprocess.STDOUT)
 row['analysisExit']=a.returncode
 (out/'receipt.json').write_text(json.dumps(row,indent=2)+'\n');rows.append(row);(r/(lane+'-results.json')).write_text(json.dumps(rows,indent=2)+'\n');print('RESULT',json.dumps(row),flush=True)
 if x.get('coldFailure')or(x.get('coldAttemptStarted')and not x.get('guards',{}).get('bothOfflineColdProfilesExact')):
  (r/'STOP.json').write_text(json.dumps({'rule':'Any no-F cold failure stops immediately','case':row},indent=2)+'\n');sys.exit(3)
print('ALL SIX '+lane+' CELLS RETAINED',flush=True)

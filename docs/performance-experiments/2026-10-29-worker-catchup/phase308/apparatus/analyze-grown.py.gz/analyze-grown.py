from pathlib import Path
import json,math
r=Path(__file__).parent;out=[]
def stat(v):
 s=sorted(v);return{'n':len(s),'p50':s[math.ceil(.5*len(s))-1],'p95':s[math.ceil(.95*len(s))-1],'max':s[-1]}
for row in json.loads((r/'grown-results.json').read_text()):
 x=json.loads((r/row['name']/'result.json').read_text());keys=[o for o in x['offers']if o['kind']=='key'];markers=[o for o in x['offers']if o['kind']=='marker'];assert [q['index']for q in keys]==list(range(120));assert [q['index']for q in markers]==[0,1,2];assert all(c['outcome']=='passed'for c in x['catchups']);assert all(x['guards'].values());vals=[];mv=[]
 for device,p in enumerate(x['probes']):
  b=[v for g in x['clocks']for v in g['rows'][device]];lo=max(q['renderer']-q['after']-1 for q in b);hi=min(q['renderer']-q['before']+1 for q in b);assert lo<=hi
  vals.append([next(q['at']for q in p['counts']if q['at']>=o['at']-5 and q['count']>=x['baselines'][device]+i)-o['at']-lo for i,o in enumerate(keys,1)]);mv.append([p['markers'][i]-o['at']-lo for i,o in enumerate(markers)])
 assert len(x['probes'][1]['events'])==123 and all(e['trusted']and e['focused']and e['visible']=='visible'for e in x['probes'][1]['events']);assert not row['withhold']or x['notifications'][0]['withheld']>0
 before=x['maintenanceBeforeTyping'];assert before['status']['phase']=='running'and before['status']['progress']['stage']=='verifying'and any(e.get('reason')=='preparation-saved'for e in before['events'])
 overlap=sum(k['at']<x['catchups'][0]['completedAt']for k in keys);m=x['finalMaintenance'];metadata=next(z for z in json.loads((r/'post-run-metadata/result.json').read_text())['results']if z['case']==row['name']);assert metadata['outcome']=='passed'and metadata['scriptCount']==metadata['workerCount']==0
 data={**row,'peerMs':stat(vals[0]),'localMs':stat(vals[1]),'markerPeerMs':mv[0],'keysDuringBacklog':overlap,'backlogMs':max(c['completedAt']-x['startedAt']for c in x['catchups']),'failedError':x.get('error'),'guardsReached':x['guards'],'maintenanceAttempts':m['diagnostics']['attempts'],'maintenanceCompletions':m['diagnostics']['completions'],'maintenanceStatus':m['status'],'counterVersionAfterFailure':metadata['databases'][0]['counterVersion'],'cold':'not reached','accepted':False,'qualification':'Supplemental descriptive metrics from failed full cases. Strict original analyzer failure retained; maintenance120s deadline not changed; no cold or acceptance credit. No unmatched old153 relative credit.'}
 data['diagnosticPredicates']={'local16ms':data['localMs']['p95']<=16,'peer2500ms':data['peerMs']['p95']<=2500,'everyMarker2500ms':max(data['markerPeerMs'])<=2500,'atLeast60KeysDuringCatchup':overlap>=60,'fullBacklog600s':data['backlogMs']<=600000,'maintenanceCompletes':False,'originalColdGuard':'not reached'}
 out.append(data)
(r/'grown-analysis.json').write_text(json.dumps(out,indent=2)+'\n');lines=['# Grown2048 maintenance — all six FAILED journeys','', 'Supplemental timing calculations preserve each original failed case and strict analyzer failure. No full-case pass, no cold credit, no acceptance credit.','', '|Journey|Input p95 ms|Peer p95 ms|Worst marker ms|Keys during catch-up|Backlog s|Maintenance attempts / completions|Counter after|Cold|','|---|---:|---:|---:|---:|---:|---|---:|---|']
for x in out:lines.append(f"|{x['name']}|{x['localMs']['p95']:.3f}|{x['peerMs']['p95']:.3f}|{max(x['markerPeerMs']):.3f}|{x['keysDuringBacklog']}|{x['backlogMs']/1000:.3f}|{x['maintenanceAttempts']} / {x['maintenanceCompletions']}|{x['counterVersionAfterFailure']}|not reached|")
(r/'GROWN.md').write_text('\n'.join(lines)+'\n');print('\n'.join(lines))

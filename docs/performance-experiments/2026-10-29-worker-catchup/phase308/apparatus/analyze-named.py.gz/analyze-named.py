from pathlib import Path
import json,math,statistics
r=Path(__file__).parent;rows=json.loads((r/'named-results.json').read_text());out=[]
def stat(v):
 s=sorted(v);return{'n':len(s),'p50':s[math.ceil(.5*len(s))-1],'p95':s[math.ceil(.95*len(s))-1],'max':s[-1]}
for row in rows:
 x=json.loads((r/row['name']/'result.json').read_text());keys=[o for o in x['offers']if o['kind']=='key'];markers=[o for o in x['offers']if o['kind']=='marker'];assert len(keys)==120 and len(markers)==3;assert x['outcome']=='passed'and all(x['guards'].values());vals=[];mv=[]
 for device,p in enumerate(x['probes']):
  b=[v for g in x['clocks']for v in g['rows'][device]];lo=max(q['renderer']-q['after']-1 for q in b);hi=min(q['renderer']-q['before']+1 for q in b);assert lo<=hi
  vals.append([next(q['at']for q in p['counts']if q['at']>=o['at']-5 and q['count']>=x['baselines'][device]+i)-o['at']-lo for i,o in enumerate(keys,1)]);mv.append([p['markers'][i]-o['at']-lo for i,o in enumerate(markers)])
 ev=x['probes'][1]['events'];assert len(ev)==123 and all(e['trusted']and e['focused']and e['visible']=='visible'for e in ev)
 def counters(rows):return{k:sum(z.get('value',{}).get(k,0)for z in rows)for k in ['repairActivations','repairIntervals','quietReads','contentHints','namedHints']}
 before=[counters(z)for z in x['labBefore']];after=[counters(z)for z in x['labAfter']];delta=[{k:a[k]-b[k]for k in a}for a,b in zip(after,before)];events=[e for z in x['labAfter'][0]for e in z.get('value',{}).get('events',[])];act=[e['at']for e in events if e['kind']=='repairActivation'and e['at']>=x['typingStartedAt']];first=min(act)if act else None
 times=[(o['at']>x['drainEndedAt'])if row['kind']=='idle'else(o['at']>next(c['completedAt']for c in x['catchups']if c['label']=='H1'))for o in keys]
 budget=x['budgetAfter']['budget']['events'];tokens=sum(e['units']for e in budget if x['typingStartedAt']<=e['at']<=x['typingFinishedAt']);tokensFinal=sum(e['units']for e in budget if x['typingStartedAt']<=e['at']<=x['newDeliveryAt'])
 data={**row,'peerMs':stat(vals[0]),'localMs':stat(vals[1]),'firstKeyPeerMs':vals[0][0],'perKeyPeerMs':vals[0],'markerPeerMs':mv[0],'tokensTypingWindow':tokens,'tokensThroughDelivery':tokensFinal,'realmCountersBefore':before,'realmCountersAfter':after,'realmCounterDeltas':delta,'keysAfterMeasuredReaderDrain':sum(times),'keysAfterBothDrains':row.get('keysAfterBothDrains'),'postDrainPeerMs':stat([v for v,t in zip(vals[0],times)if t])if any(times)else None,'firstRepairAfterTypingMs':first-x['typingStartedAt']if first is not None else None,'peerAfterFirstActivation':stat([v for v,o in zip(vals[0],keys)if first is not None and o['at']>first])if first is not None and any(o['at']>first for o in keys)else None,'qualification':'No acceptance credit. Original conservative clock brackets/120keys/3markers/trusted focused events checked; per-key rows not independent runs. Tokens are net logical budget units during actual typing and through delivery using raw server epochs; snapshots preserve timing uncertainty. Native+Window counters reported separately by device. Cold guards all pass.'}
 if row['bits'][2]=='1'and row['withhold']:assert after[0]['repairActivations']>0,('Rnotexposed',row['name'])
 
 activeUntil=0; episodes=0; arms=sorted([e for e in events if e['kind']=='repairActivation'and e['at']>=x['typingStartedAt']],key=lambda e:e['at'])
 for e in arms:
  if e['at']>=activeUntil:episodes+=1
  activeUntil=e['until']
 data['repairEpisodesInObservedWindow']=episodes;data['repairArmAndRearmEventsInObservedWindow']=len(arms);data['namedHintsActuallyObserved']=delta[0]['namedHints']>0; data['namedExposureExpected']=row['D']==1; out.append(data)
(r/'named-analysis.json').write_text(json.dumps(out,indent=2)+'\n');lines=['# Named hints — every run, no credit','', '|Run|D|Peerp95s|Localp95ms|Keysafterreaderdrain|Repair arm/rearm events Δ(reader)|Quietreads Δ(reader)|Tokens typing|Worstmarkers|Cold|','|---|---:|---:|---:|---:|---:|---:|---:|---:|---|']
for x in out:lines.append(f"|{x['name']}|{x['bits'][3]}|{x['peerMs']['p95']/1000:.3f}|{x['localMs']['p95']:.3f}|{x['keysAfterMeasuredReaderDrain']}|{x['realmCounterDeltas'][0]['repairActivations']}|{x['realmCounterDeltas'][0]['quietReads']}|{x['tokensTypingWindow']}|{max(x['markerPeerMs'])/1000:.3f}|pass|")
(r/'NAMED.md').write_text('\n'.join(lines)+'\n');print('\n'.join(lines))

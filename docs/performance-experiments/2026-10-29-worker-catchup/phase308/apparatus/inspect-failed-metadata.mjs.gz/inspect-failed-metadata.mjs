import { chromium } from '@playwright/test';
import { readFileSync, writeFileSync, mkdirSync, cpSync, existsSync } from 'node:fs';
import { join } from 'node:path';
const root='/private/tmp/done-range-vgr-lab-20261030';
if(existsSync(join(root,'STOP.json')))throw Error('Cold-failure stop rule: no later work');
const dir=join(root,'post-run-metadata');mkdirSync(dir,{mode:0o700});const results=[];
for(const row of JSON.parse(readFileSync(join(root,'grown-results.json'),'utf8'))){
 if(row.functionalExit===0)continue;
 const raw=JSON.parse(readFileSync(join(root,row.name,'result.json'),'utf8'));if(raw.coldAttemptStarted||raw.coldFailure)throw Error('Unexpected cold state; inspect stop rule first');
 const source=join(root,row.name,'private-profile-H2'),profile=join(dir,row.name+'-copied-profile');
 if(existsSync(join(source,'SingletonLock')))throw Error('Original test profile still has a browser lock');
 cpSync(source,profile,{recursive:true,errorOnExist:true});
 const entry={case:row.name,mode:'Metadata-only read on a COPY; no app load or unlock; not a cold-reopen cell',originalProfileUnmodified:true,requests:[],outcome:'starting'};let ctx;
 try{
  ctx=await chromium.launchPersistentContext(profile,{executablePath:'/private/tmp/done-civil-gates-browser-20261030/Chrome.app/Contents/MacOS/Google Chrome',serviceWorkers:'block',headless:true});
  const pages=ctx.pages();if(pages.some(p=>p.url()!=='about:blank'))throw Error('Refusing unexpected restored navigation');const p=pages[0]??await ctx.newPage();let workers=0;p.on('worker',()=>workers++);
  const cdp=await ctx.newCDPSession(p);await cdp.send('Network.enable');await cdp.send('Network.setBypassServiceWorker',{bypass:true});
  const url='http://localhost:53781/__lab_metadata_only';
  await ctx.route('**/*',async route=>{entry.requests.push(route.request().url());if(route.request().url()!==url)throw Error('Unexpected request; application must not load');await route.fulfill({status:200,contentType:'text/html',headers:{'Content-Security-Policy':"default-src 'none'; script-src 'none'; connect-src 'none'; worker-src 'none'",'Cache-Control':'no-store'},body:'<!doctype html><title>Metadata only</title><body>Read-only fictional profile metadata</body>'});});
  await p.goto(url);if(await p.title()!=='Metadata only'||await p.locator('script').count()!==0||workers!==0)throw Error('Application isolation failed');
  entry.databases=await p.evaluate(async()=>{const out=[];for(const info of await indexedDB.databases()){
   if(!/^done\.[0-9a-f]{32}$/.test(info.name??''))continue;
   const db=await new Promise((yes,no)=>{const q=indexedDB.open(info.name);q.onupgradeneeded=()=>{q.transaction.abort();no(Error('Refused creation/upgrade'));};q.onsuccess=()=>yes(q.result);q.onerror=()=>no(q.error);});
   try{const counts={};for(const name of db.objectStoreNames)counts[name]=await new Promise((yes,no)=>{const q=db.transaction(name,'readonly').objectStore(name).count();q.onsuccess=()=>yes(q.result);q.onerror=()=>no(q.error);});const version=await new Promise((yes,no)=>{const q=db.transaction('meta','readonly').objectStore('meta').get('counter');q.onsuccess=()=>yes(q.result?.v??null);q.onerror=()=>no(q.error);});out.push({name:info.name,databaseVersion:info.version,counterVersion:version,records:counts});}finally{db.close();}
  }return out;});
  if(entry.databases.length!==1||entry.databases[0].counterVersion===null)throw Error('Missing identifiable workspace counter');
  entry.workerCount=workers;entry.scriptCount=await p.locator('script').count();if(workers||entry.requests.length!==1)throw Error('Unexpected application activity');entry.readOnlyTransactions=true;entry.outcome='passed';
 }catch(error){entry.outcome='failed';entry.error=String(error);}finally{if(ctx)await ctx.close();results.push(entry);writeFileSync(join(dir,'result.json'),JSON.stringify({labOnly:true,acceptanceCredit:false,metadataOnly:true,results},null,2)+'\n');}
 if(entry.outcome!=='passed')throw Error(entry.error);
 console.log(entry.case,JSON.stringify(entry.databases.map(d=>({counterVersion:d.counterVersion,records:d.records}))));
}

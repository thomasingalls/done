from pathlib import Path
import os,json,subprocess,time,hashlib,datetime,sys
r=Path(__file__).parent;node='/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();frozen=json.loads((r/'deep-inputs.json').read_text());plan=json.loads((r/'r-plan.json').read_text());rows=[]
for c in plan:
 assert all(sha(r/'source'/n)==h for n,h in frozen['sources'].items());assert all(sha(r/'combined-dist'/n)==h for n,h in frozen['assets'].items());assert json.loads((r/'private-fixture/fixture.json').read_text())['accounts'][0]['date']==datetime.datetime.now(datetime.timezone.utc).date().isoformat(),'Civil fixture expired'
 out=r/c['name'];out.mkdir(mode=0o700,exist_ok=False);env={**os.environ,'PATH':str(Path(node).parent)+':'+os.environ['PATH'],'FAIR_OUT':str(out),'FAIR_DIST':str(r/'combined-dist'),'FAIR_LAB_BITS':c['bits'],'FAIR_VARIANT':'GV-R-screen','QUIET_WITHHOLD':'1'if c['withhold']else'0','CHROMIUM_PATH':'/private/tmp/done-civil-gates-browser-20261030/Chrome.app/Contents/MacOS/Google Chrome'};cmd=[node,'node_modules/@playwright/test/cli.js','test','--config','test/account-continuation-lab/'+c['config']]
 with(out/'list.log').open('w')as log:p=subprocess.run(cmd+['--list'],cwd=r/'harness',env=env,stdout=log,stderr=subprocess.STDOUT)
 if p.returncode:print('List preflight failed',c['name'],flush=True);sys.exit(4)
 print('START',c['name'],flush=True);start=time.time()
 with(out/'console.log').open('w')as log:p=subprocess.run(cmd,cwd=r/'harness',env=env,stdout=log,stderr=subprocess.STDOUT)
 x=json.loads((out/'result.json').read_text())if(out/'result.json').exists()else{};row={**c,'exit':p.returncode,'startedAt':start,'finishedAt':time.time(),'outcome':x.get('outcome'),'error':x.get('error'),'guards':x.get('guards'),'keysAfterReaderDrain':x.get('keysAfterReaderDrain',x.get('keysAfterDrain')),'keysAfterBothDrains':x.get('keysAfterBothDrains',x.get('keysAfterDrain')),'coldFailure':x.get('coldFailure',False),'labOnly':True,'acceptanceCredit':False};row['exposure']='not-exposed'if c.get('postDrainExposureRequired')and not(row['keysAfterReaderDrain']or 0)>0 else'exposed';(out/'receipt.json').write_text(json.dumps(row,indent=2)+'\n');rows.append(row);(r/'r-results.json').write_text(json.dumps(rows,indent=2)+'\n');print('RESULT',json.dumps(row),flush=True)
 if row['coldFailure']or(x.get('coldAttemptStarted')and not x.get('guards',{}).get('bothOfflineColdProfilesExact')):
  (r/'STOP.json').write_text(json.dumps({'rule':'Any no-F cold failure stops immediately','case':row},indent=2)+'\n');print('STOP: no-F cold failure',flush=True);sys.exit(3)
print('ALL R SCREEN CELLS RETAINED',flush=True)

from pathlib import Path
import shutil,json,hashlib,subprocess,os,time
m=Path(__file__).parent;old=Path('/private/tmp/done-production-worker-baseline-20261030');candidate=Path('/private/tmp/done-verified-selection-control-20261030');r=Path('/private/tmp/done-quiet-input-control-20261030');repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');r.mkdir();sha=lambda b:hashlib.sha256(b).hexdigest()
# Same exact248source in both profiles. Signed0abserver remains fixed independently.
for v in ['before','after']:
 shutil.copytree(candidate/'source-after',r/('source-'+v),symlinks=True);(r/(v+'-source-inputs.json')).write_bytes((candidate/'after-source-inputs.json').read_bytes())
(r/'source-server').symlink_to(old/'source-after',target_is_directory=True);(r/'source-R').symlink_to(r/'source-server',target_is_directory=True);(r/'private-fixture').symlink_to(old/'private-fixture',target_is_directory=True)
for n in ['container-image.json','container-service.mjs','observer.mjs','notification-probe.mjs','notification-probe.d.mts','read-request.mjs','read-request.d.mts','playwright-storage-source.txt','analyze-case.py','run.py','smoke.mjs','release-flags.json']:(r/n).write_bytes((old/n).read_bytes().replace(str(old).encode(),str(r).encode()))
shutil.copytree(old/'harness',r/'harness',symlinks=True,ignore=shutil.ignore_patterns('node_modules','test-results','artifacts'));(r/'harness/node_modules').symlink_to(repo/'node_modules',target_is_directory=True)
for f in(r/'harness').rglob('*'):
 if f.is_file()and not f.is_symlink()and f.suffix in ['.mjs','.ts','.json']:
  f.write_bytes(f.read_bytes().replace(str(old).encode(),str(r).encode()))
p=r/'harness/test/account-continuation-lab/runtime.mjs';s=p.read_text().replace("source='"+str(r/'source-after')+"'","source='"+str(r/'source-server')+"'");p.write_text(s)
flags=json.loads((r/'release-flags.json').read_text())['expected'];(r/'build-flags.json').write_text(json.dumps(flags,indent=2)+'\n');node='/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node';rows=[]
for v in ['before','after']:
 src=r/('source-'+v);identity=json.loads((r/(v+'-source-inputs.json')).read_text());assert all(sha((src/p).read_bytes())==h for p,h in identity['files'].items());actual={**flags,**({'VITE_ACCOUNT_WARM_LOADS':'0'}if v=='before'else{})};(r/(v+'-flags.json')).write_text(json.dumps(actual,indent=2)+'\n');assert not list(src.glob('.env*'));env={k:value for k,value in os.environ.items()if not k.startswith('VITE_ACCOUNT_')};env.update(actual);env.update({'PATH':str(Path(node).parent)+':'+os.environ['PATH'],'APP_BUILD_REVISION':identity['baseCommit']+'-dirty','APP_BUILD_DATE':'2026-10-30'});cmd=[node,str(src/'node_modules/vite/bin/vite.js'),'build','--outDir',str(r/(v+'-dist')),'--emptyOutDir','--sourcemap'];start=time.time_ns()//1000000
 with(r/(v+'-build.log')).open('w')as f:p=subprocess.run(cmd,cwd=src,env=env,stdout=f,stderr=subprocess.STDOUT)
 assert p.returncode==0;assets={str(f.relative_to(r/(v+'-dist'))):sha(f.read_bytes())for f in(r/(v+'-dist')).rglob('*')if f.is_file()};(r/(v+'-assets.json')).write_text(json.dumps(assets,indent=2)+'\n');rows.append({'variant':v,'flags':actual,'command':cmd,'source':'exact248candidate','startedAt':start,'finishedAt':time.time_ns()//1000000,'assetCount':len(assets)});print(v,'built',flush=True)
(r/'build-receipts.json').write_text(json.dumps(rows,indent=2)+'\n')
# Reuse bounded metadata diagnostic exactly, rooted here. No source stages or profile recording.
for n in ['input-diagnostic.spec.ts','input-diagnostic.config.ts']:(r/'harness/test/account-continuation-lab'/n).write_bytes((candidate/'harness/test/account-continuation-lab'/n).read_bytes().replace(str(candidate).encode(),str(r).encode()))
plan=[{'name':'01-warm-default-withheld-base','mode':'late','variant':'after','withhold':True,'config':'late.config.ts'},{'name':'02-warm-off-withheld-diagnostic','mode':'late','variant':'before','withhold':True,'config':'input-diagnostic.config.ts'},{'name':'03-warm-default-withheld-diagnostic','mode':'late','variant':'after','withhold':True,'config':'input-diagnostic.config.ts'}];(r/'run-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
print('Three fixed clean-host controls prepared, one explicit named warm0 exception, all original gates')

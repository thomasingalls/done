from pathlib import Path
import json,hashlib,re
r=Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();release=json.loads((r/'release-flags.json').read_text());expected=release['compiledGateReads'][0]['flags'];report={'sourceMapBodies':{},'compiledGateReads':{},'flags':release['expected'],'warmLoads':'afterunset/default-on; beforeexplicit0 namedcontrol','checks':[]}
assert 'VITE_ACCOUNT_WARM_LOADS'not in release['expected']and 'VITE_ACCOUNT_WARM_LOADS'not in expected
for variant in ['before','after']:
 src=r/('source-'+variant);identity=json.loads((r/(variant+'-source-inputs.json')).read_text());assert all(sha((src/p).read_bytes())==h for p,h in identity['files'].items());assert not list(src.glob('.env*'));assert json.loads((r/'build-receipts.json').read_text())[0 if variant=='before'else 1]['flags']=={**release['expected'],**({'VITE_ACCOUNT_WARM_LOADS':'0'}if variant=='before'else{})}
 assets=json.loads((r/(variant+'-assets.json')).read_text());assert assets=={str(f.relative_to(r/(variant+'-dist'))):sha(f.read_bytes())for f in(r/(variant+'-dist')).rglob('*')if f.is_file()};matched={};compiled=[]
 for f in(r/(variant+'-dist')).rglob('*.map'):
  m=json.loads(f.read_text())
  for path,body in zip(m['sources'],m.get('sourcesContent',[])):
   key=next((prefix+'/'+path.split('/'+prefix+'/',1)[1]for prefix in ['src','account-protocol','private','wasm']if'/'+prefix+'/'in path),None)
   if key and(src/key).is_file():assert body.encode()==(src/key).read_bytes(),(variant,key);matched[key]=sha(body.encode())
 assert matched and 'src/crdt/accountCapture.ts'in matched;report['sourceMapBodies'][variant]=len(matched)
 for f in(r/(variant+'-dist')).rglob('*.js'):
  for m in re.finditer(r'\{[^{}]*VITE_ACCOUNT_[^{}]*\}',f.read_text()):
   flags=dict(re.findall(r'(VITE_ACCOUNT_\w+):[`"]([^`"]*)[`"]',m[0]))
   if 'VITE_ACCOUNT_BASELINE_READ'in flags:assert flags=={**expected,**({'VITE_ACCOUNT_WARM_LOADS':'0'}if variant=='before'else{})},(variant,f.name,flags,expected);compiled.append({'file':str(f.relative_to(r/(variant+'-dist'))),'flags':flags})
 assert compiled;report['compiledGateReads'][variant]=compiled
for key in ['package.json','pnpm-lock.yaml','vite.config.ts']:assert(r/'source-before'/key).read_bytes()==(r/'source-after'/key).read_bytes()
report['browserExecutableSha256']=sha(Path('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome').read_bytes());report['fixtureSha256']=sha((r/'private-fixture/fixture.json').read_bytes());report['checks']=['both exact candidate248 source manifests','both source map bodies exact','both emitted assets exact','explicit build settings equal release except named warm0 before control','compiled gate dictionaries equal actual release reads except named warm0 before control','WARM_LOADS absent in after; exactly0 in before','same lock and vite config'];(r/'qa.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k!='compiledGateReads'},indent=2))

from pathlib import Path
import subprocess,os,json,time,sys,hashlib,datetime
from zoneinfo import ZoneInfo
r=Path(__file__).parent;node='/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node';plan=json.loads((r/'run-plan.json').read_text());env={**os.environ,'PATH':str(Path(node).parent)+':'+os.environ['PATH'],'CHROMIUM_PATH':'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'};qa=json.loads((r/'qa.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest();failures=[];harness=json.loads((r/'frozen-harness.json').read_text())
def clean():
 for f in r.glob('*/container.cid'):
  p=subprocess.run(['docker','inspect','--format','{{.State.Running}}',f.read_text().strip()],capture_output=True,text=True);assert p.returncode!=0,'Own prior container remains'
 commands=subprocess.check_output(['ps','-axo','command'],text=True).splitlines();assert not any(v.startswith('/Applications/Google Chrome')and'--user-data-dir='+str(r)+'/'in v for v in commands),'Own prior browser remains'
for case in plan:
 clean();local=datetime.datetime.now(ZoneInfo('Etc/GMT+12'));assert local.date().isoformat()=='2026-10-29'and(local+datetime.timedelta(seconds=900)).date()==local.date(),'Fixture civil day would freeze'
 assert json.loads((r/(case['variant']+'-flags.json')).read_text())=={**json.loads((r/'release-flags.json').read_text())['expected'],**({'VITE_ACCOUNT_WARM_LOADS':'0'}if case['variant']=='before'else{})},'Unapproved build flag difference'
 assert sha(Path(env['CHROMIUM_PATH']).read_bytes())==qa['browserExecutableSha256'];assert sha((r/'private-fixture/fixture.json').read_bytes())==qa['fixtureSha256'];assert all(sha((r/p).read_bytes())==digest for p,digest in harness.items()),'Harness changed'
 assets=json.loads((r/(case['variant']+'-assets.json')).read_text());assert assets=={str(f.relative_to(r/(case['variant']+'-dist'))):sha(f.read_bytes())for f in(r/(case['variant']+'-dist')).rglob('*')if f.is_file()}
 out=r/case['name'];out.mkdir(mode=0o700,exist_ok=False);e={**env,'FAIR_OUT':str(out),'FAIR_VARIANT':case['variant'],'FAIR_DIST':str(r/(case['variant']+'-dist')),'QUIET_WITHHOLD':'1'if case['withhold']else'0'};cmd=[node,'node_modules/@playwright/test/cli.js','test','--config','test/account-continuation-lab/'+case['config']];receipt={'case':case,'startedAt':time.time_ns()//1000000,'command':cmd,'civilPreflight':local.isoformat()}
 print('Starting',case['name'],flush=True)
 with(out/'console.log').open('w')as f:p=subprocess.run(cmd,cwd=r/'harness',env=e,stdout=f,stderr=subprocess.STDOUT)
 receipt.update(exit=p.returncode,finishedAt=time.time_ns()//1000000);(out/'runner-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');clean();print(case['name'],'functional exit',p.returncode,flush=True)
 if p.returncode:failures.append({'case':case['name'],'stage':'functional','exit':p.returncode});break
 with(out/'analysis.log').open('w')as f:p=subprocess.run([sys.executable,str(r/'analyze-case.py'),json.dumps(case)],cwd=r,stdout=f,stderr=subprocess.STDOUT)
 print(case['name'],'analysis exit',p.returncode,flush=True)
 if p.returncode:failures.append({'case':case['name'],'stage':'analysis','exit':p.returncode})
(r/'run-outcomes.json').write_text(json.dumps(failures,indent=2)+'\n');print('Fixed comparison finished',flush=True);sys.exit(1 if failures else 0)

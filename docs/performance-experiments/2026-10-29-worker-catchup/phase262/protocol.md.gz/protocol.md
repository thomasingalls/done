# Phase262 — quiet-host withheld input control

2026-10-30. After259productionflag ABBA and261original compatibility reruns, finish the outstanding
input attribution control before another product mechanism. Exact phase248candidate source in both
variants, fixed signed0abservice. Strip inherited VITE_ACCOUNT_* and all.env. After profile equals
seven actual release settings with warmunset; before profile has ONLY explicit named WARM_LOADS=0
exception. Independent emitted flag dictionaries must match that declaration.396/396source maps
and complete assets must match manifests. This is not an adoption or release test.

Three fixed fresh serial fictional-account journeys, no repeats:01warmdefault withheld original
observers;02warmoff withheld bounded input/driver metadata diagnostic;03warmdefault withheld same
diagnostic. Normal original120realkeys500ms and3markers33/513/993. Same1CPU/1GiB/noOOM service,
browser/viewport/fixture/real clock brackets/civil-onlyEtc/GMT+12 editable date preflight+900s.
Every16ms end-to-end inputp95/2.5s peerp95 AND everymarker/30s/600s and actual native factor,
authority/history/ledger/witness/commit/fencing/synchronous-journal/archive/offlinecold guard stays.
Functional failure retained/stops fixed block; gate failure retained/continues fixed plan. No
favorable replacement, deadline extension or fast-handler subset credit. No other heavy host work.
Operator quiet confirmation coordinates host work; cannot establish perfect OS/thermal isolation.

Diagnostic is exactly prior253bounded read-only metadata observer, not product source: trusted
keydown/beforeinput creation/arrival stamps, EventTiming where reported (missing is censored),
>=50msLongTasks, rAFgaps>20ms; driver20msheartbeat/gaps>40ms/event-loopdelay, request metadata
handler/save intervals. Arm only after unlock/focus, stop before export/lock/cold; finally-safe.
No writing/keyvalues/targets/proofs/factors serialized. Window arrays capped20k and dropped must0.
No CPU/profile or extra Worker stages. Real event timestamp/clock consistency must be checked.

Unit of analysis is a complete journey, not each dependent key. Main attribution outcomes are
original offer→DOM plus offer→eventcreation, creation→keydown/beforeinput→DOM, actual request
callbacks per typing interval and their handler cost/driver-gap overlap. Compare02/03 warm setting
and01/03 added observer exposure descriptively. One journey per condition, fixed order, residual
host/cache/thermal drift: no precise causal effect, no stable population tail or phone claim.
Observer changes can affect scheduling; diagnostic passes/fails earn no product acceptance.

Decision: if clean baseline/diagnostics miss, preserve fail and locate delay before choosing remedy;
late creation with fast processing supports driver/browser/OS delivery investigation, not a Main
handler repair. If not reproduced, historical contaminated failures still remain; report lack of
reproduction, not cure. Relate request callback rate/cost to attribution without claiming complete
CDP or native signature/commit counts from browsernetwork metadata. Those need later dedicated
source-bound work measurement and WorkerCPU profiles. Proposed empty-Window/publication/CPUyield
ideas are hypotheses. Keep all security checks and original publiccold/deepjoined failures261.
No product edit, sign/push/releaseprep/deploy/preview/serviceautomation/CUA/phone/real data.

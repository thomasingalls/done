from pathlib import Path
import json,hashlib,subprocess,collections,random
r=Path(__file__).parent;repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();facts={};before=json.loads((r/'canonical-start.json').read_text());print('canonical map fields',list(before))
changed=[n for n,h in before['files'].items()if not(repo/n).is_file()or sha(repo/n)!=h];assert not changed;facts['canonicalSourceInputsUnchanged']=len(before['files']);facts['head']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();facts['realIndexEmpty']=not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=repo,text=True).strip();assert facts['realIndexEmpty'];facts['diffCheckExit']=subprocess.run(['git','diff','--check'],cwd=repo,capture_output=True).returncode
inputs=json.loads((r/'baseline322b-inputs.json').read_text());facts['sourceMatchesFrozen']=all(sha(r/'source'/n)==h for n,h in inputs['sources'].items());facts['assetsMatchFrozen']=all(sha(r/'combined-dist'/n)==h for n,h in inputs['assets'].items());facts['apparatusMatchesFrozen']=all(sha(r/n)==h for n,h in inputs['apparatus'].items());assert all(facts[k]for k in ['sourceMatchesFrozen','assetsMatchFrozen','apparatusMatchesFrozen']);facts['declaredReplacementJourneys']=len(inputs['plan']);rows=json.loads((r/'baseline322b-results.json').read_text());facts['reachedReplacementJourneys']=len(rows);facts['unreachedReplacementJourneys']=[c['name']for c in inputs['plan']if c['name']not in [x['name']for x in rows]];assert len(rows)==7 and rows[-1]['coldFailure'];facts['stop']=json.loads((r/'STOP.json').read_text());facts['allOriginalDockerFailuresRetained']=len(json.loads((r/'baseline322-results.json').read_text()))==8;assert facts['allOriginalDockerFailuresRetained'];facts['noOptimizationOr75Build']=not(r/'baseline322c-results.json').exists();assert facts['noOptimizationOr75Build'];facts['fixtureSha256']=sha(r/'private-fixture/fixture.json');facts['prefetchMatchesMainCommit']='bb89aa9ae1ad800d52ad896279ad9a95d8fb02269702f18865dd0c461e4b0499';assert sha(repo/'src/crdt/receivePrefetch.ts')==facts['prefetchMatchesMainCommit']
summary=json.loads((r/'baseline-analysis.json').read_text());facts['drainsIndependentlyRecomputed']=[];facts['budgetKinds']=collections.Counter();facts['methodCountsIndependentlyRecomputed']=[]
for row in rows:
 x=json.loads((r/row['name']/'deep-gv/result.json').read_text());t=x['startedAt'];n=0;cross=None
 for e in x['worker']['events']:
  if e['kind']=='inboundCommit'and e['at']>=t:
   n+=e['positions']
   if n>=1025 and cross is None:cross=e['at']-t
 assert n==1025 and cross==x['timeTo1025Ms'];facts['drainsIndependentlyRecomputed'].append({'run':row['name'],'positions':n,'drainMs':cross,'cold':x['guards'].get('originalAccountReaderColdExact',False)})
 messages=0;charge=0
 for realm in ['pageAtDrain','workerAtDrain']:
  v=x[realm];messages+=sum(n for k,n in v.items()if k.startswith('channel:')and k.endswith(':count'));charge+=sum(n for k,n in v.items()if k.startswith('channel:')and k.endswith(':bytes'))
 z=next(q for q in summary if q['run']==row['name']);assert z['channelAtObservedDrain']=={'count':messages,'chargedBytes':charge};facts['methodCountsIndependentlyRecomputed'].append({'run':row['name'],'messages':messages,'chargedBytes':charge});assert not x['worker'].get('eventOverflow',0)
 for e in x['budgetAfter']['budget']['events']:
  if t<=e['at']<=t+cross:facts['budgetKinds'][e['kind']]+=1
 assert abs(sum(z['exclusivePartitionMs'].values())-cross)<.1
 # Independently compare full old/new classifications on 101 evenly spaced wall-time midpoints.
 spans=[]
 for e in x['worker']['events']:
  if'ms'not in e:continue
  k=e['kind'];p={'prefixComparison':0,'appendPrefixComparison':0,'clientValidation':1,'receiveGroup':2,'emptyCheck':3,'receivePage':4,'prepareGroupTotal':5,'fetchNetworkTotal':6,'channelWait:workspacePrepare':7}.get(k)
  if p is not None:spans.append((e['at']-e['ms'],e['at'],p))
 for i in range(101):
  tick=t+cross*(i+.5)/101;active=[p for a,b,p in spans if a<=tick<=b];old=any(p<=4 for p in active);new=min(active)if active else 8;assert old==(new<=4)
 facts['methodCountsIndependentlyRecomputed'][-1]['partitionSamplesChecked']=101
facts['budgetKinds']=dict(facts['budgetKinds']);assert not any(k in facts['budgetKinds']for k in ['capacity','rate','refused']);(r/'independent-check.json').write_text(json.dumps(facts,indent=2)+'\n');print(json.dumps({k:v for k,v in facts.items()if k not in ['stop','methodCountsIndependentlyRecomputed','drainsIndependentlyRecomputed']},indent=2))

from pathlib import Path
import json
r=Path(__file__).parent
p=r/'container-service.mjs';s=p.read_text();assert '[0,50].includes(labRtt)'in s;p.write_text(s.replace('[0,50].includes(labRtt)','[0,50,75].includes(labRtt)'))
plan=[]
for i in range(4):plan.append({'name':f'baseline75-{i+1:02d}'+('-profile'if i==3 else''),'rtt':75,'profile':i==3,'bits':'10101','SY':'11','repairMs':1000,'config':'worker-owner.config.ts','fileFilter':'worker-owner.spec.ts','grep':'lab G V deep joined with cold reopen$','result':'deep-gv/result.json','labOnly':True,'acceptanceCredit':False})
(r/'baseline322c-plan.json').write_text(json.dumps(plan,indent=2)+'\n');s=(r/'run-baseline-retry.py').read_text().replace("key='baseline322b'","key='baseline322c'");(r/'run75.py').write_text(s)
(r/'ADDED-75MS-PROTOCOL.md').write_text('Operator addendum: add 75ms added RTT to baseline. Three fresh unprofiled journeys, then one separately profiled diagnostic; original code, assets, gates and original eight failed plus replacement eight journeys retained. Only server injection allowlist grows 0/50 ->0/50/75; implementation/delay method unchanged. Same plan/freeze/load/cold controls. readPrefetch.ts source SHA equals 460fefd8: bb89aa9ae1ad800d52ad896279ad9a95d8fb02269702f18865dd0c461e4b0499. Historical 600-position 194.6->101.0s is operator-supplied; new 1025-position G8/P1 results are not a matched replication of that old experiment.\n')

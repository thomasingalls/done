from pathlib import Path
import json,math,statistics,csv,hashlib
r=Path(__file__).parent;rows=json.loads((r/'baseline322b-results.json').read_text());out=[];methodrows=[]
for row in rows:
 x=json.loads((r/row['name']/'deep-gv/result.json').read_text());t0=x['startedAt'];end=t0+x['timeTo1025Ms'];events=x['worker']['events'];spans=[]
 for e in events:
  if 'ms'not in e:continue
  a,b=e['at']-e['ms'],e['at'];k=e['kind'];base=None
  if k in ['prefixComparison','appendPrefixComparison']:base=('prefixComparison',0)
  elif k=='clientValidation':base=('clientValidation',1)
  elif k=='receiveGroup':base=('nativeReceiveOther',2)
  elif k=='emptyCheck':base=('emptyOther',3)
  elif k=='receivePage':base=('singlePageOther',4)
  if base:spans.append((a,b,base[0],base[1],True))
  elif k=='prepareGroupTotal':spans.append((a,b,'previousRemainder:prepareGroup',5,False))
  elif k=='fetchNetworkTotal':spans.append((a,b,'previousRemainder:networkCollect',6,False))
  elif k=='channelWait:workspacePrepare':spans.append((a,b,'previousRemainder:pageHandoff',7,False))
 points=sorted({t0,end,*[max(t0,min(end,v))for a,b,*_ in spans for v in [a,b]if a<end and b>t0]});parts={};oldRemainder=0
 for a,b in zip(points,points[1:]):
  active=[q for q in spans if q[0]<=a+.001 and q[1]>=b-.001];selected=min(active,key=lambda q:q[3])if active else None;key=selected[2]if selected else'previousRemainder:stillUnattributed';parts[key]=parts.get(key,0)+b-a
  if not any(q[4]for q in active):oldRemainder+=b-a
 assert abs(sum(parts.values())-x['timeTo1025Ms'])<.1
 # Method scalars are the snapshots observed immediately after drain, not a reconstruction of exact last-commit boundaries.
 totals={'count':0,'chargedBytes':0}
 for realm,key in [('Window','pageAtDrain'),('Worker','workerAtDrain')]:
  for k,n in x[key].items():
   if k.startswith('channel:')and k.endswith(':count'):
    _,kind,method,_=k.split(':');charge=x[key].get(f'channel:{kind}:{method}:bytes',0);methodrows.append({'run':row['name'],'realm':realm,'kind':kind,'method':method,'messages':n,'chargedBytes':charge});totals['count']+=n;totals['chargedBytes']+=charge
 budget=x['budgetAfter']['budget']['events'];activeBudget=[q for q in budget if t0<=q['at']<=end];refusals=[q for q in activeBudget if q.get('allowed')is False or q.get('ok')is False or q.get('kind')=='refused'];tokens=sum(q.get('units',0)for q in activeBudget)
 load=[json.loads(z)for z in(r/row['name']/'host-load.jsonl').read_text().splitlines()];load=[z for z in load if z.get('kind')=='load'];busy=[100-z['hostPercent']['idle']for z in load]
 out.append({'run':row['name'],'rtt':row['rtt'],'profiled':row['profile'],'drainMs':x['timeTo1025Ms'],'time700Ms':x['timeTo700Ms'],'positions30':x['positionsAt30'],'deep30Pass':x['deep30Pass'],'childExit':row['childExit'],'cold':bool(x['guards'].get('originalAccountReaderColdExact')),'coldFailure':x.get('coldFailure',False),'error':x.get('error'),'oldRemainderMs':oldRemainder,'exclusivePartitionMs':parts,'channelAtObservedDrain':totals,'pageMessagesPerPosition':totals['count']/1025,'inputP95Ms':None,'peerP95Ms':None,'typingNotExposed':True,'tokensThroughDrain':tokens,'budgetEventKeys':list(activeBudget[0])if activeBudget else[],'budgetRefusals':refusals,'hostBusyMedian':statistics.median(busy)if busy else None,'hostBusyMax':max(busy)if busy else None,'eventOverflow':x['worker'].get('eventOverflow',0)})
(r/'baseline-analysis.json').write_text(json.dumps(out,indent=2)+'\n')
with(r/'page-methods.csv').open('w')as f:w=csv.DictWriter(f,fieldnames=list(methodrows[0]));w.writeheader();w.writerows(methodrows)
print(json.dumps(out,indent=2))

from pathlib import Path
import subprocess,json,os
r=Path(__file__).parent;repo='/Users/thomasingalls/.codex/worktrees/7fda/done';node='/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node';rows=[]
for name in ['check-yjs-patch.mjs','check-write-admission.mjs','check-authority-map.mjs','check-recipient-authority.mjs','check-retention.mjs','check-update-limit.mjs','check-wasm-seal.mjs']:
 with(r/(name+'.log')).open('w')as f:p=subprocess.run([node,'scripts/'+name],cwd=repo,stdout=f,stderr=subprocess.STDOUT)
 rows.append({'check':name,'exit':p.returncode})
(r/'contracts.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows));assert all(v['exit']==0 for v in rows)

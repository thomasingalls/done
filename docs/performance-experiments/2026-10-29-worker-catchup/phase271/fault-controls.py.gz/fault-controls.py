from pathlib import Path
import shutil,subprocess,os,json,hashlib
r=Path(__file__).parent;repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');src=r/'fault-source';shutil.copytree('/private/tmp/done-due-send-yield-20261030/source-after',src,symlinks=True);(src/'test').mkdir(exist_ok=True);shutil.copy2(repo/'test/workerBaselineRecoveryRegression.test.ts',src/'test/workerBaselineRecoveryRegression.test.ts');file=src/'src/crdt/accountWorkerRecoveryStream.ts';file.write_bytes((repo/'src/crdt/accountWorkerRecoveryStream.ts').read_bytes());original=file.read_bytes();needle="(h.seq === 0 && (index !== 0 || h.recordKind !== 'state'))";assert original.decode().count(needle)==1;rows=[];node='/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node';env={**os.environ,'APP_BUILD_REVISION':'0ab9cbc8937e32c6542aaeeca697c87ba116c3be-dirty','APP_BUILD_DATE':'2026-10-30'}
for name,replacement,select in [('accept-update-zero','false','an update at sequence zero'),('accept-later-zero',"(h.seq === 0 && h.recordKind !== 'state')",'a later state at sequence zero')]:
 file.write_text(original.decode().replace(needle,replacement))
 try:
  with(r/('fault-'+name+'.log')).open('w')as f:p=subprocess.run([node,str(src/'node_modules/vitest/vitest.mjs'),'run','test/workerBaselineRecoveryRegression.test.ts','--testNamePattern',select],cwd=src,env=env,stdout=f,stderr=subprocess.STDOUT)
  log=(r/('fault-'+name+'.log')).read_text();assert p.returncode==1 and 'promise resolved'in log,(name,p.returncode,log[-1200:]);rows.append({'fault':name,'selection':select,'exit':p.returncode,'sensitiveToBroaderAcceptance':True})
 finally:file.write_bytes(original)
 assert file.read_bytes()==original
(r/'fault-controls.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))

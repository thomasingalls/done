# Worker Performance Brief

2026-10-30

Re-baseline at production flags before the next repair. Phases 241–250 ran with warm loads off, production runs them on, and single-read peer polling costs about as much as the real payload, or more.

## Findings that change the plan

The current baselines do not match production, so verify these three points before choosing the next repair.

**1. Warm loads are off in the benchmarks and on in production.**

- `VITE_ACCOUNT_WARM_LOADS=0` entered the lab builds at phase 163 and was copied into phase 241's `setup-matched241.py`.
- Phase 252 makes no claim about deployed flags, but the release evidence settles it for `b6f0160a`. `development-evidence/2026-10-28-resumable-sync-release/compiled-flags.json` does not list the flag, the Dockerfile has no such `ARG`, and `accountCapture.ts:112` treats unset as on.
- Phase 155's build receipt does not set it either, so phase 156's accepted journeys ran with warm loads on.

**2. Several conclusions do not carry over to production flags.**

| Conclusion | Why it needs re-testing |
| --- | --- |
| Worker overhead is 3–4% (phase 242) | Measured warm off. Worker takes 146–157 s warm on with source 248; Page took 93–101 s in phase 156. The dates differ, so the real overhead is unknown. |
| The 100→200 s gap is unexplained | Page took 226–230 s warm off and 93–101 s warm on. The flag may explain most of the gap. |
| Public cold entry misses 15 s (205, 237, 239) | `phase237/native237/build.mjs` sets 0, as do the lab builds through phase 228. All warm-on journeys in phases 252–253 passed the offline cold guard, and the warm-off control failed it. That guard is a different test, so re-run the public case. |
| Deep joined catch-up misses 30 s (182, 237) | Same lab builds. It has not been measured warm on. |

**3. Outside load overlapped the input measurements.**

A separate read-only Claude session ran on this Mac during phases 252 and 253.

- Journeys 01 and 02: bulk `git diff`, `find` and `grep` commands between 10:12 and 10:18 CET.
- Journey 04: lighter `grep` and JSON parsing between 10:32 and 10:35 CET.
- Journey 03: trivial reads only.

Treat 01, 02 and 04 as having extra host load. That does not explain the input failure, because journey 04 still missed at 25.2 ms. Its eight slow keys show no long tasks, and about 3 ms at most from event creation to DOM. The delay falls before event creation, which points away from Window work. Four of the eight overlap a driver gap, so the driver or browser input path needs a clean control.

## Where client time goes

Peer polling costs about as much as the real payload, or more. Quiet peers alone take 28–41% of client time with warm loads on, and 39–56% with them off.

| Journey | Warm loads | Client | Run (s) | Payload batches (%) | Quiet peers (%) | Live writer (%) | Other (%) |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 01 normal | On | H1 | 150 | 35 | 34 | 20 | 12 |
| 01 normal | On | H2 | 156 | 40 | 41 | – | 19 |
| 02 withheld | On | H1 | 135 | 42 | 28 | 19 | 11 |
| 02 withheld | On | H2 | 145 | 42 | 41 | – | 17 |
| 03 normal | Off | H1 | 280 | 27 | 39 | 19 | 16 |
| 03 normal | Off | H2 | 281 | 30 | 56 | – | 14 |

Each share is the gap from a request to that client's next request, from `result.json` under `/private/tmp/done-verified-selection-control-20261030`. H2's shares also absorb envelope work before each submit, so they are upper bounds. Live-writer reads on H1 include real edits. Phase 246's Worker trace gives a direct count with warm loads off: empty steps took 54% of H1's run and 51% of H2's.

- **Check rate:** each quiet peer is checked about once a second (median gap 0.8–1.2 s). The 750 ms memo holds as a floor, so the cost sits in each check.
- **Check cost:** a check takes about 95–130 ms warm on and 150–185 ms warm off. Network is about 14 ms of that.
- **State loads:** an empty step loads authenticated state four times: status before, `prepareRead`, `receivePage` and status after.
- **Hints:** each content hint clears every quiet entry (`accountReceive.ts:3583`). Journey 01 made 1,370 single reads in 156.6 s, and hint-free journey 02 made 1,108 in 145.9 s.
- **Phase 250's throughput cost:** in normal mode, 41 more hints came with 124 more single reads on H1. That is roughly 19 of the extra 31 s. Withheld mode shows no such pattern (+37 on H1, −10 on H2), so this explains only part of it.

## Next work, in order

Fix the baseline first, then remove wasted work, then change the scheduler. Several ordering rules date from when this work shared a thread with input. After each step, re-run the fixed journeys at production flags against every original gate. As of 11:05 CET, phases 257–258 cover steps 1 and 2.

1. **Record the flag mismatch and the overlap.** Add both to the phase record. Keep every prior result and failure as it stands.
2. **Re-baseline at production flags.**
    - Leave `VITE_ACCOUNT_WARM_LOADS` unset and change nothing else in the phase 241 apparatus.
    - Repeat Page `8d6d42c1` against Worker `0ab9cbc8` in ABBA order.
    - Re-run public cold entry and deep joined catch-up.
    - Add a harness check that build flags equal the release flags, unless a case names the difference.
    - If Worker/Page reaches the predeclared 1.10 signal, attribute that before adding mechanism.
3. **Finish the input control.**
    - Run the withheld journey with nothing else on the host.
    - Compare warm on and warm off at the offer-to-event-creation stage.
    - Test whether driver observers or CDP traffic scale with the higher request rate.
4. **Measure work as well as time.**
    - Count requests, signatures, state loads, strict commits and Window round trips per 1,024 positions and per publication. Counts do not drift; the same warm-off build took 236 s and 281 s.
    - Take one Worker CPU profile of an empty step and of envelope preparation. I found none for the Worker.
    - Test the `cpuBudget.ts` idea with the existing `VITE_ACCOUNT_CPU_YIELD=0` flag (`accountCapture.ts:337`). Input no longer shares this thread.
5. **Skip the Window for empty reads.**
    - An empty reply calls `promote([])` (`accountReceive.ts:1595`), so `workerWorkspaceQueues.ts` runs the full flight with nothing to apply.
    - That means four Worker-Window exchanges, a capture task and a pass through the Window FIFO: `workspacePrepare`, `workspaceFrames`, `workspaceFinish` and `workspaceApply`.
    - The Page path's `immediate` shortcut is unused here, so this may explain part of any Worker overhead.
    - Return after verification when there are no updates. First check what relies on the flight's side effects, including `prepareOwned` aborting maintenance and calling `notify`.
6. **Cut the commits in each publication.**
    - A new publication makes five appends: position, attempt, envelope, submission and response.
    - Each append makes two strict commits (`contentStore.ts:721` and `:766`), so a publication makes at least 10.
    - Reserve sequence numbers in blocks. `contentStore.ts:739` already allows abandoned ranges. Check the budget at `contentRecord.ts:279` first.
    - See whether position and attempt can share one append.
    - Stop reloading rows this owner just wrote. `prepareNextEnvelope` reloads three times, and `persist` loads again before committing.
    - Keep the write-ahead order: the invocation is durable before sealing, and the envelope is durable before submission.
7. **Check quiet peers in one batched request.**
    - `read-v2-batch` takes four separately signed reads. Neither `account-service/inboundBatch.ts` nor `receivePageTransport.ts` requires one publisher.
    - The client path is missing: `outstandingGroup` and `receiveGroup` assume one publisher.
    - Keep every page verification. Keep the conflict check and a fresh final status once per batch.
    - Keep a cadence near one second, so withheld-mode discovery does not regress.
    - Each empty read also costs the service a signature check, a write transaction and a signature.
    - Estimate: 30–45 s off a 150 s journey and about 900 fewer requests.
8. **Name the publisher in content hints.**
    - `account-service/notifications.ts` sends a boolean today. A named hint would invalidate one quiet entry and check that peer next.
    - It stays a scheduling input: no proof, no progress and no skipped peers. The service can already delay any read, so it gains no new power.
    - This targets the 560 ms writer search in phase 246's trace.
    - The backlog's phase 243 entry rules out prioritising an unauthenticated publisher hint, with no recorded reason. State the reason or propose amending the rule.
    - This is a wire change, so ask the operator first.
9. **Let send and receive overlap.**
    - `accountSyncDriver.ts:3` says "Two lanes, one pass". I found no recorded reason in `decisions.md` or the TRD.
    - Both lanes use capture tasks, so overlap the network waits and leave storage serialized. First check what depends on whole-pass exclusion.
    - If this is safe, it can replace the phase 248 yield. Expect a similar upload increase, so pair it with step 10.
10. **Publish less while peers are busy.**
    - Keys 500 ms apart and a 300 ms quiet window make nearly every key a publication: 109 uploads for 120 keys.
    - Each publication costs the sender its commits and every receiver a step.
    - Test a longer quiet window while a backlog exists, inside the existing 2 s maximum, against every marker.
11. **Read more per round trip.**
    - The client sends `limit: 1` (`accountReceive.ts:1149`), while the wire allows 8 entries per signed read.
    - `verifyInboundPage` reads only `entries[0]`. `verifyHistoryPage` already handles multi-entry pages under a fixed cut.
    - Once step 7 separates quiet checks from turn order, stay longer on a publisher with known backlog.
    - Estimate: 25–30 s here, and more on real networks. Reads take about 14 ms on localhost; 1,400 reads at 50 ms extra adds about 70 s.
12. **Verify concurrently and cache imported keys.**
    - `crypto.subtle` already runs off-thread, but the loop in `inboundLedger.ts` awaits one check at a time.
    - Check a known batch concurrently, then commit in order. This needs no second Worker.
    - Cache imported keys. On 10-12, one open ran 6,684 imports and 5,420 signature checks. Recount first, because those figures are dated.

## Hold for now

These items may matter later, but none has the evidence or approval to start.

| Item | Waiting for |
| --- | --- |
| Snapshot plus tail (`VITE_ACCOUNT_HISTORY_AUTO`) | Operator approval. It is the only item that stops cost growing with history. |
| One signed list of publisher tips, or a workspace change feed | An operator design decision. Polling grows with every certified reader, and step 7 is only the interim. |
| Freshness check once per sweep instead of per task | An operator decision, because it widens the accepted warm-load trust window |
| Persisted verified prefix for cold open | A trace of public cold entry at production flags, plus an operator decision on how far AEAD-sealed local rows are trusted. Phase 121 saw three full baseline validations on one reopen. |
| Phone open and refocus evidence | Operator approval. Phone work is excluded today, but these are the stalls the operator reported. |
| Download ahead of verification | Steps 7 and 11, plus a design for read-request expiry |
| Coalescing received-page updates in the Window | Evidence. Phase 253 found no long tasks or handler cost behind the local gate miss. |
| OPFS ledger storage or a verification Worker | A Worker profile showing storage or crypto dominate. `2026-10-12-bulk-custody` was a negative result. |
| Releasing the native task before the Window apply reply | Evidence of Window stalls, plus a durability design (`acknowledgedReceive.ts`) |
| New proof reuse or finer yields | Steps 2–7 at production flags |

## Limits

This brief adds no authorization, and every constraint in the active task stays in force.

- Keep the 16 ms, 2.5 s peer and every-marker, 30 s and 600 s gates, every native check and synchronous journal admission.
- No signing, push, merge, release preparation, deployment, preview change, service automation, computer use, phone work or real profiles.
- No heavy work during timed runs, and no favorable reruns.
- Keep sequential patches and the usual `decisions.md`, `completed.md` and backlog entries.
- Verify the flags, counts and time shares against the raw results before relying on them. The estimates in steps 7 and 11 are untested. Steps 5, 6 and 12 come from reading code, with no costs measured. One run per mode supports no population claim.
- Phases 241 onward exist only in the working tree and `/private/tmp`, so protect them before any cleanup.

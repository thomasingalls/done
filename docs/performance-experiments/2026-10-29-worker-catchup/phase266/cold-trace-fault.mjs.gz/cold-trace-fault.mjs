import {profileWorker} from './worker-profile.mjs';
const now=()=>performance.timeOrigin+performance.now();
export function installColdProbe(){
 const state={shellAt:null,longTasks:[],overflow:0,support:PerformanceObserver.supportedEntryTypes.includes('longtask')};
 const sample=()=>{if(state.shellAt===null&&document.querySelector('.shell'))state.shellAt=performance.timeOrigin+performance.now();};
 new MutationObserver(sample).observe(document,{childList:true,subtree:true});sample();
 if(state.support)new PerformanceObserver(list=>{for(const e of list.getEntries()){if(state.longTasks.length<10000)state.longTasks.push({start:performance.timeOrigin+e.startTime,duration:e.duration});else state.overflow++;}}).observe({type:'longtask',buffered:false});
 window.__coldNumericProbe=()=>structuredClone(state);
}
function numericRealm(){return{at:performance.timeOrigin+performance.now(),timeOrigin:performance.timeOrigin,metrics:typeof globalThis.__doneLedgerMetrics==='function'?globalThis.__doneLedgerMetrics():null,milestones:typeof globalThis.__doneOpenMilestones==='function'?globalThis.__doneOpenMilestones():null,shell:typeof document!=='undefined'?!!document.querySelector('.shell'):null,probe:typeof globalThis.__coldNumericProbe==='function'?globalThis.__coldNumericProbe():null};}
async function bounded(job,ms){let timer;try{return await Promise.race([job,new Promise(resolve=>{timer=setTimeout(()=>resolve({unavailable:'observer-deadline'}),ms)})]);}catch{return{unavailable:'realm-closed'}}finally{clearTimeout(timer);}}
export async function tracePublicCold(page,record,openOriginal){
 const state=record.coldDiagnostic={startedAt:now(),originalShellDeadlineMs:15000,snapshots:[],profile:null,profileError:null};let selected=false,profileJob,inFlight,stopped=false;
 const attach=worker=>{if(selected||!worker.url().includes('/assets/accountOwner.worker-')||worker.url().includes('/worker-app/'))return;selected=true;state.profileSelectedAt=now();profileJob=profileWorker(page.context().browser(),url=>url===worker.url()).catch(error=>{state.profileError=String(error);return null});};
 page.on('worker',attach);for(const worker of page.workers())attach(worker);
 const snapshot=label=>{if(inFlight)return inFlight;inFlight=(async()=>{const requestedAt=now(),workers=page.workers();const realms=await Promise.all([bounded(page.evaluate(numericRealm),2000),...workers.map(w=>bounded(w.evaluate(numericRealm),2000))]);state.snapshots.push({label,requestedAt,returnedAt:now(),realms:realms.map((value,i)=>({realm:i===0?'Window':'Worker',asset:i===0?null:new URL(workers[i-1].url()).pathname,...value}))});})();return inFlight.finally(()=>{inFlight=undefined});};
 let originalError,timer;try{await snapshot('before-original-open');timer=setInterval(()=>{if(!stopped&&state.snapshots.length<24)void snapshot('periodic').catch(()=>{});},5000);
 try{await openOriginal();state.originalGate='passed';state.originalReturnedAt=now();}catch(error){originalError=error;state.originalGate='failed';state.originalError=String(error);state.originalFailedAt=now();}
 await snapshot('after-original-gate');if(originalError){const remaining=Math.max(0,90000-(now()-state.startedAt));try{await page.waitForFunction(()=>!!document.querySelector('.shell'),undefined,{timeout:Math.max(1,remaining)});state.shellObservedAfterGateAt=now();}catch{state.shellObservationCensoredAt=now();}}
 }finally{stopped=true;if(timer)clearInterval(timer);page.off('worker',attach);await snapshot('final');const capture=profileJob?await bounded(profileJob,2000):null;if(capture?.stop){try{state.profile=await capture.stop();}catch(error){state.profileError=String(error);}}else if(!selected)state.profileError='No shipping account Worker observed';state.finishedAt=now();}
 
}

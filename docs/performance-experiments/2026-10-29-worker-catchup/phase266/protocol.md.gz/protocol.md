# Phase266 — public cold-open attribution after both original baseline paths

2026-10-30. Rebuild exact signed0abfrontend/native lab with released settings, warmunset and one
named diagnostic exception VITE_ACCOUNT_LEDGER_PROFILE=1. Service is unmodified signed0ab with
original16/session64/process and all native/security/admission bounds. Do not carry lab64 policy.
Original lab zero preparation identity retained as before; shipping frontend actual source identity.
Question: how much fresh cold-open work repeats baseline validation/recovery versus other native
work, after journal-era rebind and after completed resumable reduction? No optimization selected.

Run both original cases once serially with fresh fictional state/profiles. Every case body/assertion,
original15s.shell gate,180swholecase, native baseline/saved-slice/cold-resume/reduction/input/Undo
checks stays. Only shipping observer helper wraps unchanged openSaved. If original15sgate fails,
record/rethrow that original failure regardless of later progress. Observe shell until at most90s
from public open start, bounded also by original180swholecase. Later shell observation earns no pass.
Cases that do not reach cold shipping retain prior failures; missing profile is unavailable, notzero.

Metadata-only hooks __doneLedgerMetrics/__doneOpenMilestones sampled from Window and each live
Worker, before open, every5s (<=24snapshots), at original gate and final. Each observer evaluation
has2sdeadline; busy/closed realm recorded unavailable rather than blocking forever. Preserve node
request/return brackets and each realm timeOrigin/sampletime; milestone times are per-realm.
No equal-clock or zero-missing assumptions. Counters/timings stay numeric/fixed enums; no writing,
keys,factors,proofs,heap/script snapshots or raw RPC serialized. Window probe records first.shell
mutation time and >=50msLongTasks, max10k with overflow. Init on actual public navigation/reload.

Capture one actual shipping accountOwner Worker CPU profile per case with1ms sampling, attached
without pause after Worker creation. Record attach/start/stop bounds and any errors. Source-map
closure/assets independently verified. Public CDP synthetic150msbusy-loop smoke proves actual
Worker profile samples; first smoke import used absent directplaywright-core path and failed before
browser launch, corrected to installed@playwright/test and retained. No product monkeypatch,
crypto/storage/verification bypass or changed scheduling policy. Original realtime factor prompts
remain actual fictional native WebAuthn setup. All source checks preserve each signed body.

Analysis: report original gate outcome, later.shell time or censoring, realm milestone durations,
baselineFullReplays/exact/warm/incremental reuse and startup/load/custody/authority costs, profile
CPU self/inclusive sample weights mapped to exact source. Distinguish sampled JS/wasmCPU, async/
idle/I/O and walltime. Counters count calls/work, summed nested durations are not exclusive elapsed
cost. Repeat validation is a candidate only if actual repeated counts/timings/profile support it;
no cache widening/persisted trustedprefix from this trace. Missing hooks/partialprofile invalidates
that attribution, not native security checks or original failure record. One case each/diagnostic
instrumentation may perturb timing; no population/phone or release acceptance claim.

No heavy concurrent host work/build/test/profile. Keep all prior fail/pass receipts and sequential
patches; completion records before backlog. Rate experiment265supported partial budget contribution,
not30sclosure. The normalcard fixture needs a safe civil refresh before later capped/uncapped
Page/Worker/yield trajectories. Independent cold traces proceed first because no card editability
assumption. No source repair/sign/push/merge/releaseprep/deploy/preview/serviceautomation/CUA/
phone/real data. Every16ms/2.5s/everymarker/30s/600s gate remains for subsequent acceptance work.

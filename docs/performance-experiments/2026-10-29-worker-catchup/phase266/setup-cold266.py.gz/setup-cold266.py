from pathlib import Path
import shutil,json,hashlib,subprocess,os,time
m=Path(__file__).parent;old=Path('/private/tmp/done-production-native-compatibility-20261030');r=Path('/private/tmp/done-public-cold-profile-20261030');repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');source=(old/'source-after').resolve();sha=lambda b:hashlib.sha256(b).hexdigest()
shutil.copytree(source,r/'source-after',symlinks=True);(r/'source-R').symlink_to(r/'source-after',target_is_directory=True);(r/'node_modules').symlink_to(repo/'node_modules',target_is_directory=True);(r/'test-inputs').symlink_to((old/'test-inputs').resolve(),target_is_directory=True);(r/'private-fixture').symlink_to((old/'private-fixture').resolve(),target_is_directory=True)
shutil.copytree(old/'harness',r/'harness',symlinks=True,ignore=shutil.ignore_patterns('node_modules','test-results','artifacts'));(r/'harness/node_modules').symlink_to(repo/'node_modules',target_is_directory=True)
for f in(r/'harness').rglob('*'):
 if f.is_file()and not f.is_symlink()and f.suffix in ['.mjs','.ts','.json']:f.write_bytes(f.read_bytes().replace(str(old).encode(),str(r).encode()))
shutil.copytree(old/'lab',r/'lab',symlinks=True)
for n in ['src','account-protocol','wasm']:
 p=r/'lab'/n;p.unlink();p.symlink_to(r/'source-after'/n,target_is_directory=True)
for n in ['container-image.json','container-service.mjs','observer.mjs','run.py','smoke.mjs','release-flags.json','source-inputs.json']:(r/n).write_bytes((old/n).read_bytes().replace(str(old).encode(),str(r).encode()))
flags={**json.loads((r/'release-flags.json').read_text())['expected'],'VITE_ACCOUNT_LEDGER_PROFILE':'1'};(r/'build-flags.json').write_text(json.dumps(flags,indent=2)+'\n');assert 'VITE_ACCOUNT_WARM_LOADS'not in flags
node='/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node';env={k:v for k,v in os.environ.items()if not k.startswith('VITE_ACCOUNT_')};env.update(flags);env.update({'APP_BUILD_REVISION':'0ab9cbc8937e32c6542aaeeca697c87ba116c3be','APP_BUILD_DATE':'2026-10-30','PATH':str(Path(node).parent)+':'+os.environ['PATH']});start=time.time_ns()//1000000
with(r/'frontend-build.log').open('w')as f:p=subprocess.run([node,str(r/'source-after/node_modules/vite/bin/vite.js'),'build','--outDir',str(r/'frontend'),'--emptyOutDir','--sourcemap'],cwd=r/'source-after',env=env,stdout=f,stderr=subprocess.STDOUT)
assert p.returncode==0
s=(old/'build.mjs').read_text().replace(str(old),str(r));anchor="define:{__ACCOUNT_PREPARATION_VERIFIER__";assert anchor in s;s=s.replace(anchor,"define:{'import.meta.env.VITE_ACCOUNT_LEDGER_PROFILE':JSON.stringify('1'),__ACCOUNT_PREPARATION_VERIFIER__");(r/'build.mjs').write_text(s)
with(r/'lab-build.log').open('w')as f:p=subprocess.run([node,str(r/'build.mjs')],cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
assert p.returncode==0;(r/'build-receipt.json').write_text(json.dumps({'sourceCommit':'0ab9cbc8937e32c6542aaeeca697c87ba116c3be','flags':flags,'namedException':{'VITE_ACCOUNT_LEDGER_PROFILE':'1'},'warmLoads':'unset/default-on','startedAt':start,'finishedAt':time.time_ns()//1000000,'labPreparationIdentity':'original zero fixture identity preserved'},indent=2)+'\n')
# Original runner retains its180s whole-case ceiling; make profile flag exception explicit.
p=r/'run.py';s=p.read_text().replace("json.loads((r/'release-flags.json').read_text())['expected'],'Release flag mismatch'","{**json.loads((r/'release-flags.json').read_text())['expected'],'VITE_ACCOUNT_LEDGER_PROFILE':'1'},'Unapproved profiling flag difference'");p.write_text(s)
print('Actual public/frontend+native lab rebuilt, exact0absource; only named diagnosticflag1, all default budgets')

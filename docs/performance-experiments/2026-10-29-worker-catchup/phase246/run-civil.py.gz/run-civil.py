from pathlib import Path
import os,json,subprocess,hashlib,time,sys
import datetime
assert datetime.datetime.now(datetime.timezone.utc).date().isoformat()=='2026-10-29'
r=Path(__file__).parent;node='/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node';sha=lambda b:hashlib.sha256(b).hexdigest();qa=json.loads((r/'marker-qa.json').read_text());assert sha(Path('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome').read_bytes())==qa['browserSha256'];assert sha((r/'private-fixture/fixture.json').read_bytes())==qa['fixtureSha256'];assert json.loads((r/'marker-assets.json').read_text())=={str(f.relative_to(r/'marker-dist')):sha(f.read_bytes())for f in(r/'marker-dist').rglob('*')if f.is_file()}
for f in r.glob('*/container.cid'):
 p=subprocess.run(['docker','inspect','--format','{{.State.Running}}',f.read_text().strip()],capture_output=True,text=True);assert p.returncode!=0,'Own prior container remains'
commands=subprocess.check_output(['ps','-axo','command'],text=True);assert not any(v.startswith('/Applications/Google Chrome')and'--user-data-dir='+str(r)+'/'in v for v in commands.splitlines())
case={'name':'06-civil-diagnostic','variant':'marker','mode':'late','withhold':False,'config':'marker-civil.config.ts'};out=r/case['name'];out.mkdir(mode=0o700);env={**os.environ,'PATH':str(Path(node).parent)+':'+os.environ['PATH'],'CHROMIUM_PATH':'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome','FAIR_OUT':str(out),'FAIR_VARIANT':'marker','FAIR_DIST':str(r/'marker-dist'),'QUIET_WITHHOLD':'0'};cmd=[node,'node_modules/@playwright/test/cli.js','test','--config','test/account-continuation-lab/marker-civil.config.ts'];receipt={'case':case,'startedAt':time.time_ns()//1000000,'command':cmd,'diagnosticOnly':True}
with(out/'console.log').open('w')as f:p=subprocess.run(cmd,cwd=r/'harness',env=env,stdout=f,stderr=subprocess.STDOUT)
receipt.update(exit=p.returncode,finishedAt=time.time_ns()//1000000);(out/'runner-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('Functional diagnostic exit',p.returncode,flush=True)
if p.returncode:sys.exit(p.returncode)
with(out/'analysis.log').open('w')as f:p=subprocess.run([sys.executable,str(r/'analyze-case.py'),json.dumps(case)],stdout=f,stderr=subprocess.STDOUT)
print('Diagnostic existing-gate analysis exit',p.returncode,flush=True)
sys.exit(p.returncode)

# Retained analysis corrections

The first analyze-civil.py attempt incorrectly compared all final network requests with an earlier
trace snapshot. Capture intentionally happens after new delivery, before the remaining catch-up:
H1 later has37 and H2 has94 additional200read calls. Restrict source-event matching to its ordered
captured prefix; retain the single prepared/unfetched tail. Workload or assertions were not changed.

The second attempt assumed Playwright's response callback always preceded Worker fetch completion.
That is false: CDP/event-loop delivery is asynchronous. Actual five Worker/driver clock brackets give
H1 offset[-0.951660,1.638672]ms and H2[-0.935059,1.665039]ms. On matched prefixes, driver header
observations can be later than source completion (82/80 rows, observed upper maxima35.865/865.466ms).
Do not turn callback times into physical wire arrival, inflate clock allowances, or hide late callbacks.
The corrected analysis retains those counts/limits, requires ordered prepare/group counts to match
real requests, and uses direct Worker brackets for internal timelines. Original latency gates remain
computed by the original analyzer and original clock allowances. No additional journey was run.

Attempt source files and assertion sites are archived. Their redirected stdout logs are empty because
Python wrote the assertions to stderr; this note preserves the failure facts instead of claiming those
empty logs prove success. The final reconstruction and separate raw-data review agree on stage values.

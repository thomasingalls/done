from pathlib import Path
import json,math
r=Path(__file__).parent;x=json.loads((r/'06-civil-diagnostic/result.json').read_text());assert x['outcome']=='passed';assert all(x['guards'].values());assert len(x['offers'])==123
m=next(q for q in x['offers']if q['kind']=='marker'and q['index']==2);t=m['at'];readers={v['readerSha256']for q in x['network']if q['label']=='H2'for v in q.get('reads',[])};assert len(readers)==1
clock=[v for g in x['clocks']for v in g['rows'][0]];offset=max(v['renderer']-v['after']-1 for v in clock);visible=x['probes'][0]['markers'][2]-offset
out={'diagnosticOnly':True,'markerAt':t,'peerVisibleUpperMs':visible-t,'realms':[],'chronology':[]}
for device in x['ownerEvents']:
 assert all(v['dropped']==0 for v in device['realms']);active=[v for v in device['realms']if any(q['tag']=='begin'for q in v['rows'])];assert len(active)==1,(device['label'],len(active));rows=active[0]['rows'];assert all(a['at']<=b['at']for a,b in zip(rows,rows[1:]));out['realms'].append({'client':device['label'],'events':len(rows),'dropped':0})
 # Operational cross-clock bounds from original transport causality, not assuming equal realm clocks:
 # prepared BEFORE request observed by driver, fetched AFTER headers observed by driver.
 # Use ordered actual delivery requests and trace pairs; read-prepared/fetched must align exactly.
 net=[q for q in x['network']if q['label']==device['label']and q['path']in ['/account/delivery/read-v2','/account/delivery/read-v2-batch']and q.get('status')==200]
 pre=[q for q in rows if q['tag']=='read-prepared'];post=[q for q in rows if q['tag']=='receive-fetched'];assert len(pre)>=len(post)and len(pre)-len(post)<=1,(len(net),len(pre),len(post));assert len(net)>=len(post)and len(net)-len(post)<=1,(len(net),len(pre),len(post))
 workerIndex=next(i for i,v in enumerate(device['realms'])if v is active[0])-1;assert workerIndex>=0;clockRows=next(v for v in x['workerClocks']if v['label']==device['label'])['rows'][workerIndex];lo=max(v['renderer']-v['after']-1 for v in clockRows);hi=min(v['renderer']-v['before']+1 for v in clockRows);assert lo<=hi,(lo,hi)
 out['realms'][-1]['workerMinusDriverBoundMs']=[lo,hi];out['realms'][-1]['clockMethod']='actual Worker/driver five clock brackets with1ms allowance';out['realms'][-1]['matchedRequests']=len(post);out['realms'][-1]['traceTailCounts']={'prepared':len(pre),'fetched':len(post),'observed200':len(net)}
 for a,b,q in zip(pre,post,net):
  assert a['at']-hi<=q['at']+1 and b['at']-lo>=q['headersAt']-1,('transport order',a,b,q)
 # Conservative earliest/latest driver positions. Within-Worker differences need no clock conversion.
 chosen=[]
 for q in rows:
  if t-300<=q['at']-lo<=visible+400:
   chosen.append({'tag':q['tag'],'values':q['values'],'workerAt':q['at'],'driverRelativeLowerMs':q['at']-hi-t,'driverRelativeUpperMs':q['at']-lo-t})
 out['chronology'].append({'client':device['label'],'events':chosen})
submit=next(q for q in x['network']if q['label']=='H2'and q['path']=='/account/delivery/submit'and q['at']>=t);read=next(q for q in x['network']if q['label']=='H1'and q['at']>=submit['headersAt']and any(v['publisherSha256']in readers for v in q.get('reads',[])))
out['coarseStagesMs']={'markerToSubmit':submit['at']-t,'submitRequestToHeaders':submit['headersAt']-submit['at'],'submitHeadersToWriterRead':read['at']-submit['headersAt'],'readRequestToHeaders':read['headersAt']-read['at'],'readHeadersToVisibleUpper':visible-read['headersAt']}
(r/'civil-attribution.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k!='chronology'},indent=2))
for v in out['chronology']:
 print('\n',v['client'])
 for q in v['events']:print(round(q['driverRelativeLowerMs'],2),round(q['driverRelativeUpperMs'],2),q['tag'],q['values'])

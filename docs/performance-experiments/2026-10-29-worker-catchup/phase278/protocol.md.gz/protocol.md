# Phase 278 — deep joined traffic extent/cadence before multi-entry repair

Run original deep joined actor1 once on exact frozen275 client assets, production flags, default
16/session64/process limits and30s gate. Only Node observer changes: request at and response
headersAt in one epoch/performance clock, method/path/status and bounded decoded publisher/after/
limit. Capture successes and failures, at most8192requests, explicit dropped/malformed counts,
no response bodies, signatures, tokens, codes or writing. Observation grants no verification.
Keep source publication before sender closes, original native admission, Undo and cold exactness.
No fixture refresh, product change, normal Page/Worker comparison, higher production budget or
release preparation. First account cold repair passed separately; do not attribute new deep
outcome to bulk reads, which do not exist yet. Preserve all raw outcomes and original gates.

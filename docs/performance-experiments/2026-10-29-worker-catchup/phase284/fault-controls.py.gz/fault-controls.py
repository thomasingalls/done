from pathlib import Path
import shutil,subprocess,os,json,re
r=Path(__file__).parent;repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');src=r/'fault-source';
if not src.exists():shutil.copytree('/private/tmp/done-unreduced-baseline-after-20261030/source-after',src,symlinks=True)
shutil.copytree(repo/'test',src/'test',dirs_exist_ok=True);shutil.copytree(repo/'docs/account-crypto',src/'docs/account-crypto',dirs_exist_ok=True)
changed=['accountInbound.ts','accountMembership.ts','accountSuccessor.ts','inboundRecord.ts','inboundLedger.ts','incrementalAccountLedger.ts','localRetentionPlan.ts']
for n in changed:shutil.copy2(repo/'src/crdt'/n,src/'src/crdt'/n)
faults=[
 ('skip-later-entry','accountInbound.ts','index < Math.max(1, p.entries.length)','index < Math.min(1, p.entries.length)','multiEntryInbound.test.ts','the entire range refuses a bad-envelope'),
 ('skip-aggregate-record-bound','accountInbound.ts','if (bytes > MAX_BATCH_BYTES || records > MAX_BATCH_RECORDS)', 'if (false)','multiEntryInbound.test.ts','a range exceeding the existing atomic record count'),
 ('skip-stored-page-auth','accountInbound.ts','{ index: event.entry, authenticate: authenticateInboundWire }','{ index: event.entry, authenticate: async () => {} }','multiEntryInbound.test.ts','stored v2 receipts authenticate their original service page'),
 ('borrow-context','accountInbound.ts','context = captureContext(input)','context = input','multiEntryInbound.test.ts','range verification owns its caller bytes'),
 ('membership-fallthrough','accountMembership.ts','return isInboundRecordTag(v[0])',"return v[0] === 'done/account-inbound/v1'",'multiEntryInboundReaders.test.ts','membership boundary reads a v2 receipt epoch'),
 ('successor-fallthrough','accountSuccessor.ts','isInboundRecordTag(v[0])',"v[0] === 'done/account-inbound/v1'",'multiEntryInboundReaders.test.ts','successor and membership replay boundaries'),
 ('census-fallthrough','inboundLedger.ts','else if (isInboundRecordTag(tag))',"else if (tag === 'done/account-inbound/v1')",'multiEntryInboundReaders.test.ts','full census keeps v2 receipts out'),
 ('retained-wrong-entry','inboundLedger.ts','entries[event.entry ?? 0]','entries[0]','multiEntryInboundReaders.test.ts','successor and membership replay boundaries'),
 ('index-epoch-fallthrough','incrementalAccountLedger.ts','if (isInboundRecordTag(f[0]))',"if (f[0] === 'done/account-inbound/v1')",'multiEntryInboundReaders.test.ts','cold incremental indexing derives the epoch'),
 ('extension-eligibility-fallthrough','incrementalAccountLedger.ts','if (isInboundRecordTag(tag))',"if (tag === 'done/account-inbound/v1')",'multiEntryInboundReaders.test.ts','incremental v2 admission takes the checked extension path'),
 ('extension-event-fallthrough','incrementalAccountLedger.ts','isInboundRecordTag(tag) ? decodeInboundRecord',"tag === 'done/account-inbound/v1' ? decodeInboundRecord",'multiEntryInboundReaders.test.ts','incremental v2 admission takes the checked extension path'),
 ('retention-fallthrough','localRetentionPlan.ts','else if (isInboundRecordTag(tag))',"else if (tag === 'done/account-inbound/v1')",'multiEntryInboundReaders.test.ts','native local retention classifies v2 receive frontiers'),
]
rows=[];node='/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node';env={**os.environ,'APP_BUILD_REVISION':'0ab9cbc8937e32c6542aaeeca697c87ba116c3be-dirty','APP_BUILD_DATE':'2026-10-30'}
for name,file,needle,replacement,test,selection in faults:
 p=src/'src/crdt'/file;original=p.read_bytes();assert original.decode().count(needle)==1,(name,needle)
 p.write_text(original.decode().replace(needle,replacement));report=r/('fault-'+name+'.json')
 try:
  with(r/('fault-'+name+'.log')).open('w')as out:result=subprocess.run([node,str(src/'node_modules/vitest/vitest.mjs'),'run','test/'+test,'--testNamePattern',selection,'--reporter=json','--outputFile',str(report)],cwd=src,env=env,stdout=out,stderr=subprocess.STDOUT)
  data=json.loads(report.read_text());failed=[a for f in data['testResults']for a in f['assertionResults']if a['status']=='failed'];assert result.returncode==1 and data['numFailedTests']==1 and len(failed)==1 and selection in failed[0]['fullName'],(name,result.returncode,data)
  rows.append({'fault':name,'file':file,'selection':selection,'exit':result.returncode,'exactNamedCaseFailed':True})
 finally:p.write_bytes(original)
 assert p.read_bytes()==original
(r/'fault-controls.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))

# Phase 280 — multi-entry reader contract and red regression

2026-10-30. Keep all existing gates, production session16/process64, wire limit8, four-position
publisher allowance, pending/admission/native bytes and record limits. Existing multi-request
batching returns limit1 pages; only request/page count changes in a later writer phase.

Reader-first bounded outcome: extend the shared inbound verification mechanism, preserving the
existing one-entry public API and byte-exact v1 records/negative tests. New explicit range API may
verify a current forward range under the captured outstanding owner-signed request. Fresh service
page/request binding, every acceptance/envelope signature, expected position/parent/epoch/key/actor,
request expiry and synchronous owner lifetime checks remain. No prefix escapes an invalid range.
Header authentication can be shared only inside this one call, not persisted as trust or transferred.

Canonical encrypted plaintext receipt v2 adds an explicit selected-entry index to original v1-like
JSON fields while retaining the complete original signed request and page. Each selected position
gets its own receipt/update coverage and spool witness event. This keeps existing per-position
history/cut/adoption semantics, including a cut inside a downloaded range, instead of requiring a
new authority cut model. v1 stays closed and rejects wider requests; old readers refuse v2 rather
than misinterpret it. All current tag consumers (full/incremental census, membership/successor
boundary, retention and handoff replay) must recognize the new receipt through one tag home.
Stored replay reauthenticates original evidence, independent prefix and selected index after expiry;
never trusts a response-selected route/retained prefix. No service wire/crypto key/AD change.

Tradeoff: each indexed receipt carries the complete page, so a two-entry range can repeat evidence
twice. Keep width2 initially, all aggregate byte/record limits unchanged, and require actual deep/
fairness and normal gates before adoption. A new record label must be registered as an open crypto
qualification obligation; all prior specified contracts and release blocks remain. This is not
release authorization or a new trust promise. Reader phase does not enable production range writes.

Later planner/writer: only composed peer catch-up, only authenticated observed backlog, max width2
and max four positions in a publisher turn. Own reconciliation remains limit1. Short pages credit
actual verified positions, not requested width. Larger receipts/updates or HTTP replies must safely
replan single entries for that publisher without progress, disabling no other publisher or route;
all selected evidence is verified again, no fallback bypasses authentication. Reference, freshness,
late authority, commit/recheck/readback, FIFO/journal fencing and caller erasure remain.

Before implementation: independent Node/OpenSSL fixture creates genuine chained entries and signed
wider request/page. Check exact indexed v2 bytes, old v1 bytes/API, expiry vs stored replay, interior
cut, short/empty range, bad later entry/actor/link/signatures/request, prefix gap, final lifetime and
aggregate record bounds. Failed initial aggregate-receipt sketch is retained; it was superseded
before product edits because it crosses existing per-position cuts. No old tests changed.

After reader tests/guard faults/source bookkeeping, enable planner in a separate bounded patch,
add fairness/large-entry/fallback regressions, rerun original deep with at/headersAt. Page composition
is already a real syncing owner in the lab; then deep joined Page64 needs no date refresh. Finally
re-runnable fixture recipe and withheld/normal gates. Normal Page/Worker comparison remains held.
No computer use, real profiles, service automation, signing/push/deployment or release preparation.

from pathlib import Path
import json,subprocess,os,time
r=Path('/private/tmp/done-public-cold-owner-trace-20261030');previous=Path('/private/tmp/done-public-cold-profile-20261030')
flags={**json.loads((r/'release-flags.json').read_text())['expected'],'VITE_ACCOUNT_LEDGER_PROFILE':'1'};(r/'build-flags.json').write_text(json.dumps(flags,indent=2)+'\n');node='/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node';env={k:v for k,v in os.environ.items()if not k.startswith('VITE_ACCOUNT_')};env.update(flags);env.update({'APP_BUILD_REVISION':'0ab9cbc8937e32c6542aaeeca697c87ba116c3be-dirty','APP_BUILD_DATE':'2026-10-30','PATH':str(Path(node).parent)+':'+os.environ['PATH']});start=time.time_ns()//1000000
with(r/'frontend-build.log').open('w')as f:p=subprocess.run([node,str(r/'source-after/node_modules/vite/bin/vite.js'),'build','--outDir',str(r/'frontend'),'--emptyOutDir','--sourcemap'],cwd=r/'source-after',env=env,stdout=f,stderr=subprocess.STDOUT)
assert p.returncode==0
s=(previous/'build.mjs').read_text().replace(str(previous),str(r));(r/'build.mjs').write_text(s)
with(r/'lab-build.log').open('w')as f:p=subprocess.run([node,str(r/'build.mjs')],cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
assert p.returncode==0;(r/'build-receipt.json').write_text(json.dumps({'baseCommit':'0ab9cbc8937e32c6542aaeeca697c87ba116c3be','flags':flags,'sourceDiagnosticOnly':['src/crdt/coldOwnerDiagnostic.ts','src/crdt/workerChannel.ts','src/crdt/workerAccountHandoff.ts','src/crdt/firstDeviceOwner.worker.ts','src/ui/windowCeremonyUi.ts'],'allChecksAndThrowObjectsPreserved':True,'warmLoads':'unset','startedAt':start,'finishedAt':time.time_ns()//1000000},indent=2)+'\n')
p=r/'run.py';s=(previous/'run.py').read_text().replace(str(previous),str(r));p.write_text(s)
print('Correct actualownerCPU and bounded enum/location errors built; actualapp/controlflowchecks unchanged')

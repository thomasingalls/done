let emitted = 0;
export function reportColdOwnerError(site: string, input: unknown): void {
 try {
  if ('1' !== '1') return;
  if (++emitted > 100) { if (emitted === 101) console.info('done/experiment/' + JSON.stringify({kind:'cold-owner-error-overflow'})); return; }
  const chain: unknown[] = []; let cause: any = input;
  for(let i=0;i<4&&cause&&typeof cause==='object';i++) {
   const token=(v: unknown)=>typeof v==='string'&&/^[A-Za-z-]{1,64}$/.test(v)?v:null;
   const stack=typeof cause.stack==='string'?cause.stack.split(String.fromCharCode(10)).slice(1,8):[];
   const locations=stack.flatMap((line: string)=>{const m=/(https?:[/][/][^ )]+):([0-9]+):([0-9]+)/.exec(line);if(!m)return[];try{const u=new URL(m[1]!);return u.pathname.includes('/assets/')?[{asset:u.pathname,line:Number(m[2]),column:Number(m[3])}]:[]}catch{return[]}});
   chain.push({name:token(cause.name),code:token(cause.code),locations});
   const next=Object.getOwnPropertyDescriptor(cause,'cause');cause=next&&'value'in next?next.value:undefined;
  }
  console.info('done/experiment/'+JSON.stringify({kind:'cold-owner-error',site,chain}));
 } catch { /* Diagnostic failure must never replace the original refusal. */ }
}

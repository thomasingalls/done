# Phase268 — actual public owner CPU and bounded failure-location trace

2026-10-30. Preserve267partial attempt: numericfirstDeviceOwner metrics valid, guessedaccountOwner
CPUtarget absent. Firstcase diagnosticpass does not erase261unprofiled failure. Secondcase actual
public fallback/noWorker is not established purelatency. This phase corrects measurement coverage
and investigates that opening failure before any performance mechanism or trust-window decision.

Same two original bodies/assertions/deadlines, fresh fictional profiles, once serially. Signed0ab
base with releasedsettings/warmunset and namedLEDGER_PROFILE1. Actualservice remains original
16/session64/process. Native/public frontend rebuilt with four log-only failure-handler edits plus
one diagnostichelper in isolated source, never the repository product source. Import/callbacks
only at existing catches; original causes/rethrows/closed checks/security/cleanup order retained.
Full source/map/asset hashes identify variant. Default limits and effective startup policy checked.

Profile actual shipping firstDeviceOwner physicalWorker (or normalaccountOwner when used), excluding
labworkers. Attachwithoutpause/heap/script retrieval,1msCPUsampling. Same numeric all-live-realm
metrics/milestones and firstshell/WindowLongTasks as266,2sobserverbounds/5sinterval/max24snapshots.
Record original15s.shell assertion evenif it fails. After failure observe at most90s fromopen, stopping
also on the specific known publicfallback (numeric failureAt only). Later shell/fallback never
converts original result;180swholecase unchanged. Lost profile/hook data marked unavailable.

Failure diagnostics: <=100rows/realm plusoneoverflow marker, fixed site/name/code enums, up to4
cause levels and7staticasset stacklocations each. Omit error messages, payloads, owner/account IDs,
provider fields, keys/proofs/writing and arbitrary stacktext. Only /assets/ URLpathname,line,column.
Diagnostic function catches its own failures so it cannot replace original native exception. Existing
console observer captures these enum/location records. Five contract tests cover privacy/bounds/
noninterference and originalgate-preservation/unavailableprofiles. Corrected runtime CPUtarget must
be confirmed from actual profile, not solely synthetic primitive smoke. All original cases remain.

Analysis: map errorlocations and CPUnodes to the exact diagnostic source-map closure; distinguish
actual public fallback/refusal cause from slow checks and incomplete observers. Count replay/load/
startup work and within-realm milestones before attributing sampledCPU. Nested wall timings are
not exclusiveCPU. Report originalgate/shell/fallback outcome, samplecoverage and errors/censoring.
If real failure found, isolate it and add a regression before a repair; do not weaken checks or
pretend the fixture is stale merely to pass. If a fixture issue, retain it/prove closure separately.
No population/device/no-stalls or adoptioncredit from diagnostic timing. All earlier failures stay.

Preparation failures retained: initial diagnostic build revision used unsupported-diagnostic suffix;
corrected to supported-dirty. FirstQA computed397exactmappedbodies then stopped because protocol
had not yet been written; finalQA must pass beforetiming. No failed preparation earnedtestcredit.
No heavy concurrenthostwork/build/profile. No sign/push/releaseprep/deploy/preview/serviceautomation/
CUA/phone/realdata. Original16ms/2.5s/everymarker/30s/600s acceptancegates unchanged for laterwork.

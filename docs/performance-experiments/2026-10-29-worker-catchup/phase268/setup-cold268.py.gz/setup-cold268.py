from pathlib import Path
import shutil,json,hashlib,subprocess,os,time,difflib
m=Path(__file__).parent;old=Path('/private/tmp/done-production-native-compatibility-20261030');previous=Path('/private/tmp/done-public-cold-profile-20261030');r=Path('/private/tmp/done-public-cold-owner-trace-20261030');repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');source=(old/'source-after').resolve();sha=lambda b:hashlib.sha256(b).hexdigest();r.mkdir()
shutil.copytree(source,r/'source-after',symlinks=True);(r/'source-R').symlink_to(r/'source-after',target_is_directory=True);(r/'node_modules').symlink_to(repo/'node_modules',target_is_directory=True);(r/'test-inputs').symlink_to((old/'test-inputs').resolve(),target_is_directory=True);(r/'private-fixture').symlink_to((old/'private-fixture').resolve(),target_is_directory=True)
shutil.copytree(old/'harness',r/'harness',symlinks=True,ignore=shutil.ignore_patterns('node_modules','test-results','artifacts'));(r/'harness/node_modules').symlink_to(repo/'node_modules',target_is_directory=True)
for f in(r/'harness').rglob('*'):
 if f.is_file()and not f.is_symlink()and f.suffix in ['.mjs','.ts','.json']:f.write_bytes(f.read_bytes().replace(str(old).encode(),str(r).encode()))
shutil.copytree(old/'lab',r/'lab',symlinks=True)
for n in ['src','account-protocol','wasm']:
 p=r/'lab'/n;p.unlink();p.symlink_to(r/'source-after'/n,target_is_directory=True)
for n in ['container-image.json','container-service.mjs','observer.mjs','run.py','smoke.mjs','release-flags.json','source-inputs.json']:(r/n).write_bytes((old/n).read_bytes().replace(str(old).encode(),str(r).encode()))
for n in ['worker-profile.mjs','cold-trace.mjs','cold-trace-contract.test.mjs','profile-smoke.mjs']:(r/n).write_bytes((previous/n).read_bytes().replace(str(previous).encode(),str(r).encode()))
# Bounded enum/location-only errors. Never messages, owner IDs, payloads, credential or scope values.
helper="let emitted = 0;\nexport function reportColdOwnerError(site: string, input: unknown): void {\n try {\n  if (import.meta.env?.['VITE_ACCOUNT_LEDGER_PROFILE'] !== '1') return;\n  if (++emitted > 100) { if (emitted === 101) console.info('done/experiment/' + JSON.stringify({kind:'cold-owner-error-overflow'})); return; }\n  const chain: unknown[] = []; let cause: any = input;\n  for(let i=0;i<4&&cause&&typeof cause==='object';i++) {\n   const token=(v: unknown)=>typeof v==='string'&&/^[A-Za-z-]{1,64}$/.test(v)?v:null;\n   const stack=typeof cause.stack==='string'?cause.stack.split(String.fromCharCode(10)).slice(1,8):[];\n   const locations=stack.flatMap((line: string)=>{const m=/(https?:[/][/][^ )]+):([0-9]+):([0-9]+)/.exec(line);if(!m)return[];try{const u=new URL(m[1]!);return u.pathname.includes('/assets/')?[{asset:u.pathname,line:Number(m[2]),column:Number(m[3])}]:[]}catch{return[]}});\n   chain.push({name:token(cause.name),code:token(cause.code),locations});\n   const next=Object.getOwnPropertyDescriptor(cause,'cause');cause=next&&'value'in next?next.value:undefined;\n  }\n  console.info('done/experiment/'+JSON.stringify({kind:'cold-owner-error',site,chain}));\n } catch { /* Diagnostic failure must never replace the original refusal. */ }\n}\n"
(r/'source-after/src/crdt/coldOwnerDiagnostic.ts').write_text(helper);patch=[]
for rel,importLine,changes in [
 ('src/crdt/workerChannel.ts',"import {reportColdOwnerError} from './coldOwnerDiagnostic';\n",[("const fail = (reason: unknown, notify = true) => {","const fail = (reason: unknown, notify = true) => { reportColdOwnerError('channel-fail', reason);"),("(cause) => {\n            if (!closed)","(cause) => {\n            reportColdOwnerError('channel-handler-reject', cause);\n            if (!closed)")]),
 ('src/crdt/workerAccountHandoff.ts',"import {reportColdOwnerError} from './coldOwnerDiagnostic';\n",[("} catch {\n        fail();","} catch (cause) {\n        reportColdOwnerError('handoff-accept', cause);\n        fail();")]),
 ('src/crdt/firstDeviceOwner.worker.ts',"import {reportColdOwnerError} from './coldOwnerDiagnostic';\n",[("    () => {\n      self.postMessage", "    (cause) => {\n      reportColdOwnerError('first-device-bootstrap', cause);\n      self.postMessage")]),
 ('src/ui/windowCeremonyUi.ts',"import {reportColdOwnerError} from '../crdt/coldOwnerDiagnostic';\n",[("} catch (cause) {\n            // Account entry", "} catch (cause) {\n            reportColdOwnerError('window-setup-open', cause);\n            // Account entry")])]:
 p=r/'source-after'/rel;before=p.read_text();after=before
 for a,b in changes:assert after.count(a)==1,(rel,a);after=after.replace(a,b)
 after=importLine+after;p.write_text(after);patch.append(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
(r/'diagnostic-source.patch').write_text(''.join(patch));(r/'diagnostic-helper.ts').write_text(helper)
# Correct actual physical owner target. Preserve original15s error even after terminal UI fallback.
p=r/'cold-trace.mjs';s=p.read_text().replace("!worker.url().includes('/assets/accountOwner.worker-')", "!(/\\/assets\\/(firstDeviceOwner|accountOwner)\\.worker-/.test(worker.url()))")
s=s.replace("const state={shellAt:null,longTasks", "const state={shellAt:null,failureAt:null,longTasks")
s=s.replace("const sample=()=>{if(state.shellAt", "const sample=()=>{if(state.failureAt===null&&[...document.querySelectorAll('[role=alert]')].some(e=>e.textContent?.includes('The passkey step could not finish. Try unlocking again.')))state.failureAt=performance.timeOrigin+performance.now();if(state.shellAt")
s=s.replace("()=>!!document.querySelector('.shell'),undefined", "()=>!!document.querySelector('.shell')||!!window.__coldNumericProbe?.().failureAt,undefined")
s=s.replace("state.shellObservedAfterGateAt=now();", "const observed=await page.evaluate(()=>({shell:!!document.querySelector('.shell'),fallback:!!window.__coldNumericProbe?.().failureAt}));state.laterObservation={...observed,at:now()};")
p.write_text(s)
# Reuse proven shipping observer wrapper and exact original case bodies, relocated only.
p=r/'harness/test/account-continuation-lab/worker-owner.spec.ts';s=(previous/'harness/test/account-continuation-lab/worker-owner.spec.ts').read_text().replace(str(previous),str(r));p.write_text(s)
flags={**json.loads((r/'release-flags.json').read_text())['expected'],'VITE_ACCOUNT_LEDGER_PROFILE':'1'};(r/'build-flags.json').write_text(json.dumps(flags,indent=2)+'\n');node='/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node';env={k:v for k,v in os.environ.items()if not k.startswith('VITE_ACCOUNT_')};env.update(flags);env.update({'APP_BUILD_REVISION':'0ab9cbc8937e32c6542aaeeca697c87ba116c3be-dirty','APP_BUILD_DATE':'2026-10-30','PATH':str(Path(node).parent)+':'+os.environ['PATH']});start=time.time_ns()//1000000
with(r/'frontend-build.log').open('w')as f:p=subprocess.run([node,str(r/'source-after/node_modules/vite/bin/vite.js'),'build','--outDir',str(r/'frontend'),'--emptyOutDir','--sourcemap'],cwd=r/'source-after',env=env,stdout=f,stderr=subprocess.STDOUT)
assert p.returncode==0
s=(previous/'build.mjs').read_text().replace(str(previous),str(r));(r/'build.mjs').write_text(s)
with(r/'lab-build.log').open('w')as f:p=subprocess.run([node,str(r/'build.mjs')],cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
assert p.returncode==0;(r/'build-receipt.json').write_text(json.dumps({'baseCommit':'0ab9cbc8937e32c6542aaeeca697c87ba116c3be','flags':flags,'sourceDiagnosticOnly':['src/crdt/coldOwnerDiagnostic.ts','src/crdt/workerChannel.ts','src/crdt/workerAccountHandoff.ts','src/crdt/firstDeviceOwner.worker.ts','src/ui/windowCeremonyUi.ts'],'allChecksAndThrowObjectsPreserved':True,'warmLoads':'unset','startedAt':start,'finishedAt':time.time_ns()//1000000},indent=2)+'\n')
p=r/'run.py';s=(previous/'run.py').read_text().replace(str(previous),str(r));p.write_text(s)
print('Correct actualownerCPU and bounded enum/location errors built; actualapp/controlflowchecks unchanged')

// @vitest-environment node
import { afterEach, expect, it, vi } from 'vitest';
import { createSyncScheduler } from '../src/crdt/accountSyncDriver';

afterEach(() => vi.useRealTimers());

it('offers due sending the next turn between completed publisher checks', async () => {
  vi.useFakeTimers();
  vi.setSystemTime(0);
  const controller = new AbortController();
  const sends: number[] = [];
  const checks: number[] = [];
  let remaining = 6;
  const scheduler = createSyncScheduler({
    signal: controller.signal,
    gate: () => 'ready',
    publicationBatch: { quietMs: 300, maxMs: 2000 },
    detach() {},
    send: async () => {
      sends.push(Date.now());
      return { kind: 'idle', acceptedThrough: 0 };
    },
    receive: async (yieldToSend: () => boolean) => {
      while (remaining > 0) {
        await new Promise((resolve) => setTimeout(resolve, 100));
        checks.push(--remaining);
        if (remaining > 0 && yieldToSend?.())
          return { kind: 'yielded', receivedThrough: 0 };
      }
      return { kind: 'idle', receivedThrough: 0 };
    },
  });
  try {
    scheduler.wake('start');
    await vi.advanceTimersByTimeAsync(0);
    scheduler.wake('local');
    await vi.advanceTimersByTimeAsync(299);
    expect(sends).toEqual([0]);
    await vi.advanceTimersByTimeAsync(1);
    expect(checks).toEqual([5, 4, 3]);
    expect(sends).toEqual([0, 300]);
    expect(scheduler.runtime.status.receive.lastSuccessAt).toBeNull();
    await vi.advanceTimersByTimeAsync(300);
    expect(checks).toEqual([5, 4, 3, 2, 1, 0]);
    expect(scheduler.runtime.status.receive.nextAttemptAt).toBe(5600);
  } finally {
    controller.abort();
    await vi.runAllTimersAsync();
    await scheduler.dispose();
  }
});

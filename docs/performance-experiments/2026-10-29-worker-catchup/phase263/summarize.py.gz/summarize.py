from pathlib import Path
import json,math,hashlib
r=Path(__file__).parent;plan=json.loads((r/'run-plan.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest();rows=[]
for c in plan:
 p=r/c['name'];x=json.loads((p/'result.json').read_text());a=json.loads((p/'analysis.json').read_text())
 assert x['outcome']=='passed'and all(x['guards'].values()),c['name']
 assert len(x['offers'])==123 and len(x['catchups'])==2 and all(v['outcome']=='passed'for v in x['catchups'])
 assert all(root['workerSha256']==json.loads((r/(c['variant']+'-assets.json')).read_text())['sw.js']for root in x['roots'])
 keys=sorted((q for q in x['offers']if q['kind']=='key'),key=lambda q:q['index']);markers=sorted((q for q in x['offers']if q['kind']=='marker'),key=lambda q:q['index']);assert [q['index']for q in keys]==list(range(120));assert [q['index']for q in markers]==[0,1,2]
 p95=[];markerTimes=[]
 for device,probe in enumerate(x['probes']):
  clocks=[v for phase in x['clocks']for v in phase['rows'][device]];low=max(v['renderer']-v['after']-1 for v in clocks);high=min(v['renderer']-v['before']+1 for v in clocks);assert low<=high
  arrivals=[]
  for index,offer in enumerate(keys,1):
   matches=[q['at']for q in probe['counts']if q['count']>=x['baselines'][device]+index and q['at']>=offer['at']-5];assert matches;arrivals.append(matches[0]-offer['at']-low)
  p95.append(sorted(arrivals)[math.ceil(.95*len(arrivals))-1]);markerTimes.append([probe['markers'][i]-q['at']-low for i,q in enumerate(markers)])
 assert math.isclose(p95[0],a['peerUpperMs']['p95'],abs_tol=1e-8);assert math.isclose(p95[1],a['localUpperMs']['p95'],abs_tol=1e-8);assert markerTimes[0]==a['markerPeerUpperMs']
 expected={'local16ms':p95[1]<=16,'peer2500ms':p95[0]<=2500,'everyMarker2500ms':max(markerTimes[0])<=2500,'finalNewDelivery30s':x['newDeliveryAt']-max(v['returnedAt']for v in x['offers'])<=30000}
 assert all(a['gates'][k]==v for k,v in expected.items())
 assert all(v['ready']>0 for v in x['notifications']);assert x['withhold'] and x['notifications'][0]['withheld']>0
 limits=x['metrics']['cgroupAfter'];assert limits['cpu.max']=='100000 100000'and limits['memory.max']=='1073741824'and limits['pids.max']=='128';events=dict(line.split()for line in limits['memory.events'].splitlines());assert all(events[k]=='0'for k in ['oom','oom_kill','oom_group_kill'])
 endpoints={}
 for q in x['network']:
  key=q['path']+' '+str(q.get('status','missing'));endpoints[key]=endpoints.get(key,0)+1
 rows.append({'case':c['name'],'variant':c['variant'],'backlogSeconds':a['backlogMs']/1000,'receiversSeconds':{v['label']:(v['completedAt']-x['startedAt'])/1000 for v in x['catchups']},'localP95ms':p95[1],'peerP95ms':p95[0],'markersMs':markerTimes[0],'gates':a['gates'],'accepted':a['accepted'],'serviceRequests':x['metrics']['requests'],'serviceCpuMicros':x['metrics']['cpu'],'requestCounts':endpoints,'resultSha256':sha((p/'result.json').read_bytes())})

def stats(values):
 if not values:return None
 values=sorted(values);return{'n':len(values),'p95':values[math.ceil(.95*len(values))-1],'max':max(values)}
for row,c in zip(rows,plan):
 x=json.loads((r/c['name']/'result.json').read_text());duration=x['typingFinishedAt']-x['typingStartedAt'];q=[v for v in x['network']if x['typingStartedAt']<=v['at']<=x['typingFinishedAt']];row['observedRequestsDuringTyping']={'n':len(q),'perSecond':len(q)/(duration/1000),'byClient':{label:sum(v['label']==label for v in q)for label in ['H1','H2']}}
 if 'uiDelay'in x:
  a=json.loads((r/c['name']/'input-attribution.json').read_text());assert a['overflow']==0;slow=a['slowKeys'];row['inputDiagnostic']={k:v for k,v in a.items()if k in ['summary','traceCounts','overflow','driverLoop','eventTimingMatchedKeys']};row['inputDiagnostic']['slowKeys']=len(slow);row['inputDiagnostic']['slowKeysWithDriverGaps']=sum(v['driverGapCount']>0 for v in slow);row['inputDiagnostic']['slowKeysWithSave']=sum(v['driverSaveCount']>0 for v in slow);row['inputDiagnostic']['metadataHandlerDuringTypingMs']=stats([v['end']-v['start']for v in x['driverHandlerCosts']if x['typingStartedAt']<=v['start']<=x['typingFinishedAt']])
report={'rows':rows,'source':'same248candidate, fixed0abserver','design':'three fixed single journeys; no population uncertainty or causal observer effect established','limits':['Original default run passes, diagnostic default fails17.034ms; no favorable rerun or subset replacement','No>=50msWindowLongTasks does not rule out all shorter Main/OS stalls or physical-phone behavior','Request callbacks are not full CDP traffic, native signature/commit/Window-flight counts or service CPU shares','Fixed order and one trajectory per condition cannot separate observer overhead, host drift and stochastic scheduling'],'next':'source-bound native work counts and Worker CPU profiles before mechanism'}
(r/'summary.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))

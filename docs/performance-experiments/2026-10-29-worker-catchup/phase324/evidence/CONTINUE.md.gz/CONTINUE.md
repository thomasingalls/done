# Phase 324 stopped — no further runs or repairs authorized in this phase

STOP.json records the first deep E1B0P1 0 ms no-F cold failure: Inbound verification refused: expired. Drain 17.4225 s / 1025 positions passes only that timing predicate; functional/cold fails. Runner exited 3 and no later screen/profile/live/grown/sender journey ran. Preserve this whole root and all parent roots.

Read-only source inspection identifies the P stored-replay call passing storedPhysical but leaving old stored argument undefined. current() uses !expectedRecord for live expiry, so saved historical receipts incorrectly take that branch. No repair was attempted. Review all uses of expectedRecord, add expired-stored versus expired-live controls, then seek operator direction for a new lab phase. Never bypass live expiry or mark arbitrary input as persisted evidence.

139 focused tests and strict TS pass, but the tests missed expired history; their passing result is not candidate acceptance. Earlier unit/type/preflight failures retained. Cut inside a native extent and immediate cold passed; this does not supersede deep failure. Remaining 26 screen runs, two profiles, three live, three grown, sender policy study, cap extrapolation and signed-tip design are not completed. Defaults, gates, canonical source and real index unchanged. Phase324 is evidence/docs only. No hardening/release/computer use.

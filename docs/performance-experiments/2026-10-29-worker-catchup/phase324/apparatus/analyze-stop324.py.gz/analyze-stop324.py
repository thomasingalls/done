from pathlib import Path
import json,hashlib,statistics,collections,subprocess,csv
r=Path(__file__).parent;repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda n:json.loads((r/n).read_text());q=load('screen324-results.json');assert len(q)==1 and q[0]['coldFailure'];assert load('STOP.json')['case']==q[0];x=load(q[0]['name']+'/deep-gv/result.json');t0=x['startedAt'];end=t0+x['timeTo1025Ms'];events=x['worker']['events'];cs=[e for e in events if e['kind']=='inboundCommit'and e['at']>=t0];n=0;cross={}
for e in cs:
 n+=e['positions']
 for threshold in [700,1025]:
  if n>=threshold and threshold not in cross:cross[threshold]=e['at']-t0
assert n==1025 and cross[1025]==x['timeTo1025Ms'] and cross[700]==x['timeTo700Ms'];assert sum(e['positions']for e in cs if e['at']<=t0+30000)==x['positionsAt30']==1025
spans=[e for e in x['workerAtDrain']['events']if e['kind']=='clientValidation'and t0<=e['at']<=end];ix=[e for e in x['workerAtDrain']['events']if e['kind']=='indexBudget'];logs=[json.loads(s)for s in(r/q[0]['name']/'host-load.jsonl').read_text().splitlines()];busy=[100-e['hostPercent']['idle']for e in logs if e.get('kind')=='load'];budget=[e for e in x['budgetAfter']['budget']['events']if t0<=e['at']<=end];routes=collections.defaultdict(lambda:collections.Counter());
for e in budget:routes[e.get('route','unlabelled')][e['kind']]+=e.get('units',0)
methods=[]
for realm,key in [('Window','pageAtDrain'),('Worker','workerAtDrain')]:
 for k,v in x[key].items():
  if k.startswith('channel:')and k.endswith(':count'):
   _,kind,method,_=k.split(':');methods.append({'realm':realm,'kind':kind,'method':method,'count':v,'chargedBytes':x[key].get(f'channel:{kind}:{method}:bytes',0)})
with(r/'stopped324-methods.csv').open('w')as f:
 w=csv.DictWriter(f,fieldnames=list(methods[0]),lineterminator='\n');w.writeheader();w.writerows(methods)
row={'run':q[0]['name'],'rtt':0,'E':1,'B':0,'P':1,'SY':'1N','drainMs':cross[1025],'time700Ms':cross[700],'positionsAt30':1025,'drainPredicateOnly':True,'functionalCellPass':False,'cold':'FAILED: historical replay expired','error':x['error'],'clientValidationInclusiveElapsedSumMs':sum(e['ms']for e in spans),'clientValidationSpans':len(spans),'clientValidationIsNotCPU':True,'indexPeakChargedBytes':max(e['chargedBytes']for e in ix),'lastObservedIndex':ix[-1],'indexChargeIsNotHeap':True,'codecCountersAtObservedDrain':{k:v for k,v in x['workerAtDrain'].items()if k.startswith('codec')},'eventOverflow':x['workerAtDrain'].get('eventOverflow',0),'tokensThroughDrain':sum(e.get('units',0)for e in budget),'budgetByRouteAndEvent':{k:dict(v)for k,v in routes.items()},'budgetRefusals':[e for e in budget if e.get('allowed')is False or e.get('ok')is False or any(s in e['kind']for s in ['refus','denied','capacity','limit'])],'hostBusyMedian':statistics.median(busy),'hostBusyMax':max(busy),'hostLoadSamples':len(busy),'inputP95':None,'peerP95':None,'typingExposed':False,'cellReplicatesReached':1,'cellReplicatesDeclared':3,'declaredDeepJourneys':27,'reachedDeepJourneys':1,'remainingDeepJourneysNotRun':26,'winner':None,'capPrediction':None,'profilesLiveGrownSenderNotRun':True,'labOnly':True,'acceptanceCredit':False};(r/'stopped324-analysis.json').write_text(json.dumps(row,indent=2)+'\n')
start=load('canonical-start.json');assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==start['head'];assert subprocess.check_output(['git','diff','--cached','--name-only'],cwd=repo,text=True)=='';assert all(sha(repo/n)==h for n,h in start['files'].items())
stages=[]
for key in ['cut324','cut324-run','cut324-ready','cut324-complete','screen324']:
 inp=load(key+'-inputs.json');checks={}
 for family,base in [('sources',r/'source'),('serverSources',r/'source-server'),('assets',r/'combined-dist')]:
  assert all(sha(base/n)==h for n,h in inp[family].items());checks[family]=len(inp[family])
 app=all((r/n).exists()and sha(r/n)==h for n,h in inp['apparatus'].items());
 if key in ['cut324-ready','cut324-complete','screen324']:assert app
 assert all(sha(Path(n))==h for n,h in inp['fixtures'].items());stages.append({'stage':key,'checked':checks,'apparatusCurrentExact':app,'apparatusNote':'Earlier failed preflight preceded the recorded own-root tsconfig correction'if not app else None,'fixtureHashes':len(inp['fixtures']),'declared':len(inp['plan']),'reached':len(load(key+'-results.json'))if(r/(key+'-results.json')).exists()else 0})
cut=load('cut324-complete-results.json')[0];assert cut['childExit']==0 and cut['guards']['originalAccountReaderColdExact'];assert q[0]['coldFailure']and not x['guards'].get('originalAccountReaderColdExact');assert not any(r.glob('screen324-r2*'))
verify={'canonicalSourceInputsUnchanged':len(start['files']),'head':start['head'],'realIndexEmpty':True,'stages':stages,'independentCommittedPositionSum':n,'independentDrainMs':cross[1025],'independentPositions30':1025,'interiorCutColdExact':True,'actualDeepColdFailure':True,'stoppedAfterFirstDeepJourney':True,'timedRunsAfterStop':0,'allRetainedHostLogsParse':True,'labOnly':True,'acceptanceCredit':False};(r/'independent324-check.json').write_text(json.dumps(verify,indent=2)+'\n');print(json.dumps(row,indent=2));print(json.dumps(verify,indent=2))

from pathlib import Path
r=Path(__file__).parent;s=r/'source'
p=s/'src/crdt/inboundRecord.ts';v=p.read_text();v=v.replace("export function encodeTurnInboundRecord(e:InboundRecord,owned:InboundPageTurn){\n const fields=validatedFields(e,owned),virtual=", "export function inboundLegacyCharge(e:InboundRecord,owned:InboundPageTurn){\n const fields=validatedFields(e,owned),virtual=")
v=v.replace("if(virtual>INBOUND_RECORD_LIMIT)invalid();const record=encodeDenseInbound([e],owned);charges.set(record,virtual);return record;", "if(virtual>INBOUND_RECORD_LIMIT)invalid();return virtual;\n}\nexport function encodeTurnInboundRecord(e:InboundRecord,owned:InboundPageTurn){const virtual=inboundLegacyCharge(e,owned);const record=encodeDenseInbound([e],owned);charges.set(record,virtual);return record;")
v=v.replace('physical,wire:info.owned,event:', 'physical,first:info.first,wire:info.owned,event:')
v=v.replace('export function packInboundRecords(records:readonly Bytes[]){', 'export function packInboundRecords(records:readonly Bytes[],supplied?:InboundPageTurn){')
v=v.replace('let wire:InboundPageTurn|undefined;const events', 'let wire:InboundPageTurn|undefined=supplied;const events')
v=v.replace('}return encodeDenseInbound(events,wire);}finally{wire?.close();for(const e of events){e.request.fill(0);e.page.fill(0);}}', '}return encodeDenseInbound(events,wire);}finally{if(!supplied){wire?.close();for(const e of events){e.request.fill(0);e.page.fill(0);}}}')
v+='\nexport const denseRecordFirst=(bytes:Bytes)=>denseHeader(bytes).first;\n';p.write_text(v)
p=s/'src/crdt/accountInbound.ts';v=p.read_text().replace('encodeTurnInboundRecord,inboundRecordCharge,','encodeTurnInboundRecord,inboundRecordCharge,inboundLegacyCharge,')
v=v.replace("const charged=storedPhysical?encodeTurnInboundRecord(event,wire!):record;\n    const chargedLength=inboundRecordCharge(charged);if(charged!==record)charged.fill(0);", "const chargedLength=storedPhysical?inboundLegacyCharge(event,wire!):inboundRecordCharge(record);")
v=v.replace('  positions = RECEIVE_GROUP_LIMIT,\n): Promise<readonly InboundResult[]> => verifyRange(input, request, page, lifetime, positions);','  positions = RECEIVE_GROUP_LIMIT,\n  supplied?:InboundPageTurn,\n): Promise<readonly InboundResult[]> => verifyRange(input, request, page, lifetime, positions,supplied);')
v=v.replace('  positions?: number,\n): Promise<readonly InboundResult[]> {','  positions?: number,\n  supplied?:InboundPageTurn,\n): Promise<readonly InboundResult[]> {')
v=v.replace('wire=labPP()?createInboundPageTurn(request,page):undefined;', 'wire=labPP()?(supplied??createInboundPageTurn(request,page)):undefined;')
v=v.replace('    wire?.close();\n    request.fill(0);','    if(!supplied)wire?.close();\n    request.fill(0);',1)
v=v.replace('entryIndex??decodeInboundRecord(bytes).entry??0','entryIndex??own.first');p.write_text(v)
p=s/'src/crdt/accountReceive.ts';v=p.read_text().replace("import{packInboundRecords,inboundRecordCharge}","import{packInboundRecords,inboundRecordCharge,denseRecordFirst}");v="import{createInboundPageTurn,type InboundPageTurn}from'../../account-protocol/inboundPageTurn';\n"+v
v=v.replace('const denseOwned:Bytes[]=[],denseFacts:', 'const pageTurns:(InboundPageTurn|undefined)[]=[];\n      const denseOwned:Bytes[]=[],denseFacts:')
v=v.replace('          let pageResults: readonly Awaited<ReturnType<typeof verifyInboundPage>>[] = [];','          const pageTurn=labPP()&&decodeInboundRequest(requests[i]!).limit>1?createInboundPageTurn(requests[i]!,pages[i]!):undefined;pageTurns[i]=pageTurn;\n          let pageResults: readonly Awaited<ReturnType<typeof verifyInboundPage>>[] = [];')
v=v.replace('labCutLimit(context.prefix.position,outstandingAllowance - results.length),\n                    )','labCutLimit(context.prefix.position,outstandingAllowance - results.length),\n                      pageTurn,\n                    )')
v=v.replace('for(const count of counts){','for(const[pageIndex,count]of counts.entries()){',1)
v=v.replace('packInboundRecords(wireRecords):','packInboundRecords(wireRecords,pageTurns[pageIndex]):',1)
v=v.replace('const fact=labPP()?decodeInboundRecord(packed):events[0]!;', 'const fact=labPP()?{page:pageTurns[pageIndex]!.page,request:pageTurns[pageIndex]!.request,entry:denseRecordFirst(packed)}:events[0]!;')
v=v.replace('if(labPP()){fact.request.fill(0);fact.page.fill(0);}','')
v=v.replace('for(const bytes of denseOwned)bytes.fill(0);','for(const turn of pageTurns)turn?.close();\n        for(const bytes of denseOwned)bytes.fill(0);',1);p.write_text(v)
p=s/'src/crdt/inboundLedger.ts';v=p.read_text().replace("createStoredInboundTurn,type StoredInboundTurn", "createStoredInboundTurn,isDenseInboundRecord,type StoredInboundTurn")
needle='  try {\n    for (const entry of events) {';assert v.count(needle)==1;v=v.replace(needle,"  let pageTurn:StoredInboundTurn|undefined,pageRecord:OpenedRecord|undefined;\n"+needle)
v=v.replace('      const { record, event } = entry;','      const { record, event } = entry;\n      if(labPP()&&isDenseInboundRecord(record.bytes)&&pageRecord!==record){pageTurn?.close();pageTurn=createStoredInboundTurn(record.bytes);pageRecord=record;}')
v=v.replace('verifyStoredInbound(context, record.bytes, lifetime,event.entry??0)','verifyStoredInbound(context, record.bytes, lifetime,event.entry??0,pageTurn)')
v=v.replace('const entry = decodeInboundPage(event.page).entries[event.entry ?? 0]!;', 'const entry = pageTurn?pageTurn.entry(event.entry??0):decodeInboundPage(event.page).entries[event.entry ?? 0]!;')
v=v.replace('    localCoverage?.clear();','    pageTurn?.close();\n    localCoverage?.clear();',1);p.write_text(v)
for n in ['membershipReading.ts','replacementSource.ts','handoffHistory.ts']:
 p=s/'src/crdt'/n;v=p.read_text();v="import{labPP}from'./rangeLab';\nimport{createStoredInboundTurn}from'./inboundRecord';\n"+v
 if n=='membershipReading.ts':
  v=v.replace('const cut=membershipReadingPrefix(reading,stream.publisher).position;', 'const cut=membershipReadingPrefix(reading,stream.publisher).position,turn=labPP()&&dense?createStoredInboundTurn(bytes):undefined;').replace('verifyStoredInbound(context,bytes,lifetime,event.entry??0)','verifyStoredInbound(context,bytes,lifetime,event.entry??0,turn)').replace('}finally{for(const event of views)', '}finally{turn?.close();for(const event of views)')
 elif n=='replacementSource.ts':
  v=v.replace('const cut=cuts.find(c=>c.credentialId===publisher);', 'const cut=cuts.find(c=>c.credentialId===publisher),turn=labPP()?createStoredInboundTurn(record):undefined;').replace('verifyStoredInbound(context,record,lifetime,event.entry??0)','verifyStoredInbound(context,record,lifetime,event.entry??0,turn)').replace('}finally{for(const b of owned)', '}finally{turn?.close();for(const b of owned)')
 else:
  v=v.replace('keptEvents:InboundRecord[]=[];','keptEvents:InboundRecord[]=[],turn=labPP()&&isDenseInboundRecord(bytes)?createStoredInboundTurn(bytes):undefined;').replace('verifyStoredInbound(context, bytes, lifetime,record.entry??0)','verifyStoredInbound(context, bytes, lifetime,record.entry??0,turn)').replace('        for(const e of views){e.request.fill(0);e.page.fill(0);}', '        turn?.close();for(const e of views){e.request.fill(0);e.page.fill(0);}')
 p.write_text(v)
p=s/'account-protocol/inboundPageTurn.ts';v=p.read_text().replace(',type InboundReadRequest','');p.write_text(v)
print('Native lifetime and all replay owners integrated; run strict type and focused tests next')

from pathlib import Path
import json,gzip,hashlib,shutil
r=Path(__file__).parent;repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');d=repo/'docs/performance-experiments/2026-10-29-worker-catchup/phase324';d.mkdir(exist_ok=False);items=[];seen=set();sha=lambda b:hashlib.sha256(b).hexdigest()
def keep(p,category='evidence'):
 raw=p.read_bytes();dest=d/category/(str(p.relative_to(r))+'.gz');key=str(dest)
 if key in seen:assert gzip.decompress(dest.read_bytes())==raw;return
 seen.add(key);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(gzip.compress(raw,compresslevel=6,mtime=0));items.append({'source':str(p),'copy':str(dest.relative_to(d)),'rawSha256':sha(raw),'bytes':len(raw),'gzipSha256':sha(dest.read_bytes())})
for key in ['cut324','cut324-run','cut324-ready','cut324-complete','screen324']:
 for suffix in ['plan.json','inputs.json','results.json','driver.log']:
  p=r/(key+'-'+suffix)
  if p.exists():keep(p)
 inp=json.loads((r/(key+'-inputs.json')).read_text())
 for c in inp['plan']:
  f=r/c['name']
  for n in ['list.log','console.log','receipt.json','host-load.jsonl','result.json','partial-result.json']:
   p=f/n
   if p.is_file():keep(p)
  for n in ['result.json','services.log','container-identity.json','docker-command.json']:
   for p in f.glob('*/'+n):keep(p)
for n in ['STOP.json','PROTOCOL324.md','CODEC-CONTRACT324.md','CONTINUE.md','IMPLEMENTATION-324-STATUS.md','start324.json','canonical-start.json','record-prefixes324.json','prototype324-files.json','stopped324-analysis-initial.json','stopped324-analysis.json','stopped324-methods.csv','independent324-check.json','analysis-stop324.log','build324-attempt1.log','build-flags.json','build-identity.json','release-flags.json','container-image.json','frontend-build.log','lab-build.log','cut324-preflight-failure.json','harness-tsconfig-before.json.txt','type324-attempt1.log','type324-attempt2.log','type324-attempt3.log','type324-attempt4.log','unit324-base-attempt1.log','unit324-treatment-attempt1.log','unit324-treatment-attempt2.log','unit324-final-attempt1.log']:
 p=r/n
 if p.exists():keep(p)
for n in ['implement324.py','finish324.py','final-review324.py','prepare324.py','build-lab.py','build.mjs','run-stage.py','host_load.py','lab-context.mjs','observer.mjs','container-service.mjs','read-request.mjs','notification-probe.mjs','fixture-roles.mjs','analyze-stop324.py','close324.py','preserve324.py','source/test/labPageParse324.test.ts','harness/tsconfig.json','harness/test/account-continuation-lab/worker-owner.spec.ts','harness/test/account-continuation-lab/worker-owner.config.ts','harness/test/account-continuation-lab/worker-cpu-profile.mjs','harness/test/account-continuation-lab/deep-traffic.mjs','harness/test/account-continuation-lab/dense-cut.spec.ts','harness/test/account-continuation-lab/dense-cut.config.ts','harness/test/account-continuation-lab/runtime.mjs','harness/test/account-continuation-lab/seed-profile.ts','lab-prototype324.diff','playwright-storage-source.txt']:
 p=r/n
 if p.exists():keep(p,'apparatus')
for n in ['PROTOCOL324.md','CODEC-CONTRACT324.md','stopped324-analysis.json','stopped324-methods.csv','independent324-check.json','STOP.json']:
 shutil.copy2(r/n,d/n)
(d/'evidence-index.json').write_text(json.dumps({'labRoot':str(r),'labOnly':True,'acceptanceCredit':False,'items':items,'compiledBuildsBrowserProfilesCredentialsDatabasesNotCopied':True,'inertSourceDeltaIsReproductionEvidenceOnly':True},indent=2)+'\n')
for x in items:assert gzip.decompress((d/x['copy']).read_bytes())==Path(x['source']).read_bytes();assert sha((d/x['copy']).read_bytes())==x['gzipSha256']
(d/'evidence-check.json').write_text(json.dumps({'copiesVerified':len(items),'allOriginalAndCompressedHashesMatch':True,'labOnly':True,'acceptanceCredit':False},indent=2)+'\n');print('Preserved',len(items),'exact evidence and inert recipe files')

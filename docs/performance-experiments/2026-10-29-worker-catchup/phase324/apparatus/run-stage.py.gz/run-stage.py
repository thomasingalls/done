from pathlib import Path
import json,subprocess,time,sys,os,signal,hashlib,datetime
r=Path(__file__).parent;node='/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node';key=sys.argv[1];plan=json.loads((r/(key+'-plan.json')).read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();frozen={'sources':{str(p.relative_to(r/'source')):sha(p)for d in ['src','account-protocol']for p in(r/'source'/d).rglob('*')if p.is_file()},'serverSources':{str(p.relative_to(r/'source-server')):sha(p)for p in(r/'source-server').rglob('*')if p.is_file()},'assets':json.loads((r/'build-identity.json').read_text())['files'],'apparatus':{str(p.relative_to(r)):sha(p)for p in(r/'harness/test/account-continuation-lab').rglob('*')if p.is_file()},'plan':plan,'labOnly':True,'acceptanceCredit':False,'fixtures':{str(Path(c.get('fixture',r/'private-fixture/fixture.json'))):sha(Path(c.get('fixture',r/'private-fixture/fixture.json')))for c in plan}};(r/(key+'-inputs.json')).write_text(json.dumps(frozen,indent=2)+'\n');rows=[]
subprocess.run(['docker','info','--format','{{.ServerVersion}}'],check=True,timeout=10)
for c in plan:
 assert not(r/'STOP.json').exists();assert all(sha(r/'source-server'/n)==h for n,h in frozen['serverSources'].items());assert all(sha(r/'source'/n)==h for n,h in frozen['sources'].items());assert all(sha(r/'combined-dist'/n)==h for n,h in frozen['assets'].items());assert all(sha(r/n)==h for n,h in frozen['apparatus'].items());fixture=Path(c.get('fixture',r/'private-fixture/fixture.json'));assert json.loads(fixture.read_text())['accounts'][0]['date']==datetime.datetime.now(datetime.timezone.utc).date().isoformat()
 assert sha(fixture)==frozen['fixtures'][str(fixture)]
 out=r/c['name'];out.mkdir(mode=0o700,exist_ok=False);env={k:v for k,v in os.environ.items()if not k.startswith(('FAIR_','RANGE_LAB_'))};env.update({'PATH':str(Path(node).parent)+':'+env['PATH'],'FAIR_OUT':str(out),'FAIR_DIST':str(r/'combined-dist'),'FAIR_LAB_BITS':c['bits'],'FAIR_SY_BITS':c.get('SY','11'),'FAIR_REPAIR_MS':str(c.get('repairMs',1500)),'FAIR_QUIET_OFF':'1'if c.get('quietOff')else'0','FAIR_PP':'1'if c.get('pp')else'0','FAIR_KEY_MS':str(c.get('keyMs',500)),'FAIR_EB':c.get('eb','00'),'FAIR_WORKER_PROFILE':'1'if c.get('workerProfile')else'0','FAIR_RTT':str(c.get('rtt',0)),'FAIR_PROFILE':'1'if c.get('profile')else'0','FAIR_VARIANT':'EB-lab','QUIET_WITHHOLD':'1'if c.get('withhold')else'0','FAIR_IDLE_PAUSE':'1'if c.get('idlePause')else'0','FAIR_PREP_HIDDEN':'0','CHROMIUM_PATH':'/private/tmp/done-civil-gates-browser-20261030/Chrome.app/Contents/MacOS/Google Chrome'})
 env['FAIR_FIXTURE']=str(fixture)
 if c.get('mobile')is not None:env['STALL_MOBILE']='1'if c['mobile']else'0'
 cmd=[node,'node_modules/@playwright/test/cli.js','test','--config','test/account-continuation-lab/'+c['config']]
 cmd+=[c['fileFilter']]
 if c.get('grep'):cmd+=['--grep',c['grep']]
 with(out/'list.log').open('w')as f:pre=subprocess.run(cmd+['--list'],cwd=r/'harness',env=env,stdout=f,stderr=subprocess.STDOUT)
 if pre.returncode or 'Total: 1 test in 1 file'not in(out/'list.log').read_text():print('LIST FAILED',c['name'],flush=True);sys.exit(4)
 load=out/'host-load.jsonl';sampler=subprocess.Popen([sys.executable,str(r/'host_load.py'),'--out',str(load)]);start=time.time()
 try:
  for i in range(500):
   if Path(str(load)+'.ready').exists():break
   if sampler.poll()is not None:raise RuntimeError('Sampler failed')
   time.sleep(.01)
  else:raise RuntimeError('Sampler not ready')
  print('START',c['name'],flush=True)
  with(out/'console.log').open('w')as f:p=subprocess.run(cmd,cwd=r/'harness',env=env,stdout=f,stderr=subprocess.STDOUT)
 finally:sampler.send_signal(signal.SIGTERM);sampler.wait(timeout=10)
 raw=out/c.get('result','result.json');raw=raw if raw.exists()else out/'partial-result.json';x=json.loads(raw.read_text())if raw.exists()else{};cold=bool(x.get('coldFailure'))or(bool(x.get('coldAttemptStarted'))and not any(x.get('guards',{}).get(g)for g in ['originalAccountReaderColdExact','bothOfflineColdProfilesExact','offlineColdProfileExact','originalJoinedColdReopen','originalJoinedPageColdReopenExact','actualPageColdReopenExact']))
 row={**c,'command':cmd,'childExit':p.returncode,'startedAt':start,'finishedAt':time.time(),'outcome':x.get('outcome'),'error':x.get('error'),'coldFailure':cold,'guards':x.get('guards',{}),'ownerObservation':x.get('ownerObservation',{}).get('terminal'),'ownerCold':x.get('ownerCold'),'positionsAt30':x.get('positionsAt30'),'timeTo700Ms':x.get('timeTo700Ms'),'timeTo1025Ms':x.get('timeTo1025Ms'),'deep30Pass':x.get('deep30Pass'),'externalLoadLog':'host-load.jsonl','labOnly':True,'acceptanceCredit':False};rows.append(row);(out/'receipt.json').write_text(json.dumps(row,indent=2)+'\n');(r/(key+'-results.json')).write_text(json.dumps(rows,indent=2)+'\n');print('RESULT',json.dumps(row),flush=True)
 if cold:(r/'STOP.json').write_text(json.dumps({'rule':'Any no-F cold failure stops immediately','case':row},indent=2)+'\n');sys.exit(3)
print('All declared '+key+' cells retained',flush=True)

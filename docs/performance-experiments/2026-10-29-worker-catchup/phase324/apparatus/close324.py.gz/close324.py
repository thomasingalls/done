from pathlib import Path
import json,hashlib,difflib,subprocess
r=Path(__file__).parent;repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');parent=Path('/private/tmp/done-idle-read-ahead-lab-20261101');sha=lambda b:hashlib.sha256(b).hexdigest();prefix={n:{'bytes':(repo/n).stat().st_size,'sha256':sha((repo/n).read_bytes())}for n in ['docs/completed.md','docs/decisions.md','docs/product-backlog.md']};(r/'record-prefixes324.json').write_text(json.dumps(prefix,indent=2)+'\n')
changes=[];diff=[]
for family,folders in [('source',['src','account-protocol']),('source-server',['account-service'])]:
 for folder in folders:
  for p in sorted((r/family/folder).rglob('*')):
   if not p.is_file():continue
   rel=p.relative_to(r);old=parent/rel;before=old.read_bytes()if old.exists()else b'';after=p.read_bytes()
   if before==after:continue
   changes.append({'path':str(rel),'beforeSha256':sha(before)if old.exists()else None,'afterSha256':sha(after),'bytes':len(after)})
   diff.extend(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='parent/'+str(rel),tofile='private324/'+str(rel)))
p=r/'source/test/labPageParse324.test.ts';diff.extend(difflib.unified_diff([],p.read_text().splitlines(True),fromfile='/dev/null',tofile='private324/source/test/labPageParse324.test.ts'))
(r/'lab-prototype324.diff').write_text(''.join(diff));(r/'prototype324-files.json').write_text(json.dumps(changes,indent=2)+'\n')
(r/'CODEC-CONTRACT324.md').write_text('''# Owned page parsing: baseline and prototype contract

Lab only. New P is parsed-page sharing; old dense-receipt P remains on. No format, trust, production-default or release approval.

## Baseline counts before treatment

These are a call-graph census of an uncached selected page, not a claim that every route/memo hit has the same count. `decodeInboundPage` includes the canonical JSON stringify comparison and entry hex decoding. Literal `encodeInboundPage` has zero calls in these client paths; signing-message encoding and legacy receipt hex encoding are separate whole-page work.

|Core path for n entries on one page|Full-page decodes per page|Canonical JSON stringify comparisons|Signing-message encodes|Legacy receipt page-hex encodes|
|---|---:|---:|---:|---:|
|Native preparation, selected-record decoding and dense packing|4n+2|4n+2|1|n|
|Cold census plus uncached stored ledger verification and retained-entry decoding|7n+1|7n+1|n|2n|

Native four-entry count is 18 decodes, one signing-message encode, four receipt hex encodes; the new test observes that count. Native eight-entry call-graph count is 34 decodes. Per logical position those are 4+2/n and 7+1/n decodes respectively, plus their stringify comparisons. Stored baseline has five decodes inside each uncached verification, one in retained-entry extraction, and n+1 from the logical-view census. Separate scope/route inspection can add passes. Existing exact memo hits can omit verification; do not multiply this table into a measured CPU saving.

P's counted native scope at widths four and eight does one page decode, one signing-message encode and zero legacy receipt page-hex encodes, shared through packing. Stored P test does one decode/signing-message encode per physical extent scope, with every old signature verification and per-entry decrypt still called. Census, replay, route inspection, and later owner scopes remain separate; the runtime drain counter is not one decode per page globally. No parsed syntax or verification trust is persisted.

## Boundaries retained by the prototype

The owned raw request/page, exact byte snapshots, canonical JSON, closed shape, lowercase/even/nonempty hex, extent and request/page binding permit sharing parsed syntax and signing-message bytes within an owned scope. Removing the duplicate inboundBytes regex retains the length/even check and the existing unhex lowercase/character check. Global unhex is unchanged: its general odd-length behavior is not silently adopted here.

Each selected entry still has its own acceptance signature, publisher signature/decryption, author/actor/generation checks, position/previous-link/chain check, witness completeness and committed-state coverage. Current authority/lifetime and live-request expiry are rechecked at the old boundaries around awaits and commit. Stored replay must retain its distinct contract: historical request expiry does not invalidate an independently authenticated saved receipt, while all original signatures and exact stored bytes still verify. The first deep cold failure shows that the P prototype failed this distinction; it is rejected as a candidate.

No new signature-result cache was introduced. Existing per-entry exact-evidence memo copies and full-prefix comparison remain; index charge is not total heap use. Transient P records use the existing dense framing, with exact virtual legacy encoded length to retain old preparation/batch bounds. Logical position counts, G8 allowance, audits, rate/session/fairness bounds are unchanged. Retained raw views share one owned request/page block per extent, with selected-entry data bounded in index charge. Parsing scopes wipe decoded envelope/proof arrays, message bytes, exact snapshots and owned wire bytes when their owner closes; retained views keep only their own wire block. General erasure hardening is unproved by these six controls.

## Cold regression identified by reading; not repaired or rerun

Private source/src/crdt/accountInbound.ts: verifyStoredInbound's P branch calls verify with `stored=undefined`, but supplies storedEvent and storedPhysical. verify creates expectedRecord only from stored. Its current() expiry branch still tests `!expectedRecord`, therefore P stored replay takes live-request expiry handling. It can also take other old branches gated by expectedRecord; all such uses require review before resuming. The dense tuple equality is not a substitute for the old stored-mode distinction.

The focused stored test used a request that had not expired. It compared crypto/decryption counts, outputs and wrong-baseline refusal but did not age the request. The interior-cut/cold probe also completed quickly and passed. Neither establishes expired historical replay. Required next control is paired P0/P1 stored replay after request expiry, with live expired request refusal retained, plus exact tuple/duplicate-mode/erasure controls. No fix or extra test was built after the actual no-F cold stop.
''')
(r/'CONTINUE.md').write_text('''# Phase 324 stopped — no further runs or repairs authorized in this phase

STOP.json records the first deep E1B0P1 0 ms no-F cold failure: Inbound verification refused: expired. Drain 17.4225 s / 1025 positions passes only that timing predicate; functional/cold fails. Runner exited 3 and no later screen/profile/live/grown/sender journey ran. Preserve this whole root and all parent roots.

Read-only source inspection identifies the P stored-replay call passing storedPhysical but leaving old stored argument undefined. current() uses !expectedRecord for live expiry, so saved historical receipts incorrectly take that branch. No repair was attempted. Review all uses of expectedRecord, add expired-stored versus expired-live controls, then seek operator direction for a new lab phase. Never bypass live expiry or mark arbitrary input as persisted evidence.

139 focused tests and strict TS pass, but the tests missed expired history; their passing result is not candidate acceptance. Earlier unit/type/preflight failures retained. Cut inside a native extent and immediate cold passed; this does not supersede deep failure. Remaining 26 screen runs, two profiles, three live, three grown, sender policy study, cap extrapolation and signed-tip design are not completed. Defaults, gates, canonical source and real index unchanged. Phase324 is evidence/docs only. No hardening/release/computer use.
''')
print('Closure notes and inert prototype diff written',len(changes))

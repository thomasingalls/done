from pathlib import Path
import json
r=Path(__file__).parent;s=r/'source'
def edit(n,old,new,count=1):
 p=s/n;v=p.read_text();assert v.count(old)==count,(n,old[:90],v.count(old));p.write_text(v.replace(old,new))
p=s/'src/crdt/rangeLab.ts';p.write_text(p.read_text()+"\nexport const labPP=()=>query.get('labPP')==='1'||(typeof sessionStorage!=='undefined'&&sessionStorage.getItem('done.lab.pp')==='1');Object.assign((globalThis as any).__rangeLab,{pp:labPP()});\n")
p=r/'lab-context.mjs';v=p.read_text().replace("const bits=","const pp=process.env.FAIR_PP==='1';\nconst bits=",1).replace('eb,quietOff}', 'eb,quietOff,pp}').replace("sessionStorage.setItem('done.lab.quietOff'","sessionStorage.setItem('done.lab.pp',pp?'1':'0');sessionStorage.setItem('done.lab.quietOff'",1).replace("if(quietOff)u.searchParams.set", "u.searchParams.set('labPP',pp?'1':'0');if(quietOff)u.searchParams.set");p.write_text(v)
p=s/'account-protocol/inboundTransport.ts';v=p.read_text();v="import {labPP,labCount} from '../src/crdt/rangeLab';\n"+v;v=v.replace("if (typeof v !== 'string' || v.length > max * 2 || !/^(?:[0-9a-f]{2})+$/.test(v))", "if (typeof v !== 'string' || v.length > max * 2 || (labPP()?(!v.length||v.length%2!==0):!/^(?:[0-9a-f]{2})+$/.test(v)))");v=v.replace('export const inboundPageMessage = (p: InboundReadPage): Bytes => json(pageValues(p));',"export const inboundPageMessage = (p: InboundReadPage): Bytes => {labCount('codecPageMessageEncodes');return json(pageValues(p));};");v=v.replace('export function decodeInboundPage(bytes: Bytes): InboundReadPage {',"export function decodeInboundPage(bytes: Bytes): InboundReadPage {\n  labCount('codecFullPageDecodes');");p.write_text(v)
(s/'account-protocol/inboundPageTurn.ts').write_text('''/** FICTIONAL LAB ONLY: owned syntax/canonical-byte reuse, never authority or crypto evidence. */
import{decodeInboundRequest,decodeInboundPage,checkInboundExtent,inboundPageMessage,type InboundReadRequest,type InboundReadPage}from'./inboundTransport';
import type{Bytes}from'./positionDecision';
const live=new WeakSet<object>();
export const equalPageBytes=(a:Bytes,b:Bytes)=>{if(a.length!==b.length)return false;for(let i=0;i<a.length;i++)if(a[i]!==b[i])return false;return true;};
export function createInboundPageTurn(requestInput:Bytes,pageInput:Bytes,borrow=false){
 const request=borrow?requestInput:requestInput.slice(),page=borrow?pageInput:pageInput.slice();let parsed:InboundReadPage|undefined,message:Bytes|undefined,closed=false;
 try{const r=decodeInboundRequest(request),p=parsed=decodeInboundPage(page);checkInboundExtent(p,r);
 const assert=()=>{if(closed)throw Error('Closed inbound page turn');};
 const turn={request,page,r,p,assert,match:(rq:Bytes,pg:Bytes)=>{assert();if(!equalPageBytes(rq,request)||!equalPageBytes(pg,page))throw Error('Inbound page turn bytes changed');},message:()=>{assert();return message??=inboundPageMessage(p);},close:(keepWire=false)=>{if(closed)return;closed=true;for(const e of p.entries){e.envelope.fill(0);e.proof.fill(0);}message?.fill(0);if(!keepWire){request.fill(0);page.fill(0);}}};live.add(turn);return Object.freeze(turn);
 }catch(e){request.fill(0);page.fill(0);for(const v of parsed?.entries??[]){v.envelope.fill(0);v.proof.fill(0);}throw e;}
}
export type InboundPageTurn=ReturnType<typeof createInboundPageTurn>;
export function assertInboundPageTurn(turn:InboundPageTurn){if(!live.has(turn))throw Error('Unowned page parse');turn.assert();}
''')
# Receipt helpers share parsed syntax only inside an owned extent. Raw canonical input still checked.
p=s/'src/crdt/inboundRecord.ts';v=p.read_text();v="import{labPP,labCount}from'./rangeLab';\nimport{createInboundPageTurn,assertInboundPageTurn,equalPageBytes,type InboundPageTurn}from'../../account-protocol/inboundPageTurn';\n"+v
v=v.replace('function validatedFields(e: InboundRecord) {','function validatedFields(e: InboundRecord,owned?:InboundPageTurn) {\n  if(owned){assertInboundPageTurn(owned);owned.match(e.request,e.page);}')
v=v.replace('const r = decodeInboundRequest(e.request),\n    p = decodeInboundPage(e.page),','const r = owned?.r??decodeInboundRequest(e.request),\n    p = owned?.p??decodeInboundPage(e.page),')
v=v.replace('export function encodeInboundRecord(e: InboundRecord): Bytes {','export function encodeInboundRecord(e: InboundRecord,owned?:InboundPageTurn): Bytes {\n  labCount("codecReceiptPageHexEncodes");')
v=v.replace('...validatedFields(e),','...validatedFields(e,owned),',1)
# Size stays exactly the previous canonical legacy receipt charge, even when the lab result uses dense bytes.
needle='function decodeLegacyInboundRecord(bytes: Bytes): InboundRecord {'
v=v.replace(needle,'''const charges=new WeakMap<Bytes,number>();
export const inboundRecordCharge=(bytes:Bytes)=>charges.get(bytes)??bytes.length;
export function encodeTurnInboundRecord(e:InboundRecord,owned:InboundPageTurn){
 const fields=validatedFields(e,owned),virtual=new TextEncoder().encode(JSON.stringify([...fields,'','',...(e.entry===undefined?[]:[e.entry])])).length+2*(e.request.length+e.page.length);
 if(virtual>INBOUND_RECORD_LIMIT)invalid();const record=encodeDenseInbound([e],owned);charges.set(record,virtual);return record;
}
export function assertInboundEventSame(a:InboundRecord,b:InboundRecord){
 for(const k of ['baseline','lineage','head','reader','publisher','kind','position','previous','link','entry']as const)if(a[k]!==b[k])invalid();
 if(!equalPageBytes(a.request,b.request)||!equalPageBytes(a.page,b.page))invalid();
}
'''+needle)
# denseInfo optional owned page; shared wire block is one allocation for all returned views.
v=v.replace('function denseInfo(bytes:Bytes){\n  const h=denseHeader(bytes),request=bytes.slice(h.requestAt,h.requestAt+h.requestLength),page=bytes.slice(h.pageAt,h.pageAt+h.pageLength),r=decodeInboundRequest(request),p=decodeInboundPage(page);', '''function denseInfo(bytes:Bytes){
  const h=denseHeader(bytes),storage=labPP()?new Uint8Array(h.requestLength+h.pageLength):undefined;
  if(storage){storage.set(bytes.subarray(h.requestAt,h.requestAt+h.requestLength));storage.set(bytes.subarray(h.pageAt,h.pageAt+h.pageLength),h.requestLength);}
  const request=storage?storage.subarray(0,h.requestLength):bytes.slice(h.requestAt,h.requestAt+h.requestLength),page=storage?storage.subarray(h.requestLength):bytes.slice(h.pageAt,h.pageAt+h.pageLength),owned=labPP()?createInboundPageTurn(request,page,true):undefined,r=owned?.r??decodeInboundRequest(request),p=owned?.p??decodeInboundPage(page);''')
v=v.replace('return{...h,request,page,r,p};','return{...h,request,page,r,p,owned};')
v=v.replace('request:info.request.slice(),page:info.page.slice(),','request:labPP()?info.request:info.request.slice(),page:labPP()?info.page:info.page.slice(),')
v=v.replace('validatedFields(e);return e;','validatedFields(e,info.owned);return e;')
v=v.replace('try{return denseEvent(info,index??info.first);}finally{info.request.fill(0);info.page.fill(0);}','try{return denseEvent(info,index??info.first);}finally{if(info.owned)info.owned.close(true);else{info.request.fill(0);info.page.fill(0);}}')
v=v.replace('}finally{info.request.fill(0);info.page.fill(0);if(!delivered)', '}finally{if(info.owned)info.owned.close(delivered);else{info.request.fill(0);info.page.fill(0);}if(!delivered)')
v=v.replace('return{logical:h.count,bytes:bytes.length+h.count*(h.requestLength+h.pageLength)};', 'return{logical:h.count,bytes:bytes.length+(labPP()?(h.requestLength+h.pageLength+Math.ceil(h.pageLength/2)):h.count*(h.requestLength+h.pageLength))};')
v=v.replace('export function encodeDenseInbound(events:readonly InboundRecord[]):Bytes{','export function encodeDenseInbound(events:readonly InboundRecord[],supplied?:InboundPageTurn):Bytes{\n  const own=labPP()&&!supplied&&events[0]?createInboundPageTurn(events[0].request,events[0].page):undefined,wire=labPP()?(supplied??own):undefined;try{')
v=v.replace('    validatedFields(e);\n    if(e.kind', '    validatedFields(e,wire);\n    if(e.kind')
v=v.replace('bytes.set(first.page,at);denseInfo(bytes);return bytes;\n}', 'bytes.set(first.page,at);if(wire){denseHeader(bytes);if(start+events.length>wire.p.entries.length||start+events.length>wire.r.limit)invalid();}else denseInfo(bytes);return bytes;\n  }finally{own?.close();}\n}')
# Public reader for a single physical extent; exact original physical bytes compared on each use.
v+='''
export function createStoredInboundTurn(input:Bytes){
 const physical=input.slice(),info=denseInfo(physical);if(!info.owned){physical.fill(0);throw Error('Page reuse is disabled');}
 let closed=false;return Object.freeze({physical,wire:info.owned,event:(index:number)=>{if(closed)invalid();return denseEvent(info,index);},match:(bytes:Bytes)=>{if(closed||!equalPageBytes(bytes,physical))invalid();},entry:(index:number)=>{if(closed||index<info.first||index>=info.first+info.count)invalid();const e=info.p.entries[index]!;return{envelope:e.envelope.slice(),proof:e.proof.slice()};},close:()=>{if(closed)return;closed=true;info.owned!.close();physical.fill(0);}});
}
export type StoredInboundTurn=ReturnType<typeof createStoredInboundTurn>;
/** Native packing, one page parse across independently canonical per-position records. */
export function packInboundRecords(records:readonly Bytes[]){
 if(!labPP())return encodeDenseInbound(records.map(b=>decodeInboundRecord(b)));
 if(!records.length)invalid();let wire:InboundPageTurn|undefined;const events:InboundRecord[]=[];
 try{for(const bytes of records){
  if(isDenseInboundRecord(bytes)){
   const h=denseHeader(bytes);if(h.count!==1)invalid();const rq=bytes.subarray(h.requestAt,h.requestAt+h.requestLength),pg=bytes.subarray(h.pageAt,h.pageAt+h.pageLength);wire??=createInboundPageTurn(rq,pg);wire.match(rq,pg);events.push(denseEvent({...h,request:wire.request,page:wire.page,r:wire.r,p:wire.p,owned:wire},h.first));
  }else{const e=decodeLegacyInboundRecord(bytes);wire??=createInboundPageTurn(e.request,e.page);wire.match(e.request,e.page);events.push(e);}
 }return encodeDenseInbound(events,wire);}finally{wire?.close();for(const e of events){e.request.fill(0);e.page.fill(0);}}
}
'''
p.write_text(v)
# Verifier: preserve all current/expiry/entry crypto checks, reuse owned parse and signing bytes only.
p=s/'src/crdt/accountInbound.ts';v=p.read_text();v="import{labPP}from'./rangeLab';\nimport{createInboundPageTurn,type InboundPageTurn}from'../../account-protocol/inboundPageTurn';\nimport{createStoredInboundTurn,assertInboundEventSame,encodeTurnInboundRecord,inboundRecordCharge,type StoredInboundTurn}from'./inboundRecord';\n"+v
# signature authentication function may have arbitrary formatting; modify page message expression via optional parameter.
v=v.replace('  selection?: {\n    index: number;\n    authenticate: typeof authenticateInboundWire;\n  },', '  selection?: {\n    index: number;\n    authenticate: typeof authenticateInboundWire;\n  },\n  wire?:InboundPageTurn,\n  storedEvent?:InboundRecord,\n  storedPhysical?:Bytes,')
v=v.replace('const request = captureBytes(requestInput, READ_REQUEST_LIMIT),\n    pageBytes = captureBytes(pageInput, READ_PAGE_LIMIT),\n    expectedRecord = stored ?', 'const request = wire?.request??captureBytes(requestInput, READ_REQUEST_LIMIT),\n    pageBytes = wire?.page??captureBytes(pageInput, READ_PAGE_LIMIT),\n    expectedRecord = stored ?',1)
v=v.replace('const r = decodeInboundRequest(request),\n      p = decodeInboundPage(pageBytes),','wire?.match(requestInput,pageInput);\n    const r = wire?.r??decodeInboundRequest(request),\n      p = wire?.p??decodeInboundPage(pageBytes),',1)
v=v.replace('const record = encodeInboundRecord(event);\n    if (record.length +', '''if(storedEvent)assertInboundEventSame(event,storedEvent);
    const record = storedPhysical?storedPhysical.slice():wire&&labPP()&&!expectedRecord?encodeTurnInboundRecord(event,wire):encodeInboundRecord(event,wire);
    const charged=storedPhysical?encodeTurnInboundRecord(event,wire!):record;
    const chargedLength=inboundRecordCharge(charged);if(charged!==record)charged.fill(0);
    if (chargedLength +''',1)
# existing authenticate must still verify signatures every call; optional owned page avoids materializing signing message repeatedly.
# Add wire to the call (per-range authenticate wrapper accepts full argument tuple).
v=v.replace('(c, r, p, request, subtle);','(c, r, p, request, subtle,wire);',1)
# Find declaration signature later in script; extend exact subtle parameter near authenticate definition.
start=v.index('async function authenticateInboundWire');end=v.index('\n}',start)+2;part=v[start:end];part=part.replace('subtle: SubtleCrypto,','subtle: SubtleCrypto,\n  owned?:InboundPageTurn,').replace('inboundPageMessage(p)','owned?.message()??inboundPageMessage(p)');v=v[:start]+part+v[end:]
# Range owns captured snapshots throughout and closes parse including decoded envelope/proof arrays.
v=v.replace('results: InboundResult[] = [];\n  let transferred', 'results: InboundResult[] = [],\n    wire=labPP()?createInboundPageTurn(request,page):undefined;\n  let transferred',1)
v=v.replace('const r = decodeInboundRequest(request),\n      p = decodeInboundPage(page);','const r = wire?.r??decodeInboundRequest(request),\n      p = wire?.p??decodeInboundPage(page);',1)
v=v.replace('r.limit > 1 ? { index, authenticate } : undefined,\n      );','r.limit > 1 ? { index, authenticate } : undefined,\n        wire,\n      );',1)
v=v.replace('bytes += result.record.length + result.updates.reduce', 'bytes += inboundRecordCharge(result.record) + result.updates.reduce',1)
v=v.replace('    request.fill(0);\n    page.fill(0);\n    context.generationKey.fill(0);','    wire?.close();\n    request.fill(0);\n    page.fill(0);\n    context.generationKey.fill(0);',1)
# Dense stored call bypasses redundant generated-legacy serialization only; retains tuple/raw exact equality and old size charge.
v=v.replace('  entryIndex?:number,\n): Promise<InboundResult> {','  entryIndex?:number,\n  supplied?:StoredInboundTurn,\n): Promise<InboundResult> {\n  if(labPP()&&isDenseInboundRecord(bytes)){\n    const own=supplied??createStoredInboundTurn(bytes);try{own.match(bytes);const event=own.event(entryIndex??decodeInboundRecord(bytes).entry??0);return await verify(context,own.wire.request,own.wire.page,lifetime,undefined,event.entry===undefined?undefined:{index:event.entry,authenticate:authenticateInboundWire},own.wire,event,own.physical);}finally{if(!supplied)own.close();}\n  }')
p.write_text(v)
# Native packed write path uses a single extent packing operation, not N independent decodes.
p=s/'src/crdt/accountReceive.ts';v=p.read_text();v="import{labPP}from'./rangeLab';\nimport{packInboundRecords,inboundRecordCharge}from'./inboundRecord';\n"+v;v=v.replace('const size = result.record.length + result.updates.reduce', 'const size = inboundRecordCharge(result.record) + result.updates.reduce')
old="const events=selected.map(value=>decodeInboundRecord((value as Extract<typeof value,{kind:'received'}>).record));"
v=v.replace(old,"const wireRecords=selected.map(value=>(value as Extract<typeof value,{kind:'received'}>).record);\n            const events=labPP()?[]:wireRecords.map(value=>decodeInboundRecord(value));")
v=v.replace('const packed=encodeDenseInbound(events);denseOwned.push(packed);','const packed=labPP()?packInboundRecords(wireRecords):encodeDenseInbound(events);denseOwned.push(packed);\n              const fact=labPP()?decodeInboundRecord(packed):events[0]!;')
v=v.replace("events[0]!.page))","fact.page))").replace('first:events[0]!.entry??0','first:fact.entry??0').replace('wireBytes:events[0]!.request.length+events[0]!.page.length','wireBytes:fact.request.length+fact.page.length');v=v.replace('pageHash.fill(0);\n              for(const value','pageHash.fill(0);if(labPP()){fact.request.fill(0);fact.page.fill(0);}\n              for(const value')
p.write_text(v)
# Ledger retains selected envelope/proof copies; the shared per-extent parse is always closed.
p=s/'src/crdt/inboundLedger.ts';v=p.read_text();v="import{labPP}from'./rangeLab';\nimport{createStoredInboundTurn,type StoredInboundTurn}from'./inboundRecord';\n"+v
# Find the actual async replay function's localCoverage boundary; scope variable lives in that function only.
needle='  let localCoverage:'
if needle in v: raise Error('Inspect local coverage declaration before changing')
# targeted start before its try/loop is completed by a follow-up edit after reading.
p.write_text(v)
(r/'IMPLEMENTATION-324-STATUS.md').write_text('Initial P prototype staged in private source only. Ledger scope/caller integration and verifier auth signature must be inspected/finished before any build/test. No timed run.\n')
print('Initial owned parse/dense prototype written; finish scope integration before tests')

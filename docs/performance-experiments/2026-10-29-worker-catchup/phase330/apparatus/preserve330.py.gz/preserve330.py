from pathlib import Path
import gzip,json,hashlib,subprocess,shutil
r=Path(__file__).parent;repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');d=repo/'docs/performance-experiments/2026-10-29-worker-catchup/phase330';sha=lambda b:hashlib.sha256(b).hexdigest();items=[];seen=set()
a=Path('/private/tmp/done-retained-scope-lab-20261101/source-repaired/src/crdt/accountReceive.ts');b=r/'source/src/crdt/accountReceive.ts';q=subprocess.run(['git','diff','--no-index','--binary','--',str(a),str(b)],capture_output=True);assert q.returncode==1;(r/'observation330.diff').write_bytes(q.stdout);d.mkdir(exist_ok=False)
def keep(p,cat='evidence'):
 if not p.is_file()or p.is_symlink():return
 dest=d/cat/(str(p.relative_to(r))+'.gz')
 if str(dest)in seen:return
 seen.add(str(dest));raw=p.read_bytes();packed=gzip.compress(raw,compresslevel=6,mtime=0);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(packed);items.append({'source':str(p),'copy':str(dest.relative_to(d)),'rawSha256':sha(raw),'bytes':len(raw),'gzipSha256':sha(packed)})
for p in sorted(r.iterdir()):
 if p.is_file()and not p.is_symlink()and p.suffix in['.json','.jsonl','.log','.md','.csv','.py','.mjs','.txt','.diff']and not p.name.startswith('freeze330-stderr'):keep(p,'apparatus'if p.suffix in['.py','.mjs','.diff']else'evidence')
for p in(r/'prepare330-admitted-checkpoint').rglob('*'):
 if p.is_file()and (p.parent==r/'prepare330-admitted-checkpoint'and p.suffix in['.json','.jsonl','.log']or p.name=='error-context.md'):keep(p)
for p in(r/'harness/test/account-continuation-lab').rglob('*'):
 if p.is_file():keep(p,'apparatus')
for name in['build-identity.json','build-flags.json','frontend-build.log','lab-build.log','build-lab.py','build.mjs','release-flags.json']:keep(r/'build'/name,'apparatus'if name.endswith(('.py','.mjs'))else'evidence')
for name in['PROTOCOL330.md','stop330-analysis.json']:shutil.copy2(r/name,d/name)
(d/'evidence-index.json').write_text(json.dumps({'labRoot':str(r),'labOnly':True,'acceptanceCredit':False,'noApplicationPatch':True,'compiledBuildsBrowserProfilesCredentialsDatabasesNotCopied':True,'noRunningOutputCaptured':True,'items':items},indent=2)+'\n')
for x in items:
 raw=Path(x['source']).read_bytes();packed=(d/x['copy']).read_bytes();assert sha(raw)==x['rawSha256']and sha(packed)==x['gzipSha256']and gzip.decompress(packed)==raw
(d/'evidence-check.json').write_text(json.dumps({'copiesVerified':len(items),'allRawAndCompressedHashesMatch':True},indent=2)+'\n');print('Preserved',len(items),'exact inert files')

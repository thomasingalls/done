// Diagnostic only; routes CDP to the actual dedicated owner target, no page data inspection.
export async function ownerProfile(browser, workerUrl) {
 const root = await browser.newBrowserCDPSession();
 const all = await root.send('Target.getTargets'); const targets = all.targetInfos.filter(t => t.type === 'worker' && t.url === workerUrl);
 if (targets.length !== 1) throw Error('Need one actual owner target, found ' + targets.length);
 const {sessionId} = await root.send('Target.attachToTarget', {targetId:targets[0].targetId, flatten:false});
 let next=0; const pending=new Map();
 root.on('Target.receivedMessageFromTarget', event => { if(event.sessionId!==sessionId)return; const m=JSON.parse(event.message);const p=pending.get(m.id);if(p){pending.delete(m.id);clearTimeout(p.timer);m.error?p.reject(Error(JSON.stringify(m.error))):p.resolve(m.result);} });
 const call=(method,params={})=>new Promise((resolve,reject)=>{const id=++next;const timer=setTimeout(()=>{pending.delete(id);reject(Error('CDP owner diagnostic deadline '+method));},20000);pending.set(id,{resolve,reject,timer});root.send('Target.sendMessageToTarget',{sessionId,message:JSON.stringify({id,method,params})}).catch(reject);});
 await call('Profiler.enable');await call('Profiler.setSamplingInterval',{interval:1000});await call('Profiler.start');
 return {target:targets[0],stop:async()=>{try{return(await call('Profiler.stop')).profile;}finally{await root.detach();}}};
}

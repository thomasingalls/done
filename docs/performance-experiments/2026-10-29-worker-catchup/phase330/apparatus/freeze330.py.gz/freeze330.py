from pathlib import Path
import subprocess,json,hashlib,tempfile,shutil,sys
repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');out=Path('/private/tmp/done-worker-catchup-matched-20261029');phase=int(sys.argv[1]);slug=sys.argv[2];scope=sys.argv[3];sha=lambda b:hashlib.sha256(b).hexdigest();path=out/'PATCHES.json';seq=json.loads(path.read_text())if path.exists()else{'baseCommit':'0ab9cbc8937e32c6542aaeeca697c87ba116c3be','sequence':[]};assert not seq['sequence']or seq['sequence'][-1]['phase']==phase-1;assert subprocess.check_output(['git','diff','--cached','--name-only'],cwd=repo,text=True)==''
for row in seq['sequence']:assert sha((out/row['patch']).read_bytes())==row['sha256']
work=Path(tempfile.mkdtemp(prefix=f'done-matched{phase}-replay-',dir='/private/tmp'))
def git(*args):
 p=subprocess.run(['git',*args],cwd=work,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 if p.stderr:
  with Path('/private/tmp/done-checkpoint-return-lab-20261101/freeze330-stderr.log').open('ab') as log:log.write(p.stderr)
 if p.returncode:raise subprocess.CalledProcessError(p.returncode,p.args,p.stdout,p.stderr)
 return p.stdout
git('init','--quiet');tracked=subprocess.check_output(['git','diff','--name-only','--no-renames'],cwd=repo,text=True).splitlines();untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=repo).decode().rstrip('\0').split('\0');untracked=[p for p in untracked if p]
for name in tracked:
 dest=work/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(subprocess.check_output(['git','show',seq['baseCommit']+':'+name],cwd=repo))
for row in seq['sequence']:git('apply',str(out/row['patch']))
def inventory():return{str(f.relative_to(work)):sha(f.read_bytes())for f in work.rglob('*')if f.is_file()and'.git'not in f.relative_to(work).parts}
prior=inventory();git('add','--all')
# Preserve explicit deletions from cumulative untracked predecessors as well as existing files.
for name in prior:
 if not (repo/name).exists():
  (work/name).unlink()
for name in tracked+untracked:
 src=repo/name;dest=work/name;assert src.is_file()and not src.is_symlink(),name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dest)
new=[n for n in untracked if n not in prior]
if new:git('add','--intent-to-add',*new)
scopeNames=git('diff','--name-only','--no-renames').decode().splitlines();assert all(n.startswith('docs/performance-experiments/2026-10-29-worker-catchup/phase330/')or n in ['docs/completed.md','docs/decisions.md','docs/product-backlog.md']for n in scopeNames),scopeNames
patch=out/f'{phase}-{slug}.patch';assert not patch.exists();patch.write_bytes(git('diff','--binary','--no-ext-diff','--no-renames'));candidate=inventory();names=git('diff','--name-only','--no-renames').decode().splitlines();assert set(names)=={n for n in set(prior)|set(candidate)if prior.get(n)!=candidate.get(n)}
for name,digest in candidate.items():assert sha((repo/name).read_bytes())==digest,name
git('apply','--reverse','--check',str(patch));git('apply','--reverse',str(patch));assert inventory()==prior;git('apply','--check',str(patch));git('apply',str(patch));assert inventory()==candidate;assert subprocess.check_output(['git','diff','--cached','--name-only'],cwd=repo,text=True)==''
meta={'phase':phase,'baseCommit':seq['baseCommit'],'requires':seq['sequence'][-1]['patch']if seq['sequence']else seq['baseCommit'],'patch':patch.name,'patchSha256':sha(patch.read_bytes()),'files':len(names),'scope':scope,'checks':['signed base','immutable predecessor hashes','exact cumulative bytes','forward/reverse replay','real index empty']};(out/f'{phase}-manifest.json').write_text(json.dumps(meta,indent=2)+'\n');seq['sequence'].append({'phase':phase,'patch':patch.name,'sha256':meta['patchSha256']});path.write_text(json.dumps(seq,indent=2)+'\n');print(json.dumps(meta,indent=2));print('Replay:',work)

from pathlib import Path
import shutil,json,hashlib,subprocess
old=Path('/private/tmp/done-retained-scope-lab-20261101');r=Path('/private/tmp/done-checkpoint-return-lab-20261101');r.mkdir(mode=0o700)
repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name,source in [('source',old/'source-repaired'),('source-server',old/'source-server'),('harness',old/'harness')]:
 shutil.copytree(source,r/name,symlinks=True,ignore=shutil.ignore_patterns('node_modules','.git','dist','test-results'))
 (r/name/'node_modules').symlink_to(repo/'node_modules',target_is_directory=True)
for name,target in [('source-repaired',r/'source'),('source-after',r/'source-server'),('source-R',r/'source-server'),('node_modules',repo/'node_modules'),('private-fixture',old/'private-fixture'),('test-inputs',old/'test-inputs')]: (r/name).symlink_to(target,target_is_directory=True)
for name in ['lab-context.mjs','observer.mjs','container-service.mjs','container-image.json','host_load.py','read-request.mjs','notification-probe.mjs','fixture-roles.mjs','run-stage.py','playwright-storage-source.txt']:
 p=r/name;p.write_text((old/name).read_text().replace(str(old),str(r)))
for p in(r/'harness').rglob('*'):
 if p.is_file()and not p.is_symlink()and p.suffix in ['.ts','.mjs','.json','.html']:
  p.write_text(p.read_text().replace(str(old),str(r)))
# Observation statements only. Record the decision without changing it or forcing historyRequired.
p=r/'source/src/crdt/accountReceive.ts';s=p.read_text();s="import {fault327 as observe330} from './faultTrace327';\n"+s
s=s.replace("        if (!historyRequired) return null;", "        observe330({kind:'history-catalog-decision330',historyRequired,continuation:!!continuation,installed:!!current.installedHistory,inherited:!!(inheritedHistoryHash&&inheritedHistoryHash!==EMPTY_HISTORY_CHECKPOINT),epoch:base.authority.tip,generation:base.generation});\n        if (!historyRequired) return null;")
s=s.replace("      const catalog = (\n", "      observe330({kind:'history-catalog-request330'});\n      const catalog = (\n",1)
s=s.replace("      historyDue = Date.now() + 5000;", "      observe330({kind:'history-catalog-reply330',sequence:catalog.sequence,empty:catalog.latest===EMPTY_HISTORY_CHECKPOINT});\n      historyDue = Date.now() + 5000;",1)
s=s.replace("      let result: Awaited<ReturnType<typeof verifyHistoryInstall>> | undefined,", "      observe330({kind:'history-install-start330',bytes:bytes.length});\n      let result: Awaited<ReturnType<typeof verifyHistoryInstall>> | undefined,",1)
s=s.replace("            return { kind: 'already-installed' as const };", "            observe330({kind:'history-install-result330',result:'already-installed'});\n            return { kind: 'already-installed' as const };",1)
s=s.replace("            return { kind: 'history-required' as const };", "            observe330({kind:'history-install-result330',result:'history-required'});\n            return { kind: 'history-required' as const };",1)
s=s.replace("          return { kind: 'installed' as const };", "          observe330({kind:'history-install-result330',result:'installed'});\n          return { kind: 'installed' as const };",1)
s=s.replace("        result?.update.fill(0);\n      }\n    },\"accountReceive.ts:1508:installHistory\")", "        observe330({kind:'history-install-end330',committed});\n        result?.update.fill(0);\n      }\n    },\"accountReceive.ts:1508:installHistory\")",1)
s=s.replace("                // Even an empty prepared receipt", "                observe330({kind:'history-storage-start330',command});\n                // Even an empty prepared receipt",1)
s=s.replace("                  await refreshCustody();\n                }\n              },\"accountReceive.ts:2881:history\")", "                  await refreshCustody();\n                  observe330({kind:'history-storage-end330',command});\n                }\n              },\"accountReceive.ts:2881:history\")",1)
s=s.replace("      historyFlights++;", "      observe330({kind:'history-command-start330',command});\n      historyFlights++;",1)
s=s.replace("        historyFlights--;", "        observe330({kind:'history-command-end330',command});\n        historyFlights--;",1)
assert s.count('observe330(')==12,s.count('observe330(')
p.write_text(s)
# Verify deleting only observation import/statements recovers exact parent bytes.
clean='\n'.join(line for line in s.split('\n')if 'observe330'not in line);assert clean==(old/'source-repaired/src/crdt/accountReceive.ts').read_text()
(r/'canonical-start.json').write_text((old/'canonical-start.json').read_text())
(r/'source-inputs330.json').write_text(json.dumps({str(p.relative_to(r/'source')):sha(p)for part in['src','account-protocol','test']for p in(r/'source'/part).rglob('*')if p.is_file()},indent=2)+'\n')
b=r/'build';b.mkdir();(b/'source').symlink_to(r/'source',target_is_directory=True);shutil.copytree(old/'build-repaired/lab',b/'lab',symlinks=True)
for p in(b/'lab').rglob('*'):
 if p.is_file()and p.suffix in['.ts','.mjs','.html']:p.write_text(p.read_text().replace(str(old/'build-repaired'),str(b)).replace(str(old),str(r)))
for name in['build-lab.py','build.mjs','release-flags.json']:(b/name).write_text((old/'build-repaired'/name).read_text().replace(str(old/'build-repaired'),str(b)).replace(str(old),str(r)))
print(r)

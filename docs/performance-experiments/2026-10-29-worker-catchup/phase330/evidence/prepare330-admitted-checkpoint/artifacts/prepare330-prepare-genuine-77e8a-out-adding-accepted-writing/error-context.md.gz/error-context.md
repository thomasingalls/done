# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: prepare330.spec.ts >> prepare genuine A-produced C-admitted checkpoint without adding accepted writing
- Location: test/account-continuation-lab/phase330/prepare330.spec.ts:3:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 1

@@ -55,11 +55,11 @@

  - H planning item 0: Review decisions and follow up.

  - Fair H reverse:

- - Fair H target: Seed H all-device boundary;0123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123
+ - Fair H target: Seed H all-device boundary;

  - Keep the first device writing
  ",
    "master.md": "# Account H

```

# Test source

```ts
  1  | import {expect,chromium,type Page} from '@playwright/test';
  2  | import {readFileSync,writeFileSync,mkdirSync,cpSync} from 'node:fs';
  3  | import {join} from 'node:path';
  4  | import {DatabaseSync} from 'node:sqlite';
  5  | import {configureLabContext} from '../../../../lab-context.mjs';
  6  | import {readRequestInfo} from '../../../../read-request.mjs';
  7  | import {decodeInboundPage} from '../../../../source/account-protocol/inboundTransport';
  8  | import {decodeInboundBatchPages} from '../../../../source/account-protocol/inboundBatch';
  9  | import {seedProfile} from '../seed-profile';
  10 | import {restoreAuthenticator,openSaved} from '../devices';
  11 | import {browserIdentity,clockBrackets} from '../dispatch-probe';
  12 | import {start,stop,control,resourceStop} from '../runtime.mjs';
  13 | import {root,card,exported,archiveIdentity,lock,digest} from '../common';
  14 | import {openMenuSection} from '../../geometry/openApp';
  15 | export {expect,start,stop,control,resourceStop,root,card,exported,archiveIdentity,lock,digest,openMenuSection,readFileSync,writeFileSync,mkdirSync,cpSync,join};
  16 | export const now=()=>performance.timeOrigin+performance.now();
  17 | export const out=process.env['FAIR_OUT']!,fixture=JSON.parse(readFileSync(process.env['FAIR_FIXTURE']!,'utf8')),account=fixture.accounts.find((a:any)=>a.label==='H');
  18 | export function probe330(){
  19 |  const stamp=()=>performance.timeOrigin+performance.now(),s:any={counts:[],events:[],visibleAt:null,expected:'',prefix:'',previous:-1,armed:false};
  20 |  const read=()=>{const target=[...document.querySelectorAll('.day-panel[data-active="true"] .card')].find(e=>e.textContent?.includes('Fair H target:'));if(s.expected&&target?.textContent?.includes(s.expected)&&s.visibleAt===null)s.visibleAt=stamp();const text=document.querySelector('.goals .cm-content')?.textContent??'',needle=s.prefix.replace(/^\n/,''),at=text.lastIndexOf(needle);if(s.prefix&&at>=0){const count=text.slice(at+needle.length).split('x').length-1;if(count!==s.previous){s.previous=count;s.counts.push({at:stamp(),count});}}};
  21 |  new MutationObserver(read).observe(document,{subtree:true,childList:true,characterData:true});
  22 |  for(const kind of ['keydown','beforeinput'])addEventListener(kind,(e:Event)=>{if(!s.armed||!(e.target instanceof Element)||!e.target.closest('.goals'))return;const row:any={kind,at:stamp(),trusted:e.isTrusted,focused:document.hasFocus(),visible:document.visibilityState,key:(e as KeyboardEvent).key,rafAt:null};s.events.push(row);if(kind==='beforeinput')requestAnimationFrame(()=>row.rafAt=stamp());},true);
  23 |  (window as any).__measurement330={arm:(prefix:string,expected?:string)=>{s.prefix=prefix;s.armed=true;s.counts=[];s.events=[];s.previous=-1;if(expected)s.expected=expected;read();},target:(expected:string)=>{s.expected=expected;s.visibleAt=null;read();},read:()=>{read();return structuredClone(s);}};
  24 | }
  25 | export async function actor330(index:number,label:string,result:any,contexts:any[]){
  26 |  const saved=account.actors[index],profile=join(out,'profile-'+label),ctx=await configureLabContext(await chromium.launchPersistentContext(profile,{executablePath:process.env['CHROMIUM_PATH']!,baseURL:'http://localhost:53781',viewport:{width:1440,height:1000},timezoneId:'UTC',headless:true}));contexts.push(ctx);result.roots??=[];result.roots.push({label,...await browserIdentity(ctx.browser()!)});await seedProfile(ctx,saved.storage);const p=ctx.pages()[0]??await ctx.newPage();await p.addInitScript(probe330);const a:any={index,label,saved,profile,ctx,p,jobs:[],requests:new Map()};
  27 |  p.on('request',q=>{const path=new URL(q.url()).pathname;if(!path.startsWith('/account/'))return;const row:any={device:label,path,at:now(),...readRequestInfo(q)};if(path==='/account/history/v1/checkpoint'){try{const v=q.postDataJSON();row.action=v.action;row.payloadKind=typeof v.payload==='string'?v.payload:'object';}catch{}}a.requests.set(q,row);(result.network??=[]).push(row);});
  28 |  p.on('response',response=>{const row=a.requests.get(response.request());if(!row)return;row.status=response.status();row.headersAt=now();if(row.status!==200)return;const job=(async()=>{try{if(['/account/delivery/read-v2','/account/delivery/read-v2-batch'].includes(row.path)){const wire=new Uint8Array(await response.body());row.responseBytes=wire.length;const pages=row.path.endsWith('-batch')?decodeInboundBatchPages(wire):[wire];row.pages=pages.map((bytes,i)=>{const page=decodeInboundPage(bytes);return{entries:page.entries.length,through:page.through,after:row.reads?.[i]?.after,publisherSha256:row.reads?.[i]?.publisherSha256}});for(const b of pages)b.fill(0);wire.fill(0);}else if(row.path==='/account/history/v1/checkpoint'){const raw=await response.body(),v=JSON.parse(raw.toString());row.responseBytes=raw.length;row.catalog=v.catalog?{sequence:v.catalog.sequence,latest:v.catalog.latest}:undefined;if(v.checkpoint){const cp=v.checkpoint;row.checkpoint={jsonBytes:Buffer.byteLength(JSON.stringify(cp)),ciphertextBytes:cp.ct.length/2,manifest:cp.manifest,heads:cp.heads,sources:cp.sources.length,hasAdmission:!!v.admission};}}row.bodyObservedAt=now();}catch(error){row.observationError=String(error);}})();a.jobs.push(job);});
  29 |  const auth=await restoreAuthenticator(p,saved.credentials);a.auth=auth;await p.goto('/');await p.evaluate(()=>navigator.serviceWorker.ready);await p.reload();await p.waitForFunction(()=>!!navigator.serviceWorker.controller);const sw=await p.evaluate(async()=>Array.from(new Uint8Array(await(await fetch((await navigator.serviceWorker.ready).active!.scriptURL)).arrayBuffer())));expect(digest(Buffer.from(sw))).toBe(digest(readFileSync(process.env['FAIR_DIST']!+'/sw.js')));await ctx.setOffline(true);return a;
  30 | }
  31 | export async function unlock330(a:any,result:any,measure=false){
  32 |  const {p,saved,index}=a;const field=p.getByLabel('Unlock code',{exact:true});const choice=p.getByRole('button',{name:index===0?/^Unlock Device owner/:/Resume device connection/});await expect.poll(async()=>await field.isVisible()||await choice.isVisible()).toBe(true);if(!await field.isVisible())await choice.click();await field.fill(saved.code);if(measure){await p.evaluate(expected=>(window as any).__measurement330.target(expected),account.expected);result.unlockSubmittedAt=now();}await p.getByRole('button',{name:/^(Confirm code and unlock with passkey|Unlock enrollment|Unlock and get invitation)$/}).click();await expect(p.locator('.shell')).toBeVisible({timeout:120000});if(measure)result.editorUsableAt=now();await p.getByLabel('Go to date',{exact:true}).fill(account.date);return a;
  33 | }
  34 | export async function historyPanel330(p:Page){await openMenuSection(p,'Data');const region=p.getByRole('region',{name:'History maintenance',exact:true});if(!await region.count())await p.getByRole('button',{name:'History maintenance',exact:true}).click();return region;}
  35 | export async function inspect330(a:any){const panel=await historyPanel330(a.p);await panel.getByRole('button',{name:'Check history',exact:true}).click();await expect(panel.getByRole('button',{name:'Check history',exact:true})).toBeEnabled({timeout:600000});await expect(panel.getByRole('alert')).toHaveCount(0);return panel;}
  36 | export async function goals330(a:any,prefix:string){await a.p.locator('.goals .cm-content').click();await a.p.keyboard.press('ControlOrMeta+End');await a.p.evaluate(prefix=>(window as any).__measurement330.arm(prefix),prefix);await a.p.keyboard.insertText(prefix);}
  37 | export async function keys330(a:any,offers:any[],count=120,whileRunning?:()=>boolean){const begin=now();for(let i=0;i<count;i++){if(whileRunning&&!whileRunning())break;await a.p.waitForTimeout(Math.max(0,begin+i*150-now()));const row:any={index:i,at:now(),scheduledAt:begin+i*150};offers.push(row);await a.p.keyboard.press('x');row.returnedAt=now();}return offers.length;}
  38 | export async function readFault330(a:any){const data=await a.p.evaluate(()=>({fault:(globalThis as any).__fault327?.read(),external:(globalThis as any).__fault327External,maintenance:(globalThis as any).__maintenanceRead?.()}));const file='fault330-'+a.label+'.json';writeFileSync(join(out,file),JSON.stringify(data,null,2)+'\n');const workers=data.external?.workers??[];return{file,events:[...(data.fault?.rows??[]),...workers.flatMap((w:any)=>w.critical??[])],streams:workers.map((w:any)=>({gaps:w.gaps,dropped:w.workerDropped,received:w.received})),maintenance:data.maintenance?{status:data.maintenance.status,diagnostics:data.maintenance.diagnostics}:null};}
  39 | export async function snapshot330(a:any){await Promise.allSettled(a.jobs);return{probe:await a.p.evaluate(()=>(window as any).__measurement330.read()),fault:await readFault330(a),clock:await clockBrackets(a.p)};}
> 40 | export async function exact330(a:any,expected:any){const actual=await exported(a.p);expect(actual).toEqual(expected);return archiveIdentity(actual);}
     |                                                                                                    ^ Error: expect(received).toEqual(expected) // deep equality
  41 | export function accepted330(state:string){const db=new DatabaseSync(join(state,'account.sqlite'),{readOnly:true});try{return db.prepare("SELECT account_id,credential_id,ordinal,position,digest,envelope_epoch,kind FROM publisher_decisions ORDER BY account_id,credential_id,position").all();}finally{db.close();}}
  42 | export async function undo330(a:any,expected:any){await a.p.locator('.goals .cm-content').click();await a.p.keyboard.press('ControlOrMeta+End');await a.p.waitForTimeout(750);const marker=' Undo330!';await a.p.keyboard.insertText(marker);await expect(a.p.locator('.goals .cm-content')).toContainText(marker);await a.p.keyboard.press('ControlOrMeta+z');await a.p.keyboard.press('Escape');await exact330(a,expected);}
  43 | export async function cold330(a:any,expected:any,result:any,contexts:any[]){await a.ctx.setOffline(true);await lock(a.p);await a.ctx.close();const ctx=await configureLabContext(await chromium.launchPersistentContext(a.profile,{executablePath:process.env['CHROMIUM_PATH']!,baseURL:'http://localhost:53781',viewport:{width:1440,height:1000},timezoneId:'UTC',headless:true,offline:true}),true);contexts.push(ctx);const p=ctx.pages()[0]??await ctx.newPage();await restoreAuthenticator(p,a.saved.credentials);await p.goto('/');await openSaved(p,a.saved.code,a.index!==0);await p.getByLabel('Go to date',{exact:true}).fill(account.date);const reopened={...a,p,ctx};await exact330(reopened,expected);await undo330(reopened,expected);(result.cold??=[]).push({device:a.label,archiveExact:true,offlineEditUndoExact:true});await ctx.close();}
  44 | export async function close330(contexts:any[]){for(const ctx of contexts)await ctx.close().catch(()=>{});await stop();}
  45 | 
```
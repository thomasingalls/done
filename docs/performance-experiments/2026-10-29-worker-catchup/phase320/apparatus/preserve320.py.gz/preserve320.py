from pathlib import Path
import json,gzip,hashlib,shutil
lab_root=Path(__file__).parent
repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done')
report=repo/'docs/performance-experiments/2026-10-29-worker-catchup/phase320'
report.mkdir(exist_ok=False)
sha=lambda value:hashlib.sha256(value).hexdigest()
items=[]
def keep(path,category='evidence'):
    data=path.read_bytes()
    destination=report/category/(str(path.relative_to(lab_root))+'.gz')
    destination.parent.mkdir(parents=True,exist_ok=True)
    destination.write_bytes(gzip.compress(data,compresslevel=6,mtime=0))
    items.append({'source':str(path),'copy':str(destination.relative_to(report)),'rawSha256':sha(data),'bytes':len(data),'gzipSha256':sha(destination.read_bytes())})
for name in ['final-gates-plan.json','final-gates-inputs.json','final-gates-results.json','final-gates-analysis.json','final-gates-analysis-console.log','final-gates-cells.json','final-grown-results.json','final-grown-analysis.json','final-grown-analysis-console.log','final-grown-attempts.csv','final-independent-check.json','final-late-results.json','final-late-analysis.json','final-late-analysis-console.log','final-gates-runs.csv','final-grown-owners.csv','final-grown-retry-waits.csv','final-grown-interruptions.csv','FINAL-GATES-PROTOCOL.md','build-identity.json','build-flags.json','final-observer-ast-check.json','old1024-independent-check.json']:
    path=lab_root/name
    if path.exists():keep(path)
rows=json.loads((lab_root/'final-gates-results.json').read_text())
for row in rows:
    folder=lab_root/row['name']
    names=['console.log','list.log','receipt.json','result.json','partial-result.json','host-load.jsonl','container-identity.json','cold-stages.jsonl','analysis.json','analysis.log']
    for name in names:
        if(folder/name).exists():keep(folder/name)
    for name in ['result.json','cold-stages.jsonl','container-identity.json']:
        for path in folder.glob('*/'+name):keep(path)
for name in ['preserve320.py','write320.py','verify-final-evidence.py','run-final-gates.py','analyze-final-late.py','analyze-final-gates.py','analyze-final-grown.py','analyze-case.py','analyze-fairness.py','host_load.py','lab-context.mjs','harness/test/account-continuation-lab/grown-maintenance.spec.ts','harness/test/account-continuation-lab/grown-maintenance.config.ts','harness/test/account-continuation-lab/gate-native.spec.ts','harness/test/account-continuation-lab/stall.spec.ts','harness/test/account-continuation-lab/continuation.spec.ts','harness/test/account-continuation-lab/cold-observer.ts','harness/test/account-continuation-lab/gate-maintenance.spec.ts']:
    keep(lab_root/name,'apparatus')
for name in ['final-gates-analysis.json','final-gates-cells.json','final-grown-analysis.json','final-grown-attempts.csv','final-independent-check.json','final-late-analysis.json','final-gates-runs.csv','final-grown-owners.csv','final-grown-retry-waits.csv','final-grown-interruptions.csv']:
    if(lab_root/name).exists():shutil.copy2(lab_root/name,report/name)
if(lab_root/'STOP.json').exists():keep(lab_root/'STOP.json')
(report/'evidence-index.json').write_text(json.dumps({'labRoot':str(lab_root),'items':items,'profilesCredentialsDatabasesBuildsNotCopied':True},indent=2)+'\n')
for item in items:
    assert sha(gzip.decompress((report/item['copy']).read_bytes()))==item['rawSha256']
    assert sha(Path(item['source']).read_bytes())==item['rawSha256']
(report/'evidence-check.json').write_text(json.dumps({'allExact':True,'verifiedOriginalCopies':len(items)},indent=2)+'\n')
print('Preserved',len(items),'files for',len(rows),'reached journeys')

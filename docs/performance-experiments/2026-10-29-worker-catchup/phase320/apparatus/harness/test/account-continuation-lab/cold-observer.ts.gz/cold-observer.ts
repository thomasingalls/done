import {appendFileSync} from 'node:fs';

export async function observedCold(r:any,label:string,work:()=>Promise<any>){
 const file=process.env['FAIR_OUT']+'/cold-stages.jsonl',stage={label,at:Date.now()};r.coldAttemptStarted=true;r.coldAllAttemptedExact=false;r.coldStage=label;appendFileSync(file,JSON.stringify({kind:'start',...stage})+'\n');
 try{const value=await work();r.coldAllAttemptedExact=true;(r.coldStages??=[]).push({label,exact:true});appendFileSync(file,JSON.stringify({kind:'end',label,at:Date.now(),exact:true})+'\n');return value;}
 catch(error){r.coldFailure=true;appendFileSync(file,JSON.stringify({kind:'end',label,at:Date.now(),exact:false})+'\n');throw error;}
 finally{r.coldStage=null;}
}

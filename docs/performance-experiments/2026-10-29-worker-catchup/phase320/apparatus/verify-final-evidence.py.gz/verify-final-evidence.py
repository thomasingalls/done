from pathlib import Path
import json,csv,hashlib,collections
r=Path(__file__).parent
read=lambda name:json.loads((r/name).read_text())
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
rows=read('final-gates-results.json');analysis=read('final-gates-analysis.json');grown=read('final-grown-analysis.json');late=read('final-late-analysis.json');inputs=read('final-gates-inputs.json')
assert len(rows)==len(analysis)==36 and len(grown)==len(late)==6
assert all(row['childExit']==0 and not row['coldFailure']for row in rows)
assert not(r/'STOP.json').exists()
assert inputs['plan']==read('final-gates-plan.json')
for name,digest in inputs['sources'].items():assert sha(r/'source'/name)==digest
for name,digest in inputs['assets'].items():assert sha(r/'combined-dist'/name)==digest
for name,digest in inputs['apparatus'].items():assert sha(r/name)==digest
for name in ['analyze-case.py','analyze-fairness.py']:assert sha(r/name)==sha(Path('/private/tmp/done-range-vgr-lab-20261030')/name)
old=read('old1024-independent-check.json');assert sha(r/'old1024-fixture/fixture.json')==old['rebuiltFixtureSha256'];assert sha(r/'private-fixture/fixture.json')==old['originalFixtureSha256']
lateby={x['name']:x for x in late}
for row in analysis:
 if row['name']in lateby:
  item=lateby[row['name']];row.update(postDrainPeerP95ms=item['postDrainPeerMs']['p95'],postDrainKeys=item['keysAfterReaderDrain'],postDrain2500ms=item['postDrainPeerMs']['p95']<=2500)
for row in analysis:
 if row['cell'].startswith('old-maintenance'):
  raw=read(row['name']+'/result.json');overlap=sum(x['kind']=='key'and x['at']<raw['catchups'][0]['completedAt']for x in raw['offers']);assert overlap==row['keysDuringBacklog'];assert row['failedPredicates']==['atLeast60KeysDuringCatchup']
assert all(x['allMeasuredPredicates']for x in late)
coldStarts=0
for row in rows:
 for p in list((r/row['name']).glob('cold-stages.jsonl'))+list((r/row['name']).glob('*/cold-stages.jsonl')):
  pending=[]
  for line in p.read_text().splitlines():
   event=json.loads(line)
   if event['kind']=='start':pending.append(event['label']);coldStarts+=1
   else:assert event['exact']is True and pending.pop()==event['label']
  assert not pending
retryRows=[];ownerRows=[];interruptRows=[]
for row in grown:
 raw=read(row['name']+'/result.json')
 assert all(row['gatePredicates'].values())
 for owner in row['owners']:
  assert owner['capacityRefusals']==0 and not owner['startsDuringTyping'] and not owner['startsDuringReaderDrain'] and owner['traceOverflow']==0
  for family in owner.get('families',[]):assert sum(v['bytes']for v in family.values())<=33554432
  interrupts=owner.get('interruptedAttempts',[]);waits=owner.get('retryWaits',[])
  for attempt in interrupts:
   for condition in attempt['conditions']:
    interruptRows.append({'case':row['name'],'role':owner['role'],'attempt':attempt['attempt'],'condition':json.dumps(condition,separators=(',',':'))})
  for wait in waits:
   assert wait['scheduledRetryMs']==10000 and wait['priorityOnly']is True
   retryRows.append({'case':row['name'],'role':owner['role'],'afterTyping':wait['endedAt']>=raw['typingFinishedAt'],**wait})
  post=[w for w in waits if w['endedAt']>=raw['typingFinishedAt']]
  ownerRows.append({'case':row['name'],'role':owner['role'],'attempts':owner['attempts'],'completions':owner['completions'],'firstCompletionAfterKeyMs':owner['firstCompletionAfterLastKeyMs'],'interruptedAttempts':len(interrupts),'postTypingRetries':len(post),'scheduledRetryMs':json.dumps([w['scheduledRetryMs']for w in waits]),'postTypingActualWaitMs':json.dumps([w['actualEndToNextStartMs']for w in post]),'preTypingActualWaitMs':json.dumps([w['actualEndToNextStartMs']for w in waits if w not in post]),'censoredRetries':sum(w['censoredNoNextStart']for w in waits),'peakMapBytes':owner['maxMapBytes'],'peakDurablePayloadBytes':owner['durablePeakBytes'],'capacity':owner['capacityRefusals'],'jobTags':json.dumps(dict(collections.Counter(c.get('arrivingJob',{}).get('name','unknown')for a in interrupts for c in a['conditions']))),'startsDuringTyping':len(owner['startsDuringTyping']),'startsDuringReaderDrain':len(owner['startsDuringReaderDrain'])})
(r/'final-gates-analysis.json').write_text(json.dumps(analysis,indent=2)+'\n')
for name,data in [('final-grown-owners.csv',ownerRows),('final-grown-retry-waits.csv',retryRows),('final-grown-interruptions.csv',interruptRows)]:
 with(r/name).open('w',newline='')as stream:writer=csv.DictWriter(stream,fieldnames=list(data[0]),lineterminator='\n');writer.writeheader();writer.writerows(data)
columns=['name','cell','replicate','childExit','allOriginalPredicates','inputP95ms','peerP95ms','worstMarkerMs','deepMs','keysDuringBacklog','postDrainPeerP95ms','postDrainKeys','paragraphBeforeinputP95ms','paragraphRafP95ms','paragraphRafMaxMs','paragraphRafOver100ms','hostBusyMedian','hostBusyMax','failedPredicates']
with(r/'final-gates-runs.csv').open('w',newline='')as stream:
 writer=csv.DictWriter(stream,fieldnames=columns,lineterminator='\n');writer.writeheader();writer.writerows({k:json.dumps(x.get(k))if k=='failedPredicates'else x.get(k)for k in columns}for x in analysis)
facts={'all36Reached':True,'all36FunctionalAndColdGuardsPass':True,'actualNoFColdFailures':0,'independentlyBalancedObservedColdStages':coldStarts,'sourceArtifactAndHarnessHashesStillExact':True,'originalAnalyzersByteExact':True,'oldFixtureHashesExact':True,'originalPredicateFailures':{x['name']:x['failedPredicates']for x in analysis if not x['allOriginalPredicates']},'allSixGrownPredicatesPass':True,'allSixLatePostDrainTargetsPass':True,'grownOwnerRows':len(ownerRows),'grownInterruptedAttempts':len(retryRows),'grownInterruptionConditions':len(interruptRows),'noGrownAttemptsStartDuringTypingOrReaderDrain':True,'nonPriority60sRetryCoverage':'Not exposed here; keep60, requires separate hardening controls','labOnly':True,'acceptanceCredit':False}
(r/'final-independent-check.json').write_text(json.dumps(facts,indent=2)+'\n')
print(json.dumps(facts,indent=2))

from pathlib import Path
import json,subprocess,time,sys,os,signal,hashlib,datetime
r=Path(__file__).parent;node='/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node';key='final-gates';plan=json.loads((r/(key+'-plan.json')).read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert len(plan)==36
original=[c for c in plan if not c.get('grown')];grown=[c for c in plan if c.get('grown')]
assert len(original)==30 and len(grown)==6 and all(sum(c['cell']==k for c in original)==3 for k in set(c['cell']for c in original)) and len(set(c['cell']for c in original))==10
assert all(sum(c['cell']==k for c in grown)==3 for k in set(c['cell']for c in grown)) and len(set(c['cell']for c in grown))==2
frozen={'sources':{str(p.relative_to(r/'source')):sha(p)for d in ['src','account-protocol']for p in(r/'source'/d).rglob('*')if p.is_file()},'assets':json.loads((r/'build-identity.json').read_text())['files'],'apparatus':{str(p.relative_to(r)):sha(p)for p in(r/'harness/test/account-continuation-lab').rglob('*')if p.is_file()},'plan':plan,'labOnly':True,'acceptanceCredit':False,'oneFailFailsCell':True};(r/(key+'-inputs.json')).write_text(json.dumps(frozen,indent=2)+'\n');rows=[]
for c in plan:
 assert not(r/'STOP.json').exists();assert all(sha(r/'source'/n)==h for n,h in frozen['sources'].items());assert all(sha(r/'combined-dist'/n)==h for n,h in frozen['assets'].items());assert all(sha(r/n)==h for n,h in frozen['apparatus'].items())
 if c.get('mode')or c['cell']=='fairness':
  fixture=Path(c.get('fixture',r/'private-fixture/fixture.json'));assert json.loads(fixture.read_text())['accounts'][0]['date']==datetime.datetime.now(datetime.timezone.utc).date().isoformat(),'Actual civil fixture expired; no clock override'
 out=r/c['name'];out.mkdir(mode=0o700,exist_ok=False);env={k:v for k,v in os.environ.items()if not k.startswith(('FAIR_','RANGE_LAB_','STALL_'))};env.update({'PATH':str(Path(node).parent)+':'+env['PATH'],'FAIR_OUT':str(out),'FAIR_DIST':str(r/'combined-dist'),'FAIR_LAB_BITS':c['bits'],'FAIR_SY_BITS':'11','FAIR_REPAIR_MS':'1000','FAIR_VARIANT':c.get('variant','C'),'QUIET_WITHHOLD':'1'if c.get('withhold')else'0','FAIR_IDLE_PAUSE':'0','FAIR_PREP_HIDDEN':'0','STALL_MOBILE':'1'if c.get('mobile')else'0','STALL_PROFILE':'0','CHROMIUM_PATH':'/private/tmp/done-civil-gates-browser-20261030/Chrome.app/Contents/MacOS/Google Chrome'})
 if c.get('fixture'):env['FAIR_FIXTURE']=c['fixture']
 cmd=[node,'node_modules/@playwright/test/cli.js','test','--config','test/account-continuation-lab/'+c['config']]
 if c.get('grep'):cmd+=['--grep',c['grep']]
 with(out/'list.log').open('w')as f:pre=subprocess.run(cmd+['--list'],cwd=r/'harness',env=env,stdout=f,stderr=subprocess.STDOUT)
 if pre.returncode:print('LIST FAILED',c['name'],flush=True);sys.exit(4)
 load=out/'host-load.jsonl';sampler=subprocess.Popen([sys.executable,str(r/'host_load.py'),'--out',str(load)]);started=time.time()
 try:
  for i in range(500):
   if Path(str(load)+'.ready').exists():break
   if sampler.poll()is not None:raise RuntimeError('Sampler failed')
   time.sleep(.01)
  else:raise RuntimeError('Sampler not ready')
  print('START',c['name'],flush=True)
  with(out/'console.log').open('w')as f:p=subprocess.run(cmd,cwd=r/'harness',env=env,stdout=f,stderr=subprocess.STDOUT)
 finally:sampler.send_signal(signal.SIGTERM);sampler.wait(timeout=10)
 paths=list(out.glob('result.json'))+list(out.glob('*/result.json'));raw=[];cold=False;reasons=[]
 for path in paths:
  x=json.loads(path.read_text());guards=x.get('guards',{})or{};complete=bool(x.get('coldAllAttemptedExact'))or any(guards.get(g)for g in ['unchangedShippingReaderExact','originalAccountReaderColdExact','bothOfflineColdProfilesExact','offlineColdProfileExact','originalJoinedColdReopen','originalJoinedPageColdReopenExact','actualPageColdReopenExact']);failed=bool(x.get('coldFailure'))or(bool(x.get('coldAttemptStarted'))and not complete)
  if failed:reasons.append(str(path.relative_to(out))+': explicit cold state')
  cold|=failed;raw.append({'path':str(path.relative_to(out)),'outcome':x.get('outcome'),'error':x.get('error'),'guards':guards,'coldFailure':failed})
 stagePaths=list(out.glob('cold-stages.jsonl'))+list(out.glob('*/cold-stages.jsonl'));stages=[]
 for stagePath in stagePaths:
  pending=[]
  for line in stagePath.read_text().splitlines():
   z=json.loads(line);stages.append({**z,'observerFile':str(stagePath.relative_to(out))})
   if z['kind']=='start':pending.append(z['label'])
   else:
    if z.get('exact')is not True:cold=True;reasons.append('cold-stage '+z['label']+' failed')
    assert pending and pending[-1]==z['label'],'Cold observer stage mismatch';pending.pop()
  if pending:cold=True;reasons.append('unfinished actual cold stages '+repr(pending))
 row={**c,'command':cmd,'childExit':p.returncode,'startedAt':started,'finishedAt':time.time(),'rawResults':raw,'coldFailure':cold,'coldReasons':reasons,'coldStages':stages,'externalLoadLog':'host-load.jsonl','labOnly':True,'acceptanceCredit':False};rows.append(row);(out/'receipt.json').write_text(json.dumps(row,indent=2)+'\n');(r/(key+'-results.json')).write_text(json.dumps(rows,indent=2)+'\n');print('RESULT',json.dumps(row),flush=True)
 if cold:(r/'STOP.json').write_text(json.dumps({'rule':'Any no-F cold failure stops immediately','case':row},indent=2)+'\n');print('STOP: later declared cells withheld',flush=True);sys.exit(3)
print('All thirty original plus six separate grown replicates retained',flush=True)

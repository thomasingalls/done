# Operator additions after phase315

Capacity is thrown as PreparationCapacity, not returned as skipped/capacity. automaticLocalRetention catches it as owner-error and sets the live controller halted. It is not parked. No fix is built. S landing must map the specific preparation-capacity refusal to skipped/capacity without swallowing integrity/storage/authority failures, and test durable checkpoint/reopen behavior separately.

Every 3072 cell reports journal map bytes by family and first measured index fallback, including missing/censored evidence. Predicted positions/bytes are hypotheses only. Every grown gate reports interruptions and retry waits separately for writer and reader. R1000 has not yet had a complete maintenance window; phase314 run02 used R1500, three10s retries contributed to81s.

The two R-off controls are predeclared in NAMED-COST-PROTOCOL.md before D pairs; no rebuild.

## Reopen behavior established by source, not a new capacity test

`createAutomaticLocalRetention` initializes `halted = false` in memory. The receiving owner creates a controller for its lifetime. Closing and reopening the owner therefore discards the prior halted flag; it does not increase the 32 MiB preparation-map limit or erase the durable checkpoint. On a later eligible attempt, contentStore loads the saved checkpoint, authenticates/decrypts its deltas, checks generation/context/prefix and imports only status `ready`. Stale/invalid proofs are not imported. The PreparationCapacity path is not the PreparationPause catch, so that attempt's unsaved pending work is disposed rather than persisted. Previously saved slices remain available. A new owner can repeat the same capacity failure; reopening is not a remedy. This is a static behavior trace, not a fresh measured reopen of a capacity-halted profile.

S landing must map only the specific PreparationCapacity result into `skipped/capacity`, leaving integrity, storage, journal, authority and uncertain-mutation errors unchanged, and cover parked/retry/new-hint/reopen behavior. The current lab prototype deliberately retains the throwing/owner-error behavior. No fix or test relaxation is built here.

from pathlib import Path
import json,math,csv,statistics
r=Path(__file__).parent;out=[];bins=[];attemptRows=[]
for row in json.loads((r/'index3072-results.json').read_text()):
 x=json.loads((r/row['name']/'result.json').read_text());realms=x.get('lab')or x.get('finalLab')or[];ee=sorted([e for q in realms for e in(q.get('value')or{}).get('events',[])],key=lambda e:e['at']);t0=x.get('drainStartedAt',x.get('startedAt'));end=x.get('drainCompletedAt');active=[e for e in ee if t0 is not None and e['at']>=t0 and(end is None or e['at']<=end)];commits=[e for e in active if e['kind']=='inboundCommit'];budgets=[e for e in active if e['kind']=='indexBudget'];false=[e for e in budgets if not e['fits']];cumulative=0;cross={0:t0};through=[]
 for e in commits:
  before=cumulative;cumulative+=e['positions'];through.append((e['at'],cumulative))
  for n in range(100,3100,100):
   if before<n<=cumulative and n not in cross:cross[n]=e['at']
  if before<3072<=cumulative:cross[3072]=e['at']
 first=false[0]if false else None
 fallback={'at':first['at'],'throughObservedLogicalPositions':sum(e['positions']for e in commits if e['at']<=first['at']),'elapsedMsMixedClock':first['at']-t0,**{k:first[k]for k in ['rows','logical','chargedBytes','physicalBytes','lastSeq','maxRows','maxBytes']}}if first else None
 last=0
 for n in list(range(100,3100,100))+[3072]:
  elapsed=cross[n]-cross[last]if n in cross and last in cross else None;bins.append({'case':row['name'],'fromExclusive':last,'through':n,'elapsedMs':elapsed,'msPerPosition':elapsed/(n-last)if elapsed is not None else None,'censored':elapsed is None,'clock':'first bin mixes Node/Worker epoch without new brackets; later differences within Worker clock'});last=n
 overflow=sum(q.get('value',{}).get('eventOverflow',0)for q in realms);scalar=sum(q.get('value',{}).get('inboundPositions',0)for q in realms);traces=x.get('traces')or x.get('finalTraces')or[];aa=[];te=[]
 for realm in traces:
  v=realm.get('value')or{};aa+=v.get('attempts',[]);te+=v.get('events',[])
 cap=[e for e in te if e.get('kind')in ['PreparationCapacity','preparation-capacity']];saves=[e for e in te if e.get('kind')=='checkpoint-saved'];complete=[a for a in aa if a.get('outcome',{}).get('kind')in ['removed','already-removed']];journals=[j for a in aa for j in a.get('journals',[])]
 for a in aa:
  s=[e for e in saves if e['attempt']==a['id']]
  for j in a.get('journals',[])or[{}]:attemptRows.append({'case':row['name'],'attempt':a['id'],'startAt':a['startedAt'],'endAt':a.get('endedAt'),'stage':a.get('stage'),'outcome':a.get('outcome',{}).get('kind','active-at-capture'),'entries':j.get('entries'),'pending':j.get('pending'),'hits':j.get('hits'),'newMisses':j.get('misses'),'lookupMisses':j.get('lookupMisses'),'firstMissMs':j.get('firstMiss',{}).get('elapsedMs'),'mapBytes':j.get('bytes'),'byteCap':j.get('byteCap'),'durableBytes':s[-1]['bytes']if s else None,'durableDeltas':s[-1]['deltas']if s else None,'replayMs':sum(e.get('ms',0)for e in a.get('replays',[])),'families':json.dumps(j.get('families')),'interruptions':json.dumps(a.get('interruptions',[]))})
 firstCommitAt=commits[0]['at']if commits else None;lastCommitAt=commits[-1]['at']if commits else None;totalBytes=sum(e['bytes']for e in commits);facts=[e for e in active if e['kind']=='denseReceiptStored'];seen=set();dup=0
 for e in facts:
  if e['pageSha256']in seen:dup+=1
  seen.add(e['pageSha256'])
 loads=[json.loads(s)for s in(r/row['name']/'host-load.jsonl').read_text().splitlines()];busy=[100-z['hostPercent']['idle']for z in loads if z.get('kind')=='load'];data={**row,'drainComplete':bool(x.get('guards',{}).get('fullArchiveAfterDrain')),'drainMs':end-t0 if end is not None and t0 is not None else None,'observedLogicalCommitPositions':cumulative,'scalarLogicalPositions':scalar,'eventOverflow':overflow,'timelineComplete':overflow==0 and cumulative==scalar,'firstIndexFallback':fallback,'indexPeakObservedCharge':max((e['chargedBytes']for e in budgets),default=None),'indexPeakObservedPhysicalBytes':max((e['physicalBytes']for e in budgets),default=None),'comparisonMsScalar':sum((q.get('value')or{}).get(k,0)for q in realms for k in ['prefixComparisonMs','appendPrefixComparisonMs']),'observedNativeRows':sum(e['physicalRows']for e in commits),'observedHeadRows':sum(e['physicalReceipts']for e in commits),'observedPlaintextBytes':totalBytes,'observedBytesPerPosition':totalBytes/cumulative if cumulative else None,'denseExtentCountObserved':len(facts),'duplicateOriginalPageStoresObserved':dup,'readerAttempts':len(aa),'readerCompletions':len(complete),'readerCapacityRefusals':len(cap),'readerPeakMapBytes':max((j.get('bytes',0)for j in journals),default=None),'readerDurablePeakBytes':max((s['bytes']for s in saves),default=None),'readerLastOutcome':aa[-1].get('outcome')if aa else None,'readerFurthestStages':sorted(set(a.get('stage','unknown')for a in aa)),'cold':'exact'if x.get('guards',{}).get('offlineColdProfileExact')else'FAILED'if x.get('coldFailure')else'not reached','hostBusyMedian':statistics.median(busy)if busy else None,'hostBusyMax':max(busy)if busy else None,'qualification':'Diagnostic only, no credit. Expanded index charge is not heap size. Event truncation/censoring remains explicit; no missing positions interpolated. Node drain duration is end-to-end; first native timeline bin has unbracketed epoch alignment. Reader120swindow/600sdrain/guards unchanged; cold only if maintenance reaches it.'};data['readerJournalFamilySnapshots']=[{'attempt':a['id'],'journal':j.get('id'),'mapBytes':j.get('bytes'),'cap':j.get('byteCap'),'families':j.get('families'),'entries':j.get('entries'),'newMisses':j.get('misses')}for a in aa for j in a.get('journals',[])];data['readerRetryClocks']=[e for e in te if e.get('kind')=='retry-clock'];data['readerInterruptions']=[{'attempt':a['id'],**e}for a in aa for e in a.get('interruptions',[])];out.append(data)
(r/'index3072-analysis.json').write_text(json.dumps(out,indent=2)+'\n')
for name,rows in [('index3072-per100.csv',bins),('index3072-attempts.csv',attemptRows)]:
 if rows:
  with(r/name).open('w',newline='')as f:w=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows)
print(json.dumps(out,indent=2))

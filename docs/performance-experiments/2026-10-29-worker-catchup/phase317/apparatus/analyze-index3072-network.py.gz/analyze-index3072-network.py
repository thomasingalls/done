from pathlib import Path
import json,csv,collections
r=Path(__file__).parent;a=json.loads((r/'index3072-analysis.json').read_text());bins=[]
for x in a:
 raw=json.loads((r/x['name']/'result.json').read_text());pubs=collections.defaultdict(list)
 for q in raw['network']:
  for z in q.get('reads',[]):
   if not z.get('self')and q.get('status')==200:pubs[z['publisherSha256']].append({**z,'at':q['at'],'headersAt':q.get('headersAt')})
 pub,rows=max(pubs.items(),key=lambda kv:max(z['after']for z in kv[1])-min(z['after']for z in kv[1]));rows=sorted(rows,key=lambda z:z['at']);base=min(z['after']for z in rows);cross={0:raw['drainStartedAt']}
 for n in list(range(100,3100,100))+[3072]:cross[n]=next((q['at']for q in rows if q['after']>=base+n),None)
 last=0
 for n in list(range(100,3100,100))+[3072]:
  elapsed=cross[n]-cross[last]if cross[n]is not None and cross[last]is not None else None;bins.append({'case':x['name'],'fromExclusive':last,'through':n,'requestCursorElapsedMs':elapsed,'requestCursorMsPerPosition':elapsed/(n-last)if elapsed is not None else None,'qualification':'Uncapped Node request cursor, not native verification/application or proof of first index fallback'});last=n
 scalar={k:sum((q.get('value')or{}).get(k,0)for q in raw.get('lab')or raw.get('finalLab')or[])for k in ['fullLedgerChecks','fullPhysicalLoads','prefixComparisonCalls','prefixComparisonMs','receiveGroupMs']}
 x['uncappedNativeScalars']=scalar;x['requestCursor']={'publisherSha256':pub,'baselineAfter':base,'lastAfter':max(q['after']for q in rows),'requestCount':len(rows),'crossings':cross,'qualification':'Network cursor only; cannot assign exact index fallback from a timing bend.'};x['firstIndexFallbackMeasurement']='NOT MEASURED: event cap truncated before the boundary. No absent-event/no-fallback inference.'
(r/'index3072-analysis.json').write_text(json.dumps(a,indent=2)+'\n')
with(r/'index3072-network-per100.csv').open('w',newline='')as f:w=csv.DictWriter(f,fieldnames=list(bins[0]),lineterminator='\n');w.writeheader();w.writerows(bins)
for x in a:
 print(x['name'],x['uncappedNativeScalars'])
 for b in bins:
  if b['case']==x['name']and b['through']in [2000,2300,2400,2500,2600,2700,2800,3000,3072]:print(b['through'],round(b['requestCursorMsPerPosition'],2)if b['requestCursorMsPerPosition']else None)

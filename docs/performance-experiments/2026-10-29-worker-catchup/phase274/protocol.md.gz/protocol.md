# Phase274 — unreduced cold baseline reuse contract and discriminating regression

2026-10-30. Operator order supersedes prior normalPage/Worker comparison: hold that comparison.
First exact-evidence reuse only within one carrier, no cross-owner handoff/persisted trust. Then
record deep-request at/headersAt, implement multi-entry reads and re-check fairness; if oldPage
composition syncs, deepjoinedPage64 is a separate labcomparison needing no datefixture refresh.
Only after that make a re-runnable fixture recipe, missing0abwithheldyieldcell andnormalgates.
No productionlimits/flags/gates/security guarantees change, no releaseprep/sign/push/deploy/CUA.

History:354c9c59 introduced privatewarm reduced(v5) reuse. da5f2853/phase122 deliberately retained
v3/v4 physical/reference comparisons and one-shot exactreuse onlyv5/nonwarm. Currentunreducedv3/v4
misses exactgate(metadata.reduced), retains no chunks unlessv5, retains noauthority proof unless
reduced, and cannotseedwarm/incremental state(metadata.reduced). Consequently each call invokes
localBaselineShadow's !reduced fullhistory+baseline+equivalence comparison. This was conservative
scope, not a measured necessity for repeating identical same-carrier evidence. First fullcomparison
is still required; do not remove localBaselineShadow's reference check on cache misses.

Repair bound: completed proof private to one ContentOwner. One-shot immutable-capability opt-in or
privatewarmunreduced owner may reuse only after fresh complete physical rows/chunks, authenticated
counter including exact pointer/era/witness, same sealedbytes/census and fresh verifier-owned pins
before/after reuse. Counter/change, capability reconstruction/replacement, invalidation/reference,
failedreads or close prevent reuse. View identity guard across awaits and caller detachment stay.
v3 completed verification can exist without a logicalprojection; retain its completed-proof marker,
not invented records. Direct snapshot/transition/retention/reference consumers force fullcomparison.
Existing reducedwarm guard/rollingaudit/incrementalcontinuation remains unchanged; never feed
unreducedphysicalprefix into reduced-only incremental reuse. No freshness/trustwindow widening,
new API/format/key/domain, cachedTask, owner transfer or persisted proof. Validator still invoked.

Evidence before repair: realcrypto/fakeIDB unreducedv3/v4 created via actual installBaseline without
deleting/restoring lowrows. Coldoptin andlivewarm exactrepeat discriminators mustfail at repeated
verifyCompleteLocalBaseline count, notsetup. Negative cases: optoutreference, allfreshnative reads,
changedoldprefix/chunk/MAC, addedmetadata, counterappend, authority identity/latechange, close,
invalidation, explicitreference, failedreadthenrestore, detachedcaller andexpiredTask isolation.
Original122/oldtests retained. Deliberate faults mustdetect skippedbyte/pin/finalview guards.

Then sourcebookkeeping/unitcontracts and actual rebuilt production-flag publiccold15s cases with
no diagnostichooks, retaining fullmaintenance/Undo/exactarchive and original30sdeepgates. Numeric
profile comparison can show eliminatedwork but is not physicalphone/no-stalls/population evidence.
One-carrier control must stillreplay on anewcarrier, even sameimmutableauthority. No normalPage/
Workertrajectory, nor a higherproductionrate. Preserve every prior raw failure and sequentialpatch;
completed before backlog; otherseat progress unchanged. All16ms/2.5s/everymarker/30s/600sgatesstay.

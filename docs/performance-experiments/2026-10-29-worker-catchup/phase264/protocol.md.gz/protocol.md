# Phase264 — disposable session-budget falsifier

2026-10-30. Test whether the scoped session request budget materially limits the original deepjoined
actor1case. Reuse exact signed0abclient/native lab/publicfrontend assets and the original260case
with production settings/warmunset, same fictional fixture/real clock/native checks/deadlines.
Server is a complete signed0abcopy with precisely one policy value changed: sessionPerSecond16→64.
Keep sessionBurst120/processBurst480/processRate64/sessionActive4/processActive16/byte/deadline/
authority/history/ledger/witness/freshcommit/fencing/journal checks. No product default changes.
A numeric startup field reports actual imported REQUEST_LIMITS; no in-flight budget instrumentation.

One fresh isolated serial original actor1journey, no retries. Its original30000ms native-state
completion wait remains binding, along with exact accepted source/senderclosed/Windowapply/Undo/
original-reader cold guards. Before timing verify exact clientasset/input hashes, one-line server
policy diff, actual startup policy and service readiness/shutdown. No concurrent build/scan/profile.
Host quiet coordination from prior operator answer carries forward, not perfect OS/thermal isolation.
Original261failure447positions/30s remains recorded. The unit is one complete synthetic journey;
requests/positions are dependent. Compare with retained original as a mechanism probe, not a powered
or contemporaneously randomized population effect. No gain or production-rate recommendation from
one trajectory, and no modified-policy result replaces original acceptance.

Pass of full original case supports material budget contribution on this fixture. If it still fails,
retain native receivedThrough/working/failure state and original last200traffic response rows, compare
progress over the unchanged30swait to original447 and259payload work rates. Similar progress weakens
a session-budget-only explanation; improved-but-incomplete progress indicates another limit remains.
Non-authority partial progress earns no success; any new authority/storage/cleanup failure stops for
classification. Budget-table counts in supplied brief remain estimates unless reconstructed; network
success counts do not equal exact reservations/refunds. Endpoint/API/CPU caps remain independent.

Next separately repeat original Page/Worker normal workload with same lab policy after its expired
civil fixture is safely refreshed through actual app operations (no fake auth/epoch clocks/relaxed
freeze). Do not start its original900srun unless real editable-day preflight permits the wholecase.
Then profile publiccold after both baseline cases with named numeric profiling flag, keeping original
15sgate and any later observation diagnostic-only. Higher productionrate remains out of scope until
fairness testing/operatordecision; earlier32candidate failed fairness. No releaseprep/commit/push/
deploy/preview/serviceautomation/CUA/phone/realdata. Preserve all prior patches/raw failures.

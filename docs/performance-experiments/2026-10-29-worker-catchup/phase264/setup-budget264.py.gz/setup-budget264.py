from pathlib import Path
import shutil,json,hashlib,subprocess,difflib
m=Path(__file__).parent;old=Path('/private/tmp/done-production-native-compatibility-20261030');r=Path('/private/tmp/done-session-budget-probe-20261030');repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');r.mkdir();sha=lambda b:hashlib.sha256(b).hexdigest()
source=old/'source-after';shutil.copytree(source,r/'source-server',symlinks=True)
(r/'source-after').symlink_to(source.resolve(),target_is_directory=True);(r/'source-R').symlink_to(r/'source-after',target_is_directory=True)
for name in ['combined-dist','lab','test-inputs','private-fixture']:(r/name).symlink_to((old/name).resolve(),target_is_directory=True)
(r/'node_modules').symlink_to(repo/'node_modules',target_is_directory=True)
shutil.copytree(old/'harness',r/'harness',symlinks=True,ignore=shutil.ignore_patterns('node_modules','test-results','artifacts'));(r/'harness/node_modules').symlink_to(repo/'node_modules',target_is_directory=True)
for f in(r/'harness').rglob('*'):
 if f.is_file()and not f.is_symlink()and f.suffix in ['.mjs','.ts','.json']:f.write_bytes(f.read_bytes().replace(str(old).encode(),str(r).encode()))
p=r/'harness/test/account-continuation-lab/runtime.mjs';s=p.read_text();s=s.replace("source='"+str(r/'source-after')+"'","source='"+str(r/'source-server')+"'");p.write_text(s)
for n in ['container-image.json','container-service.mjs','observer.mjs','build-identity.json','build.mjs','build-flags.json','release-flags.json','run.py','smoke.mjs']:(r/n).write_bytes((old/n).read_bytes().replace(str(old).encode(),str(r).encode()))
p=r/'source-server/account-service/requestBudget.ts';original=p.read_text();assert original.count('sessionPerSecond: 16,')==1;p.write_text(original.replace('sessionPerSecond: 16,','sessionPerSecond: 64,'));assert (repo/'account-service/requestBudget.ts').read_bytes()==original.encode()
(r/'lab-budget.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),p.read_text().splitlines(True),fromfile='a/account-service/requestBudget.ts',tofile='b/account-service/requestBudget.ts')))
# Numeric startup receipt proves the module actually used by the service, no in-flight instrumentation.
p=r/'container-service.mjs';s=p.read_text();s="import {REQUEST_LIMITS} from '/app/account-service/requestBudget.ts';\n"+s;s=s.replace('node:process.version,cgroup:cg()', 'node:process.version,requestLimits:REQUEST_LIMITS,cgroup:cg()');p.write_text(s)
manifest=json.loads((old/'source-inputs.json').read_text());changed=[]
for n,h in manifest['files'].items():
 actual=sha((r/'source-server'/n).read_bytes())
 if h!=actual:changed.append(n)
assert changed==['account-service/requestBudget.ts'];assert p.is_file();(r/'source-change.json').write_text(json.dumps({'baseCommit':manifest['commit'],'changes':changed,'onlySemanticChange':{'sessionPerSecond':[16,64]},'allOtherServerFilesExact':True,'clientSourceUnchanged':True,'assets':'exact260 productionflag build; no client rebuild','originalFailure':'261 actor1 progress447/30s','productionFileSha256':sha(original.encode()),'labFileSha256':sha((r/'source-server/account-service/requestBudget.ts').read_bytes())},indent=2)+'\n')
# New closed input inventory; original case body/deadline is only root-relocated.
expected=(old/'harness/test/account-continuation-lab/worker-owner.spec.ts').read_bytes().replace(str(old).encode(),str(r).encode());assert expected==(r/'harness/test/account-continuation-lab/worker-owner.spec.ts').read_bytes()
files=[f for f in(r/'harness').rglob('*')if f.is_file()and not f.is_symlink()and'node_modules'not in f.parts];files +=[r/n for n in ['container-image.json','container-service.mjs','observer.mjs','source-change.json','lab-budget.patch','build-identity.json','build-flags.json','release-flags.json']];files +=[r/'source-server'/n for n in manifest['files']];(r/'frozen-inputs.json').write_text(json.dumps({str(f.relative_to(r)):sha(f.read_bytes())for f in files},indent=2)+'\n')
print('Original deepjoined body/assets reused; one lab policy value changed16→64; production unchanged')

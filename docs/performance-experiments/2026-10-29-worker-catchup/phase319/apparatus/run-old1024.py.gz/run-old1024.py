from pathlib import Path
import json,subprocess,time,sys,os,signal,hashlib,datetime
r=Path(__file__).parent;node='/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();dist=Path('/private/tmp/done-civil-fixture-20261030-r1/dist');out=r/'old1024-cohort-generation';out.mkdir(mode=0o700,exist_ok=False);assert not(r/'STOP.json').exists();assert json.loads((r/'private-fixture/fixture.json').read_text())['accounts'][0]['date']==datetime.datetime.now(datetime.timezone.utc).date().isoformat()
inputs={'producerDist':str(dist),'producerFiles':{str(p.relative_to(dist)):sha(p)for p in dist.rglob('*')if p.is_file()},'fixtureSha256':sha(r/'private-fixture/fixture.json'),'apparatus':{str(p.relative_to(r)):sha(p)for p in(r/'harness/test/account-continuation-lab').rglob('*')if p.is_file()},'scope':'Recreate original legacy single-entry1024 caught-up H2 fixture on current civil date. Old seed-only auto-off/range-off producer is apparatus, not candidate and no timing credit. No conversion/relabeling.'};(r/'old1024-cohort-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
env={k:v for k,v in os.environ.items()if not k.startswith(('FAIR_','RANGE_LAB_','STALL_'))};env.update({'PATH':str(Path(node).parent)+':'+env['PATH'],'FAIR_OUT':str(out),'FAIR_DIST':str(dist),'FAIR_LAB_BITS':'10000','FAIR_SY_BITS':'00','FAIR_REPAIR_MS':'1000','QUIET_WITHHOLD':'0','FAIR_IDLE_PAUSE':'0','FAIR_PREP_HIDDEN':'0','CHROMIUM_PATH':'/private/tmp/done-civil-gates-browser-20261030/Chrome.app/Contents/MacOS/Google Chrome'});cmd=[node,'node_modules/@playwright/test/cli.js','test','--config','test/account-continuation-lab/old1024-cohort.config.ts'];load=out/'host-load.jsonl';sampler=subprocess.Popen([sys.executable,str(r/'host_load.py'),'--out',str(load)]);start=time.time()
try:
 for i in range(500):
  if Path(str(load)+'.ready').exists():break
  if sampler.poll()is not None:raise RuntimeError('Sampler failed')
  time.sleep(.01)
 else:raise RuntimeError('Sampler not ready')
 print('START old1024 fixture apparatus',flush=True)
 with(out/'console.log').open('w')as f:p=subprocess.run(cmd,cwd=r/'harness',env=env,stdout=f,stderr=subprocess.STDOUT)
finally:sampler.send_signal(signal.SIGTERM);sampler.wait(timeout=10)
x=json.loads((out/'result.json').read_text())if(out/'result.json').exists()else{};row={'command':cmd,'childExit':p.returncode,'startedAt':start,'finishedAt':time.time(),'outcome':x.get('outcome'),'error':x.get('error'),'fixture':x.get('fixturePath'),'labOnly':True,'acceptanceCredit':False};(out/'receipt.json').write_text(json.dumps(row,indent=2)+'\n');(r/'old1024-cohort-results.json').write_text(json.dumps([row],indent=2)+'\n');print(json.dumps(row),flush=True)
if x.get('coldFailure'):(r/'STOP.json').write_text(json.dumps(row,indent=2)+'\n');sys.exit(3)
sys.exit(p.returncode)

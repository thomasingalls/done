from pathlib import Path
import json, subprocess, sys, hashlib, statistics
lab_root = Path(__file__).parent
rows = json.loads((lab_root / 'final-gates-results.json').read_text())
output = []
node = '/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node'
for row in rows:
    folder = lab_root / row['name']
    command = None
    if row.get('mode') and not row.get('grown'):
        command = [sys.executable, str(lab_root / 'analyze-case.py'), json.dumps({'name': row['name'], 'variant': 'C', 'mode': row['mode'], 'withhold': row.get('withhold', False)})]
    elif row['cell'] == 'fairness':
        command = [sys.executable, str(lab_root / 'analyze-fairness.py'), str(folder)]
    elif row['cell'].startswith('goals'):
        command = [sys.executable, '/private/tmp/done-goals-stall-20261028/analyze.py', str(folder)]
    analysis_exit = None
    if command:
        with (folder / 'analysis.log').open('w') as stream:
            result = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT)
        analysis_exit = result.returncode
    path = folder / 'analysis.json'
    analysis = json.loads(path.read_text()) if path.exists() else None
    record = {**row, 'analysisExit': analysis_exit, 'functionalPass': row['childExit'] == 0, 'qualification': 'Lab only, no acceptance credit. One failed replicate fails its cell; every run retained.'}
    try:
        if row.get('grown'):
            record['separateGrownReport'] = 'final-grown-analysis.json'
        elif row.get('mode'):
            assert analysis is not None, 'Original analyzer did not reach a complete result; see retained failure log'
            record.update(inputP95ms=analysis['localUpperMs']['p95'], peerP95ms=analysis['peerUpperMs']['p95'], worstMarkerMs=max(analysis['markerPeerUpperMs']), backlogMs=analysis['backlogMs'], keysDuringBacklog=analysis.get('keysDuringBacklog'), originalGates=analysis['gates'], failedPredicates=[k for k,v in analysis['gates'].items() if not v], allOriginalPredicates=all(analysis['gates'].values()) and row['childExit'] == 0)
        elif row['cell'] == 'fairness':
            assert analysis is not None
            value = analysis['runs'][0]
            record.update(inputP95ms=value['localMs']['p95'], peerP95ms=value['peerObservedSubsetMs'].get('p95'), originalGates=value['gates'], failedPredicates=[k for k,v in value['gates'].items() if not v], allOriginalPredicates=value['primaryAcceptance'] and row['childExit'] == 0)
        elif row['cell'].startswith('goals'):
            assert analysis is not None
            record.update(allOriginalPredicates=analysis_exit == 0 and row['childExit'] == 0, paragraphBeforeinputP95ms=analysis['offerToBeforeinputUpperMs'].get('p95'), paragraphRafP95ms=analysis['offerToRafUpperMs'].get('p95'), paragraphRafMaxMs=analysis['offerToRafUpperMs'].get('max'), paragraphRafOver100ms=analysis['offerToRafUpperMs'].get('over100ms'), denominator=analysis['inputDenominator'], dataGuards=analysis['guards'], qualification='Original Goals diagnostic; its key-to-rAF is not the existing16ms mutation gate or peer gate. Lab only, no credit.')
        else:
            assert len(row['rawResults']) == 1, 'Expected one selected native journey'
            raw = json.loads((folder / row['rawResults'][0]['path']).read_text())
            record.update(allOriginalPredicates=row['childExit'] == 0 and raw['outcome'] == 'passed' and all(raw['guards'].values()), nativeGuards=raw['guards'], deepMs=raw.get('catchupWaitMs'))
    except Exception as error:
        record.update(analysisError=repr(error), allOriginalPredicates=False)
    samples = [json.loads(line) for line in (folder / 'host-load.jsonl').read_text().splitlines()]
    busy = [100-x['hostPercent']['idle'] for x in samples if x.get('kind') == 'load']
    record['hostBusyMedian'] = statistics.median(busy) if busy else None
    record['hostBusyMax'] = max(busy) if busy else None
    output.append(record)
# The richer grown analyzer preserves per-owner timings even when a functional predicate fails.
grown = [row for row in rows if row.get('grown')]
(lab_root / 'final-grown-results.json').write_text(json.dumps(grown, indent=2)+'\n')
if grown:
    with (lab_root / 'final-grown-analysis-console.log').open('w') as stream:
        result = subprocess.run([sys.executable, str(lab_root / 'analyze-final-grown.py')], stdout=stream, stderr=subprocess.STDOUT)
    assert result.returncode == 0, 'Grown analysis failed; raw runs retained'
    detailed = {x['name']: x for x in json.loads((lab_root / 'final-grown-analysis.json').read_text())}
    for record in output:
        if not record.get('grown'):
            continue
        value = detailed[record['name']]
        gates = value['gatePredicates']
        record.update(inputP95ms=value.get('inputP95Ms'), peerP95ms=value.get('peerP95Ms'), worstMarkerMs=value.get('peerWorstMarkerMs'), backlogMs=value.get('backlogMs'), keysDuringBacklog=value.get('overlapKeys'), originalGates=gates, failedPredicates=[k for k,v in gates.items() if not v], allOriginalPredicates=all(gates.values()) and record['functionalPass'], ownerMaintenance=value['owners'])
(lab_root / 'final-gates-analysis.json').write_text(json.dumps(output, indent=2)+'\n')
cells = {}
for key in dict.fromkeys(row['cell'] for row in rows):
    runs = [x for x in output if x['cell'] == key]
    cells[key] = {'runs': [x['name'] for x in runs], 'replicatesReached': len(runs), 'threeReplicatesComplete': len(runs) == 3, 'cellPass': len(runs) == 3 and all(x['allOriginalPredicates'] for x in runs), 'failedRuns': [x['name'] for x in runs if not x['allOriginalPredicates']], 'grownReportedSeparately': bool(runs[0].get('grown')), 'acceptanceCredit': False}
(lab_root / 'final-gates-cells.json').write_text(json.dumps(cells, indent=2)+'\n')
for record in output:
    print(json.dumps({k:record.get(k) for k in ['name','cell','childExit','allOriginalPredicates','inputP95ms','peerP95ms','worstMarkerMs','keysDuringBacklog','failedPredicates','analysisError','hostBusyMedian','hostBusyMax']}))
print('Reached', len(rows), 'of36 declared journeys; passing cells', sum(x['cellPass'] for x in cells.values()))

from pathlib import Path
import shutil,ast
r=Path(__file__).parent;d=r/'harness/test/account-continuation-lab'
tree=ast.parse((r/'prepare-native-cold-observer.py').read_text());helper=ast.literal_eval(next(n.value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='helper'for t in n.targets)))
# This script is not invoked until the active matrix has closed.
for name in ['stall.spec.ts','continuation.spec.ts']:
 p=d/name;s=p.read_text();assert 'observedCold('not in s;shutil.copy2(p,r/('before-cold-observation-'+name));s="import {observedCold} from './cold-observer';\n"+s
 if name=='stall.spec.ts':
  old="await lock(p);await p.reload();await openSaved(p,saved.code,true);expect(await exported(p)).toEqual(archive);result.guards.lockReopenExact=true;"
  assert old in s;s=s.replace(old,"await observedCold(result,'goals-lock-reopen',async()=>{"+old+"});")
 else:
  lines=s.splitlines();changes=[]
  for i,line in enumerate(lines):
   if line.strip().startswith('const reopened=')and 'offlineColdWriterReopen='in line:
    lines[i]="  await observedCold(result,'fairness-writer-profile',async()=>{"+line+"});";changes.append('writer')
   elif line.strip().startswith('await lock(peer.page);')and'result.closedPeerProfile='in line:
    lines[i]="  await observedCold(result,'fairness-peer-profile',async()=>{"+line+"});";changes.append('peer')
  assert changes==['writer','peer'],changes;s='\n'.join(lines)+'\n'
 p.write_text(s)
helper=helper.replace('async function observedCold','export async function observedCold')
# The literal used by the native preparer carries an escaped newline in its Python source.
(d/'cold-observer.ts').write_text("import {appendFileSync} from 'node:fs';\n"+helper)
print('Added fairness and Goals cold-stage observations only')

import ts from './harness/node_modules/typescript/lib/typescript.js';
import fs from 'node:fs';
import crypto from 'node:crypto';
const root = new URL('.', import.meta.url).pathname;
const pairs = [
 ['gate-native-before-cold-observer.spec.ts', 'harness/test/account-continuation-lab/gate-native.spec.ts'],
 ['before-cold-observation-stall.spec.ts', 'harness/test/account-continuation-lab/stall.spec.ts'],
 ['before-cold-observation-continuation.spec.ts', 'harness/test/account-continuation-lab/continuation.spec.ts'],
 ['gate-maintenance-before-explicit-old-fixture.spec.ts', 'harness/test/account-continuation-lab/gate-maintenance.spec.ts'],
];
const printer=ts.createPrinter({removeComments:true});
function inspect(name) {
 const bytes=fs.readFileSync(root+name,'utf8');
 const file=ts.createSourceFile(name,bytes,ts.ScriptTarget.Latest,true,ts.ScriptKind.TS);
 if(file.parseDiagnostics.length) throw Error(name+': '+file.parseDiagnostics.map(x=>ts.flattenDiagnosticMessageText(x.messageText,' ')).join('; '));
 const assertions=[],tests=[],waits=[];
 function visit(node) {
  if(ts.isCallExpression(node)) {
   const expression=printer.printNode(ts.EmitHint.Unspecified,node.expression,file);
   if(expression==='expect'||expression.startsWith('expect(')||expression.startsWith('expect.')||expression.includes('.expect(')) assertions.push(printer.printNode(ts.EmitHint.Unspecified,node,file));
   if(expression==='test') tests.push(printer.printNode(ts.EmitHint.Unspecified,node.arguments[0],file));
   if(/waitForFunction|waitForTimeout|expect\.poll|setTimeout/.test(expression)) waits.push(printer.printNode(ts.EmitHint.Unspecified,node,file));
  }
  ts.forEachChild(node,visit);
 }
 visit(file);
 return {assertions,tests,waits,sha256:crypto.createHash('sha256').update(bytes).digest('hex')};
}
const reports=[];
for(const [before,after] of pairs) {
 const a=inspect(before),b=inspect(after);
 for(const key of ['assertions','tests','waits']) if(JSON.stringify(a[key])!==JSON.stringify(b[key])) throw Error(after+': changed '+key);
 reports.push({before,after,beforeSha256:a.sha256,afterSha256:b.sha256,assertions:a.assertions.length,testNames:a.tests,waits:a.waits.length,allExact:true});
}
inspect('harness/test/account-continuation-lab/cold-observer.ts');
fs.writeFileSync(root+'final-observer-ast-check.json',JSON.stringify({reports,parser:'TypeScript independent AST/printer comparison',oldAssertionsTestNamesAndWaitsExact:true},null,2)+'\n');
console.log(JSON.stringify(reports.map(x=>({after:x.after,assertions:x.assertions,waits:x.waits,allExact:x.allExact})),null,2));

from pathlib import Path
import json,datetime
lab_root = Path(__file__).parent
old_plan = json.loads(Path('/private/tmp/done-range-vgr-lab-20261030/gate-plan.json').read_text())
plan=[]
for replicate in [1,2,3]:
    for old_case in [x for x in old_plan if x['replicate']==replicate]:
        case={**old_case,'name':'final-'+old_case['name'],'bits':'10101','SY':'11','repairMs':1000,'variant':'C','labOnly':True,'acceptanceCredit':False,'oneFailFailsCell':True}
        if case['cell'].startswith('old-maintenance'):
            case['fixture']=str(lab_root/'old1024-fixture/fixture.json')
        plan.append(case)
    doses=[False,True] if replicate!=2 else [True,False]
    for withhold in doses:
        label='withheld' if withhold else 'normal'
        plan.append({'name':f'final-grown-r{replicate}-{label}','config':'grown-maintenance.config.ts','cell':'grown-'+label,'mode':'maintenance','grown':True,'replicate':replicate,'withhold':withhold,'fixture':str(lab_root/'cohort-P1/fixture.json'),'bits':'10101','SY':'11','repairMs':1000,'variant':'P-screen','timeoutMs':900000,'labOnly':True,'acceptanceCredit':False,'oneFailFailsCell':True})
assert len(plan)==36
(lab_root/'final-gates-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
(lab_root/'FINAL-GATES-PROTOCOL.md').write_text('''# Frozen lab challenge declaration

Declared at '''+datetime.datetime.now(datetime.timezone.utc).isoformat()+''', before the first gate run. All36exact journeys/order/config/grep/fixture are in final-gates-plan.json: ten original cells ×3, plus grown normal/withheld ×3each, reported separately. One failed replicate fails the cell; every run retained, no rerun-to-green. Lab only, no acceptance credit. G8/R1000/S1Y1/P1,V0,D0, networkrange4,quiet750. Same313application/build, no rebuild. Range writer defaultoff outside lab, v2development-only, serviceautomationoff, Fnever,Vcomparisononly,Creserve.

All original gates and deadlines remain:16ms input,2500ms peer/every marker,30s native deep,600s backlog, original cold checks,120s writer maintenance completion and >=60overlap keys. The original old-maintenance1024fixture is reconstructed on current civil date using the old single-entry/auto-off/range-off producer; the grown2048P1writer cohort is separate. Native/Goals retain their original prepared-v5 fixture because those gates require that predecessor; their document is not a civil-day editor workload. No blanket fixture refresh. Original maintenance-withheld retains the historical153backlog+10% numeric predicate and its unmatched-current-civil qualification.

Each run uses a fresh fake server state/profile and pinned Chrome156, unchanged1CPU/1GiBserver/rate/fairness budgets. External hostCPU and top executable names every5s. No concurrent build/analysis/freezer. STALL_PROFILE0 and correct STALL_MOBILE; Goals key-to-rAF remains diagnostic, not the mutation16ms gate. Host is not isolated: Firefox/WindowServer remain accepted, all activity retained.

Observation-only changes add durable start/end/exact/failure markers around actual native/fairness/Goals cold checks, plus an explicit old-maintenance fixture override. Independent Babel TypeScript AST comparison confirms all prior assertions/test names/waits unchanged. Config timeouts unchanged. Runner scans result and cold-stage files at both depths; an actual no-F cold failure stops immediately and later declared cells are withheld. Other errors/missing exposure/timeouts/capacity remain visible and later cells continue. No unattempted cold is a pass.

Every grown owner separately reports attempts/completion, map families and durable bytes, capacity, interruption condition/job, priority versus other scheduled retry delay, and actual/censored time to next attempt. Keep original writer-only120s wait; reader completion is a diagnostic, not a substituted gate. New starts during typing and reader drain are checked. R1000has no previous full maintenance window; do not attribute its wall time to verifying alone.

After all reached cells, original analyzers retain their exact contracts. Failed analysis is reported with raw evidence, never converted to pass. Missing metrics fail/not measured. Three repetitions are independent journeys, not independent per-key samples. Publication, source hardening, operator format choices and landing controls are out of scope.
''')
print('Declared36journeys in exact order; no gate has started')

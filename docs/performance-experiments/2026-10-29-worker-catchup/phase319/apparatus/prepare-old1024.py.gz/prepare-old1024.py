from pathlib import Path
import shutil
r=Path(__file__).parent
p=r/'harness/test/account-continuation-lab/dense-cohort.spec.ts'
s=p.read_text().replace("test('grow paired real 2048 reader cohort through selected receipt writer'", "test('recreate original single-entry 1024 writer fixture on current civil date'")
s=s.replace("root+'/prepared-fixture/fixture.json'", "root+'/private-fixture/fixture.json'").replace('expect(account.backlog).toBe(2048)', 'expect(account.backlog).toBe(1024)').replace("const folder=root+'/cohort-P'+Number(P)", "const folder=root+'/old1024-fixture'")
(r/'harness/test/account-continuation-lab/old1024-cohort.spec.ts').write_text(s)
c=(r/'harness/test/account-continuation-lab/dense-cohort.config.ts').read_text().replace('dense-cohort.spec.ts','old1024-cohort.spec.ts')
(r/'harness/test/account-continuation-lab/old1024-cohort.config.ts').write_text(c)
print('Created old1024 fixture apparatus; no assertion, timeout or admission shortcut')

import {parse} from '/Users/thomasingalls/.codex/worktrees/7fda/done/node_modules/.pnpm/@babel+parser@7.29.7/node_modules/@babel/parser/lib/index.js';
import fs from 'node:fs';
import crypto from 'node:crypto';
const root = new URL('.', import.meta.url).pathname;
const pairs = [
 ['gate-native-before-cold-observer.spec.ts', 'harness/test/account-continuation-lab/gate-native.spec.ts'],
 ['before-cold-observation-stall.spec.ts', 'harness/test/account-continuation-lab/stall.spec.ts'],
 ['before-cold-observation-continuation.spec.ts', 'harness/test/account-continuation-lab/continuation.spec.ts'],
 ['gate-maintenance-before-explicit-old-fixture.spec.ts', 'harness/test/account-continuation-lab/gate-maintenance.spec.ts'],
];
function clean(value) {
 if (Array.isArray(value)) return value.map(clean);
 if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).filter(([k])=>!['start','end','loc','extra','comments','leadingComments','trailingComments','innerComments','tokens'].includes(k)).map(([k,v])=>[k,clean(v)]));
 return value;
}
function chainRoot(node) {
 if (node?.type==='Identifier') return node.name;
 if (node?.type==='CallExpression'||node?.type==='OptionalCallExpression') return chainRoot(node.callee);
 if (node?.type==='MemberExpression'||node?.type==='OptionalMemberExpression') return chainRoot(node.object);
 return null;
}
function inspect(name) {
 const bytes=fs.readFileSync(root+name,'utf8');
 const file=parse(bytes,{sourceType:'module',plugins:['typescript']});
 const assertions=[],tests=[],waits=[];
 function visit(node) {
  if (!node || typeof node !== 'object') return;
  if (Array.isArray(node)) { node.forEach(visit); return; }
  if (node.type==='CallExpression') {
   if (chainRoot(node.callee)==='expect') assertions.push(clean(node));
   if (node.callee.type==='Identifier'&&node.callee.name==='test') tests.push(clean(node.arguments[0]));
   const callee=bytes.slice(node.callee.start,node.callee.end);
   if (/waitForFunction|waitForTimeout|expect\.poll|setTimeout/.test(callee)) waits.push(clean(node));
  }
  for (const [key,value] of Object.entries(node)) if (!['loc','tokens','comments'].includes(key)) visit(value);
 }
 visit(file);
 return {assertions,tests,waits,sha256:crypto.createHash('sha256').update(bytes).digest('hex')};
}
const reports=[];
for (const [before,after] of pairs) {
 const a=inspect(before),b=inspect(after);
 for (const key of ['assertions','tests','waits']) if(JSON.stringify(a[key])!==JSON.stringify(b[key])) throw Error(after+': changed '+key);
 reports.push({before,after,beforeSha256:a.sha256,afterSha256:b.sha256,assertions:a.assertions.length,testNames:a.tests,waits:a.waits.length,allExact:true});
}
inspect('harness/test/account-continuation-lab/cold-observer.ts');
fs.writeFileSync(root+'final-observer-ast-check.json',JSON.stringify({reports,parser:'Independent Babel7 TypeScript AST, location/format metadata removed',oldAssertionsTestNamesAndWaitsExact:true},null,2)+'\n');
console.log(JSON.stringify(reports.map(x=>({after:x.after,assertions:x.assertions,waits:x.waits,allExact:x.allExact})),null,2));

# Invoke only before final-gate declarations, never during a matrix that froze this harness.
from pathlib import Path
import shutil
r=Path(__file__).parent;p=r/'harness/test/account-continuation-lab/gate-native.spec.ts';v=p.read_text();assert 'async function observedCold'not in v;shutil.copy2(p,r/'gate-native-before-cold-observer.spec.ts')
helper="""
async function observedCold(r:any,label:string,work:()=>Promise<any>){
 const file=process.env['FAIR_OUT']+'/cold-stages.jsonl',stage={label,at:Date.now()};r.coldAttemptStarted=true;r.coldAllAttemptedExact=false;r.coldStage=label;appendFileSync(file,JSON.stringify({kind:'start',...stage})+'\\n');
 try{const value=await work();r.coldAllAttemptedExact=true;(r.coldStages??=[]).push({label,exact:true});appendFileSync(file,JSON.stringify({kind:'end',label,at:Date.now(),exact:true})+'\\n');return value;}
 catch(error){r.coldFailure=true;appendFileSync(file,JSON.stringify({kind:'end',label,at:Date.now(),exact:false})+'\\n');throw error;}
 finally{r.coldStage=null;}
}
"""
v="import {appendFileSync} from 'node:fs';\n"+v
at=v.index("const root=");v=v[:at]+helper+v[at:]
lines=v.splitlines();changes=[]
for i,line in enumerate(lines):
 if line.startswith('async function shipping('):
  a=line.index('{')+1;b=line.rfind('}');lines[i]=line[:a]+"return observedCold(r,'public-shipping',async()=>{"+line[a:b]+"});"+line[b:];changes.append('shipping')
 elif '__mirrorLab.createPublisher' in line and 'r.guards.originalAccountReaderColdExact=true;'in line:
  a=line.index('await p.evaluate');b=line.index('r.guards.originalAccountReaderColdExact=true;')+len('r.guards.originalAccountReaderColdExact=true;');lines[i]=line[:a]+"await observedCold(r,'original-account-reader',async()=>{"+line[a:b]+"});"+line[b:];changes.append('original-account-reader')
 elif "await opening(p,'composed');r.guards.savedSliceColdReopened=true;"in line:
  lines[i]=line.replace("await opening(p,'composed');r.guards.savedSliceColdReopened=true;","await observedCold(r,'saved-slice-reopen',async()=>{await opening(p,'composed');});r.guards.savedSliceColdReopened=true;");changes.append('saved-slice')
assert 'shipping'in changes and'original-account-reader'in changes and'saved-slice'in changes,changes
p.write_text('\n'.join(lines)+'\n');(r/'native-cold-observer-changes.txt').write_text('\n'.join(changes)+'\n');print('Added cold-stage observation only',changes)

from pathlib import Path
import json,gzip,hashlib,re
r=Path(__file__).parent;repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');p=repo/'docs/performance-experiments/2026-10-29-worker-catchup/phase244';p.mkdir();names=['run-marker.py','marker-run.log','analyze-marker.py','classify-marker-failure.py','marker-failure.json','244-cleanup.json','packet244.py'];names+=['05-marker-diagnostic/'+n for n in ['result.json','partial-result.json','console.log','runner-receipt.json','container-identity.json','docker-command.json','services.log']];ids={}
for name in names:
 b=(r/name).read_bytes();ids[name]=hashlib.sha256(b).hexdigest();b=re.sub(rb'(?<![A-Z0-9])[A-Z0-9]{5}(?:-[A-Z0-9]{5}){4}(?![A-Z0-9])',b'[disposable code redacted]',b);d=p/(name+'.gz');d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(gzip.compress(b,mtime=0))
(p/'inputs.json').write_text(json.dumps(ids,indent=2)+'\n');(p/'README.md').write_text('''# Phase244 — retain the invalid midnight diagnostic

2026-10-30. The one phase243 diagnostic failed its original30s final-delivery assertion.
Both original backlog checks completed, but archive/cold guards were not reached: no credit.
The fixture day2026-10-27 was two days old at reconnect23:57:32 Europe/Paris Oct29 and three
days old at attempted late marker00:01:52 Oct30. Actual freeze.ts policy freezes at three days;
the original assertion error observes data-frozen=true. No writer submission follows that late
keyboard attempt; all observed HTTP statuses are200 or absent. Do not treat a key sent to a
frozen card as admitted writing, or this as proof of an authority/network refusal.

The collector was incorrectly after the failed assertion, so owner events and final DOM probes
were lost. Preserve that diagnostic-machinery failure. Exact container absent. No retry erased
this trajectory; no relaxed deadline/guard. Raw result/logs, actual timestamps and classification
script retained; no profiles/state/factors or error-context artifacts copied into the repository.
No unmodified performance result is superseded and2.5s acceptance remains blocked.

A separate corrected diagnostic may use civil timezoneUTC while actual date is still Oct29:
this restores the original valid fixture's effective age, without faking Date.now, authentication
expiry or any protocol clock. Add explicit editable/freeze guards before marker input and collect
in finally even on a failing assertion. This is an apparatus correction, not a favorable performance
rerun or a product repair. No release preparation or deployment.
''')
for name,text in [('decisions.md','Classify midnight diagnostic invalid: actual three-day freeze crossed during run, frozen DOM observed, late attempt never submitted. Preserve original30s failure and lost post-assertion trace; no security bypass or performance credit. Correct civil-calendar apparatus and failure-safe capture separately.'),('completed.md','Phase243 diagnostic fails original30s final-delivery; both backlog checks complete but archive/cold not reached. Observed frozen card after real midnight explains calendar-invalid fixture; detailed collector was after failed assertion and lost events. Exact container absent. Failure and limitations retained.'),('product-backlog.md','Phase244: original matched latency misses remain. Detailed attribution pending corrected civil-date fixture and finally-safe trace collector; do not infer upload/authority failure from a keyboard attempt against a frozen card.')]:
 with(repo/'docs'/name).open('a')as f:f.write('\n\n## 2026-10-30 — phase244: invalid midnight diagnostic retained\n\n'+text+' [Evidence](performance-experiments/2026-10-29-worker-catchup/phase244/README.md).\n')

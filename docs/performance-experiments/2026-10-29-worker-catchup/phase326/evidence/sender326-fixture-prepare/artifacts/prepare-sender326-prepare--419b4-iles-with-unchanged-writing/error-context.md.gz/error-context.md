# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: prepare-sender326.spec.ts >> prepare genuinely caught-up sender profiles with unchanged writing
- Location: test/account-continuation-lab/prepare-sender326.spec.ts:5:1

# Error details

```
Error: ENOENT: no such file or directory, open 'cohort-winning/fixture.json'
```

# Test source

```ts
  1  | import{test,expect,chromium}from'@playwright/test';
  2  | import{readFileSync,writeFileSync,mkdirSync,cpSync}from'node:fs';import{join}from'node:path';
  3  | import{configureLabContext}from'../../../lab-context.mjs';import{root,card,exported,archiveIdentity,lock}from'./common';import{start,stop,control}from'./runtime.mjs';import{seedProfile}from'./seed-profile';import{restoreAuthenticator,openSaved,credentials}from'./devices';import{captureLab}from'./capture-lab';
  4  | const out=process.env.FAIR_OUT!;
  5  | test('prepare genuinely caught-up sender profiles with unchanged writing',async()=>{
> 6  |  const fixture=JSON.parse(readFileSync(process.env.FAIR_FIXTURE!,'utf8')),account=fixture.accounts.find((a:any)=>a.label==='H'),contexts:any[]=[],result:any={outcome:'starting',apparatusOnly:true,labOnly:true,acceptanceCredit:false,guards:{},owners:[]};
     |                           ^ Error: ENOENT: no such file or directory, open 'cohort-winning/fixture.json'
  7  |  try{const state=join(out,'state');cpSync(fixture.state,state,{recursive:true,errorOnExist:true});await start(state,process.env.FAIR_DIST!);await control('start');
  8  |  for(const index of[1,2]){const saved=account.actors[index],profile=join(out,'private-profile-H'+index),ctx=await configureLabContext(await chromium.launchPersistentContext(profile,{executablePath:process.env.CHROMIUM_PATH!,baseURL:'http://localhost:53781',viewport:{width:1440,height:1000},timezoneId:'UTC',headless:true}));contexts.push(ctx);await seedProfile(ctx,saved.storage);const p=ctx.pages()[0]??await ctx.newPage(),auth=await restoreAuthenticator(p,saved.credentials);await p.goto('/');await p.evaluate(()=>navigator.serviceWorker.ready);await p.reload();await p.waitForFunction(()=>!!navigator.serviceWorker.controller);await openSaved(p,saved.code,true);await p.getByLabel('Go to date',{exact:true}).fill(account.date);await expect(card(p,'H')).toContainText(account.expected,{timeout:600000});expect(await exported(p)).toEqual(account.archive);result.owners.push({index,profile,drainedAt:Date.now()});(ctx as any).__owner={index,p,auth,saved};}
  9  |  await Promise.all(contexts.map(async ctx=>{const {p,index}=ctx.__owner,entry=result.owners.find((a:any)=>a.index===index);entry.waitStartedAt=Date.now();try{await p.waitForFunction(()=>{const r=(window as any).__maintenanceRead?.();return r?.diagnostics.completions>=1||r?.status.phase==='halted';},undefined,{timeout:120000});entry.maintenance=await p.evaluate(()=>(window as any).__maintenanceRead?.());}catch(error){entry.maintenanceWaitError=String(error);}entry.waitEndedAt=Date.now();entry.lab=await captureLab(p);expect(await exported(p)).toEqual(account.archive);}));
  10 |  for(const ctx of contexts){const {p,index,auth,saved}=ctx.__owner;await lock(p);account.actors[index]={...saved,storage:await ctx.storageState({indexedDB:true}),credentials:await credentials(auth)};await ctx.close();}contexts.length=0;result.metrics=(await control('end')as any).metrics;await stop();fixture.state=state;const folder=root+'/sender-fixture';mkdirSync(folder,{mode:0o700});writeFileSync(folder+'/fixture.json',JSON.stringify(fixture),{mode:0o600});result.archive=archiveIdentity(account.archive);result.guards.bothFullArchivesExact=true;result.guards.onlyFixtureActorsOneAndTwoRefreshed=true;result.outcome='passed';
  11 |  }catch(error){result.outcome='failed';result.error=String(error);throw error;}finally{await Promise.all(contexts.map(c=>c.close().catch(()=>{})));writeFileSync(join(out,'result.json'),JSON.stringify(result,null,2)+'\n');await stop();}
  12 | });
  13 | 
```
# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: phase321/grown-maintenance.spec.ts >> genuine accumulated local preparation yields to typing while a peer catches up
- Location: test/account-continuation-lab/phase321/grown-maintenance.spec.ts:10:1

# Error details

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 1
Received:    0
```

# Test source

```ts
  1  | import{captureMaintenanceTrace}from'../capture-maintenance-trace';
  2  | import {captureLab} from '../capture-lab';
  3  | import {configureLabContext} from '../../../../lab-context.mjs';
  4  | import {test,expect,chromium,type BrowserContext}from'@playwright/test';
  5  | import{readFileSync,writeFileSync,mkdirSync,cpSync}from'node:fs';import{join}from'node:path';
  6  | import{readRequestInfo}from'../../../../read-request.mjs';import{installNotificationProbe}from'../../../../notification-probe.mjs';
  7  | import{root,card,focus,exported,archiveIdentity,lock,digest}from'../common';import{start,stop,control,resourceStop}from'../runtime.mjs';import{seedProfile}from'../seed-profile';import{restoreAuthenticator,openSaved}from'../devices';import{browserIdentity,clockBrackets}from'../dispatch-probe';
  8  | const out=process.env['FAIR_OUT']!,variant=process.env['FAIR_VARIANT']!,withhold=process.env['QUIET_WITHHOLD']==='1',markers=[' Early peer;',' Mid peer;',' Late peer;'];
  9  | function probe(values:string[]){const now=()=>performance.timeOrigin+performance.now(),state:any={counts:[],markers:values.map(()=>null),events:[]};let previous=-1;const read=()=>{const c=[...document.querySelectorAll('.day-panel[data-active="true"] .card')].find(c=>c.textContent?.includes('Fair H reverse:'));const text=(c?.querySelector('.cm-content')??c?.querySelector('.card-surface'))?.textContent??'';const count=text.split('w').length-1;if(count!==previous){previous=count;state.counts.push({at:now(),count});}values.forEach((v,i)=>{if(state.markers[i]===null&&text.includes(v))state.markers[i]=now();});return count;};new MutationObserver(read).observe(document,{subtree:true,childList:true,characterData:true});addEventListener('beforeinput',(e:Event)=>{if(!(e.target instanceof Element)||!e.target.closest('.card'))return;state.events.push({at:now(),trusted:e.isTrusted,focused:document.hasFocus(),visible:document.visibilityState});},true);(window as any).__late={read:()=>{read();return structuredClone(state)},count:read};}
  10 | test('genuine accumulated local preparation yields to typing while a peer catches up',async()=>{
  11 |  mkdirSync(out,{recursive:true,mode:0o700});const fixture=JSON.parse(readFileSync(process.env['FAIR_FIXTURE']??(root+'/civil31-grown/prepared-fixture/fixture.json'),'utf8')),account=fixture.accounts.find((a:any)=>a.label==='H'),contexts:BrowserContext[]=[];
  12 |  const result:any={variant,withhold,outcome:'starting',roots:[],network:[],offers:[],clocks:[],guards:{},catchups:[]};let hot=0,append='';const save=()=>writeFileSync(join(out,'partial-result.json'),JSON.stringify(result,null,2)+'\n');
  13 |  const open=async(index:number)=>{const saved=account.actors[index],profile=join(out,'private-profile-H'+index),ctx=await configureLabContext(await chromium.launchPersistentContext(profile,{executablePath:process.env['CHROMIUM_PATH']!,baseURL:'http://localhost:53781',viewport:{width:1440,height:1000},timezoneId:'UTC'}), ({executablePath:process.env['CHROMIUM_PATH']!,baseURL:'http://localhost:53781',viewport:{width:1440,height:1000},timezoneId:'UTC'})?.offline === true);contexts.push(ctx);result.roots.push(await browserIdentity(ctx.browser()!));await seedProfile(ctx,saved.storage);const p=ctx.pages()[0]??await ctx.newPage();await p.addInitScript(installNotificationProbe,{withhold:index===1&&withhold});await p.addInitScript(probe,markers);const requests=new Map<any,any>();p.on('request',q=>{const path=new URL(q.url()).pathname;if(!path.startsWith('/account/'))return;const row:any={label:'H'+index,path,at:(performance.timeOrigin + performance.now()),...readRequestInfo(q)};requests.set(q,row);result.network.push(row);});p.on('response',r=>{const row=requests.get(r.request());if(!row)return;row.status=r.status();row.headersAt=(performance.timeOrigin + performance.now());if(index===1&&row.status===200)for(const v of row.reads??[])if(v.after>hot)hot=v.after;});await restoreAuthenticator(p,saved.credentials);await p.goto('/');await p.evaluate(()=>navigator.serviceWorker.ready);await p.reload();await p.waitForFunction(()=>!!navigator.serviceWorker.controller);const bytes=await p.evaluate(async()=>Array.from(new Uint8Array(await(await fetch((await navigator.serviceWorker.ready).active!.scriptURL)).arrayBuffer())));expect(digest(Buffer.from(bytes))).toBe(digest(readFileSync(process.env['FAIR_DIST']!+'/sw.js')));result.roots.at(-1).workerSha256=digest(Buffer.from(bytes));await ctx.setOffline(true);await openSaved(p,saved.code,true);await p.getByLabel('Go to date',{exact:true}).fill(account.date);await expect(card(p,'H',true)).toBeVisible();return{ctx,p,saved,profile,index};};
  14 |  let writer:any,reader:any;
  15 |  try{
  16 |   const state=join(out,'state');cpSync(fixture.state,state,{recursive:true,errorOnExist:true});await start(state,process.env['FAIR_DIST']!);await control('start');reader=await open(1);writer=await open(2);result.serviceAutomationPortPresent=await writer.p.evaluate(()=>!!(window as any).__maintenanceOwner.devices.automaticHistory);expect(result.serviceAutomationPortPresent).toBe(false);expect(await exported(writer.p)).toEqual(account.archive);await expect(card(reader.p,'H')).not.toContainText(account.expected);
  17 |   result.baselines=await Promise.all([reader,writer].map(a=>a.p.evaluate(()=>(window as any).__late.count())));expect(result.baselines[0]).toBe(result.baselines[1]);
  18 |   result.startedAt=(performance.timeOrigin + performance.now());await Promise.all([reader,writer].map(a=>a.ctx.setOffline(false)));
  19 |   const catching=(async()=>{const row:any={label:'H1',startedAt:result.startedAt};result.catchups.push(row);try{await expect(card(reader.p,'H')).toContainText(account.expected,{timeout:600000});row.completedAt=(performance.timeOrigin + performance.now());row.outcome='passed';}catch(error){row.outcome='failed';row.error=String(error);}save();})();
  20 |   await expect.poll(()=>hot,{timeout:30000}).toBeGreaterThanOrEqual(33);
  21 |   await writer.p.waitForFunction((candidate:boolean)=>{const r=(window as any).__maintenanceRead?.();return r?.status.phase==='halted'||(r?.status.phase==='running'&&r.status.progress?.stage==='verifying'&&(!candidate||r.events.some((e:any)=>e.reason==='preparation-saved')));},true,{timeout:90000});
  22 |   result.maintenanceBeforeTyping=await writer.p.evaluate(()=>(window as any).__maintenanceRead());expect(result.maintenanceBeforeTyping.status.phase).toBe('running');expect(result.maintenanceBeforeTyping.status.progress.stage).toBe('verifying');if(true)expect(result.maintenanceBeforeTyping.events.some((e:any)=>e.reason==='preparation-saved')).toBe(true);
  23 |   expect(result.catchups[0].outcome).toBeUndefined();result.guards.actualPreparationAndBacklogAtTypingStart=true;
  24 |   await writer.p.bringToFront();await focus(writer.p,'H',true);result.clocks.push({phase:'before',rows:await Promise.all([reader,writer].map(a=>clockBrackets(a.p)))});result.labBefore=await Promise.all([reader,writer].map(a=>captureLab(a.p)));result.budgetBefore=await control('lab-budget');result.typingStartedAt=(performance.timeOrigin + performance.now());let markerIndex=0;
  25 |   for(let i=0;i<120;i++){const scheduledAt=result.typingStartedAt+i*500;await writer.p.waitForTimeout(Math.max(0,scheduledAt-(performance.timeOrigin + performance.now())));if([0,60,119].includes(i)){const index=markerIndex++;const row:any={kind:'marker',index,at:(performance.timeOrigin + performance.now()),hotCursor:hot};await writer.p.keyboard.insertText(markers[index]!);row.returnedAt=(performance.timeOrigin + performance.now());result.offers.push(row);append+=markers[index];}const row:any={kind:'key',index:i,scheduledAt,at:(performance.timeOrigin + performance.now()),hotCursor:hot};await writer.p.keyboard.press('w');row.returnedAt=(performance.timeOrigin + performance.now());result.offers.push(row);append+='w';}
  26 |   result.typingFinishedAt=(performance.timeOrigin + performance.now());await writer.p.keyboard.press('Escape');await expect.poll(()=>reader.p.evaluate(()=>(window as any).__late.count()),{timeout:30000}).toBe(result.baselines[0]+120);await expect(card(reader.p,'H',true)).toContainText(append,{timeout:30000});result.newDeliveryAt=(performance.timeOrigin + performance.now());result.probes=await Promise.all([reader,writer].map(a=>a.p.evaluate(()=>(window as any).__late.read())));result.notificationFault=await control('lab-withheld-count');result.notifications=[result.notificationFault.notificationFacts.heldReader,result.notificationFault.notificationFacts.other];result.labAfter=await Promise.all([reader,writer].map(a=>captureLab(a.p)));result.budgetAfter=await control('lab-budget');result.clocks.push({phase:'after',rows:await Promise.all([reader,writer].map(a=>clockBrackets(a.p)))});if(withhold)expect(result.notifications[0].withheld).toBeGreaterThan(0);save();
  27 |   await catching;expect(result.catchups[0].outcome).toBe('passed');const archives=await Promise.all([reader,writer].map(a=>exported(a.p)));expect(archives[0]).toEqual(archives[1]);expect(Object.fromEntries(Object.entries(archives[0]!).map(([name,text])=>[name,(text as string).replace(append,'')]))).toEqual(account.archive);result.guards.fullOriginalArchivePlusOnlyOfferedAppend=true;
  28 |   // One fresh edit/undo after measurement must still traverse durable publication and peer receipt.
  29 |   const undo=' Undo safety guard;';await focus(writer.p,'H',true);await writer.p.keyboard.insertText(undo);await expect(card(reader.p,'H',true)).toContainText(undo,{timeout:30000});await writer.p.keyboard.press('ControlOrMeta+z');await expect(card(reader.p,'H',true)).not.toContainText(undo,{timeout:30000});await writer.p.keyboard.press('Escape');result.guards.undoAndPeerConvergence=true;
> 30 |   await writer.p.waitForFunction(()=>{const r=(window as any).__maintenanceRead?.();return r?.diagnostics.completions>=1||r?.status.phase==='halted';},undefined,{timeout:120000});result.maintenanceAfter=await writer.p.evaluate(()=>(window as any).__maintenanceRead());expect(result.maintenanceAfter.diagnostics.completions).toBeGreaterThanOrEqual(1);expect(result.maintenanceAfter.overflow).toBe(0);result.guards.maintenanceFinishesAfterInput=true;
     |                                                                                                                                                                                                                                                                                                                                     ^ Error: expect(received).toBeGreaterThanOrEqual(expected)
  31 |   // Phase321: diagnostic only. The original writer wait/assertions above are unchanged.
  32 |   // The limit is absolute, so time already spent waiting for the writer is not added again.
  33 |   const diagnosticCutoff=result.typingFinishedAt+120000;
  34 |   result.ownerObservation={diagnosticOnly:true,acceptanceCredit:false,cutoffAt:diagnosticCutoff,lastKeyReferenceAt:result.typingFinishedAt,startedAt:performance.timeOrigin+performance.now(),pollMs:1000,samples:[],terminal:{}};
  35 |   const observing=[{role:'reader',actor:reader},{role:'writer',actor:writer}];
  36 |   while(true){
  37 |     const snapshots=await Promise.all(observing.filter(v=>!result.ownerObservation.terminal[v.role]).map(async({role,actor})=>{const observedAt=performance.timeOrigin+performance.now();const status=await actor.p.evaluate(()=>{const v=(window as any).__maintenanceRead?.();return v?{phase:v.status.phase,reason:v.status.reason,stage:v.status.progress?.stage,attempts:v.diagnostics.attempts,interruptions:v.diagnostics.interruptions,completions:v.diagnostics.completions}:null;});return{role,observedAt,sampleReturnedAt:performance.timeOrigin+performance.now(),status};}));
  38 |     for(const sample of snapshots){
  39 |       result.ownerObservation.samples.push(sample);
  40 |       if(sample.status?.completions>=1||sample.status?.phase==='halted')result.ownerObservation.terminal[sample.role]={...sample,kind:sample.status.completions>=1?'completion-observed':'halt-observed'};
  41 |     }
  42 |     const observedNow=performance.timeOrigin+performance.now();
  43 |     if(Object.keys(result.ownerObservation.terminal).length===2||observedNow>=diagnosticCutoff){
  44 |       for(const {role}of observing)if(!result.ownerObservation.terminal[role])result.ownerObservation.terminal[role]={role,kind:'cutoff',observedAt:observedNow};
  45 |       result.ownerObservation.endedAt=observedNow;break;
  46 |     }
  47 |     await new Promise<void>(resolve=>setTimeout(resolve,Math.min(1000,diagnosticCutoff-observedNow)));
  48 |   }
  49 |   save();
  50 |   result.ownerMaintenanceBeforeCold=await Promise.all([reader,writer].map(a=>a.p.evaluate(()=>(window as any).__maintenanceRead?.())));
  51 |   result.maintenanceTraceBeforeCold=await Promise.all([reader,writer].map(a=>captureMaintenanceTrace(a.p)));
  52 |   result.coldAttemptStarted=true;try{for(const a of [reader,writer]){const coldOwner={role:a.index===1?'reader':'writer',startedAt:performance.timeOrigin+performance.now(),outcome:'started',archiveExact:false};(result.ownerCold??=[]).push(coldOwner);save();await a.ctx.setOffline(true);await lock(a.p);await a.ctx.close();const ctx=await configureLabContext(await chromium.launchPersistentContext(a.profile,{executablePath:process.env['CHROMIUM_PATH']!,baseURL:'http://localhost:53781',viewport:{width:1440,height:1000},timezoneId:'UTC',offline:true}), ({executablePath:process.env['CHROMIUM_PATH']!,baseURL:'http://localhost:53781',viewport:{width:1440,height:1000},timezoneId:'UTC',offline:true})?.offline === true);contexts.push(ctx);const p=ctx.pages()[0]??await ctx.newPage();await restoreAuthenticator(p,a.saved.credentials);await p.goto('/');await openSaved(p,a.saved.code,true);await p.getByLabel('Go to date',{exact:true}).fill(account.date);expect(await exported(p)).toEqual(archives[0]);coldOwner.archiveExact=true;await ctx.close();coldOwner.outcome='passed';(coldOwner as any).completedAt=performance.timeOrigin+performance.now();save();}result.guards.bothOfflineColdProfilesExact=true;}catch(error){const coldOwner=result.ownerCold?.at(-1);if(coldOwner&&coldOwner.outcome!=='passed'){coldOwner.outcome='failed';coldOwner.error=String(error);}result.coldFailure=true;throw error;}result.guards.noColdStorageReinjection=true;result.finalArchive=archiveIdentity(archives[0]!);expect(resourceStop).toBeFalsy();result.metrics=(await control('end')as any).metrics;result.trace=await control('trace');result.outcome='passed';
  53 |  }catch(error){result.outcome='failed';result.error=String(error);throw error;}finally{result.finalOwnerMaintenance=await Promise.all([reader,writer].filter(Boolean).map(a=>a.p.evaluate(()=>(window as any).__maintenanceRead?.()).catch(()=>null)));result.finalMaintenanceTraces=await Promise.all([reader,writer].filter(Boolean).map(a=>captureMaintenanceTrace(a.p)));if(writer)result.finalMaintenance=await writer.p.evaluate(()=>(window as any).__maintenanceRead?.()).catch(()=>null);await Promise.all(contexts.map(c=>c.close().catch(()=>{})));writeFileSync(join(out,'result.json'),JSON.stringify(result,null,2)+'\n');await stop();}
  54 | });
  55 | 
```
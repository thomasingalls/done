from pathlib import Path
import json,random,hashlib
r=Path(__file__).parent;repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');s=json.loads((r/'selection326.json').read_text());fp=r/'sender-fixture/fixture.json';f=json.loads(fp.read_text());original=json.loads((r/'cohort-winning/fixture.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert f['accounts'][0]['archive']==original['accounts'][0]['archive'];assert f['accounts'][1:]==original['accounts'][1:];a=f['accounts'][0];old=original['accounts'][0];assert a['actors'][0]==old['actors'][0]and a['actors'][3:]==old['actors'][3:];assert a['date']=='2026-11-01'
checks=[]
for i in [1,2]:
 rows=[]
 for origin in a['actors'][i]['storage']['origins']:
  for db in origin.get('indexedDB',[]):
   if not db['name'].startswith('done.')or len(db['name'])!=37:continue
   counts={v['name']:len(v['records'])for v in db['stores']};counter=[row.get('value') for st in db['stores'] if st['name']=='meta' for row in st['records'] if row.get('key')=='counter'];rows.append({'stores':counts,'counterVersion':counter[0].get('v') if counter and isinstance(counter[0],dict) else None,'encodedCounterNotDecoded':bool(counter and counter[0] is None)})
 checks.append({'actor':i,'databases':rows})
(r/'sender-fixture326-check.json').write_text(json.dumps({'fixtureSha256':sha(fp),'originalFixtureSha256':sha(r/'cohort-winning/fixture.json'),'sameFullArchive':True,'otherAccountsAndActorsUnchanged':True,'date':a['date'],'actors':checks,'labOnly':True,'acceptanceCredit':False},indent=2)+'\n')
# Final harness revision between completed stages, before declaring the mixed sender screen.
p=r/'harness/test/account-continuation-lab/sender326.spec.ts';p.write_text((r/'sender326.spec.ts.draft').read_text())
plan=[];rng=random.Random(326325)
for rep in range(1,4):
 block=[(policy,work,delay)for policy in ['coordinated-2000','reference','immediate-inflight']for work,delay in [('single500',0),('paired150',0),('paired150',50)]];rng.shuffle(block)
 for policy,work,delay in block:plan.append({'name':f'sender326-r{rep}-{work}-d{delay}-{policy}','replicate':rep,'policy':policy,'workload':work,'rtt':delay,'writers':2 if work=='paired150'else 1,'keys':300 if work=='paired150'else 120,'keyMs':150 if work=='paired150'else 500,'bits':'10101','SY':'1N','repairMs':1000,'eb':s['eb'],'pp':s['pp'],'source':str(r/'sender-source'),'dist':str(r/f'sender-{policy}/combined-dist'),'fixture':str(fp),'config':'sender326.config.ts','fileFilter':'sender326.spec.ts','result':'result.json','labOnly':True,'acceptanceCredit':False})
assert len(plan)==27;(r/'sender326-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
(r/'SENDER-GRID326.md').write_text('Declared27journeys before any sender measurement, seed326325 mixed3blocks of9: threepolicies ×single120keys500ms/0added,paired300keys/device150ms/0added,paired150/50added ×3replicates. Same frozen source/fixture; separate identified policybinaries. Commoninstrumentation and bounds/backoff unchanged; healthy50ms pacing removed onlyimmediate. Start onlywhenbotharchivesexact andeachsend idle; compare UIacceptedtip with read-onlyserverpublisher tip before/after. Independent writer loops on separate browserprocesses/cards, actualtiming/focus retained. 3markers/writer are separate commands; positions/100key denominator excludesmarkers, numeratorincludesallwritingblockenvelopes, also reportper100inputcommands. Record per-directionlatency/budgets, coldunlock/navtimings andofflineeditUndo exactness. Existinggatesreported/no defaultdecision. Any P cold stopsPonly; noP1latervalidstack requiresoperator-approved323EBfallback, retainingPfailures.\n')
print('Declared27sender journeys; fixture checks',checks)

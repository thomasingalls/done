from pathlib import Path
import hashlib,json,subprocess
r=Path(__file__).parent;repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
start=json.loads((r/'canonical-start.json').read_text());assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==start['head'];assert subprocess.check_output(['git','diff','--cached','--name-only'],cwd=repo,text=True)==''
for n,h in start['files'].items():assert sha(repo/n)==h,n
checks=[]
for p in sorted(r.glob('*326*-inputs.json')):
 inp=json.loads(p.read_text())
 if not 'plan'in inp:continue
 counts={};mismatches=[]
 for family in ['sourceRoots','assetRoots']:
  for root,files in inp.get(family,{}).items():
   for n,h in files.items():assert sha((Path(root)if Path(root).is_absolute()else r/root)/n)==h,(p.name,root,n)
   counts[family+':'+root]=len(files)
 for n,h in inp.get('serverSources',{}).items():assert sha(r/'source-server'/n)==h,(p.name,n)
 for n,h in inp.get('fixtures',{}).items():assert sha(Path(n)if Path(n).is_absolute()else r/n)==h,(p.name,n)
 for n,h in inp.get('apparatus',{}).items():
  if sha(r/n)!=h:mismatches.append({'file':n,'expected':h,'current':sha(r/n),'interpretation':'apparatus changed between declared stages; recorded stage identity is retained, not equated with latest harness'})
 checks.append({'stage':p.name,'sourceAndAssetRoots':counts,'serverInputs':len(inp.get('serverSources',{})),'fixtureHashesMatch':True,'apparatusRevisions':mismatches})
# Each reached timed case needs its own retained host log and child exit.
cases={}
for p in sorted(r.glob('*326*-results.json')):
 try:rows=json.loads(p.read_text())
 except Exception:continue
 if not isinstance(rows,list):continue
 for row in rows:
  if not isinstance(row,dict)or'childExit'not in row or'startedAt'not in row:continue
  out=r/row['name'];log=out/'host-load.jsonl';assert log.exists(),row['name'];events=[json.loads(z)for z in log.read_text().splitlines()];loads=[z for z in events if z['kind']=='load'];cases[row['name']]={'childExit':row['childExit'],'coldFailure':row.get('coldFailure'),'hostSamples':len(loads),'hostBusyMedian':__import__('statistics').median(100-z['hostPercent']['idle']for z in loads)if loads else None,'hostBusyMax':max((100-z['hostPercent']['idle']for z in loads),default=None),'hostLogComplete':events[-1]['kind']=='end','seconds':row['finishedAt']-row['startedAt']}
result={'head':start['head'],'canonicalFilesUnchanged':len(start['files']),'realIndexEmpty':True,'stageChecks':checks,'cases':cases,'noLandingOrCredit':True}
(r/'independent326-check.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'canonical':len(start['files']),'stages':len(checks),'timedCases':len(cases),'coldFailures':sum(bool(x['coldFailure'])for x in cases.values())},indent=2))

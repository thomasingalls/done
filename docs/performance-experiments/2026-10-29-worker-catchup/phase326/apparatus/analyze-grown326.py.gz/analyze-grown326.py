from pathlib import Path
import json,csv,math,statistics
r=Path(__file__).parent
runs=json.loads((r/'grown326-results.json').read_text())
summary=[]
attempt_rows=[]
def quantile(xs,p=.95):
    ys=sorted(xs)
    return ys[math.ceil(p*len(ys))-1]
for run in runs:
    x=json.loads((r/run['name']/'result.json').read_text())
    groups=x.get('maintenanceTraceBeforeCold') or x.get('finalMaintenanceTraces',[])
    owners=[]
    for owner,realms in enumerate(groups):
        for realm in realms:
            v=realm.get('value')
            if not v or not v['attempts']:
                continue
            aa=v['attempts'];ee=v['events']
            saves=[e for e in ee if e['kind']=='checkpoint-saved']
            caps=[e for e in ee if e['kind'] in ['PreparationCapacity','preparation-capacity']]
            complete=[a for a in aa if a.get('outcome',{}).get('kind') in ['removed','already-removed']]
            drains=x.get('catchups',[])
            drain_end=drains[0].get('completedAt') if drains else None
            during_typing=[a['id'] for a in aa if x.get('typingStartedAt',math.inf)<=a['startedAt']<=x.get('typingFinishedAt',-math.inf)]
            during_drain=[a['id'] for a in aa if drain_end and x['startedAt']<=a['startedAt']<drain_end] if owner==0 else []
            for a in aa:
                ss=[e for e in saves if e['attempt']==a['id']]
                ll=[e for e in ee if e['kind']=='checkpoint-loaded' and e['attempt']==a['id']]
                durable=ss[-1] if ss else (ll[-1] if ll else {})
                for j in a['journals'] or [{}]:
                    attempt_rows.append({'case':run['name'],'role':['reader','writer'][owner],'attempt':a['id'],'startAt':a['startedAt'],'endAt':a.get('endedAt'),'stage':a.get('stage'),'outcome':a.get('outcome',{}).get('kind','active-at-capture'),'reason':a.get('outcome',{}).get('reason'),'entries':j.get('entries'),'pending':j.get('pending'),'hits':j.get('hits'),'newCompletedMisses':j.get('misses'),'lookupMisses':j.get('lookupMisses'),'firstMissMs':j.get('firstMiss',{}).get('elapsedMs'),'mapBytes':j.get('bytes'),'mapByteCap':j.get('byteCap'),'durableDeltas':durable.get('deltas'),'durableBytes':durable.get('bytes'),'durableChunks':durable.get('chunks'),'durableByteCap':durable.get('byteCap'),'durableChunkCap':durable.get('chunkAndDeltaCap'),'replayMs':sum(z.get('ms',0) for z in a['replays']),'families':json.dumps(j.get('families'),separators=(',',':')),'interruptions':json.dumps(a['interruptions'],separators=(',',':')),'capacity':sum(e['attempt']==a['id'] for e in caps)})
            journals=[j for a in aa for j in a['journals']]
            own={'role':['reader','writer'][owner],'attempts':len(aa),'completions':len(complete),'capacityRefusals':len(caps),'maxMapBytes':max((j.get('bytes',0) for j in journals),default=0),'durableBytes':saves[-1]['bytes'] if saves else None,'durablePeakBytes':max((e['bytes'] for e in saves),default=None),'durableDeltas':len(saves),'durableChunks':saves[-1]['chunks'] if saves else None,'byteCap':33554432,'lastStage':aa[-1].get('stage'),'lastOutcome':aa[-1].get('outcome'),'startsDuringTyping':during_typing,'startsDuringReaderDrain':during_drain,'firstCompletionAfterLastKeyMs':complete[0]['endedAt']-x['typingFinishedAt'] if complete else None,'retryClocks':[e for e in ee if e['kind']=='retry-clock'],'families':[j.get('families')for j in journals if j.get('families')],'traceOverflow':v['overflow']}
            own['interruptedAttempts']=[{'attempt':a['id'],'outcome':a.get('outcome'),'conditions':a.get('interruptions',[])}for a in aa if a.get('interruptions')]
            own['retryWaits']=[]
            for e in ee:
                if e.get('kind')!='retry-clock':continue
                a=next((a for a in aa if a['id']==e['attempt']),None);n=next((a for a in aa if a['startedAt']>e['at']),None)
                own['retryWaits'].append({'attempt':e['attempt'],'priorityOnly':e.get('priorityRetry'),'scheduledRetryMs':e.get('retryMs'),'quietUntilAtScheduling':e.get('quietUntil'),'notBefore':e.get('notBefore'),'endedAt':a.get('endedAt')if a else None,'nextAttempt':n['id']if n else None,'actualEndToNextStartMs':n['startedAt']-a['endedAt']if n and a and a.get('endedAt')else None,'actualClockToNextStartMs':n['startedAt']-e['at']if n else None,'censoredNoNextStart':n is None})
            owners.append(own)
    statuses=x.get('ownerMaintenanceBeforeCold') or x.get('finalOwnerMaintenance',[])
    for owner in range(2):
        role=['reader','writer'][owner]
        if not any(o['role']==role for o in owners):
            owners.append({'role':role,'attempts':0,'completions':0,'capacityRefusals':0,'maxMapBytes':None,'durableBytes':None,'durablePeakBytes':None,'durableDeltas':0,'durableChunks':None,'byteCap':33554432,'lastStage':None,'lastOutcome':None,'startsDuringTyping':[],'startsDuringReaderDrain':[],'firstCompletionAfterLastKeyMs':None,'retryClocks':[],'traceOverflow':0,'statusAtCapture':statuses[owner]['status'] if len(statuses)>owner and statuses[owner] else None,'diagnostic':'No attempt in observed window; reader diagnostics censored at original cold step'})
    owners.sort(key=lambda o:['reader','writer'].index(o['role']))
    row={**run,'owners':owners,'cold':'pass' if x.get('guards',{}).get('bothOfflineColdProfilesExact') else 'failed' if x.get('coldFailure') else 'not reached','guards':x.get('guards',{}),'error':x.get('error')}
    try:
        if x.get('probes') and x.get('clocks'):
            keys=[o for o in x['offers'] if o['kind']=='key'];markers=[o for o in x['offers'] if o['kind']=='marker']
            assert [o['index'] for o in keys]==list(range(120))
            for device,name in [(0,'peer'),(1,'input')]:
                b=[z for group in x['clocks'] for z in group['rows'][device]]
                lo=max(z['renderer']-z['after']-1 for z in b);hi=min(z['renderer']-z['before']+1 for z in b)
                assert lo<=hi
                p=x['probes'][device]
                vals=[min(z['at'] for z in p['counts'] if z['at']>=o['at']-5 and z['count']>=x['baselines'][device]+i)-o['at']-lo for i,o in enumerate(keys,1)]
                row[name+'P95Ms']=quantile(vals)
                row[name+'WorstMarkerMs']=max(p['markers'][i]-o['at']-lo for i,o in enumerate(markers))
            row['overlapKeys']=sum(o['at']<x['catchups'][0]['completedAt'] for o in keys)
            row['backlogMs']=x['catchups'][0]['completedAt']-x['startedAt']
            row['finalNewDeliveryMs']=x['newDeliveryAt']-max(o['returnedAt'] for o in x['offers'])
            row['trustedFocusedVisibleInput']=len(x['probes'][1]['events'])==123 and all(e['trusted'] and e['focused'] and e['visible']=='visible' for e in x['probes'][1]['events'])
            row['gatePredicates']={'finalNewDelivery30s':row['finalNewDeliveryMs']<=30000,'faultExposed':not run['withhold'] or x['notifications'][0]['withheld']>0,'trustedFocusedVisibleInput':row['trustedFocusedVisibleInput'],'input16ms':row['inputP95Ms']<=16,'peer2500ms':row['peerP95Ms']<=2500,'everyMarker2500ms':row['peerWorstMarkerMs']<=2500,'overlap60':row['overlapKeys']>=60,'backlog600s':row['backlogMs']<=600000,'functionalAndOriginalWriterDeadline':run['childExit']==0,'bothColdExact':row['cold']=='pass'}
    except Exception as error:
        row['metricAnalysisError']=repr(error)
        row['gatePredicates']={'metricEvidenceComplete':False,'functionalAndOriginalWriterDeadline':run['childExit']==0,'bothColdExact':row['cold']=='pass'}
    if 'gatePredicates'not in row:row['gatePredicates']={'metricEvidenceComplete':False,'functionalAndOriginalWriterDeadline':run['childExit']==0,'bothColdExact':row['cold']=='pass'}
    loads=[json.loads(s) for s in (r/run['name']/'host-load.jsonl').read_text().splitlines()]
    loads=[s for s in loads if s['kind']=='load']
    row['hostBusyMedian']=statistics.median(100-z['hostPercent']['idle'] for z in loads)
    row['hostBusyMax']=max(100-z['hostPercent']['idle'] for z in loads)
    summary.append(row)
(r/'grown326-predicates-analysis.json').write_text(json.dumps(summary,indent=2)+'\n')
if attempt_rows:
    with (r/'grown326-predicates-attempts.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(attempt_rows[0]),lineterminator='\n');w.writeheader();w.writerows(attempt_rows)
print(json.dumps([{'name':z['name'],'functionalExit':z['childExit'],'cold':z['cold'],'peerP95Ms':z.get('peerP95Ms'),'inputP95Ms':z.get('inputP95Ms'),'owners':[{k:o[k] for k in ['role','attempts','completions','capacityRefusals','durableBytes','startsDuringTyping','startsDuringReaderDrain','firstCompletionAfterLastKeyMs']} for o in z['owners']]} for z in summary],indent=2))

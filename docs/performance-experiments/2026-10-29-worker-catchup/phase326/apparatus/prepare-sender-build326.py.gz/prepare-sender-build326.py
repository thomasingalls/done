from pathlib import Path
import json,shutil,subprocess,hashlib,os
r=Path(__file__).parent;node='/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node';selection=json.loads((r/'selection326.json').read_text());s=r/'sender-source';shutil.copytree(Path(selection['source']),s,symlinks=True);subprocess.run(['python3',str(r/'add-immediate326.py'),str(s)],check=True)
# Shared source exactly for all three policies. Additional Window flush timestamp is observation only.
workspace=r/'sender-build';workspace.mkdir(mode=0o700);(workspace/'source').symlink_to(s,target_is_directory=True);shutil.copytree(r/'lab',workspace/'lab',symlinks=True)
for p in(workspace/'lab').rglob('*'):
 if p.is_file()and p.suffix in ['.mjs','.html','.ts']:p.write_text(p.read_text().replace(str(r),str(workspace)))
for n in ['release-flags.json','build-lab.py','build.mjs']:
 p=workspace/n;p.write_text((r/n).read_text().replace(str(r),str(workspace)))
# Typecheck the final sender source and controls; previous source remains frozen and intact.
t=json.loads((r/'tsconfig.lab.json').read_text());t['extends']='./sender-source/tsconfig.app.json';t['include']=[x.replace('source/','sender-source/',1)for x in t['include']]+['sender-source/test/labImmediate326.test.ts'];(r/'tsconfig.sender326.json').write_text(json.dumps(t,indent=2)+'\n')
tests=['test/labImmediate326.test.ts','test/accountBatching.test.ts','test/accountSyncDriver.test.ts','test/admissionJournalFence.test.ts','test/admissionQueue.test.ts','test/spoolBatch.test.ts','test/outboundSpool.test.ts','test/accountDelivery.test.ts','test/labStoredMode326.test.ts','test/labStoredExternal326-P0.test.ts','test/labStoredExternal326-P1.test.ts']
with(r/'sender-unit326-attempt1.log').open('w')as f:p=subprocess.run([node,'node_modules/vitest/vitest.mjs','run',*tests,'--reporter=verbose'],cwd=s,stdout=f,stderr=subprocess.STDOUT)
print('Sender unit child',p.returncode,flush=True)
if p.returncode:raise SystemExit(p.returncode)
with(r/'sender-type326-attempt1.log').open('w')as f:p=subprocess.run([node,'source/node_modules/typescript/bin/tsc','-p','tsconfig.sender326.json'],cwd=r,stdout=f,stderr=subprocess.STDOUT)
print('Sender type child',p.returncode,flush=True)
if p.returncode:raise SystemExit(p.returncode)
sourceMap={str(p.relative_to(s)):hashlib.sha256(p.read_bytes()).hexdigest()for folder in ['src','account-protocol']for p in(s/folder).rglob('*')if p.is_file()};(r/'sender326-source-inputs.json').write_text(json.dumps(sourceMap,indent=2)+'\n')
for policy in ['coordinated-2000','reference','immediate-inflight']:
 env={**os.environ,'LAB_BATCH_POLICY':policy}
 with(r/f'sender-build326-{policy}.log').open('w')as f:p=subprocess.run(['python3',str(workspace/'build-lab.py')],cwd=workspace,env=env,stdout=f,stderr=subprocess.STDOUT)
 if p.returncode:raise SystemExit(p.returncode)
 target=r/('sender-'+policy);target.mkdir(mode=0o700);shutil.move(str(workspace/'combined-dist'),target/'combined-dist')
 for name in ['build-identity.json','build-flags.json','frontend-build.log','lab-build.log']:shutil.copy2(workspace/name,target/name)
 assert all(hashlib.sha256((s/n).read_bytes()).hexdigest()==v for n,v in sourceMap.items());print('Built sender policy',policy,flush=True)

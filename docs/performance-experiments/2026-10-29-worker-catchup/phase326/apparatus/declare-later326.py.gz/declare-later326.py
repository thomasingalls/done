from pathlib import Path
import json
r=Path(__file__).parent;s=json.loads((r/'selection326.json').read_text());base={'rtt':0,'bits':'10101','SY':'1N','repairMs':1000,'labOnly':True,'acceptanceCredit':False};stack={**base,**{k:s[k]for k in ['eb','pp','dist','source']}}
profiles=[{**base,'name':'profile326-E1B0P0','eb':'10','pp':False,'workerProfile':True,'config':'worker-owner.config.ts','fileFilter':'worker-owner.spec.ts','grep':'lab G V deep joined with cold reopen$','result':'deep-gv/result.json'},{**stack,'name':'profile326-winner','workerProfile':True,'config':'worker-owner.config.ts','fileFilter':'worker-owner.spec.ts','grep':'lab G V deep joined with cold reopen$','result':'deep-gv/result.json'}]
live=[{**stack,'name':f'live326-r{n}','replicate':n,'withhold':False,'config':'r-late.config.ts','fileFilter':'r-late.spec.ts','result':'result.json'}for n in range(1,4)]
grown=[{**stack,'name':f'grown326-withheld-r{n}','replicate':n,'withhold':True,'fixture':str(r/'cohort-winning/fixture.json'),'config':'grown-maintenance.config.ts','fileFilter':'phase321/grown-maintenance.spec.ts','result':'result.json'}for n in range(1,4)]
(r/'later326-plan.json').write_text(json.dumps(profiles+live+grown,indent=2)+'\n');print(json.dumps({'selectedStack':s,'declaredLaterJourneys':8},indent=2))

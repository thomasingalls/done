from pathlib import Path
import json,statistics,math
r=Path(__file__).parent;rows=[]
def fit(events,label):
 # Sample one observation per aggregate logical count, before maintenance can reset the index.
 points={}
 for e in events:
  n=e.get('densePositions',0)
  if 200<=n<=1900 and e.get('fits'):points[n]=e
 if len(points)<20:return {'label':label,'notMeasured':'insufficient bounded pre-drain index observations','points':len(points)}
 data=list(points.items());xs=[n for n,e in data];ys=[e['chargedBytes']for n,e in data];mean=statistics.mean(xs);ym=statistics.mean(ys);xx=sum((x-mean)**2 for x in xs);slope=sum((x-mean)*(y-ym)for x,y in zip(xs,ys))/xx;offset=ym-slope*mean;pred=(33554432-offset)/slope
 ls=[e['logical']for n,e in data];lm=statistics.mean(ls);lslope=sum((x-mean)*(y-lm)for x,y in zip(xs,ls))/xx;loffset=lm-lslope*mean;lpred=(32768-loffset)/lslope
 residual=max(abs(y-(offset+slope*x))for x,y in zip(xs,ys))
 return{'label':label,'observedDensePositionRange':[min(xs),max(xs)],'uniquePoints':len(xs),'chargedBytesPerAdditionalDensePosition':slope,'interceptBytes':offset,'maximumAbsoluteResidualBytes':residual,'predictedDensePositionAt32MiB':pred,'predictedDensePositionAt32768LogicalWork':lpred,'predictedFirstIndexLimitDensePosition':min(pred,lpred),'measuredPastCap':False,'model':'OLS charged/logical work against aggregate dense positions during drain, n200..1900; no claim for other update/page mixes or future maintenance resets'}
for case in json.loads((r/'screen326-results.json').read_text()):
 if case.get('childExit')!=0:continue
 x=json.loads((r/case['name']/'deep-gv/result.json').read_text());events=[e for e in x['workerAtDrain']['events']if e['kind']=='indexBudget'];f=fit(events,case['name']);f.update(eb=case['eb'],pp=case['pp'],rtt=case['rtt']);rows.append(f)
for case in json.loads((r/'grown326-results.json').read_text()):
 x=json.loads((r/case['name']/'result.json').read_text());drain=x['catchups'][0]['completedAt']
 for i,realms in enumerate(x['labAfter']):
  events=[e for realm in realms for e in(realm.get('value')or{}).get('events',[])if e['kind']=='indexBudget'and e['at']<=drain];f=fit(events,case['name']+':'+['reader','writer'][i]);f.update(eb=case['eb'],pp=case['pp'],grown=True);rows.append(f)
(r/'cap326-analysis.json').write_text(json.dumps({'capBytes':33554432,'logicalWorkCap':32768,'rows':rows,'qualification':'Predictions for this lab receipt/account/update mix. Incoming dense position is not publisher cursor or total account history. Index charge is not heap. Fallback at the predicted position has not been measured. Failure/maintenance/cold verdicts are unchanged.','labOnly':True,'acceptanceCredit':False},indent=2)+'\n')
print(json.dumps([x for x in rows if x.get('grown')],indent=2))

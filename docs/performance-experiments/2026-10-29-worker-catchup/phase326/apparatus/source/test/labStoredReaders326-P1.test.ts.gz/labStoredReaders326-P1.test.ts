vi.hoisted(()=>{Object.defineProperty(globalThis,'location',{configurable:true,value:{href:'https://lab.invalid/?lab=10101&labSY=1N&labPP=1'}})});
import { replayHandoffStream, mergeHandoffHistory } from '../src/crdt/handoffHistory';
import { decodeHistoryInstall } from '../src/crdt/historyInstall';
import { publisherContext } from '../src/crdt/inboundLedger';
import { Y } from '../src/crdt/yjs';
// @vitest-environment node
import { sign } from 'node:crypto';
import { afterEach, expect, it, vi } from 'vitest';
import { membershipEventEpoch } from '../src/crdt/accountMembership';
import {
  inspectInbound,
  verifyInboundLedger,
  createInboundCoverage,
} from '../src/crdt/inboundLedger';
import { advanceSelfReceive } from '../src/crdt/accountSyncState';
import { replayFullLocalHistory, type LocalBaselineContext } from '../src/crdt/localBaselineReplay';
import {
  indexVerifiedLedger,
  extendAccountLedger,
  sameAccountLedger,
} from '../src/crdt/incrementalAccountLedger';
import { createVerificationMemo } from '../src/crdt/verificationMemo';
import {
  emptySpoolWitness,
  type ContentCounter,
  type OpenedRecord,
} from '../src/crdt/contentRecord';
import { extendSpoolWitness } from '../src/crdt/spoolRecord';
import { hash } from './account-inbound/fixtures';
// @ts-expect-error Shared independent real membership, adoption and crypto fixture.
import { memberFixture } from './local-baseline/fixtures.mjs';
const clean: (() => void)[] = [];
afterEach(() => {
  clean.splice(0).forEach((f) => f());
  vi.restoreAllMocks();
  vi.unstubAllGlobals();Object.defineProperty(globalThis,'location',{configurable:true,value:{href:'https://lab.invalid/?lab=10101&labSY=1N&labPP=1'}});
  vi.unstubAllEnvs();
});
const json = (v: unknown) => new Uint8Array(Buffer.from(JSON.stringify(v))),
  hex = (b: Uint8Array) => Buffer.from(b).toString('hex');
async function fixture(peer = true, own = true) {
  const f = await memberFixture();
  clean.push(f.clear);
  if (own) await f.appendOwn();
  const append = async () => {
    await f.appendPeer();
    const row = (f.rows as OpenedRecord[]).at(-1)!;
    const v = JSON.parse(new TextDecoder().decode(row.bytes)),
      r = JSON.parse(Buffer.from(v[11], 'hex').toString()),
      p = JSON.parse(Buffer.from(v[12], 'hex').toString());
    r.pop();
    r[11] = 4;
    r[13] = 30000;
    const request = json([...r, sign(null, json(r), f.f.keys.existing).toString('hex')]);
    p.pop();
    p[2] = hash(request);
    const page = json([...p, sign(null, json(p), f.f.f.keys.acceptance).toString('hex')]);
    // Independent new plaintext framing; partial one-entry page under a genuine wider signature.
    v[0] = 'done/account-inbound/v2';
    v[1] = 2;
    v[11] = hex(request);
    v[12] = hex(page);
    v.push(0);
    row.bytes = json(v);
    return row;
  };
  if (peer) await append();
  const context: LocalBaselineContext = f.ctx;
  const counter = async (): Promise<ContentCounter> => {
    let spool = emptySpoolWitness();
    for (const row of f.rows as OpenedRecord[]) {
      if (
        row.kind === 'heads' ||
        (row.kind === 'outbound' &&
          !new TextDecoder().decode(row.bytes).startsWith('["done/source-capture/v1"'))
      )
        spool = await extendSpoolWitness(spool, row.bytes, crypto.subtle);
    }
    const next = (f.rows as OpenedRecord[]).at(-1)!.seq + 4;
    return {
      v: 2,
      store_id: context.identity.storeId,
      intent: '04'.repeat(16),
      active_gen: 1,
      next_seq: next,
      reserved: { 1: next - 1 },
      spool,
      mac: new Uint8Array(32),
    };
  };
  const combine = () => {
    const rows = (f.rows as OpenedRecord[]).filter(
      (row) =>
        row.kind === 'heads' &&
        JSON.parse(new TextDecoder().decode(row.bytes))[0] === 'done/account-inbound/v2',
    );
    const events = rows.map((row) => JSON.parse(new TextDecoder().decode(row.bytes)));
    const r = JSON.parse(Buffer.from(events[0][11], 'hex').toString());
    r.pop();
    r[11] = 4;
    r[13] = 30000;
    const request = json([...r, sign(null, json(r), f.f.keys.existing).toString('hex')]);
    const p = JSON.parse(Buffer.from(events[0][12], 'hex').toString());
    p.pop();
    p[2] = hash(request);
    p[3] = events.at(-1)[8];
    p[4] = p[3];
    p[5] = events.map((v) => JSON.parse(Buffer.from(v[12], 'hex').toString())[5][0]);
    const page = json([...p, sign(null, json(p), f.f.f.keys.acceptance).toString('hex')]);
    for (const [index, row] of rows.entries()) {
      const v = events[index];
      v[11] = hex(request);
      v[12] = hex(page);
      v[13] = index;
      row.bytes = json(v);
    }
    return rows;
  };
  return { f, context, append, counter, combine, rows: f.rows as OpenedRecord[] };
}

import {decodeInboundRecord,encodeDenseInbound,inboundRecordViews,isDenseInboundRecord} from '../src/crdt/inboundRecord';
const packRows=(x: Awaited<ReturnType<typeof fixture>>)=>{
  const combined=x.combine(),events=combined.map(r=>decodeInboundRecord(r.bytes)),packed=encodeDenseInbound(events);
  for(const event of events){event.request.fill(0);event.page.fill(0);}
  const keep=combined.at(-1)!;keep.bytes=packed;
  for(const old of combined.slice(0,-1)){const i=x.rows.indexOf(old);x.rows.splice(i,1);old.bytes.fill(0);}
  return keep;
};
it('P full census, epoch, physical witness and logical index agree with independent full replay',async()=>{
  const x=await fixture();await x.append();const row=packRows(x),counter=await x.counter();
  const c=inspectInbound(x.rows,x.context.route,x.context.inbound);
  expect(c.entries).toHaveLength(2);expect(c.delivery.spool.events.filter(b=>isDenseInboundRecord(b))).toHaveLength(1);
  expect(membershipEventEpoch(row.bytes)).toBe(x.context.route.epoch);
  const full=await replayFullLocalHistory({records:x.rows,counter},x.context);
  expect([...full.inbound.peers!.values()].some(p=>p.prefix.position===2&&p.retained.size===2)).toBe(true);
  const indexes=await indexVerifiedLedger(full,x.rows,x.context.route,counter,crypto.subtle);
  expect(indexes).toBeDefined();expect(indexes!.epoch).toBe(x.context.route.epoch);
});
it('P checked incremental extension retains all entries with index-specific memo keys',async()=>{
  const x=await fixture(false),before=x.rows.map(r=>({...r,bytes:r.bytes.slice()})),counter=await x.counter();
  const previous=await replayFullLocalHistory({records:before,counter},x.context),indexes=await indexVerifiedLedger(previous,before,x.context.route,counter,crypto.subtle);
  await x.append();await x.append();packRows(x);const nextCounter=await x.counter(),memo=createVerificationMemo();clean.push(()=>memo.clear());
  const extended=await extendAccountLedger({...previous,indexes:indexes!},before,x.rows,x.context.route,nextCounter,x.context.inbound,x.context.signer,crypto.subtle,{memo,current(){}});
  expect(extended).toBeDefined();const inbound=await verifyInboundLedger(extended!.census,x.rows,x.context.inbound,{assertCurrent(){},now:()=>61000});
  const full=await replayFullLocalHistory({records:x.rows,counter:nextCounter},x.context);
  const coverage=createInboundCoverage();try{advanceSelfReceive(extended!.census.delivery,extended!.delivery,inbound,x.context.route,updates=>coverage.check(x.rows,updates));}finally{coverage.clear();}
  expect(sameAccountLedger({...extended!,inbound},full)).toBe(true);
});
it('P handoff cut inside an exact original two-entry page keeps only the verified suffix',async()=>{
  const x=await fixture(),installed=decodeHistoryInstall(await x.f.appendHistory());await x.append();
  const row=packRows(x),proof={checkpoint:installed.checkpoint,admission:installed.admission},base=publisherContext(x.context.inbound,decodeInboundRecord(row.bytes).publisher),doc=new Y.Doc({gc:false});
  try{
    await mergeHandoffHistory(doc,proof,base.history!,base.generationKey);
    const replayed=await replayHandoffStream(doc,base,[hex(row.bytes)],proof,{assertCurrent(){},now:()=>61000});
    expect(replayed.records).toHaveLength(1);const tail=inboundRecordViews(replayed.records[0]!.record);
    expect(tail).toHaveLength(1);expect(tail[0]!.position).toBe(2);expect(tail[0]!.entry).toBe(1);
    expect(tail[0]!.page).toEqual(decodeInboundRecord(row.bytes).page);expect(replayed.context.prefix.position).toBe(2);
    for(const e of replayed.records){e.record.fill(0);for(const u of e.updates)u.fill(0);}
  }finally{doc.destroy();}
});

import {writeFileSync} from 'node:fs';
import {IDBFactory,IDBKeyRange} from 'fake-indexeddb';
import {createContentOwner} from '../src/crdt/contentStore';
import {keys,cryptFor} from './local-baseline/anchor-fixture';
import type {SessionTask} from '../src/crdt/writeSession';
const nativeTask:SessionTask={signal:new AbortController().signal,step:f=>f(),wait:async f=>f()};
it('P authenticated interior-page handoff suffix survives native v5 baseline cold reopen',async()=>{
 const x=await fixture(),installed=decodeHistoryInstall(await x.f.appendHistory());
 vi.stubGlobal('indexedDB',new IDBFactory());vi.stubGlobal('IDBKeyRange',IDBKeyRange);
 for(const name of ['VITE_ACCOUNT_BASELINE_INSTALL','VITE_ACCOUNT_BASELINE_READ','VITE_ACCOUNT_RETENTION'])vi.stubEnv(name,'1');
 const crypt={...cryptFor(x.context.identity,await keys()),reuseOpened:true as const,warmLoads:true as const,readBaseline:true as const,baseline:async(t:SessionTask)=>({...x.context,assertCurrent:()=>t.step(()=>{})})};
 const owner=createContentOwner(x.context.identity,1,crypt);clean.push(()=>owner.dispose());await owner.initialize(nativeTask,{intent:'04'.repeat(16),checkCreation(){}});await owner.enableSpool(nativeTask);
 for(const row of x.rows){if(row.kind==='heads'||(row.kind==='outbound'&&!new TextDecoder().decode(row.bytes).startsWith('["done/source-capture/v1"'))){const before=await owner.spoolWitness(nativeTask),after=await extendSpoolWitness(before,row.bytes,crypto.subtle);await owner.appendSpool(nativeTask,row,{before,after});}else await owner.append(nativeTask,[row]);}
 expect((await owner.removeHistory(nativeTask,async()=>{},()=>{},0)).kind).toBe('removed');expect(owner.hasReducedHistory()).toBe(true);
 await x.append();const row=packRows(x),proof={checkpoint:installed.checkpoint,admission:installed.admission},base=publisherContext(x.context.inbound,decodeInboundRecord(row.bytes).publisher),doc=new Y.Doc({gc:false});
 try{
  await mergeHandoffHistory(doc,proof,base.history!,base.generationKey);
  const replayed=await replayHandoffStream(doc,base,[hex(row.bytes)],proof,{assertCurrent(){},now:()=>61000});expect(replayed.records).toHaveLength(1);
  const tail=replayed.records[0]!,view=decodeInboundRecord(tail.record);expect(view.entry).toBe(1);expect(view.position).toBe(2);expect(view.page).toEqual(decodeInboundRecord(row.bytes).page);
  const before=await owner.spoolWitness(nativeTask),after=await extendSpoolWitness(before,tail.record,crypto.subtle);
  await owner.appendInbound(nativeTask,[...tail.updates.map(bytes=>({kind:'update' as const,bytes})),{kind:'heads',bytes:tail.record}],{before,after,beforeCommit:async()=>{}});
  const expected=await owner.loadAccount(nativeTask);expect(expected.kind).toBe('baseline-plus-suffix');owner.dispose();
  if(process.env['P_COLD_RECEIPT_PATH'])writeFileSync(process.env['P_COLD_RECEIPT_PATH'],JSON.stringify({attemptStarted:true,exact:false}));
  const fresh=createContentOwner(x.context.identity,1,crypt);clean.push(()=>fresh.dispose());await fresh.initialize(nativeTask);const reopened=await fresh.loadAccount(nativeTask);expect(reopened).toEqual(expected);if(process.env['P_COLD_RECEIPT_PATH'])writeFileSync(process.env['P_COLD_RECEIPT_PATH'],JSON.stringify({attemptStarted:true,exact:true}));
 }finally{doc.destroy();}
});

it('declared P1 parser treatment is actually exposed',async()=>{expect((await import('../src/crdt/rangeLab')).labPP()).toBe(true);});

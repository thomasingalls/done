// @ts-nocheck
// @vitest-environment node
import{vi,it,expect}from'vitest';
import*as client from'./account-membership/replacement-checkpoint-entry';
import{sourceFixture}from'./account-membership/replacement-source-fixture.mjs';
import{deliveryFixture}from'./account-membership/delivery-fixtures.mjs';
import{signed,hash}from'./account-membership/fixtures.mjs';
import{parseMembershipDelivery,parseMembershipInstallation,membershipDeliveryMessage,membershipDeliveryHash,membershipInstallationMessage}from'../account-protocol/membershipDelivery';
import{replacementCheckpointHash,replacementCheckpointAdmissionBody,replacementCheckpointAdmissionMessage}from'../account-protocol/replacementCheckpoint';
import{decodeInboundRecord,encodeDenseInbound}from'../src/crdt/inboundRecord';
vi.hoisted(()=>{Object.defineProperty(globalThis,'location',{configurable:true,value:{href:'https://lab.invalid/?lab=10101&labSY=1N&labPP=0'}})});
async function fixture() {
  const f = await sourceFixture({client});
  const source = await client.openReplacementSource(f.input);
  let checkpoint;
  try {
    for (const e of f.entries) {
      const p = f.packet(e);
      (await source.appendPage(e.publisher, p.request, p.page)).fill(0);
    }
    checkpoint = await source.checkpoint(f.survivor, f.sign);
  } finally {
    source.dispose();
  }
  const d = await deliveryFixture('existing', {
    f: f.x.f,
    anchor: f.rotated,
    admission: f.admission,
  });
  const delivery = parseMembershipDelivery({
    ...d.delivery,
    v: 3,
    checkpointHash: await replacementCheckpointHash(checkpoint),
  });
  delivery.signature = signed(d.keys.existing, await membershipDeliveryMessage(delivery));
  const admission = await replacementCheckpointAdmissionBody(checkpoint);
  admission.signature = signed(d.keys.new, await replacementCheckpointAdmissionMessage(admission));
  const installation = parseMembershipInstallation({
    ...d.installation,
    v: 3,
    deliveryHash: await membershipDeliveryHash(delivery),
    checkpoint: admission,
  });
  installation.signature = signed(d.keys.new, await membershipInstallationMessage(installation));
  const certification = d.certify({ ...d.epoch, delivery, installation });
  const proofs = { ...f.proofs, continuations: [...f.proofs.continuations, certification] };
  const { history } = await client.verifyMembershipChain(proofs, f.input.authority.base);
  const authority = { base: f.input.authority.base, ...proofs },
    who = d.c.candidate,
    reading = {
      v: 3,
      head: history.current.head,
      epoch: history.current.tip,
      checkpoint,
      admission,
      binding: f.input.checkpoint.binding,
      streams: history.readers.map((m) => {
        const cut = checkpoint.heads.find((h) => h.credentialId === m.id);
        return {
          publisher: m.id,
          events: [],
          prefix: { position: cut.position, link: cut.link, observedThrough: cut.position },
        };
      }),
    };
  return {
    ...f,
    d,
    history,
    authority,
    who,
    reading,
    replay: (r = reading, key = f.key2) =>
      client.replayMembershipReading(r, authority, history, who, key, {
        assertCurrent() {},
        now: () => 61000,
      }),
  };
}


it('replacementSource appends authentic dense stored receipts more than thirty seconds after expiry',async()=>{const f=await sourceFixture({client});let source,aged;const records=[];try{source=await client.openReplacementSource(f.input);for(const e of f.entries){const p=f.packet(e),bytes=await source.appendPage(e.publisher,p.request,p.page);records.push(encodeDenseInbound([decodeInboundRecord(bytes)]));bytes.fill(0);}source.dispose();source=undefined;aged=await client.openReplacementSource({...f.input,lifetime:{assertCurrent(){},now:()=>61000}});for(let i=0;i<records.length;i++)(await aged.appendStored(f.entries[i].publisher,records[i])).fill(0);expect(aged.pending()).toEqual([]);const cp=await aged.checkpoint(f.survivor,f.sign),opened=await client.openReplacementCheckpoint(cp,f.key2,f.parent);try{expect(opened.getText('master').toString()).toContain('removed accepted');expect(opened.getText('master').toString()).toContain('survivor accepted');}finally{opened.destroy();}}finally{source?.dispose();aged?.dispose();for(const b of records)b.fill(0);f.cleanup();}});
it('membershipReading replays a genuine dense post-checkpoint suffix after expiry with exact crypto and cut',async()=>{const f=await fixture();let first,cold;try{first=await f.replay();const sv=client.Y.encodeStateVector(first.doc);first.doc.getText('master').insert(first.doc.getText('master').length,' aged suffix 326');const e=f.entry(f.input.producer,f.d.keys.existing,client.Y.encodeStateAsUpdate(first.doc,sv),11,{epoch:f.history.current.tip,generation:2,position:2,previous:f.entries[0].link}),p=f.packet(e,2,f.history,f.who.id,f.d.keys.new),ctx=first.contexts.find(c=>c.publisher.id===e.publisher),value=await client.verifyInboundPage(ctx,p.request,p.page,{assertCurrent(){},now:()=>1000});expect(value.kind).toBe('received');const dense=encodeDenseInbound([decodeInboundRecord(value.record)]),stream=f.reading.streams.find(s=>s.publisher===e.publisher);stream.events.push(Buffer.from(dense).toString('hex'));stream.prefix={position:value.position,link:value.link,observedThrough:value.through};cold=await f.replay();expect(cold.doc.getText('master').toString()).toContain(' aged suffix 326');expect(cold.contexts.find(c=>c.publisher.id===e.publisher).prefix.position).toBe(2);const corrupt=structuredClone(f.reading);corrupt.streams.find(s=>s.publisher===e.publisher).events[0]=Buffer.from(dense.map((n,i)=>i===dense.length-4?n^1:n)).toString('hex');await expect(f.replay(corrupt)).rejects.toThrow();dense.fill(0);value.record.fill(0);for(const u of value.updates)u.fill(0);}finally{if(first)client.eraseMembershipReading(first);if(cold)client.eraseMembershipReading(cold);f.cleanup();}});

import {configureLabContext} from '../../../lab-context.mjs';
import{test,expect,chromium}from'@playwright/test';import{readFileSync,writeFileSync,mkdirSync,cpSync}from'node:fs';import{join}from'node:path';
import{root,exported,archiveIdentity,lock}from'./common';import{start,stop}from'./runtime.mjs';import{seedProfile}from'./seed-profile';import{restoreAuthenticator,openSaved}from'./devices';
const out=process.env['FAIR_OUT']!;
test('apparatus pilot observes actual accumulated-history preparation and a durable checkpoint',async()=>{
 mkdirSync(out,{recursive:true,mode:0o700});const fixture=JSON.parse(readFileSync(root+'/prepared-fixture/fixture.json','utf8')),a=fixture.accounts.find((a:any)=>a.label==='H'),saved=a.actors[2];let ctx:any;const result:any={kind:'apparatus-only',outcome:'starting'};
 try{
 const state=join(out,'state');cpSync(fixture.state,state,{recursive:true,errorOnExist:true});await start(state,process.env['FAIR_DIST']!);
 ctx=await configureLabContext(await chromium.launchPersistentContext(join(out,'private-profile'),{executablePath:process.env['CHROMIUM_PATH']!,baseURL:'http://localhost:53781',viewport:{width:1440,height:1000}}), ({executablePath:process.env['CHROMIUM_PATH']!,baseURL:'http://localhost:53781',viewport:{width:1440,height:1000}})?.offline === true);await seedProfile(ctx,saved.storage);const p=ctx.pages()[0]??await ctx.newPage();await restoreAuthenticator(p,saved.credentials);await p.goto('/');await p.evaluate(()=>navigator.serviceWorker.ready);await p.reload();await p.waitForFunction(()=>!!navigator.serviceWorker.controller);await openSaved(p,saved.code,true);await p.getByLabel('Go to date',{exact:true}).fill(a.date);expect(await exported(p)).toEqual(a.archive);
 await p.waitForFunction(()=>{const r=(window as any).__maintenanceRead?.();return r?.events.some((e:any)=>e.reason==='preparation-saved') || r?.status.phase==='halted' || r?.diagnostics.completions>0;},undefined,{timeout:60000});result.observation=await p.evaluate(()=>(window as any).__maintenanceRead());
 expect(result.observation.overflow).toBe(0);expect(result.observation.events.some((e:any)=>e.reason==='preparation-saved')).toBe(true);expect(result.observation.status.phase).not.toBe('halted');
 await lock(p);await ctx.close();ctx=undefined;result.archive=archiveIdentity(a.archive);result.outcome='passed';
 }catch(e){result.outcome='failed';result.error=String(e);throw e;}finally{if(ctx){result.final=await(ctx.pages()[0]?.evaluate(()=>(window as any).__maintenanceRead?.()).catch(()=>null));await ctx.close().catch(()=>{});}writeFileSync(join(out,'result.json'),JSON.stringify(result,null,2)+'\n');await stop();}
});

from pathlib import Path
import subprocess,json,hashlib,random
r=Path(__file__).parent;node='/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node';p=r/'source/src/crdt/accountInbound.ts';good=p.read_text();fault=good.replace('stored !== undefined || storedPhysical !== undefined ? "stored" : "live"','stored !== undefined ? "stored" : "live"');assert fault!=good;(r/'stored-mode326-good.sha256').write_text(hashlib.sha256(good.encode()).hexdigest()+'\n')
try:
 p.write_text(fault)
 with(r/'stored-mode326-fault.log').open('w')as f:out=subprocess.run([node,'node_modules/vitest/vitest.mjs','run','test/labStoredMode326.test.ts','test/labStoredExternal326-P1.test.ts','test/labStoredReaders326-P1.test.ts','--testNamePattern','replays legacy|full census|handoff cut|replacementSource|membershipReading','--reporter=verbose'],cwd=r/'source',stdout=f,stderr=subprocess.STDOUT)
 assert out.returncode!=0,'Fault not detected'
finally:p.write_text(good)
(r/'stored-mode326-fault.json').write_text(json.dumps({'control':'restore old P mode omission only; no timed journey','childExit':out.returncode,'faultDetected':True,'sourceRestoredExact':hashlib.sha256(p.read_bytes()).hexdigest()==(r/'stored-mode326-good.sha256').read_text().strip()})+'\n')
# Declare screen, selection and stops before any timed browser journey.
plan=[];rng=random.Random(326)
for rep in range(1,4):
 block=[(delay,b,pp,1)for delay in[0,50]for b in[0,1]for pp in[0,1]]+[(0,1,0,0)];rng.shuffle(block)
 for delay,b,pp,e in block:plan.append({'name':f'screen326-r{rep}-d{delay}-E{e}B{b}P{pp}','replicate':rep,'rtt':delay,'eb':f'{e}{b}','pp':bool(pp),'bits':'10101','SY':'1N','repairMs':1000,'labOnly':True,'acceptanceCredit':False,'config':'worker-owner.config.ts','fileFilter':'worker-owner.spec.ts','grep':'lab G V deep joined with cold reopen$','result':'deep-gv/result.json'})
(r/'screen326-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
(r/'cut326-plan.json').write_text(json.dumps([{'name':'cut326-P1-aged','rtt':0,'eb':'11','pp':True,'bits':'10101','SY':'1N','repairMs':1000,'config':'dense-cut.config.ts','fileFilter':'dense-cut.spec.ts','result':'dense-cut/result.json'}],indent=2)+'\n')
(r/'PROTOCOL326.md').write_text('''# Phase 326 — declared before timed journeys

Lab only, fictional accounts only, no acceptance credit/landing/hardening/release/default change. Keep all parent roots, all old runs and failures. P means parsed-page reuse; old dense receipt factor stays on, V0 full-prefix, F absent, G8/R1000/SY1N, D0, quiet750. Limits and all original gates/deadlines unchanged: 0ms deep30s, input16ms, peer/every-marker2500ms, maintenance120s, >=60 overlap only grown fixtures. 50ms is report-only as a gate. External5s CPU/top-process logs on every timed journey, no concurrent build/heavy analysis. One journey is the independent unit, not keys or directions.

Before timed browser work: explicit private stored/live mode and all expectedRecord branch review; P0/P1 >30s-expired legacy/dense stored replay, expired live refusal, stored empty/duplicate refusal, real inboundLedger/handoffHistory/membershipReading/replacementSource callers and deliberate old-mode fault sensitivity. Preserve all signatures, chain, authority, expiry on live requests, witness, exact canonical bytes and erasure. Interior native cut with real31s wait before fresh-owner cold, unchanged remaining deadlines.

Screen: all27 declared new journeys in screen326-plan.json; three mixed9-case blocks seeded326, E1 B0/B1 × P0/P1 at0/50ms plusE0B1P0 at0ms. Phase324 contributes no replicate. One failing replicate fails its cell. A P1 cold failure marks P disqualified and skips later P1 journeys only, preserving each declared skip; P0 still runs. A non-P cold failure stops the lane. P is never silently repaired within a frozen screen.

Winner rule AMENDED before running: among E1 arms with3/3functional/cold at both delays and all0ms30s gates, choose lowest50ms median; within5% of fastest choose lower median peak index charge at50ms, then lower0ms median, then B0/P0 deterministic tie. Selection is for later lab stages only. 50ms remains diagnostic, not a30s gate. If noP1arm qualifies, later stages and sender study use phase323build3 E+B (SY1N), as directed; never drop gates to make P qualify. Identity and any instrumentation-only sender fork must be explicit.

After screen: two0msWorkerCPU profiles (E1B0P0 and selected stack), same profiler-control session retained through cold. At drain sample Worker Runtime.getHeapUsage without forced GC; report used/total heap and optional embedder/backing storage fields alongside logical index charge, never equate charge with heap. Profiles are diagnostics/no credit. Then3original normal live journeys and3original2048grown withheld journeys on selected stack, all waits/predicates/cold retained. Report each owner, interruptions/retry clocks, index charge, preparation capacity and measured drain; fit index charge versus logical dense positions to predict32MiB cap, label extrapolation and separate row cap. No result is inferred for an unexposed predicate.

Sender addendum325 retained plus paired150at50ms:3policies(coordinated-2000,reference,immediate-inflight) × [single500at0ms,paired150at0ms,paired150at50ms] ×3replicates =27senderjourneys. Paired300keys/device on separate cards and single120keys, identical markers/clock brackets; independent schedules/common start barrier. Exact mixed9-case blocks declared before the stage after winner/fixture identity known. No artificial quiet wait for immediate arm, first eligible send now, edits behind active immutable send use next bounded envelope; commit/input guarantees, retry/backoff/rate/session/bounds unchanged. Same source/observations except policy, build all before mixed runs. Report per-direction peerp50/p95/inputp95, accepted positions/100keys (retry counted once), route read/write/other units, actualcadence/focus, bound splits, measured coldunlock-to-editable/exactness for both persistentprofiles. Sender is report-only; unchanged gates are reported, not default adoption. Single500 brackets the remaining280ms only if observed. No hints withheld in sender study.

Read-only design: one signed multi-publisher tip replacing perpublisher quiet discovery, with completeness, exact scope, fresh authority and bounded logical accounting, rollback/freshness and withheld-hint liveness. No endpoint built. End with separate landing requirements; no hardening begins.
''')
print('Fault detected, source restored, protocol and27screen cases declared')

from pathlib import Path
import json
r=Path(__file__).parent;s=r/'source';p=s/'test/labStoredMode326.test.ts'
p.write_text('''// @vitest-environment node
import{it,expect,vi,afterEach}from'vitest';
import{entry,packet,sources,A}from'./account-inbound/fixtures';
import{reframe,context,hex,live,prior,eventWire}from'./account-inbound-codecs/oracle';
afterEach(()=>{vi.unstubAllGlobals();vi.resetModules();});
async function modules(pp:boolean){vi.stubGlobal('location',{href:'https://lab.invalid/?lab=10101&labSY=1N&labEB=11&labPP='+(pp?'1':'0')});vi.resetModules();return{v:await import('../src/crdt/accountInbound'),r:await import('../src/crdt/inboundRecord')};}
const expired={assertCurrent(){},now:()=>61000};
for(const pp of[false,true]){
it('P'+Number(pp)+' replays legacy and dense signed receipts older than thirty seconds, refusing the same live expired bytes',async()=>{const m=await modules(pp),e=sources().entries[0]!,ctx=context(A),p=reframe(packet(e),{request:r=>{r[13]=30000}});const result=await m.v.verifyInboundPage(ctx,p.request,p.page,live);expect(result.kind).toBe('received');if(result.kind!=='received')throw Error();const legacy=m.r.encodeInboundRecord(m.r.decodeInboundRecord(result.record)),dense=m.r.encodeDenseInbound([m.r.decodeInboundRecord(legacy)]);for(const bytes of[legacy,dense]){const verify=vi.spyOn(crypto.subtle,'verify'),decrypt=vi.spyOn(crypto.subtle,'decrypt');try{const out=await m.v.verifyStoredInbound(ctx,bytes,expired,0);expect(out.kind).toBe('received');expect(verify.mock.calls.length).toBeGreaterThanOrEqual(3);expect(decrypt).toHaveBeenCalledTimes(1);if(out.kind==='received'){expect(out.updates).toEqual(e.updates);out.record.fill(0);for(const u of out.updates)u.fill(0);}}finally{verify.mockRestore();decrypt.mockRestore();}const corrupt=bytes.slice();corrupt[corrupt.length-4]=corrupt[corrupt.length-4]!^1;await expect(m.v.verifyStoredInbound(ctx,corrupt,expired,0)).rejects.toThrow();}await expect(m.v.verifyInboundPage(ctx,p.request,p.page,expired)).rejects.toThrow('expired');});
it('P'+Number(pp)+' refuses empty and duplicate stored outcomes while leaving valid live duplicate semantics intact',async()=>{const m=await modules(pp),e=sources().entries[0]!,ctx=context(A),empty=reframe(packet(e),{request:r=>{r[13]=30000},page:p=>{p[3]=0;p[4]=0;p[5]=[]}});await expect(m.v.verifyStoredInbound(ctx,eventWire(e,ctx,empty),expired)).rejects.toThrow('record');const p=reframe(packet(e),{request:r=>{r[13]=30000}}),c=prior(ctx,e),legacy=eventWire(e,ctx,p);await expect(m.v.verifyStoredInbound(c,legacy,expired)).rejects.toThrow('record');const dense=m.r.encodeDenseInbound([m.r.decodeInboundRecord(legacy)]);await expect(m.v.verifyStoredInbound(c,dense,expired,0)).rejects.toThrow('record');expect((await m.v.verifyInboundPage(c,p.request,p.page,live)).kind).toBe('duplicate');});
}
''')
# Real caller fixtures copied into new lab tests, never old tests. Both P modes and real aged crypto.
base=(s/'test/labDenseReaders.test.ts').read_text()
for pp in [0,1]:
 v=base.replace("import { replayHandoffStream",f"import{{vi as modeVi}}from'vitest';modeVi.hoisted(()=>{{Object.defineProperty(globalThis,'location',{{configurable:true,value:{{href:'https://lab.invalid/?lab=10101&labSY=1N&labPP={pp}'}}}})}});\nimport {{ replayHandoffStream",1)
 v=v.replace('vi.unstubAllGlobals();',"vi.unstubAllGlobals();Object.defineProperty(globalThis,'location',{configurable:true,value:{href:'https://lab.invalid/?lab=10101&labSY=1N&labPP="+str(pp)+"'}});")
 v=v.replace('{assertCurrent(){}}','{assertCurrent(){},now:()=>61000}')
 (s/f'test/labStoredReaders326-P{pp}.test.ts').write_text(v)
v=json.loads((r/'tsconfig.lab.json').read_text());v['include']+=['source/test/labStoredMode326.test.ts','source/test/labStoredReaders326-P0.test.ts','source/test/labStoredReaders326-P1.test.ts'];(r/'tsconfig.lab.json').write_text(json.dumps(v,indent=2)+'\n')

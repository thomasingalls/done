from pathlib import Path
import json,math,statistics
r=Path(__file__).parent

def stat(v):
 s=sorted(v);return {'n':len(s),'p50':s[math.ceil(.5*len(s))-1],'p95':s[math.ceil(.95*len(s))-1],'max':s[-1]}if s else None

def ev(realms):return[e for realm in realms for e in(realm.get('value')or{}).get('events',[])]
rows=[]
for row in json.loads((r/'sender326c-analysis.json').read_text()):
 if row['workload']!='single500':continue
 x=json.loads((r/row['name']/'result.json').read_text());a=1;events=ev(x.get('labAfter',[[],[]])[a]);window=ev([z for z in x.get('labAfter',[[],[]])[a]if z['realm']=='window']);keys=[z for z in x['offers'][a]if z['kind']=='key'];net=x['network'];start=x['typingStartedAt'];end=x.get('newDeliveryAt',x['typingFinishedAt']);posts=[q for q in net if q['actor']==a+1 and q['path']=='/account/delivery/submit'and start<=q['at']<=end];peers=[q for q in net if q['actor']==1 and '/delivery/read'in q['path']and start<=q['at']<=end];b=[z for g in x['clocks']for z in g['rows'][a]];lo=max(z['renderer']-z['after']-1 for z in b);hi=min(z['renderer']-z['before']+1 for z in b);assert lo<=hi;offset=(lo+hi)/2
 flush=[z for z in window if z['kind']=='senderJournalFlush'and z.get('bytes',0)>0 and start<=z['at']-offset<=end];turns=[z for z in events if z['kind']=='driverTurnStart'and z.get('lane')=='send'and start<=z['at']-offset<=end]
 assigned=[]
 for i,key in enumerate(keys[:-1]):
  if key['index']in[0,60,119]:continue
  next_at=keys[i+1]['at'];hits=[q for q in posts if key['at']<=q['at']<next_at];f=[z for z in flush if key['at']<=z['startedAt']-offset<next_at];t=[z for z in turns if key['at']<=z['at']-offset<next_at]
  if len(hits)!=1:continue
  q=hits[0];assigned.append({'key':key['index'],'keyToPostMs':q['at']-key['at'],'submitHeadersMs':None if 'headersAt'not in q else q['headersAt']-q['at'],'keyToFirstFlushEndMs':f[0]['at']-offset-key['at']if f else None,'firstFlushDurationMs':f[0]['ms']if f else None,'keyToFirstSendTurnMs':t[0]['at']-offset-key['at']if t else None})
 data={'name':row['name'],'policy':row['policy'],'functional':row['functional'],'peerLatency':row['directions'][0]['latency'].get('peer'),'localLatency':row['directions'][0]['latency'].get('local'),'submitRequestToHeadersMs':stat([z['headersAt']-z['at']for z in posts if'headersAt'in z]),'readerRequestToHeadersMs':stat([z['headersAt']-z['at']for z in peers if'headersAt'in z]),'nonemptyJournalFlushDurationMs':stat([z['ms']for z in flush]),'temporalKeyToPostMs':stat([z['keyToPostMs']for z in assigned]),'temporalKeyToFlushEndMs':stat([z['keyToFirstFlushEndMs']for z in assigned if z['keyToFirstFlushEndMs']is not None]),'temporalKeyToSendTurnMs':stat([z['keyToFirstSendTurnMs']for z in assigned if z['keyToFirstSendTurnMs']is not None]),'temporalAssociations':assigned,'eventLogLastEpoch':max((e['at']for e in events),default=None),'perRealmEventLastEpoch':{z['realm']:max((e['at']for e in(z.get('value')or{}).get('events',[])),default=None)for z in x.get('labAfter',[[],[]])[a]},'typingFinishedAt':x['typingFinishedAt'],'qualification':'Temporal brackets only: exactly one POST inside a non-marker 500ms key interval does not prove that POST contains that key. No per-envelope acceptance/commit correlation was recorded. Header time includes wire, queue, server verification/commit/signing, and response; peer read can overlap it. Flush/turn events may be truncated before typing finishes. Distributions are not an additive per-key causal decomposition; residual remains unidentified. No paired attribution or invented 280ms residual.'}
 rows.append(data)
(r/'sender326c-attribution.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps([{k:v for k,v in z.items()if k not in['temporalAssociations','qualification']}for z in rows],indent=2))

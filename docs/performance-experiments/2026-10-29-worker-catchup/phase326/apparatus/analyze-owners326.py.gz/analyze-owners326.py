from pathlib import Path
import json,csv,collections,statistics,math
r=Path(__file__).parent
runs=json.loads((r/'grown326-results.json').read_text())
summary=[];attemptRows=[];ownerRows=[];retryRows=[];conditionRows=[]
for run in runs:
 folder=r/run['name'];file=folder/'result.json';file=file if file.exists() else folder/'partial-result.json';x=json.loads(file.read_text())
 last=x.get('typingFinishedAt');cutoff=last+120000 if last is not None else None;observation=x.get('ownerObservation',{})
 traces=x.get('maintenanceTraceBeforeCold')or x.get('finalMaintenanceTraces',[]);statuses=x.get('ownerMaintenanceBeforeCold')or x.get('finalOwnerMaintenance',[])
 owners=[]
 for index,role in enumerate(['reader','writer']):
  realms=traces[index]if len(traces)>index else[];aa=[];ee=[];overflow=0
  for realm in realms:
   value=realm.get('value')or{};aa+=value.get('attempts',[]);ee+=value.get('events',[]);overflow+=value.get('overflow',0)
  aa.sort(key=lambda a:a['startedAt']);ee.sort(key=lambda e:e['at'])
  window=[a for a in aa if cutoff is None or a['startedAt']<=cutoff]
  completed=sorted([a for a in window if a.get('outcome',{}).get('kind')in['removed','already-removed']and a.get('endedAt')is not None],key=lambda a:a['endedAt'])
  first=completed[0]if completed else None
  within=bool(first and cutoff is not None and first['endedAt']<=cutoff)
  capacity=[e for e in ee if e.get('kind')in['PreparationCapacity','preparation-capacity']and(cutoff is None or e['at']<=cutoff)]
  status=statuses[index]if len(statuses)>index and statuses[index]else{}
  terminal=observation.get('terminal',{}).get(role)
  halted=bool((terminal and terminal.get('kind')=='halt-observed')or status.get('status',{}).get('phase')=='halted')
  haltAttempts=[a for a in window if a.get('endedAt')is not None and a.get('outcome',{}).get('kind')not in[None,'removed','already-removed','preparation-saved','skipped']]
  haltAt=haltAttempts[-1]['endedAt']if halted and haltAttempts else None
  haltWithin=bool(haltAt is not None and cutoff is not None and haltAt<=cutoff)
  endpoint='completed-within120s'if within else'late-completion'if first else'halted-within120s'if haltWithin else'halted-at-capture'if halted else'cutoff'if observation else'original-journey-failed-before-observation'
  journals=[(a,j)for a in window for j in(a.get('journals',[])or[{}])]
  peak=max((pair for pair in journals if pair[1]),key=lambda pair:pair[1].get('bytes')or 0,default=None)
  saves=[e for e in ee if e.get('kind')=='checkpoint-saved'and(cutoff is None or e['at']<=cutoff)]
  interrupted=[a for a in window if any(cutoff is None or c['at']<=cutoff for c in a.get('interruptions',[]))]
  jobs=collections.Counter()
  for a in interrupted:
   for condition in a['interruptions']:
    if cutoff is not None and condition['at']>cutoff:continue
    job=condition.get('arrivingJob',{}).get('name')or condition.get('site','unknown');jobs[job]+=1
    conditionRows.append({'case':run['name'],'role':role,'attempt':a['id'],'job':job,'condition':json.dumps(condition,separators=(',',':'))})
  waits=[]
  for event in ee:
   if event.get('kind')!='retry-clock'or(cutoff is not None and event['at']>cutoff):continue
   previous=next((a for a in aa if a['id']==event['attempt']),None)
   following=next((a for a in aa if a['startedAt']>event['at']),None)
   nextInside=bool(following and(cutoff is None or following['startedAt']<=cutoff))
   gap=following['startedAt']-previous['endedAt']if following and previous and previous.get('endedAt')is not None else None
   row={'case':run['name'],'role':role,'attempt':event['attempt'],'priorityOnly':event.get('priorityRetry'),'scheduledRetryMs':event.get('retryMs'),'quietUntilAtScheduling':event.get('quietUntil'),'notBefore':event.get('notBefore'),'endedAt':previous.get('endedAt')if previous else None,'nextAttempt':following['id']if following else None,'nextInside120sWindow':nextInside,'actualGapMs':gap,'censoredAt120s':not nextInside,'afterLastKey':bool(previous and last is not None and previous.get('endedAt',0)>=last)}
   waits.append(row);retryRows.append(row)
  for a,j in journals:
   saved=[e for e in saves if e.get('attempt')==a['id']]
   attemptRows.append({'case':run['name'],'role':role,'attempt':a['id'],'startAfterLastKeyMs':a['startedAt']-last if last is not None else None,'endAfterLastKeyMs':a.get('endedAt')-last if a.get('endedAt')is not None and last is not None else None,'stage':a.get('stage'),'outcome':json.dumps(a.get('outcome')),'entries':j.get('entries'),'pending':j.get('pending'),'hits':j.get('hits'),'newMisses':j.get('misses'),'lookupMisses':j.get('lookupMisses'),'firstMissMs':j.get('firstMiss',{}).get('elapsedMs'),'mapBytes':j.get('bytes'),'byteCap':j.get('byteCap'),'durableBytes':saved[-1]['bytes']if saved else None,'durableDeltas':saved[-1].get('deltas')if saved else None,'replayMs':sum(v.get('ms',0)for v in a.get('replays',[])),'families':json.dumps(j.get('families')),'interruptions':json.dumps(a.get('interruptions',[]))})
  duringTyping=[a['id']for a in window if x.get('typingStartedAt',math.inf)<=a['startedAt']<=x.get('typingFinishedAt',-math.inf)]
  drain=x.get('catchups',[{}])[0].get('completedAt');duringDrain=[a['id']for a in window if index==0 and drain and x['startedAt']<=a['startedAt']<drain]
  cold=next((value for value in x.get('ownerCold',[])if value['role']==role),None)
  data={'role':role,'endpoint':endpoint,'completionAfterLastKeyMs':first['endedAt']-last if first and last is not None else None,'completedWithin120s':within,'nativeCompletionAt':first['endedAt']if first else None,'attemptsThroughCutoff':len(window),'attemptsCaptured':len(aa),'interruptedAttemptsThroughCutoff':len(interrupted),'interruptionConditionsByJob':dict(jobs),'retryClocks':waits,'peakMapBytesObserved':peak[1].get('bytes')if peak else None,'peakMapFamilies':peak[1].get('families')if peak else None,'peakJournalSnapshot':peak[1]if peak else None,'peakDurablePayloadBytesThroughCutoff':max((e['bytes']for e in saves),default=None),'maximumSavedDeltas':max((e.get('deltas',0)for e in saves),default=None),'maximumSavedChunks':max((e.get('chunks',0)for e in saves),default=None),'preparationByteCap':33554432,'capacityRefusalsThroughCutoff':len(capacity),'haltedAtCapture':halted,'haltWithin120s':haltWithin,'haltAfterLastKeyMs':haltAt-last if haltAt is not None and last is not None else None,'lastStatus':status.get('status'),'lastOutcome':window[-1].get('outcome')if window else None,'terminalSample':terminal,'nativeTraceOverflow':overflow,'newStartsDuringTyping':duringTyping,'newStartsDuringReaderDrain':duringDrain,'cold':cold,'journalPeakQualification':'Observed import/disposal snapshots through pre-cold capture; an active journal may be a lower bound. Durable bytes are saved delta payload, not encrypted disk usage.'}
  owners.append(data)
  ownerRows.append({'case':run['name'],'mode':'withheld'if run['withhold']else'normal','role':role,'endpoint':endpoint,'completionAfterLastKeyMs':data['completionAfterLastKeyMs'],'completedWithin120s':within,'attempts':len(window),'interruptedAttempts':len(interrupted),'jobs':json.dumps(dict(jobs)),'retryClocksMs':json.dumps([v['scheduledRetryMs']for v in waits]),'actualGapsMs':json.dumps([v['actualGapMs']if not v['censoredAt120s']else None for v in waits]),'peakMapBytes':data['peakMapBytesObserved'],'peakDurablePayloadBytes':data['peakDurablePayloadBytesThroughCutoff'],'capacityRefusals':len(capacity),'halted':halted,'coldOutcome':cold.get('outcome')if cold else'not reached','coldArchiveExact':cold.get('archiveExact')if cold else None})
 samples=[json.loads(s)for s in(folder/'host-load.jsonl').read_text().splitlines()];busy=[100-z['hostPercent']['idle']for z in samples if z.get('kind')=='load']
 keys=[o for o in x.get('offers',[])if o['kind']=='key'];drain=x.get('catchups',[{}])[0].get('completedAt');overlap=sum(o['at']<drain for o in keys)if drain else None
 summary.append({**run,'owners':owners,'typingFinishedAt':last,'cutoffAt':cutoff,'observation':observation,'overlapKeysInformation':overlap,'originalFunctionalOutcome':x.get('outcome'),'originalError':x.get('error'),'originalWriterWaitSatisfied':bool(x.get('guards',{}).get('maintenanceFinishesAfterInput')),'originalColdGuard':bool(x.get('guards',{}).get('bothOfflineColdProfilesExact')),'hostBusyMedian':statistics.median(busy)if busy else None,'hostBusyMaximum':max(busy)if busy else None,'noAcceptanceVerdict':True,'timingQualification':'Native performanceEpoch minus Node typingFinishedAt, as in320; one-second status samples bound observation, not exact completion. No gate credit.'})
(r/'grown326-owners-analysis.json').write_text(json.dumps(summary,indent=2)+'\n')
for name,data in [('grown326-owners.csv',ownerRows),('grown326-attempts.csv',attemptRows),('grown326-retries.csv',retryRows),('grown326-interruptions.csv',conditionRows)]:
 if data:
  with(r/name).open('w',newline='')as f:w=csv.DictWriter(f,fieldnames=list(data[0]),lineterminator='\n');w.writeheader();w.writerows(data)
for row in summary:
 print(row['name'],'host',row['hostBusyMedian'])
 for owner in row['owners']:print(json.dumps({k:owner.get(k)for k in ['role','endpoint','completionAfterLastKeyMs','attemptsThroughCutoff','interruptedAttemptsThroughCutoff','interruptionConditionsByJob','peakMapBytesObserved','peakDurablePayloadBytesThroughCutoff','capacityRefusalsThroughCutoff','cold']}))

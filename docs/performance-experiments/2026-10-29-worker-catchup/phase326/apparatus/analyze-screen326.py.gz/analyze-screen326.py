from pathlib import Path
import json,collections,statistics,csv,hashlib
r=Path(__file__).parent;key='screen326';plan=json.loads((r/(key+'-plan.json')).read_text());receipts=json.loads((r/(key+'-results.json')).read_text());rows=[];assert len(receipts)==27
for q in receipts:
 if q.get('status','').startswith('SKIPPED'):
  rows.append({**q,'functional':False,'coldExact':False,'drainMs':None,'indexPeak':None});continue
 x=json.loads((r/q['name']/q['result']).read_text());t0=x['startedAt'];duration=x.get('timeTo1025Ms');end=t0+duration if duration is not None else t0;stats=x.get('workerAtDrain',{});events=stats.get('events',[]);active=[v for v in events if t0<=v['at']<=end];indexes=[v for v in events if v['kind']=='indexBudget'];loads=[json.loads(v)for v in(r/q['name']/'host-load.jsonl').read_text().splitlines()];busy=[100-v['hostPercent']['idle']for v in loads if v.get('kind')=='load'];budget=[e for e in x.get('budgetAfter',{}).get('budget',{}).get('events',[])if t0<=e['at']<=end];commits=[v for v in x.get('worker',{}).get('events',[])if v['kind']=='inboundCommit'and v['at']>=t0];total=0;cross={}
 for v in commits:
  total+=v['positions']
  for k in [700,1025]:
   if total>=k and k not in cross:cross[k]=v['at']-t0
 if duration is not None:assert total==1025 and abs(cross[1025]-duration)<.1
 row={**q,'functional':q['childExit']==0 and x.get('outcome')=='passed'and x.get('guards',{}).get('originalAccountReaderColdExact',False),'coldExact':bool(x.get('guards',{}).get('originalAccountReaderColdExact')),'drainMs':duration,'clientValidationMs':sum(e.get('ms',0)for e in active if e['kind']=='clientValidation'),'indexPeak':max((e['chargedBytes']for e in indexes),default=None),'indexLast':indexes[-1]if indexes else None,'indexFallbacks':len([e for e in indexes if not e['fits']]),'tokens':sum(e.get('units',0)for e in budget),'budgetRefusals':[e for e in budget if any(s in e['kind']for s in ['refus','denied','capacity','limit'])or e.get('allowed')is False or e.get('ok')is False],'codec':{k:v for k,v in stats.items()if k.startswith('codec')},'hostBusyMedian':statistics.median(busy)if busy else None,'hostBusyMax':max(busy)if busy else None,'eventOverflow':stats.get('eventOverflow',0),'independentCommitPositions':total,'labOnly':True,'acceptanceCredit':False};rows.append(row)
(r/'screen326-analysis.json').write_text(json.dumps(rows,indent=2)+'\n');cells=[]
for eb,pp,delay in sorted(set((q['eb'],q['pp'],q['rtt'])for q in plan)):
 v=[x for x in rows if(x['eb'],x['pp'],x['rtt'])==(eb,pp,delay)];functional=len(v)==3 and all(x['functional']for x in v);cells.append({'eb':eb,'pp':pp,'rtt':delay,'n':len(v),'functionalCold3of3':functional,'drainsMs':[x['drainMs']for x in v],'medianDrainMs':statistics.median(x['drainMs']for x in v)if all(x['drainMs']is not None for x in v)else None,'medianIndexPeakBytes':statistics.median(x['indexPeak']for x in v)if all(x['indexPeak']is not None for x in v)else None,'zeroMsGate':functional and all(x.get('deep30Pass',False)for x in v)if delay==0 else None})
(r/'screen326-cells.json').write_text(json.dumps(cells,indent=2)+'\n');eligible=[]
for eb,pp in sorted(set((x['eb'],x['pp'])for x in cells if x['eb'][0]=='1')):
 a=next(x for x in cells if(x['eb'],x['pp'],x['rtt'])==(eb,pp,0));b=next(x for x in cells if(x['eb'],x['pp'],x['rtt'])==(eb,pp,50))
 if a['zeroMsGate']and b['functionalCold3of3']:eligible.append({'eb':eb,'pp':pp,'median50Ms':b['medianDrainMs'],'median0Ms':a['medianDrainMs'],'index50Bytes':b['medianIndexPeakBytes']})
if not any(v['pp']for v in eligible):selection={'fallback323':True,'eb':'11','pp':False,'dist':'/private/tmp/done-idle-read-ahead-lab-20261101/combined-dist','source':'/private/tmp/done-idle-read-ahead-lab-20261101/source','why':'No P1 arm qualifies; operator fallback to phase323build3 E+B/SY1N'}
else:
 fastest=min(x['median50Ms']for x in eligible);tied=[x for x in eligible if x['median50Ms']<=fastest*1.05];winner=min(tied,key=lambda x:(x['index50Bytes'],x['median0Ms'],x['eb'][1],x['pp']));selection={**winner,'fallback323':False,'dist':str(r/'combined-dist'),'source':str(r/'source')}
selection.update(eligible=eligible,rule='E1:3/3functional/cold at both delays, all0ms30s; lowest50msmedian, within5%lowerindexcharge; noP1qualifies=>323E+B fallback',labOnly=True,acceptanceCredit=False);(r/'selection326.json').write_text(json.dumps(selection,indent=2)+'\n')
columns=['name','eb','pp','rtt','functional','coldExact','drainMs','clientValidationMs','indexPeak','tokens','hostBusyMedian','hostBusyMax','eventOverflow']
with(r/'screen326-runs.csv').open('w')as f:w=csv.DictWriter(f,fieldnames=columns,lineterminator='\n');w.writeheader();w.writerows({k:x.get(k)for k in columns}for x in rows)
print(json.dumps(cells,indent=2));print(json.dumps(selection,indent=2))

from pathlib import Path
import json,gzip,hashlib,subprocess,shutil
r=Path(__file__).parent;repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');d=repo/'docs/performance-experiments/2026-10-29-worker-catchup/phase326';d.mkdir(exist_ok=False);seen=set();items=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def keep(p,cat='evidence'):
 p=Path(p)
 if not p.is_file()or p.is_symlink():return
 relative=str(p.relative_to(r));dest=d/cat/(relative+'.gz')
 if str(dest)in seen:return
 seen.add(str(dest));raw=p.read_bytes();dest.parent.mkdir(parents=True,exist_ok=True);packed=gzip.compress(raw,compresslevel=6,mtime=0);dest.write_bytes(packed);items.append({'source':str(p),'copy':str(dest.relative_to(d)),'rawSha256':sha(raw),'bytes':len(raw),'gzipSha256':sha(packed)})
# All own phase declarations/results and every reached case, including failed apparatus attempts.
stages=[]
for p in sorted(r.glob('*326*-inputs.json')):
 try:x=json.loads(p.read_text())
 except Exception:continue
 if not isinstance(x,dict)or'plan'not in x:continue
 stages.append(p.stem.removesuffix('-inputs'))
for key in stages:
 for suffix in ['plan.json','inputs.json','results.json','driver.log']:keep(r/(key+'-'+suffix))
 plan=json.loads((r/(key+'-inputs.json')).read_text())['plan']
 for c in plan:
  out=r/c['name']
  for pattern in ['*.json','*.jsonl','*.log','deep-gv/*.json','deep-gv/*.log','deep-gv/*.cpuprofile','deep-gv/*.jsonl','artifacts/**/error-context.md']:
   for p in out.glob(pattern):keep(p)
# Metadata/results, all failed checks, and inert apparatus/recipe at this phase root.
for p in sorted(r.iterdir()):
 if p.is_file()and not p.is_symlink()and ('326'in p.name or p.name in ['canonical-start.json','build-identity.json','build-flags.json','container-image.json','frontend-build.log','lab-build.log','release-flags.json','playwright-storage-source.txt']):
  if p.suffix in ['.py','.mjs','.ts']or'.spec.'in p.name:keep(p,'apparatus')
  elif p.suffix in ['.json','.jsonl','.log','.md','.csv','.txt','.diff','.patch']:keep(p)
for name in ['build-lab.py','build.mjs','run-stage.py','host_load.py','lab-context.mjs','observer.mjs','container-service.mjs','read-request.mjs','notification-probe.mjs','fixture-roles.mjs','harness/tsconfig.json']:
 keep(r/name,'apparatus')
for p in (r/'harness/test/account-continuation-lab').rglob('*'):
 if p.is_file():keep(p,'apparatus')
for p in (r/'source/test').glob('lab*326*'):keep(p,'apparatus')
for p in (r/'sender-source/test').glob('lab*326*'):keep(p,'apparatus')
for family in ['sender-coordinated-2000','sender-reference','sender-immediate-inflight']:
 for name in ['build-identity.json','build-flags.json','frontend-build.log','lab-build.log','release-flags.json','container-image.json']:keep(r/family/name)
# Private inert deltas are reproduction material, never applied as application patches.
for left,right,name in [(Path('/private/tmp/done-page-parse-lab-20261101/source'),r/'source','stored-repair326.diff'),(r/'source',r/'sender-source','sender-policy326.diff')]:
 paths=[]
 for sub in ['src','account-protocol','test']:
  paths+=sorted(set(str(p.relative_to(left))for p in(left/sub).rglob('*')if p.is_file())|set(str(p.relative_to(right))for p in(right/sub).rglob('*')if p.is_file()))
 chunks=[]
 for n in paths:
  a=left/n;b=right/n
  if a.exists()and b.exists()and a.read_bytes()==b.read_bytes():continue
  q=subprocess.run(['git','diff','--no-index','--binary','--',str(a)if a.exists()else'/dev/null',str(b)if b.exists()else'/dev/null'],capture_output=True);assert q.returncode in[0,1];chunks.append(q.stdout)
 (r/name).write_bytes(b''.join(chunks));keep(r/name,'apparatus')
# Human-readable analyses alongside their preserved compressed originals.
for name in ['PROTOCOL326.md','MODE-REPAIR326.md','SIGNED-TIPS326.md','screen326-cells.json','screen326-runs.csv','selection326.json','cap326-analysis.json','sender326c-cells.json','sender326c-runs.csv','sender326c-attribution.json','independent326-check.json']:
 p=r/name
 if p.exists():shutil.copy2(p,d/name)
index={'labRoot':str(r),'parentRoots':['/private/tmp/done-page-parse-lab-20261101','/private/tmp/done-idle-read-ahead-lab-20261101'],'labOnly':True,'acceptanceCredit':False,'items':items,'compiledBuildsBrowserProfilesCredentialsDatabasesNotCopied':True,'inertSourceDeltasAreReproductionEvidenceOnly':True,'allFailedAndReachedCasesRetained':True};(d/'evidence-index.json').write_text(json.dumps(index,indent=2)+'\n')
for x in items:
 raw=gzip.decompress((d/x['copy']).read_bytes());assert sha(raw)==x['rawSha256']and raw==Path(x['source']).read_bytes();assert sha((d/x['copy']).read_bytes())==x['gzipSha256']
(d/'evidence-check.json').write_text(json.dumps({'copiesVerified':len(items),'allRawAndCompressedHashesMatch':True,'labOnly':True,'acceptanceCredit':False},indent=2)+'\n');print('Preserved',len(items),'files')

from pathlib import Path
import hashlib,json
r=Path('/private/tmp/done-verified-selection-control-20261030');h=r/'harness/test/account-continuation-lab';s=(h/'late.spec.ts').read_text();s="import { monitorEventLoopDelay } from 'node:perf_hooks';\n"+s
probe="""
function installUiDelayProbe() {
 const now=()=>performance.timeOrigin+performance.now();
 const state:any={support:{event:PerformanceObserver.supportedEntryTypes.includes('event'),longtask:PerformanceObserver.supportedEntryTypes.includes('longtask')},events:[],tasks:[],inputs:[],frameGaps:[],dropped:0};
 let armed=false,frame=0,last=0;const observers:PerformanceObserver[]=[];
 const push=(key:string,value:any)=>{if(state[key].length>=20000)state.dropped++;else state[key].push(value);};
 const consume=(type:string,rows:PerformanceEntry[])=>{if(!armed)return;for(const v of rows){const e:any=v;if(type==='event'){if(e.target instanceof Element&&!e.target.closest('.card'))continue;push('events',{name:e.name,start:performance.timeOrigin+e.startTime,processingStart:performance.timeOrigin+e.processingStart,processingEnd:performance.timeOrigin+e.processingEnd,duration:e.duration,interactionId:e.interactionId});}else push('tasks',{name:e.name,start:performance.timeOrigin+e.startTime,duration:e.duration});}};
 const paint=()=>{if(!armed)return;const at=now();if(last&&at-last>20)push('frameGaps',{start:last,end:at,duration:at-last});last=at;frame=requestAnimationFrame(paint);};
 for(const kind of ['keydown','beforeinput'])addEventListener(kind,(e:Event)=>{if(!armed||!(e.target instanceof Element)||!e.target.closest('.card'))return;push('inputs',{kind,at:now(),stamp:performance.timeOrigin+e.timeStamp,trusted:e.isTrusted,focused:document.hasFocus(),visible:document.visibilityState});},true);
 (window as any).__uiDelay={arm(){if(armed)return;armed=true;state.armedAt=now();for(const type of ['event','longtask'])if((state.support as any)[type]){const o=new PerformanceObserver(list=>consume(type,list.getEntries()));o.observe({type,buffered:false,...(type==='event'?{durationThreshold:16}:{})});observers.push(o);}last=now();frame=requestAnimationFrame(paint);},stop(){if(armed){for(const o of observers){consume((o as any).__kind??'',o.takeRecords());o.disconnect();}state.stoppedAt=now();armed=false;cancelAnimationFrame(frame);}return structuredClone(state);}};
}
"""
# Keep observer type explicitly for safe takeRecords; no record values/keys/targets are serialized.
probe=probe.replace("observers.push(o);", "(o as any).__kind=type;observers.push(o);")
anchor="test('same-account late writing";assert s.count(anchor)==1;s=s.replace(anchor,probe+'\n'+anchor)
anchor=" const save=()=>writeFileSync(join(out,'partial-result.json'),JSON.stringify(result,null,2)+'\\n');";assert s.count(anchor)==1
replacement=""" let heartbeat:ReturnType<typeof setInterval>|undefined,loop:ReturnType<typeof monitorEventLoopDelay>|undefined,driverLast=0;result.driverGaps=[];result.driverHandlerCosts=[];result.driverSaveCosts=[];
 const save=()=>{const start=performance.timeOrigin+performance.now();writeFileSync(join(out,'partial-result.json'),JSON.stringify(result,null,2)+'\\n');result.driverSaveCosts.push({start,end:performance.timeOrigin+performance.now()});};
 const armDriver=()=>{driverLast=performance.timeOrigin+performance.now();loop=monitorEventLoopDelay({resolution:10});loop.enable();heartbeat=setInterval(()=>{const end=performance.timeOrigin+performance.now();if(end-driverLast>40)result.driverGaps.push({start:driverLast,end,duration:end-driverLast});driverLast=end;},20);};
 const collect=async()=>{if(result.uiDelay)return;if(heartbeat)clearInterval(heartbeat);loop?.disable();result.driverLoop=loop?{p50ms:loop.percentile(50)/1e6,p95ms:loop.percentile(95)/1e6,maxMs:loop.max/1e6}:null;const p=contexts[1]?.pages()[0];if(p&&!p.isClosed())result.uiDelay=await p.evaluate(()=>(window as any).__uiDelay.stop());};
"""
s=s.replace(anchor,replacement)
anchor='await p.addInitScript(lateProbe,markers);';assert s.count(anchor)==1;s=s.replace(anchor,anchor+'await p.addInitScript(installUiDelayProbe);')
anchor="const row={label:'H'+index,path,at:(performance.timeOrigin + performance.now()),...readRequestInfo(q)};";assert s.count(anchor)==1;s=s.replace(anchor,"const began=performance.timeOrigin+performance.now();"+anchor+"result.driverHandlerCosts.push({path,start:began,end:performance.timeOrigin+performance.now()});")
anchor="await focus(writer.p,'H',true);result.typingStartedAt=";assert s.count(anchor)==1;s=s.replace(anchor,"await focus(writer.p,'H',true);await writer.p.evaluate(()=>(window as any).__uiDelay.arm());armDriver();result.typingStartedAt=")
anchor=' await Promise.all(catchups);';assert s.count(anchor)==1;s=s.replace(anchor,' await collect();'+anchor)
anchor=' finally{try{result.finalDiagnostics=';assert s.count(anchor)==1;s=s.replace(anchor," finally{try{await collect();}catch(e){result.uiDelayCaptureError=String(e);}try{result.finalDiagnostics=")
(h/'input-diagnostic.spec.ts').write_text(s);(h/'input-diagnostic.config.ts').write_text((h/'late.config.ts').read_text().replace('late.spec.ts','input-diagnostic.spec.ts'))
# Separate one-journey runner, no modification of previous fixed run plans/results.
original=(r/'run.py').read_text();original=original.replace("plan=json.loads((r/'run-plan.json').read_text())", "plan=[{'name':'04-input-diagnostic-withheld','mode':'late','variant':'after','withhold':True,'config':'input-diagnostic.config.ts'}]")
(r/'run-input-diagnostic.py').write_text(original);files=['harness/test/account-continuation-lab/input-diagnostic.spec.ts','harness/test/account-continuation-lab/input-diagnostic.config.ts','run-input-diagnostic.py'];(r/'input-diagnostic-identities.json').write_text(json.dumps({f:hashlib.sha256((r/f).read_bytes()).hexdigest()for f in files},indent=2)+'\n');print('No product/source/asset changes: bounded UI/driver metadata diagnostic prepared')

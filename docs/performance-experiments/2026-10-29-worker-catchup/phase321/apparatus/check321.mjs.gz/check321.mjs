import {parse} from '/Users/thomasingalls/.codex/worktrees/7fda/done/node_modules/.pnpm/@babel+parser@7.29.7/node_modules/@babel/parser/lib/index.js';
import fs from 'node:fs';
import crypto from 'node:crypto';
const root=new URL('.',import.meta.url).pathname;
const original='harness/test/account-continuation-lab/grown-maintenance.spec.ts';
const copied='harness/test/account-continuation-lab/phase321/grown-maintenance.spec.ts';
function clean(v){if(Array.isArray(v))return v.map(clean);if(v&&typeof v==='object')return Object.fromEntries(Object.entries(v).filter(([k])=>!['start','end','loc','extra','comments','leadingComments','trailingComments','innerComments','tokens'].includes(k)).map(([k,z])=>[k,clean(z)]));return v;}
function base(n){return n?.type==='Identifier'?n.name:n?.type==='CallExpression'?base(n.callee):n?.type==='MemberExpression'?base(n.object):null;}
function inspect(name){const source=fs.readFileSync(root+name,'utf8');const tree=parse(source,{sourceType:'module',plugins:['typescript']});const assertions=[],waits=[],tests=[];function visit(n){if(!n||typeof n!=='object')return;if(Array.isArray(n)){n.forEach(visit);return;}if(n.type==='CallExpression'){const callee=source.slice(n.callee.start,n.callee.end);if(base(n.callee)==='expect')assertions.push(clean(n));if(n.callee.type==='Identifier'&&n.callee.name==='test')tests.push(clean(n.arguments[0]));if(/waitForFunction|waitForTimeout|expect\.poll/.test(callee))waits.push(clean(n));}for(const[k,v]of Object.entries(n))if(!['loc','comments','tokens'].includes(k))visit(v);}visit(tree);return{source,assertions,waits,tests};}
const a=inspect(original),b=inspect(copied);
for(const k of ['assertions','waits','tests'])if(JSON.stringify(a[k])!==JSON.stringify(b[k]))throw Error('Original '+k+' changed');
// Independent equality of the copied body after removing only the declared observations.
let restored=b.source;
const start=restored.indexOf('  // Phase321: diagnostic only.');const end=restored.indexOf('  result.ownerMaintenanceBeforeCold=',start);if(start<0||end<0)throw Error('Missing bounded observation');restored=restored.slice(0,start)+restored.slice(end);
restored=restored.replace("for(const a of [reader,writer]){const coldOwner={role:a.index===1?'reader':'writer',startedAt:performance.timeOrigin+performance.now(),outcome:'started',archiveExact:false};(result.ownerCold??=[]).push(coldOwner);save();await a.ctx.setOffline(true);","for(const a of [reader,writer]){await a.ctx.setOffline(true);");
restored=restored.replace("expect(await exported(p)).toEqual(archives[0]);coldOwner.archiveExact=true;await ctx.close();coldOwner.outcome='passed';(coldOwner as any).completedAt=performance.timeOrigin+performance.now();save();}","expect(await exported(p)).toEqual(archives[0]);await ctx.close();}");
restored=restored.replace("catch(error){const coldOwner=result.ownerCold?.at(-1);if(coldOwner&&coldOwner.outcome!=='passed'){coldOwner.outcome='failed';coldOwner.error=String(error);}result.coldFailure=true;throw error;}","catch(error){result.coldFailure=true;throw error;}");
const expected=a.source.replaceAll("from'./","from'../").replaceAll("from './","from '../").replace("from '../../../lab-context.mjs'","from '../../../../lab-context.mjs'").replaceAll("from'../../../","from'../../../../");
if(restored!==expected)throw Error('Copied body differs outside declared observations/import resolution');
const sha=s=>crypto.createHash('sha256').update(s).digest('hex');
fs.writeFileSync(root+'owners321-ast-check.json',JSON.stringify({originalSha256:sha(a.source),copySha256:sha(b.source),originalAssertionCallNodes:a.assertions.length,originalWaitCallNodes:a.waits.length,testTitleAstExact:true,expectationAndExistingWaitAstsExact:true,originalBodyIncludingColdExactAfterRemovingDeclaredObservations:true,configUnchanged:true,independentParser:'Babel7 TypeScript AST'},null,2)+'\n');
console.log('Original expectation/wait/test ASTs and entire copied body match outside observations');

from pathlib import Path
import json,hashlib,collections,subprocess
r=Path(__file__).parent;repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done')
a=json.loads((r/'owners321-analysis.json').read_text());runs=json.loads((r/'owners321-results.json').read_text());assert len(a)==len(runs)==6
counts=collections.Counter();jobs=collections.Counter();retryCounts=collections.Counter();readerAfterWriter=[];clockRows=[];ownerCold=0
for row in a:
 raw=json.loads((r/row['name']/'result.json').read_text());assert row['originalWriterWaitSatisfied'];assert row['originalColdGuard'];assert row['cutoffAt']==raw['typingFinishedAt']+120000
 assert len(raw['ownerCold'])==2
 for i,owner in enumerate(row['owners']):
  aa=[x for realm in raw['maintenanceTraceBeforeCold'][i]for x in(realm.get('value')or{}).get('attempts',[])];ee=[x for realm in raw['maintenanceTraceBeforeCold'][i]for x in(realm.get('value')or{}).get('events',[])]
  end=min((x['endedAt']for x in aa if x.get('outcome',{}).get('kind')in['removed','already-removed']),default=None)
  assert owner['completionAfterLastKeyMs']==end-raw['typingFinishedAt'];assert owner['completedWithin120s']==(end<=row['cutoffAt'])
  cap=sum(x.get('kind')in['PreparationCapacity','preparation-capacity']and x['at']<=row['cutoffAt']for x in ee);assert owner['capacityRefusalsThroughCutoff']==cap
  for attempt in aa:
   for journal in attempt.get('journals',[]):
    if journal.get('families')is not None:assert sum(v['bytes']for v in journal['families'].values())==journal['bytes']
  counts[owner['role']+'CompletedWithin120s']+=int(owner['completedWithin120s']);counts['capacity']+=cap;counts['halts']+=int(owner['haltedAtCapture']);counts['traceOverflow']+=owner['nativeTraceOverflow']
  assert not owner['newStartsDuringTyping'] and not owner['newStartsDuringReaderDrain']
  assert owner['cold']['outcome']=='passed'and owner['cold']['archiveExact'];ownerCold+=1
  jobs.update(owner['interruptionConditionsByJob'])
  for retry in owner['retryClocks']:
   retryCounts[str(retry['scheduledRetryMs'])]+=1;clockRows.append({'case':row['name'],'role':owner['role'],**retry})
 reader,writer=row['owners'];readerAfterWriter.append({'case':row['name'],'mode':'withheld'if row['withhold']else'normal','readerMinusWriterMs':reader['completionAfterLastKeyMs']-writer['completionAfterLastKeyMs'],'extraObservationMs':row['observation']['endedAt']-row['observation']['startedAt'],'overlapInformation':row['overlapKeysInformation']})
source=json.loads((r/'owners321-inputs.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();old=json.loads((r/'final-gates-inputs.json').read_text());added=set(source['apparatus'])-set(old['apparatus']);assert added=={'harness/test/account-continuation-lab/phase321/grown-maintenance.spec.ts'}
for n,h in old['apparatus'].items():assert source['apparatus'][n]==h and sha(r/n)==h
facts={'journeys':6,'normal':sum(not x['withhold']for x in a),'withheld':sum(x['withhold']for x in a),'owners':12,'counts':dict(counts),'perOwnerColdChecksPassed':ownerCold,'jobs':dict(jobs),'retryClockCountsMs':dict(retryCounts),'interruptedAttempts':sum(o['interruptedAttemptsThroughCutoff']for x in a for o in x['owners']),'originalWriterWaitAllSatisfied':all(x['originalWriterWaitSatisfied']for x in a),'allOriginalColdGuardsSatisfied':all(x['originalColdGuard']for x in a),'allCutoffsAbsolute120s':True,'onlyAddedRuntimeHarnessFile':list(added),'oldAssertionsWaitsConfigAndColdOperationsUnchanged':True,'nativeTimingsIndependentlyRecomputed':True,'journalFamilyBytesIndependentlySummed':True,'noNewTypingOrReaderDrainStarts':True,'diagnosticOnly':True,'acceptanceCredit':False}
(r/'owners321-independent-check.json').write_text(json.dumps(facts,indent=2)+'\n');(r/'owners321-censoring-context.json').write_text(json.dumps(readerAfterWriter,indent=2)+'\n')
print(json.dumps(facts,indent=2));print(json.dumps(readerAfterWriter,indent=2))
print('RETRY DETAILS')
for x in a:
 print(x['name'],'host median/max',x['hostBusyMedian'],x['hostBusyMaximum'])
 for o in x['owners']:
  post=[v['actualGapMs']for v in o['retryClocks']if v['afterLastKey']and not v['censoredAt120s']]
  pre=[v['actualGapMs']for v in o['retryClocks']if not v['afterLastKey']and not v['censoredAt120s']]
  print(o['role'],'post gaps seconds',[round(v/1000,3)for v in post],'pre gaps seconds',[round(v/1000,3)for v in pre])

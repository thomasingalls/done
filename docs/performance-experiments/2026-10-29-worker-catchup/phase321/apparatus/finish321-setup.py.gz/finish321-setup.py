from pathlib import Path
import json,hashlib
r=Path(__file__).parent;p=r/'harness/test/account-continuation-lab/phase321/grown-maintenance.spec.ts';s=p.read_text()
old="map(async({role,actor})=>({role,observedAt:performance.timeOrigin+performance.now(),status:await actor.p.evaluate(()=>{const v=(window as any).__maintenanceRead?.();return v?{phase:v.status.phase,reason:v.status.reason,stage:v.status.progress?.stage,attempts:v.diagnostics.attempts,interruptions:v.diagnostics.interruptions,completions:v.diagnostics.completions}:null;})}))"
new="map(async({role,actor})=>{const observedAt=performance.timeOrigin+performance.now();const status=await actor.p.evaluate(()=>{const v=(window as any).__maintenanceRead?.();return v?{phase:v.status.phase,reason:v.status.reason,stage:v.status.progress?.stage,attempts:v.diagnostics.attempts,interruptions:v.diagnostics.interruptions,completions:v.diagnostics.completions}:null;});return{role,observedAt,sampleReturnedAt:performance.timeOrigin+performance.now(),status};})"
assert s.count(old)==1;s=s.replace(old,new)
start="for(const a of [reader,writer]){await a.ctx.setOffline(true);"
add="for(const a of [reader,writer]){const coldOwner={role:a.index===1?'reader':'writer',startedAt:performance.timeOrigin+performance.now(),outcome:'started',archiveExact:false};(result.ownerCold??=[]).push(coldOwner);save();await a.ctx.setOffline(true);"
assert s.count(start)==1;s=s.replace(start,add)
end="expect(await exported(p)).toEqual(archives[0]);await ctx.close();}result.guards.bothOfflineColdProfilesExact=true;"
endNew="expect(await exported(p)).toEqual(archives[0]);coldOwner.archiveExact=true;await ctx.close();coldOwner.outcome='passed';(coldOwner as any).completedAt=performance.timeOrigin+performance.now();save();}result.guards.bothOfflineColdProfilesExact=true;"
assert s.count(end)==1;s=s.replace(end,endNew)
catch="catch(error){result.coldFailure=true;throw error;}"
catchNew="catch(error){const coldOwner=result.ownerCold?.at(-1);if(coldOwner&&coldOwner.outcome!=='passed'){coldOwner.outcome='failed';coldOwner.error=String(error);}result.coldFailure=true;throw error;}"
assert s.count(catch)==1;s=s.replace(catch,catchNew);p.write_text(s)
protocol=r/'PHASE321-PROTOCOL.md';v=protocol.read_text();v=v.replace('and the cold suffix is byte-exact','and the original cold operations remain in order').replace('Then execute the original cold steps unchanged.','Then execute the original cold operations unchanged, adding only per-owner start/archive-exact/end/failure records around them. No cold assertion or browser operation changes.');protocol.write_text(v)
identity=json.loads((r/'owners321-copy-identity.json').read_text());identity['copySha256']=hashlib.sha256(p.read_bytes()).hexdigest();(r/'owners321-copy-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
# A dedicated driver selects the nested copy through the existing unchanged config.
s=(r/'run-matrix.py').read_text().replace("key=sys.argv[1]","key='owners321'")
s=s.replace(" if c.get('grep'):cmd+=['--grep',c['grep']]", " cmd+=[c['fileFilter']]\n if c.get('grep'):cmd+=['--grep',c['grep']]")
s=s.replace(" if pre.returncode:print('LIST FAILED',c['name'],flush=True);sys.exit(4)", " if pre.returncode or 'Total: 1 test in 1 file'not in(out/'list.log').read_text():print('LIST FAILED',c['name'],flush=True);sys.exit(4)")
s=s.replace("raw=out/c.get('result','result.json');x=json.loads(raw.read_text())if raw.exists()else{}", "raw=out/c.get('result','result.json');raw=raw if raw.exists()else out/'partial-result.json';x=json.loads(raw.read_text())if raw.exists()else{}")
s=s.replace("'guards':x.get('guards',{}),", "'guards':x.get('guards',{}),'ownerObservation':x.get('ownerObservation',{}).get('terminal'),'ownerCold':x.get('ownerCold'),")
(r/'run321.py').write_text(s);compile(s,'run321.py','exec')
print('Finished observation-only copy and six-run driver; no original spec/config/source/build changed')

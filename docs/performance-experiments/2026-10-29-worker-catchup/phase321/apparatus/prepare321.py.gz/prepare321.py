from pathlib import Path
import json,datetime,hashlib,shutil
r=Path(__file__).parent
p=r/'harness/test/account-continuation-lab/grown-maintenance.spec.ts'
source=p.read_text()
folder=p.parent/'phase321'
folder.mkdir(exist_ok=False)
# A nested copy keeps the original config/testMatch and all assertion bodies.
copy=source.replace("from'./", "from'../").replace("from './", "from '../").replace("from '../../../lab-context.mjs'", "from '../../../../lab-context.mjs'").replace("from'../../../", "from'../../../../")
anchor="  result.ownerMaintenanceBeforeCold=await Promise.all([reader,writer].map(a=>a.p.evaluate(()=>(window as any).__maintenanceRead?.())));"
assert copy.count(anchor)==1
observation='''  // Phase321: diagnostic only. The original writer wait/assertions above are unchanged.
  // The limit is absolute, so time already spent waiting for the writer is not added again.
  const diagnosticCutoff=result.typingFinishedAt+120000;
  result.ownerObservation={diagnosticOnly:true,acceptanceCredit:false,cutoffAt:diagnosticCutoff,lastKeyReferenceAt:result.typingFinishedAt,startedAt:performance.timeOrigin+performance.now(),pollMs:1000,samples:[],terminal:{}};
  const observing=[{role:'reader',actor:reader},{role:'writer',actor:writer}];
  while(true){
    const snapshots=await Promise.all(observing.filter(v=>!result.ownerObservation.terminal[v.role]).map(async({role,actor})=>({role,observedAt:performance.timeOrigin+performance.now(),status:await actor.p.evaluate(()=>{const v=(window as any).__maintenanceRead?.();return v?{phase:v.status.phase,reason:v.status.reason,stage:v.status.progress?.stage,attempts:v.diagnostics.attempts,interruptions:v.diagnostics.interruptions,completions:v.diagnostics.completions}:null;})})));
    for(const sample of snapshots){
      result.ownerObservation.samples.push(sample);
      if(sample.status?.completions>=1||sample.status?.phase==='halted')result.ownerObservation.terminal[sample.role]={...sample,kind:sample.status.completions>=1?'completion-observed':'halt-observed'};
    }
    const observedNow=performance.timeOrigin+performance.now();
    if(Object.keys(result.ownerObservation.terminal).length===2||observedNow>=diagnosticCutoff){
      for(const {role}of observing)if(!result.ownerObservation.terminal[role])result.ownerObservation.terminal[role]={role,kind:'cutoff',observedAt:observedNow};
      result.ownerObservation.endedAt=observedNow;break;
    }
    await new Promise<void>(resolve=>setTimeout(resolve,Math.min(1000,diagnosticCutoff-observedNow)));
  }
  save();
'''
copy=copy.replace(anchor,observation+anchor)
(folder/'grown-maintenance.spec.ts').write_text(copy)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
order=[(1,False),(1,True),(2,True),(2,False),(3,False),(3,True)]
rows=[]
for i,(rep,withhold)in enumerate(order,1):
 rows.append({'name':f'owners321-{i:02d}-r{rep}-'+('withheld'if withhold else'normal'),'replicate':rep,'withhold':withhold,'bits':'10101','SY':'11','repairMs':1000,'P':1,'V':0,'D':0,'config':'grown-maintenance.config.ts','fileFilter':'test/account-continuation-lab/phase321/grown-maintenance.spec.ts','fixture':str(r/'cohort-P1/fixture.json'),'result':'result.json','diagnosticOnly':True,'labOnly':True,'acceptanceCredit':False})
assert json.loads((r/'cohort-P1/fixture.json').read_text())['accounts'][0]['date']==datetime.datetime.now(datetime.timezone.utc).date().isoformat()
(r/'owners321-plan.json').write_text(json.dumps(rows,indent=2)+'\n')
(r/'PHASE321-PROTOCOL.md').write_text('''# Phase321 — grown owner-completion observation

Declared at '''+datetime.datetime.now(datetime.timezone.utc).isoformat()+''', before any journey. This is one diagnostic, not a gate. Six grown journeys on cohort-P1: normal/withheld, withheld/normal, normal/withheld, three each. Exact order/names are owners321-plan.json. Frozen phase313 assets, G8/R1000/S1Y1/P1/V0/D0 (10101), networkrange4, quiet750. Same pinned Chrome156, logical rates/fairness,1CPU/1GiBserver and service automation off. No source/build changes. Every run gets the same5sexternal CPU/top-executable log; no concurrent builds/analysis/freezer. Fictional profiles only; every run retained.

The only new spec is a nested observation-only copy of the phase320grown spec, selected by file filter through the UNCHANGED original config. Relative imports resolve to the same helpers. Every original assertion, test title, writer wait, typing sequence, fault, archive/Undo guard, cold step, timeout and condition remains. No original spec/config is edited. Independent parser/AST checks must confirm the old expectation and wait nodes remain and the cold suffix is byte-exact before running.

After the complete original writer wait/assertions, poll each owner not yet observed complete/halted once per1000ms, without input/focus/lifecycle changes. Stop extra observation when both owners are complete/halted, or at the absolute cutoff typingFinishedAt+120000. This is the prior timestamp captured immediately after the last key returns, not another120s after the writer. Preserve actual offers/returned timestamps and the polling times. If the original writer wait extends beyond this cutoff, add no further wait and classify terminal events by their actual trace timestamp, never credit late completion as within120s. Sampling overhead/Node-Worker clock alignment are diagnostic qualifications; exact completion times come from retained native attempt traces, not poll quantization. Then execute the original cold steps unchanged. No reader-completion assertion is added. A wrong prediction, cutoff, capacity refusal or other non-cold failure remains and later declared journeys continue. Any actual no-F cold failure stops immediately as usual. An original writer assertion failure still fails that journey as in320, with its raw partial evidence retained.

Report every owner: completion after last key, whether within120s, attempts, interruptions grouped by exact arriving job, retry clocks and actual/censored gaps, preparation-map and durable-journal peaks/families, capacity/owner-error status, and original cold result. A reader that reaches cutoff is not called complete. Halting does not become parked/capacity. No hardening or fix is built.

## Operator amendment, prospective from321

From now on the >=60-key typing/catch-up overlap predicate applies only to grown fixtures. The assumption that a1,024-position backlog lasts for60keys has expired. Old maintenance cells report overlap as information; EVERY OTHER predicate remains. Phase320's six recorded overlap failures and its cell verdicts remain byte-for-byte unchanged. This321diagnostic has no acceptance verdict; its overlap remains reported with the unchanged grown threshold for context. Record this amendment in the append-only repository records at closure; do not regrade old evidence.
''')
(r/'owners321-copy-identity.json').write_text(json.dumps({'original':str(p),'originalSha256':sha(p),'copy':str(folder/'grown-maintenance.spec.ts'),'copySha256':sha(folder/'grown-maintenance.spec.ts'),'config':str(p.parent/'grown-maintenance.config.ts'),'configSha256':sha(p.parent/'grown-maintenance.config.ts'),'fixtureSha256':sha(r/'cohort-P1/fixture.json'),'declaredAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'labOnly':True,'acceptanceCredit':False},indent=2)+'\n')
print('Declared six diagnostic journeys and created only a nested observation spec copy')

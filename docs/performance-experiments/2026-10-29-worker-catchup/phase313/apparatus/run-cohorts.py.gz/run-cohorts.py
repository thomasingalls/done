from pathlib import Path
import json,subprocess,time,sys,os,signal,hashlib,datetime
r=Path(__file__).parent;node='/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();inputs={'sources':{str(p.relative_to(r/'source')):sha(p)for d in ['src','account-protocol']for p in(r/'source'/d).rglob('*')if p.is_file()},'assets':json.loads((r/'build-identity.json').read_text())['files'],'plan':[0,1],'scope':'lab fixture apparatus, not timing credit'};(r/'cohort2-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n');rows=[]
for P in inputs['plan']:
 assert not(r/'STOP.json').exists();assert all(sha(r/'source'/n)==h for n,h in inputs['sources'].items());assert all(sha(r/'combined-dist'/n)==h for n,h in inputs['assets'].items());assert json.loads((r/'prepared-fixture/fixture.json').read_text())['accounts'][0]['date']==datetime.datetime.now(datetime.timezone.utc).date().isoformat()
 out=r/f'cohort-preparation2-P{P}';out.mkdir(mode=0o700,exist_ok=False);env={**os.environ,'PATH':str(Path(node).parent)+':'+os.environ['PATH'],'FAIR_OUT':str(out),'FAIR_DIST':str(r/'combined-dist'),'FAIR_LAB_BITS':'1010'+str(P),'FAIR_SY_BITS':'11','FAIR_REPAIR_MS':'1500','QUIET_WITHHOLD':'0','FAIR_IDLE_PAUSE':'0','FAIR_PREP_HIDDEN':'0','CHROMIUM_PATH':'/private/tmp/done-civil-gates-browser-20261030/Chrome.app/Contents/MacOS/Google Chrome'};cmd=[node,'node_modules/@playwright/test/cli.js','test','--config','test/account-continuation-lab/dense-cohort.config.ts'];load=out/'host-load.jsonl';sampler=subprocess.Popen([sys.executable,str(r/'host_load.py'),'--out',str(load)]);start=time.time()
 try:
  for i in range(500):
   if Path(str(load)+'.ready').exists():break
   if sampler.poll()is not None:raise RuntimeError('Sampler failed')
   time.sleep(.01)
  else:raise RuntimeError('Sampler not ready')
  print('START cohort',P,flush=True)
  with(out/'console.log').open('w')as f:p=subprocess.run(cmd,cwd=r/'harness',env=env,stdout=f,stderr=subprocess.STDOUT)
 finally:sampler.send_signal(signal.SIGTERM);sampler.wait(timeout=10)
 x=json.loads((out/'result.json').read_text())if(out/'result.json').exists()else{};row={'P':P,'command':cmd,'childExit':p.returncode,'startedAt':start,'finishedAt':time.time(),'outcome':x.get('outcome'),'fixture':x.get('fixturePath'),'labOnly':True,'acceptanceCredit':False};rows.append(row);(out/'receipt.json').write_text(json.dumps(row,indent=2)+'\n');(r/'cohort2-results.json').write_text(json.dumps(rows,indent=2)+'\n');print('RESULT',json.dumps(row),flush=True)
 if x.get('coldFailure'):(r/'STOP.json').write_text(json.dumps(row,indent=2)+'\n');sys.exit(3)
print('Both declared cohort preparations retained',flush=True)

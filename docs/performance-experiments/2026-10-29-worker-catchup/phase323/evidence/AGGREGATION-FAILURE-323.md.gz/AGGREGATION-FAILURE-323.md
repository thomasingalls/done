# Analysis attempt retained

The first aggregate323.py execution exited1 with KeyError: ms at line9. It assumed every replay span had ended. A reader still active at the120s cutoff has an open span with no ms field. The original script is retained as aggregate323-attempt1.py. Stderr was returned in the exec session, not redirected into its empty stdout log. No timed case/result/predicate was changed. The corrected aggregator reports completed-span elapsed sums as lower bounds and counts unfinished spans separately. These are elapsed spans including waits, not sampledCPU. The earlier per-attempt CSV already used get(ms,0); do not treat missing spans as measuredzero.

A separate report-text insertion assertion failed before changing its target file; the next insertion addressed the correct marker. No report or repository file had been written by that failed insertion.

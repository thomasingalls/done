from pathlib import Path
import json,sys,math,collections,statistics,urllib.parse
r=Path(__file__).parent;key=sys.argv[1];out=[];methodRows=[]
def stat(v):
 s=sorted(v);return{'n':len(s),'p50':s[math.ceil(.5*len(s))-1],'p95':s[math.ceil(.95*len(s))-1],'max':s[-1]}if s else None
def counter(realms,name):return sum(a.get('value',{}).get(name,0)for a in realms)
for c in json.loads((r/(key+'-results.json')).read_text()):
 folder=r/c['name'];p=folder/'result.json';p=p if p.exists()else folder/'partial-result.json';x=json.loads(p.read_text());z={'run':c['name'],'arm':c.get('arm',c.get('eb')),'replicate':c.get('replicate'),'childExit':c['childExit'],'coldFailure':c.get('coldFailure'),'coldExact':x.get('guards',{}).get('bothOfflineColdProfilesExact',False),'qualification':'Lab only; no credit. Window totals are before typing through delivery; not full maintenance lifetime. Server-epoch budget interval retains clock-boundary uncertainty. One journey is one unit.'}
 try:
  keys=[v for v in x['offers']if v['kind']=='key'];assert len(keys)==120;v=x['probes'][0];b=[q for a in x['clocks']for q in a['rows'][0]];lo=max(q['renderer']-q['after']-1 for q in b);hi=min(q['renderer']-q['before']+1 for q in b);assert lo<=hi;times=[next(q['at']for q in v['counts']if q['at']>=o['at']-5 and q['count']>=x['baselines'][0]+i)-o['at']-lo for i,o in enumerate(keys,1)];drain=next(q['completedAt']for q in x['catchups']if q['label']=='H1'and q.get('outcome')=='passed');post=[(t,o)for t,o in zip(times,keys)if o['at']>drain]
  z.update(peerMs=stat(times),keysAfterDrain=len(post),postDrainMs=stat([t for t,o in post]),postDrainExposed=bool(post),drainMs=drain-x['startedAt']);events=x['budgetAfter']['budget']['events'];z['tokensTypingWindow']=sum(e.get('units',0)for e in events if x['typingStartedAt']<=e['at']<=x['typingFinishedAt']);z['tokensThroughDelivery']=sum(e.get('units',0)for e in events if x['typingStartedAt']<=e['at']<=x['newDeliveryAt']);z['budgetRefusals']=[e for e in events if x['typingStartedAt']<=e['at']<=x['newDeliveryAt']and(e.get('allowed')is False or e.get('ok')is False or any(t in e.get('kind','')for t in ['refus','denied','capacity']))];z['roleCounters']=[];z['messages']=0;z['chargedBytes']=0;z['channelDeltaComplete']=True
  for role,i in [('reader',0),('writer',1)]:
   before=x['labBefore'][i];after=x['labAfter'][i];z['roleCounters'].append({'role':role,**{n:counter(after,n)-counter(before,n)for n in ['repairActivations','repairIntervals','quietReads','contentHints','namedHints']}});old={a['realm']:a.get('value',{})for a in before};new={a['realm']:a.get('value',{})for a in after}
   for realm in set(old)|set(new):
    if realm not in old or realm not in new:z['channelDeltaComplete']=False;continue
    for k,val in new[realm].items():
     if not(k.startswith('channel:')and k.endswith(':count')):continue
     n=val-old[realm].get(k,0);chargeKey=k[:-5]+'bytes';charge=new[realm].get(chargeKey,0)-old[realm].get(chargeKey,0);_,kind,method,_=k.split(':');methodRows.append({'run':c['name'],'role':role,'realm':'Window'if realm=='window'else'Worker','kind':kind,'method':method,'messages':n,'chargedBytes':charge});z['messages']+=n;z['chargedBytes']+=charge
  z['httpStatusesFullObservation']=dict(collections.Counter(str(q.get('status','pending'))for q in x['network']));z['doseUrls']=sorted({a['realm']for group in x['labAfter']for a in group if a['realm']!='window'});z['runtimeModes']=[{k:v for k,v in urllib.parse.parse_qs(urllib.parse.urlparse(u).query).items()if k in ['lab','labSY','labEB','labRepairMs','labQuietOff']}for u in z['doseUrls']]
 except Exception as e:z['analysisError']=repr(e)
 out.append(z)
(r/(key+'-extra-analysis.json')).write_text(json.dumps(out,indent=2)+'\n')
if methodRows:
 import csv
 with(r/(key+'-messages.csv')).open('w',newline='')as f:w=csv.DictWriter(f,fieldnames=list(methodRows[0]),lineterminator='\n');w.writeheader();w.writerows(methodRows)
print(json.dumps(out,indent=2))

from pathlib import Path
import json
r=Path(__file__).parent;sroot=r/'source/src/crdt'
# Runtime-only lab settings, separate from prior G/V/R/D/P bits.
p=sroot/'rangeLab.ts';s=p.read_text();s+='''\nconst eb=query.get('labEB')??(typeof sessionStorage!=='undefined'?sessionStorage.getItem('done.lab.eb'):null)??'00';\nexport const labExtra=(name:'E'|'B')=>eb[name==='E'?0:1]==='1';\nObject.assign((globalThis as any).__rangeLab,{eb});\n''';p.write_text(s)
p=r/'lab-context.mjs';s=p.read_text().replace("repairMs=process.env.FAIR_REPAIR_MS??'1500';","repairMs=process.env.FAIR_REPAIR_MS??'1500',eb=process.env.FAIR_EB??'00';");s=s.replace('offline,idlePause,sy,repairMs})','offline,idlePause,sy,repairMs,eb})');s=s.replace("sessionStorage.setItem('done.lab.bits',bits);","sessionStorage.setItem('done.lab.eb',eb);sessionStorage.setItem('done.lab.bits',bits);");s=s.replace("u.searchParams.set('lab',bits);","u.searchParams.set('labEB',eb);u.searchParams.set('lab',bits);");s=s.replace('offline,idlePause,sy,repairMs});','offline,idlePause,sy,repairMs,eb});');p.write_text(s)
# Scheduling-only byte cache. No decoded proof, authority, plaintext or trusted progress.
(sroot/'labRawReadAhead.ts').write_text('''/** FICTIONAL LAB ONLY. Exact unverified originals, never receive authority. */
import {decodeInboundRequest} from '../../account-protocol/inboundTransport';
import {READ_REQUEST_LIMIT} from '../../account-protocol/deliveryTransport';
import {MAX_PENDING_BYTES} from './admissionQueue';
import {RECEIVE_SINGLE_PAGE_BYTES} from './receivePrefetch';
import type {Bytes} from './custodyCrypto';
type Entry={context:object;publisher:string;after:number;limit:number;expires:number;request:Bytes;page:Bytes;quiet?:object;signal:AbortSignal};
export function createLabRawReadAhead(signal:AbortSignal,now=Date.now){
 const entries:Entry[]=[];let closed=false,clock:number|undefined;
 const drop=(match:(e:Entry)=>boolean)=>{for(let i=entries.length-1;i>=0;i--)if(match(entries[i]!)){const[e]=entries.splice(i,1);e!.request.fill(0);e!.page.fill(0);}};
 const observe=()=>{const t=now();if(!Number.isSafeInteger(t)||t<0||(clock!==undefined&&t<clock))drop(()=>true);clock=t;drop(e=>closed||signal.aborted||e.signal.aborted||e.expires<=t);return t;};
 const bytes=()=>entries.reduce((n,e)=>n+e.request.length+e.page.length+8,0);
 const logical=()=>entries.reduce((n,e)=>n+e.limit,0);
 const close=()=>{closed=true;drop(()=>true)};signal.addEventListener('abort',close,{once:true});if(signal.aborted)close();
 return{get bytes(){observe();return bytes()},get logical(){observe();return logical()},
 has(context:object,publisher:string,after:number){observe();drop(e=>e.context!==context);return entries.some(e=>e.publisher===publisher&&e.after===after)},
 take(context:object,publisher:string,after:number,allowance:number){observe();drop(e=>e.context!==context);const found:Entry[]=[];let cursor=after,positions=0;for(let i=0;i<4&&positions<allowance;i++){const n=entries.findIndex(e=>e.publisher===publisher&&e.after===cursor);if(n<0)break;const[e]=entries.splice(n,1);found.push(e!);positions+=e!.limit;cursor+=e!.limit;}return found.length?found:undefined;},
 remember(context:object,request:Bytes,page:Bytes,scope:AbortSignal,quiet?:object,startedAt=now()){
  const t=observe();if(closed||scope.aborted||signal.aborted||!request.length||request.length>READ_REQUEST_LIMIT||!page.length||page.length>RECEIVE_SINGLE_PAGE_BYTES)return false;
  const q=decodeInboundRequest(request),expires=Math.min(q.expires,quiet?startedAt+750:q.expires);
  if(expires<=t||q.expires>t+60000||!Number.isSafeInteger(startedAt)||startedAt>t)return false;
  drop(e=>e.context!==context||(e.publisher===q.publisher&&e.after===q.after));
  const size=request.length+page.length+8;while(entries.length&&((bytes()+size)>MAX_PENDING_BYTES||(logical()+q.limit)>32||entries.length>=8))drop(e=>e===entries[0]);
  if(size>MAX_PENDING_BYTES||q.limit>8)return false;
  entries.push({context,publisher:q.publisher,after:q.after,limit:q.limit,expires,request:request.slice(),page:page.slice(),quiet,signal:scope});return true;
 },drop(publisher?:string){drop(e=>publisher===undefined||e.publisher===publisher)},dropQuiet(){drop(e=>!!e.quiet)},close};
}
''')
# Quiet token can conservatively date a prefetched empty proof from its original request start.
p=sroot/'receiveSelection.ts';s=p.read_text().replace('new WeakMap<object, QuietBasis>()','new WeakMap<object, QuietBasis & { startedAt?: number }>()');s=s.replace('captureQuiet(context: object, publisher: string, cursor: InboundReadCursor) {','captureQuiet(context: object, publisher: string, cursor: InboundReadCursor, startedAt?: number) {');s=s.replace("if (!Number.isFinite(at)) return undefined;\n      const token", "if (!Number.isFinite(at)||(startedAt!==undefined&&(!Number.isFinite(startedAt)||startedAt>at))) return undefined;\n      const token");s=s.replace('attempts.set(token, {\n        context,','attempts.set(token, {\n        ...(startedAt===undefined?{}:{startedAt}),\n        context,');s=s.replace('quiet.set(held.publisher, { ...held, at });','quiet.set(held.publisher, { ...held, at: Math.min(at,held.startedAt??at) });');s=s.replace('    captureQuiet(context:', '''    quietDueWithin(context:object,publisher:string,cursor:InboundReadCursor,lead:number){
      const at=now();observeClock(at);const held=quiet.get(publisher);
      return quietCursor(cursor)&&(!held||held.context!==context||!sameQuietCursor(held,cursor)||at-held.at>=RECEIVE_QUIET_MS-lead);
    },
    captureQuiet(context:''');p.write_text(s)
# Shared original collector remains two-concurrent; subtract any held raw bytes from its reservation.
p=sroot/'receivePrefetch.ts';s=p.read_text().replace('now: () => number = () => performance.now(),','now: () => number = () => performance.now(),\n  budget = MAX_PENDING_BYTES,');s=s.replace("if (!Number.isInteger(count)","if(!Number.isSafeInteger(budget)||budget<0||budget>MAX_PENDING_BYTES)throw Error('Invalid receive byte reservation');\n  if (!Number.isInteger(count)");s=s.replace('held + RECEIVE_SINGLE_PAGE_BYTES + 4 <= MAX_PENDING_BYTES','held + RECEIVE_SINGLE_PAGE_BYTES + 4 <= budget');p.write_text(s)
p=sroot/'receivePageTransport.ts';s=p.read_text().replace('export function createReceivePageTransport() {','export function createReceivePageTransport(availableBytes=()=>MAX_PENDING_BYTES) {');s=s.replace('          more,\n        );','          more,\n          undefined,\n          Math.min(MAX_PENDING_BYTES,availableBytes()),\n        );');s=s.replace('limit = BATCH_LIMIT;','limit = Math.min(BATCH_LIMIT,availableBytes());');s=s.replace('decoded.reduce((n, p) => n + p.length + 4, 0) > MAX_PENDING_BYTES','decoded.reduce((n, p) => n + p.length + 4, 0) > Math.min(MAX_PENDING_BYTES,availableBytes())');p.write_text(s)
p=sroot/'accountReceive.ts';s=p.read_text();s="import {labExtra} from './rangeLab';\nimport {createLabRawReadAhead} from './labRawReadAhead';\nimport {RECEIVE_SINGLE_PAGE_BYTES} from './receivePrefetch';\n"+s;s=s.replace('  let rangeTail:', '  let rawAhead:ReturnType<typeof createLabRawReadAhead>|undefined;\n  let supplementary: {request:Bytes;quiet?:object;startedAt:number}[]=[];\n  let preparedCached:Bytes[]|undefined;\n  let primaryWireCount=1;\n  let rangeTail:');s=s.replace('rangeTail = createReceiveRangeTail(carrier.signal);','rangeTail = createReceiveRangeTail(carrier.signal);rawAhead=createLabRawReadAhead(carrier.signal);');s=s.replace('rangeTail?.close();','rangeTail?.close();rawAhead?.close();');s=s.replace('receiveSelection.invalidateQuiet();','receiveSelection.invalidateQuiet();rawAhead?.dropQuiet();');s=s.replace('receiveSelection.reset();','receiveSelection.reset();rawAhead?.drop();');s=s.replace('invalidateQuietPublisher:(publisher:string)=>receiveSelection.invalidatePublisher(publisher),','invalidateQuietPublisher:(publisher:string)=>{receiveSelection.invalidatePublisher(publisher);rawAhead?.drop(publisher)},');s=s.replace('rangeTail?.drop(r.publisher);','rangeTail?.drop(r.publisher);rawAhead?.drop(r.publisher);')
s=s.replace('    const quiet =\n      composed', '    let quiet =\n      composed')
needle='      const widths = receivePageWidths(peerRange, count, s.prefix.observedThrough - cursor);';assert needle in s
s=s.replace(needle,'''      preparedCached=undefined;supplementary=[];
      const warm=(labExtra('E')||labExtra('B'))&&cached?rawAhead?.take(base.authority,publisher,cursor,count):undefined;
      const widths = peerRange&&labExtra('B')?[Math.min(8,Math.max(1,s.prefix.observedThrough-cursor))]:receivePageWidths(peerRange, count, s.prefix.observedThrough - cursor);''')
s=s.replace('      if (previous) {\n        requests.push(previous.request);', '''      if(warm){for(const e of warm)requests.push(e.request);preparedCached=warm.map(e=>e.page);if(warm[0]!.quiet)quiet=warm[0]!.quiet;labCount('rawAheadHits',warm.length);}
      else if (previous) {
        requests.push(previous.request);''')
needle='      await assertCurrent(task);\n      return task.step(() => {\n        outstanding?.fill(0);';assert needle in s
s=s.replace(needle,'''      primaryWireCount=requests.length;
      if(!warm&&!previous&&cached&&composed&&publisher!==base.publisher.id&&(labExtra('E')||labExtra('B'))&&!all.conflict&&hasPeerBacklog(publishers,base.publisher.id,all.peers)){
        const add=async(id:string,after:number,limit:number,quietToken?:object)=>{const next={...r,publisher:id,after,limit,nonce:hex(task.step(()=>random(32)))};next.signature=hex(new Uint8Array(await task.wait(()=>subtleFor(task).sign('Ed25519',signer!,inboundRequestMessage(next)))));supplementary.push({request:encodeInboundRequest(next),quiet:quietToken,startedAt:Date.now()});};
        const room=()=>32-(rawAhead?.logical??0)-requests.reduce((n,b)=>n+decodeInboundRequest(b).limit,0)-supplementary.reduce((n,v)=>n+decodeInboundRequest(v.request).limit,0);
        const slots=()=>4-requests.length-supplementary.length;
        // E carries independent quiet originals in the same bounded HTTP batch. No verified progress.
        if(labExtra('E'))for(const id of publishers){if(slots()<=0||room()<1)break;if(id===publisher||id===base.publisher.id)continue;const peer=publisherState(all,base,id);if(peer.conflict||peer.prefix.observedThrough!==peer.prefix.position||rawAhead?.has(base.authority,id,peer.prefix.position)||!receiveSelection.quietDueWithin(base.authority,id,peer,250))continue;const began=Date.now(),token=receiveSelection.captureQuiet(base.authority,id,peer,began);if(token)await add(id,peer.prefix.position,1,token);}
        // B uses at most the existing4×8wire extent, retaining G8 native commit turns.
        if(labExtra('B'))for(const id of publishers){if(slots()<=0||room()<1)break;if(id===base.publisher.id)continue;const peer=publisherState(all,base,id);if(peer.conflict)continue;let after=peer.prefix.position;const same=[...requests,...supplementary.map(v=>v.request)].map(decodeInboundRequest).filter(v=>v.publisher===id);if(same.length)after=Math.max(after,...same.map(v=>v.after+v.limit));while(slots()>0&&room()>0&&after<peer.prefix.observedThrough){if(rawAhead?.has(base.authority,id,after))break;const limit=Math.min(8,room(),peer.prefix.observedThrough-after);await add(id,after,limit);after+=limit;}}
      }
      for(const v of supplementary)requests.push(v.request);
      labEvent({kind:'readPlan',publisher,cursor,through:s.prefix.observedThrough,primaryWireCount,requests:requests.map(b=>{const q=decodeInboundRequest(b);return{publisher:q.publisher,after:q.after,limit:q.limit}}),rawBytes:rawAhead?.bytes??0});
      await assertCurrent(task);
      return task.step(() => {
        outstanding?.fill(0);''')
# prepareGroupOwned exports only unverified byte ownership and scheduling metadata.
s=s.replace('          quiet: outstandingQuiet,\n          cachedPage,','          quiet: outstandingQuiet,\n          cachedPage,\n          cachedPages:preparedCached,\n          primaryCount:primaryWireCount,\n          supplementary:supplementary.map(v=>({...v})),\n          rawContext:base.authority,')
s=s.replace('const receivePages = createReceivePageTransport();','const receivePages = createReceivePageTransport(()=>MAX_PENDING_BYTES-(rawAhead?.bytes??0)-(rangeTail?.bytes??0));')
s=s.replace('if (prepared.cachedPage) pages = [prepared.cachedPage];','if (prepared.cachedPage) pages = [prepared.cachedPage];\n        if(prepared.cachedPages)pages=prepared.cachedPages;')
s=s.replace('if (!prepared.cachedPage) {','if (!prepared.cachedPage&&!prepared.cachedPages) {')
s=s.replace('rangeTail?.beforeFetch(requests.length);','rangeTail?.beforeFetch(requests.length);\n          if(MAX_PENDING_BYTES-(rawAhead?.bytes??0)-(rangeTail?.bytes??0)<RECEIVE_SINGLE_PAGE_BYTES+4)rawAhead?.drop();')
s=s.replace('return decodeInboundPage(page).entries.length > 0;',"return labExtra('E')||labExtra('B')?true:decodeInboundPage(page).entries.length > 0;")
needle='        stamp.check();\n        // A speculative tail';assert needle in s
s=s.replace(needle,'''        stamp.check();
        if(!prepared.cachedPages&&pages.length>prepared.primaryCount){
          for(let i=prepared.primaryCount;i<pages.length;i++){const extra=prepared.supplementary[i-prepared.primaryCount];if(!extra)throw Error('Missing raw read owner');rawAhead?.remember(prepared.rawContext,requests[i]!,pages[i]!,stamp.signal,extra.quiet,extra.startedAt);pages[i]!.fill(0);}
          pages=pages.slice(0,prepared.primaryCount);
        }
        // A speculative tail''')
# Keep current group's raw originals only; returned remaining request copies are erased by caller finally.
p.write_text(s)
(r/'EB-BUILD-CONTRACT.md').write_text('''# E/B lab contract, before build

No handoff change. No75ms. Full stored/fresh prefix comparisons stay, V0. E piggybacks due-soon quiet publisher requests with current backlog requests, on existing batch endpoint; native selection/verification still serial. Quiet750 and own5000 unchanged. E carries original scheduling token with conservative request-start timestamp; consuming prefetched empties cannot renew their750msage. Hints/auth resets clear quiet originals. Four active network/session remains; optional individual fallback is the original two-concurrent collector. B expands downloaded original pages to existing4×8wire maximum and stores unverified future bytes, committing onlyG8 chain-ordered positions per native turn. All expiry/per-entry crypto/authorization/ledger/witness/current-commit checks remain in original owners; local edits see only committed state. No proof/cleartext cache. Raw cache <=4MiB/32logical positions/8pages, process-local exact original bytes, context identity, cancel+expiry+clock rollback; available network reservation subtracts held bytes. Index/durable formats unchanged. Cache loss only refetches. Unexpected authority/current-prefix changes still refuse and cold if uncertain, no alias-based trust.

First implementation screen will be E×B2×2 at50ms,3journeys/cell mixed order, then0msfornondominated winners and matchedbaseline.50msisdiagnosticnot30sgate;0msgatesunchanged. All no-Fcoldfailuresstop. Source/builds private/no credit. Pure quiet-timebackdating is scheduling-only and separately probed. Server retains original per-subrequest authorization and250msbatch-timebound. Original network10s/collect250ms/nativeG8/memory4MiB/rate limits remain.
''')
print('E/B private source prepared; not built or run.')

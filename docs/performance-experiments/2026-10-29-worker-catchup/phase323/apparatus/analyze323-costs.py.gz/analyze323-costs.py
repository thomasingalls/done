from pathlib import Path
import json,collections,statistics,math
r=Path(__file__).parent
out={'labOnly':True,'acceptanceCredit':False,'deepCells':{},'liveCells':{},'fairness':[]}
for key in ['eb50','eb0']:
 rows=json.loads((r/(key+'-analysis.json')).read_text())
 for arm in sorted({v['eb']for v in rows}):
  z=[v for v in rows if v['eb']==arm]
  out['deepCells'][key+'-'+arm]={'n':len(z),'allFunctional':all(v['functional']for v in z),'allColdExact':all(v['coldExact']for v in z),'gateApplied':key=='eb0','all30s':all(v['rawDeep30']for v in z)if key=='eb0'else None,'medianDrainMs':statistics.median(v['drainMs']for v in z),'drainMs':[v['drainMs']for v in z],'medianTokens':statistics.median(v['tokensThroughDrain']for v in z),'tokens':[v['tokensThroughDrain']for v in z],'medianIndexCharge':statistics.median(v['indexPeakChargedBytes']for v in z),'medianAppendedPlainBytes':statistics.median(v['appendedPlainBytes']for v in z),'medianMessages':statistics.median(v['channelAtObservedDrain']['messages']for v in z),'hostMedianRange':[min(v['hostBusyMedian']for v in z),max(v['hostBusyMedian']for v in z)]}
 for row in rows:
  raw=json.loads((r/row['run']/'deep-gv/result.json').read_text());start=raw['startedAt'];end=start+raw['timeTo1025Ms'];by=collections.defaultdict(list)
  for t in raw['traffic']['rows']:
   if not start<=t['at']<=end:continue
   for q in t.get('reads',[]):by[q['publisher']].append((t['at'],q['after'],q['limit']))
  pubs=[]
  for pub,vals in by.items():
   cursors=sorted(set(v[1]for v in vals));times=sorted(v[0]for v in vals);gaps=[b-a for a,b in zip(times,times[1:])];pubs.append({'publisher':pub,'reads':len(vals),'requestedPositions':sum(v[2]for v in vals),'cursors':cursors if len(cursors)<8 else{'n':len(cursors),'first':cursors[0],'last':cursors[-1]},'maxRequestGapMs':max(gaps)if gaps else None,'classification':'stationary'if len(cursors)==1 else'advancing'})
  out['fairness'].append({'run':row['run'],'publishers':pubs,'qualification':'HTTP request-start gaps through final commit, not native proof-consumption delay or a guaranteed liveness deadline. Quiet reuse750ms is eligibility, own5000ms and G8 native scheduling unchanged.'})
live=json.loads((r/'live323-analysis.json').read_text())
for arm in ['00','11']:
 z=[v for v in live if v['eb']==arm];out['liveCells'][arm]={'n':len(z),'allMeasuredPredicates':all(v['allMeasuredPredicates']for v in z),'inputP95Ms':[v['localMs']['p95']for v in z],'peerP95Ms':[v['peerMs']['p95']for v in z],'tokens':[v['tokensTypingWindow']for v in z],'quietReads':[[q['quietReads']for q in v['realmCounterDeltas']]for v in z],'repairActivations':[[q['repairActivations']for q in v['realmCounterDeltas']]for v in z],'postDrainKeys':[v['keysAfterReaderDrain']for v in z],'postDrainP95Ms':[v['postDrainPeerMs']['p95']for v in z],'drains':[v['drainMs']for v in z]}
(r/'costs323-analysis.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items()if k!='fairness'},indent=2))

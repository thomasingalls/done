from pathlib import Path
import json,shutil
r=Path(__file__).parent;g=r/'grown323';g.mkdir(mode=0o700);(g/'test').mkdir();(g/'node_modules').symlink_to(r/'harness/node_modules',target_is_directory=True)
old=Path('/private/tmp/done-range-vgr-lab-20261030/civil31-grown');s=(old/'test/extend.spec.ts').read_text().replace('/private/tmp/done-range-vgr-lab-20261030/civil31-grown',str(g)).replace('/private/tmp/done-range-vgr-lab-20261030/civil31-fixture/private-fixture/fixture.json',str(r/'private-fixture/fixture.json'))
s=s.replace("await openSaved(p,saved.code,index>0);", "try{await openSaved(p,saved.code,index>0);}catch(error){result.coldFailure=true;throw error;}")
(g/'test/extend.spec.ts').write_text(s);shutil.copy2(old/'test/config.ts',g/'test/config.ts')
s=(r/'harness/test/account-continuation-lab/dense-cohort.spec.ts').read_text().replace("grow paired real 2048 reader cohort through selected receipt writer","prepare winning receipt writer on real 2048 history").replace("const folder=root+'/cohort-P'+Number(P)","const folder=root+'/cohort-winning'")
s=s.replace('await openSaved(p,saved.code,true);','try{await openSaved(p,saved.code,true);}catch(error){result.coldFailure=true;throw error;}')
(r/'harness/test/account-continuation-lab/cohort323.spec.ts').write_text(s)
s=(r/'harness/test/account-continuation-lab/dense-cohort.config.ts').read_text().replace('dense-cohort.spec.ts','cohort323.spec.ts');(r/'harness/test/account-continuation-lab/cohort323.config.ts').write_text(s)
(r/'run-grown-generation.py').write_text('''from pathlib import Path
import subprocess,os,json,time,signal,sys,datetime,hashlib
r=Path(__file__).parent;g=r/'grown323';node='/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node';fixture=r/'private-fixture/fixture.json';assert json.loads(fixture.read_text())['accounts'][0]['date']==datetime.datetime.now(datetime.timezone.utc).date().isoformat();out=g/'run01';out.mkdir(mode=0o700,exist_ok=False);dist=Path('/private/tmp/done-civil-fixture-20261030-r1/dist');(g/'generation-inputs.json').write_text(json.dumps({'fixtureSha256':hashlib.sha256(fixture.read_bytes()).hexdigest(),'assets':{str(p.relative_to(dist)):hashlib.sha256(p.read_bytes()).hexdigest()for p in dist.rglob('*')if p.is_file()},'addedAcceptedPositions':1024,'backlog':2048,'labOnly':True,'acceptanceCredit':False},indent=2)+'\\n')
env={k:v for k,v in os.environ.items()if not k.startswith(('FAIR_','RANGE_LAB_'))};env.update({'PATH':str(Path(node).parent)+':'+env['PATH'],'FAIR_OUT':str(out),'FAIR_DIST':str(dist),'FAIR_FIXTURE':str(fixture),'FAIR_RTT':'0','QUIET_WITHHOLD':'0','CHROMIUM_PATH':'/private/tmp/done-civil-gates-browser-20261030/Chrome.app/Contents/MacOS/Google Chrome'});cmd=[node,'node_modules/@playwright/test/cli.js','test','--config','test/config.ts'];load=out/'host-load.jsonl';sampler=subprocess.Popen([sys.executable,str(r/'host_load.py'),'--out',str(load)]);start=time.time()
try:
 for i in range(500):
  if Path(str(load)+'.ready').exists():break
  if sampler.poll()is not None:raise RuntimeError('Sampler failed')
  time.sleep(.01)
 else:raise RuntimeError('Sampler not ready')
 print('START real+1024 accepted positions and original writer preparation',flush=True)
 with(out/'console.log').open('w')as f:p=subprocess.run(cmd,cwd=g,env=env,stdout=f,stderr=subprocess.STDOUT)
finally:sampler.send_signal(signal.SIGTERM);sampler.wait(timeout=10)
x=json.loads((out/'result.json').read_text())if(out/'result.json').exists()else{};row={'childExit':p.returncode,'startedAt':start,'finishedAt':time.time(),'command':cmd,'coldFailure':bool(x.get('coldFailure')),'outcome':x.get('outcome'),'labOnly':True,'acceptanceCredit':False};(out/'receipt.json').write_text(json.dumps(row,indent=2)+'\\n');print(row,flush=True)
if row['coldFailure']:(r/'STOP.json').write_text(json.dumps(row,indent=2)+'\\n');raise SystemExit(3)
if p.returncode:raise SystemExit(p.returncode)
link=r/'prepared-fixture';assert link.is_symlink();link.unlink();link.symlink_to(g/'prepared-fixture',target_is_directory=True);print('New2048 original source fixture ready',flush=True)
''')
(r/'GROWN-GENERATION-PROTOCOL.md').write_text('''Apparatus only, same genuine sixdeviceHcohort andten devices total. Cloneoriginal1024server/H0, openactualoldprofilewithsame signed0abseedapp, append1024UIedits eachacceptedbeforenext, verifydelta andfullarchive, lock/closesender. Originalrecipefullycatchesupactor2withautomationoff/counter2; saveallstate/census/receipt/5sloadlog. No format conversion, fakeclock, rate/timer changes. MarkanyactualexistingprofileopenfailurecoldandSTOP. Separatelyresetactor2toitsOWN originalbehindprofile andingest2048throughcurrentwinningP1writerusingexistingcohortrecipe,assertwholearchiveexactandcounter2beforelock; keepnewcohort-winningindependentofbaseline1024. Code/build/fixturegenerationnoperformancecredit. DatesmustmatchactualUTCNov1. Furthergrownremovalplan/orderdeclaredafterwinningstackandintakeareknown; >=60overlap/120smaintenanceunchanged.\n''')
print('Original growth and current-format intake apparatus prepared; not run')

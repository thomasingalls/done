from pathlib import Path
import json,gzip,hashlib,shutil
r=Path(__file__).parent;repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');d=repo/'docs/performance-experiments/2026-10-29-worker-catchup/phase323';d.mkdir(exist_ok=False);items=[];seen=set();sha=lambda x:hashlib.sha256(x).hexdigest()
def keep(p,category='evidence'):
 raw=p.read_bytes();dest=d/category/(str(p.relative_to(r))+'.gz');
 if str(dest)in seen:
  assert gzip.decompress(dest.read_bytes())==raw;return
 seen.add(str(dest));dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(gzip.compress(raw,compresslevel=6,mtime=0));items.append({'source':str(p),'copy':str(dest.relative_to(d)),'rawSha256':sha(raw),'bytes':len(raw),'gzipSha256':sha(dest.read_bytes())})
prefixes={n:{'bytes':(repo/n).stat().st_size,'sha256':sha((repo/n).read_bytes())}for n in ['docs/completed.md','docs/decisions.md','docs/product-backlog.md']};(r/'record-prefixes323.json').write_text(json.dumps(prefixes,indent=2)+'\n')
keys=['attach323','cut323','eb50','eb0','worker323','live323','parity323','intake323','removals323']
for key in keys:
 for suffix in ['plan.json','inputs.json','results.json','analysis.json','cells.json','methods.csv','messages.csv','extra-analysis.json','owners-analysis.json','owners.csv','attempts.csv','retries.csv','interruptions.csv','predicates-analysis.json','predicates-attempts.csv']:
  p=r/(key+'-'+suffix)
  if p.exists():keep(p)
 p=r/(key+'-results.json')
 if not p.exists():continue
 for c in json.loads(p.read_text()):
  f=r/c['name']
  for n in ['console.log','list.log','receipt.json','host-load.jsonl','result.json','partial-result.json','container-identity.json','docker-command.json','services.log']:
   if(f/n).is_file():keep(f/n)
  for n in ['result.json','container-identity.json','docker-command.json','services.log','page-drain.cpuprofile','worker-drain.cpuprofile']:
   for q in f.glob('*/'+n):keep(q)
for folder in ['civil01-fixture/seed','civil01-fixture-attempt2/seed','grown323/run01']:
 for n in ['receipt.json','host-load.jsonl','runner.json','services.log','seed-check.json','container-identity.json','console.log','docker-command.json','result.json']:
  p=r/folder/n
  if p.exists():keep(p)
for n in ['AGGREGATION-FAILURE-323.md','removals323-cells.json','aggregate323-console.log','record-prefixes323.json','PHASE323-ATTACH-PROTOCOL.md','EB-BUILD-CONTRACT.md','EB-ADJUSTMENTS.md','EB-SCREEN-PROTOCOL.md','ZERO-PROTOCOL.md','PROFILE-LIVE-PROTOCOL.md','CUT-REGRESSION-PROTOCOL.md','GROWN-GENERATION-PROTOCOL.md','TIMING-REMOVALS-PROTOCOL.md','TIMING-REMOVALS-PROTOCOL.md.unrun-60s-draft','removals323-plan.json.unrun-60s-draft','ZERO-RETRY-AMENDMENT.md','FIXTURE-BOUNDARY-FAILURE.md','FIXTURE-SIZE-OBSERVATION.md','LANDING-NOTES-DRAFT.md','build-identity.json','build-flags.json','frontend-build.log','lab-build.log','build3-result.log','unrun-eb-build-1-identity.json','frozen-eb-build-2/build-identity.json','frozen-eb-build-2/build-flags.json','frozen-eb-build-2/frontend-build.log','frozen-eb-build-2/lab-build.log','eb-unit-attempt1.log','eb-unit-attempt2.log','eb-typecheck-attempt1.log','eb-typecheck-attempt2.log','eb-typecheck-attempt3.log','zero-retry-unit-attempt1.log','zero-retry-typecheck-attempt1.log','zero-retry-scope-check.json','zero-retry-before.json','worker323-profile-analysis.json','worker323-profile-recheck.json','worker323-profile-recheck.log','profiler-auth-probe.json','worker-profiler-probe.json','idle-traffic-confirmation.json','eb50-selection.json','costs323-analysis.json','stage323-analysis.json','stage323-methods.csv','independent323-check.json','fixture323-verification.json','grown323/generation-inputs.json','STOP.json']:
 p=r/n
 if p.exists():keep(p)
for p in sorted(r.glob('analysis323-*.log')):keep(p)
# Inert reproduction/observation recipes only. No compiled app, browser profile, DB or fixture credentials.
for n in ['freeze323.py','aggregate323.py','aggregate323-attempt1.py','run-stage.py','run-attach.py','run-grown-generation.py','run-fresh-fixture.py','run-fresh-fixture2.py','prepare-fresh-fixture.py','build-eb.py','adjust-eb.py','prepare-eb-tests.py','final-eb-review.py','add-zero-retry.py','build-lab.py','build.mjs','prepare-grown323.py','prepare-stage-driver.py','host_load.py','trace-idle.py','analyze-eb.py','analyze-live323.py','analyze-worker323.mjs','analyze-worker323-before-build3.mjs','analyze323-costs.py','analyze323-stages.py','analyze323-extra.py','analyze-removals323-owners.py','analyze-removals323-predicates.py','verify323.py','preserve323.py','write323-report.py','labNoRetryDelay.test.ts','lab-context.mjs','container-service.mjs','read-request.mjs','fixture-roles.mjs','notification-probe.mjs','probe-worker-profiler.mjs','probe-profiler-auth.mjs','harness/test/account-continuation-lab/worker-cpu-profile.mjs','harness/test/account-continuation-lab/worker-owner.spec.ts','harness/test/account-continuation-lab/worker-owner.config.ts','harness/test/account-continuation-lab/deep-traffic.mjs','harness/test/account-continuation-lab/r-late.spec.ts','harness/test/account-continuation-lab/r-late.config.ts','harness/test/account-continuation-lab/phase321/grown-maintenance.spec.ts','harness/test/account-continuation-lab/grown-maintenance.config.ts','harness/test/account-continuation-lab/cohort323.spec.ts','harness/test/account-continuation-lab/cohort323.config.ts','grown323/test/extend.spec.ts','grown323/test/config.ts','harness/test/account-continuation-lab/dense-cut.spec.ts','harness/test/account-continuation-lab/dense-cut.config.ts','civil01-fixture-attempt2/source/test/account-continuation-lab/seed.spec.ts','civil01-fixture-attempt2/source/test/account-continuation-lab/seed.config.ts']:
 p=r/n
 if p.exists():keep(p,'apparatus')
for n in ['removals323-cells.json','eb50-methods.csv','eb0-methods.csv','live323-messages.csv','removals323-messages.csv','stage323-methods.csv','eb50-analysis.json','eb50-cells.json','eb0-analysis.json','eb0-cells.json','worker323-profile-analysis.json','live323-analysis.json','live323-extra-analysis.json','removals323-extra-analysis.json','removals323-owners-analysis.json','removals323-predicates-analysis.json','removals323-owners.csv','removals323-retries.csv','removals323-interruptions.csv','costs323-analysis.json','stage323-analysis.json','idle-traffic-confirmation.json','independent323-check.json','fixture323-verification.json']:
 p=r/n
 if p.exists():shutil.copy2(p,d/n)
(d/'evidence-index.json').write_text(json.dumps({'labRoot':str(r),'labOnly':True,'acceptanceCredit':False,'items':items,'compiledBuildsProfilesCredentialsDatabasesNotCopied':True},indent=2)+'\n')
for q in items:assert sha(gzip.decompress((d/q['copy']).read_bytes()))==q['rawSha256'];assert sha(Path(q['source']).read_bytes())==q['rawSha256']
(d/'evidence-check.json').write_text(json.dumps({'copiesVerified':len(items),'allOriginalAndCompressedHashesMatch':True,'labOnly':True,'acceptanceCredit':False},indent=2)+'\n');print('Preserved',len(items),'exact evidence/recipe artifacts')

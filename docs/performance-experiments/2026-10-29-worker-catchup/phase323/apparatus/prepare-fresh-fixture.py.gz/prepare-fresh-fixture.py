from pathlib import Path
import shutil,json
r=Path(__file__).parent;old=Path('/private/tmp/done-range-vgr-lab-20261030/civil31-fixture');fresh=r/'civil01-fixture';fresh.mkdir(mode=0o700)
for n in ['container-image.json','container-service.mjs','observer.mjs']:shutil.copy2(old/n,fresh/n)
shutil.copytree(old/'source',fresh/'source',symlinks=True)
p=fresh/'source/test/account-continuation-lab/seed.config.ts';s=p.read_text();assert "use:{baseURL:"in s;s=s.replace("use:{baseURL:","use:{timezoneId:'Europe/Paris',baseURL:");p.write_text(s)
(fresh/'recipe.json').write_text(json.dumps({'sourceRecipe':str(old/'recipe.json'),'reuseExactSigned0abSeedApp':'/private/tmp/done-civil-fixture-20261030-r1/dist','actualCivilDate':'2026-11-01','timezone':'Europe/Paris','realEpoch':True,'reason':'New whole matched cohort after local civil midnight; no fake clocks or mutation of saved formats','profiles':'fictional only','labOnly':True,'acceptanceCredit':False},indent=2)+'\n')
(r/'run-fresh-fixture.py').write_text('''from pathlib import Path
import subprocess,os,json,datetime,time,signal,sys
r=Path(__file__).parent;f=r/'civil01-fixture';node='/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node';assert datetime.datetime.now().astimezone().date().isoformat()=='2026-11-01';out=f/'seed';out.mkdir(mode=0o700,exist_ok=False)
env={k:v for k,v in os.environ.items()if not k.startswith(('FAIR_','RANGE_LAB_'))};env.update({'PATH':str(Path(node).parent)+':'+env['PATH'],'TZ':'Europe/Paris','FAIR_FIXTURE_ROOT':str(f),'FAIR_OUT':str(out),'FAIR_DIST':'/private/tmp/done-civil-fixture-20261030-r1/dist','CHROMIUM_PATH':'/private/tmp/done-civil-gates-browser-20261030/Chrome.app/Contents/MacOS/Google Chrome'})
cmd=[node,'node_modules/@playwright/test/cli.js','test','--config','test/account-continuation-lab/seed.config.ts'];load=out/'host-load.jsonl';sampler=subprocess.Popen([sys.executable,str(r/'host_load.py'),'--out',str(load)]);start=time.time()
try:
 for i in range(500):
  if Path(str(load)+'.ready').exists():break
  if sampler.poll()is not None:raise RuntimeError('Sampler failed')
  time.sleep(.01)
 else:raise RuntimeError('No sampler')
 print('START actual civil Nov1 fixture through unchanged signed seed app',flush=True)
 with(out/'console.log').open('w')as log:p=subprocess.run(cmd,cwd=f/'source',env=env,stdout=log,stderr=subprocess.STDOUT)
finally:sampler.send_signal(signal.SIGTERM);sampler.wait(timeout=10)
receipt={'childExit':p.returncode,'startedAt':start,'finishedAt':time.time(),'command':cmd,'realEpoch':True,'timezone':'Europe/Paris','apparatusOnly':True,'acceptanceCredit':False};(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\\n');print(receipt,flush=True)
if p.returncode:raise SystemExit(p.returncode)
fixture=f/'private-fixture/fixture.json';x=json.loads(fixture.read_text());assert all(a['date']=='2026-11-01'for a in x['accounts']);link=r/'private-fixture';assert link.is_symlink();link.unlink();link.symlink_to(f/'private-fixture',target_is_directory=True)
print('Fresh fictional fixture ready',flush=True)
''')
print(fresh)

from pathlib import Path
p=Path('/Users/thomasingalls/.codex/worktrees/7fda/done/docs/performance-experiments/2026-10-29-worker-catchup/phase323/README.md')
raw=p.read_bytes().rstrip(b'\n');note=b'Patch preparation: the first unregistered patch failed exact forward replay because Git removed one extra blank line at this report EOF. The failed artifact is retained; only the new report ending is normalized. See [preparation record](./freeze-preparation.md). No runtime or measured result changed.'
if note not in raw:raw+=b'\n\n'+note
p.write_bytes(raw+b'\n')

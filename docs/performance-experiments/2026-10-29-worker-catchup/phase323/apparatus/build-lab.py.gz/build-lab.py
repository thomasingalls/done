from pathlib import Path
import json,subprocess,os,time
r=Path(__file__).parent;node='/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node';flags={**json.loads((r/'release-flags.json').read_text())['expected'],'VITE_ACCOUNT_RANGE_RECEIVE':'1'};env={k:v for k,v in os.environ.items()if not k.startswith('VITE_ACCOUNT_')};env.update(flags);env.update({'APP_BUILD_REVISION':'0ab9cbc8937e32c6542aaeeca697c87ba116c3be-dirty','APP_BUILD_DATE':'2026-10-31','PATH':str(Path(node).parent)+':'+os.environ['PATH']});(r/'build-flags.json').write_text(json.dumps(flags,indent=2)+'\n');start=time.time()
with(r/'frontend-build.log').open('w')as log:p=subprocess.run([node,str(r/'source/node_modules/vite/bin/vite.js'),'build','--outDir',str(r/'frontend'),'--emptyOutDir','--sourcemap'],cwd=r/'source',env=env,stdout=log,stderr=subprocess.STDOUT)
if p.returncode:print((r/'frontend-build.log').read_text()[-6500:]);raise SystemExit(p.returncode)
# build.mjs already carries the explicit lab range opt-in.
with(r/'lab-build.log').open('w')as log:p=subprocess.run([node,str(r/'build.mjs')],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
if p.returncode:print((r/'lab-build.log').read_text()[-6500:]);raise SystemExit(p.returncode)
print(json.dumps({'singleBuildReady':True,'elapsedSeconds':time.time()-start,'flags':flags,'labOnly':True,'acceptanceCredit':False}))

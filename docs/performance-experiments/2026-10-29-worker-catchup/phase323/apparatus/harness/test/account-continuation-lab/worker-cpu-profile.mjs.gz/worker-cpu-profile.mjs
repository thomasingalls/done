// Observation only; no account data or evaluated script is requested.
export async function startWorkerCpuProfile(page,url){
 const browser=page.context().browser();if(!browser)throw Error('Browser CDP unavailable');
 const cdp=await browser.newBrowserCDPSession();const {targetInfos}=await cdp.send('Target.getTargets');const target=targetInfos.find(t=>t.type==='worker'&&t.url===url);if(!target)throw Error('Worker target not found');
 const {sessionId}=await cdp.send('Target.attachToTarget',{targetId:target.targetId,flatten:false});let id=0,ended=false,detachedBeforeCold=false;const pending=new Map();
 cdp.on('Target.detachedFromTarget',e=>{if(e.sessionId===sessionId)detachedBeforeCold=true;});
 cdp.on('Target.receivedMessageFromTarget',e=>{if(e.sessionId!==sessionId)return;const v=JSON.parse(e.message),p=pending.get(v.id);if(p){pending.delete(v.id);clearTimeout(p.timer);v.error?p.reject(Error(JSON.stringify(v.error))):p.resolve(v.result);}});
 const send=(method,params={})=>new Promise((resolve,reject)=>{const n=++id,timer=setTimeout(()=>{pending.delete(n);reject(Error('Worker profiler command deadline: '+method))},15000);pending.set(n,{resolve,reject,timer});void cdp.send('Target.sendMessageToTarget',{sessionId,message:JSON.stringify({id:n,method,params})}).catch(error=>{clearTimeout(timer);pending.delete(n);reject(error)});});
 await send('Profiler.enable');await send('Profiler.setSamplingInterval',{interval:1000});const startedBefore=Date.now();await send('Profiler.start');const startedAfter=Date.now();
 return{targetId:target.targetId,startedBefore,startedAfter,async stop(){const before=Date.now(),result=await send('Profiler.stop'),after=Date.now();return{profile:result.profile,stoppedBefore:before,stoppedAfter:after};},async afterCold(){if(ended)throw Error('Profiler already disposed');ended=true;await cdp.detach();return{controlSessionRetainedThroughCold:true,workerTargetDetachedNaturallyBeforeCold:detachedBeforeCold};}};
}

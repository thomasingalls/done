import {control as labControl} from './runtime.mjs';
import {configureLabContext} from '../../../lab-context.mjs';
import {observeDeepTraffic} from './deep-traffic.mjs';
import {registration as verifyOriginalRegistration,assertion as verifyOriginalAssertion} from '/private/tmp/done-idle-read-ahead-lab-20261101/source-after/account-service/webauthn';
import {pairedEditors} from '/private/tmp/done-idle-read-ahead-lab-20261101/test-inputs/test/packaged-account/devices';
import {pending,compared,unlock} from '/private/tmp/done-idle-read-ahead-lab-20261101/test-inputs/test/device-enrollment/helpers';
import {openMenuSection} from '/private/tmp/done-idle-read-ahead-lab-20261101/test-inputs/test/geometry/openApp';
import { waitForState } from '/private/tmp/done-idle-read-ahead-lab-20261101/source-after/scripts/storage-conformance/observe.mjs';
import{test,expect,chromium,firefox}from'@playwright/test';import{readFileSync,writeFileSync,mkdirSync,cpSync}from'node:fs';import{join}from'node:path';
import{start,stop}from'./runtime.mjs';import{seedProfile}from'./seed-profile';import{restoreAuthenticator,openSaved}from'./devices';import{exported,archiveIdentity}from'./common';
const root='/private/tmp/done-idle-read-ahead-lab-20261101',out=process.env['FAIR_OUT']!,fixture=JSON.parse(readFileSync('/private/tmp/done-idle-read-ahead-lab-20261101/private-fixture/fixture.json','utf8')),account=fixture.accounts.find((v:any)=>v.label==='H'),saved=account.actors[0];
async function laboratory(name:string,work:(p:any,r:any)=>Promise<void>,seed=saved){const d=join(out,name);mkdirSync(d,{recursive:true,mode:0o700});process.env['FAIR_OUT']=d;let ctx:any;const r:any={outcome:'starting',guards:{}};try{
 cpSync(fixture.state,d+'/state',{recursive:true,errorOnExist:true});await start(d+'/state',root+'/combined-dist');ctx=await configureLabContext(await (process.env['WORKER_BROWSER']==='firefox'?firefox:chromium).launchPersistentContext(d+'/private-profile',{executablePath:process.env['WORKER_BROWSER']==='firefox'?'/Users/thomasingalls/Library/Caches/ms-playwright/firefox-1538/firefox/Nightly.app/Contents/MacOS/firefox':process.env['CHROMIUM_PATH']!,baseURL:'http://localhost:53781',viewport:{width:1400,height:1000},headless:true}), ({executablePath:process.env['WORKER_BROWSER']==='firefox'?'/Users/thomasingalls/Library/Caches/ms-playwright/firefox-1538/firefox/Nightly.app/Contents/MacOS/firefox':process.env['CHROMIUM_PATH']!,baseURL:'http://localhost:53781',viewport:{width:1400,height:1000},headless:true})?.offline === true);await seedProfile(ctx,seed.storage);const p=ctx.pages()[0]??await ctx.newPage();if(process.env['WORKER_BROWSER']!=='firefox')(p as any).__testAuthenticator=await restoreAuthenticator(p,seed.credentials);
 await p.addInitScript(()=>{const Original=WebAssembly.Instance;(window as any).__mirrorMemories=[];(WebAssembly as any).Instance=class extends Original{constructor(module:WebAssembly.Module,imports?:WebAssembly.Imports){super(module,imports);const memory=this.exports['memory'];if(memory instanceof WebAssembly.Memory)(window as any).__mirrorMemories.push(memory)}};const RealWorker=Worker;(window as any).Worker=class extends RealWorker{constructor(url:string|URL,options?:WorkerOptions){super(url,options);(window as any).__testOwnedWorker=this;this.addEventListener('message',e=>{if(e.data?.testPreparationFailure)((window as any).__preparationDiagnostics??=[]).push(e.data.detail);if(e.data?.testWorkerBusy)(window as any).__workerBusy=true;if(e.data?.testCommitReplyHeld)(window as any).__commitReplyHeld=true;if(e.data?.testBaselineReplyHeld)(window as any).__baselineReplyHeld=true;})}}});
 p.on('console',(message:any)=>{if(message.text().startsWith('done/experiment/')){r.diagnostic??=[];r.diagnostic.push(message.text());}});await p.goto('/worker-app/index.html'+(process.env['FAIR_LAB_BITS'] ? '?lab='+process.env['FAIR_LAB_BITS']+'&hold=1&labCutProbe=1' : ''));await p.waitForFunction(()=>(window as any).__mirrorLab);await p.evaluate(async code=>{(window as any).spec={...await(window as any).__mirrorLab.metadata(),code}},seed.code);await work(p,r);r.outcome='passed';
 }catch(error){r.outcome='failed';r.error=String(error);r.workerDiagnostics=await Promise.all((ctx?.pages()[0]?.workers()??[]).map(async(w:any)=>({url:w.url(),events:await w.evaluate(()=>(globalThis as any).__rangeLab?.read()).catch(()=>null)})));throw error;}finally{writeFileSync(join(d,'result.json'),JSON.stringify(r,null,2)+'\n');await ctx?.close().catch(()=>{});await stop();process.env['FAIR_OUT']=out;}}
const opening=(p:any,fault='none')=>p.evaluate(async fault=>{(window as any).b=(window as any).__mirrorLab.create((window as any).spec,fault);return(window as any).b.opening},fault);
const empty=async(p:any)=>expect.poll(()=>p.evaluate(async()=>{const name='done/slot-writer/'+JSON.stringify((window as any).spec.slotId);return(await navigator.locks.query()).held?.filter(v=>v.name===name).length})).toBe(0);
async function shipping(p:any,expected:any,r:any){r.trace=await p.evaluate(()=>(window as any).b.trace);await p.goto('/');await p.evaluate(()=>navigator.serviceWorker.ready);await p.reload();await openSaved(p,saved.code);const archive=await exported(p);expect(archive).toEqual(expected);r.shippingArchive=archiveIdentity(archive);r.guards.unchangedShippingReaderExact=true;}
async function input(p:any,text:string){return p.evaluate(text=>{const v=(window as any).b.input(text);(window as any).input=v;v.ticket.accepted.catch(()=>{});return{before:v.before,after:v.after,requestsDuringHandler:v.requestsDuringHandler,journals:Object.keys(localStorage).filter(v=>v.startsWith('done.pending-update.')).length}},text)}
async function quota(p:any){await p.evaluate(()=>{const original=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){if(this===localStorage&&k.startsWith('done.pending-update.'))throw new DOMException('Disposable quota fault','QuotaExceededError');return original.call(this,k,v)}})}


test('P real native cut inside range-four page then fresh-owner local reopen',async()=>laboratory('dense-cut',async(p,r)=>{
 r.labOnly=true;r.acceptanceCredit=false;await opening(p,'composed');
 const worker=p.workers().find((w:any)=>w.url().includes('accountOwner.worker'));expect(worker).toBeTruthy();r.workerUrl=worker.url();
 expect(await worker.evaluate(()=>(globalThis as any).__rangeLab.bits)).toBe('10101');
 await worker.evaluate(()=>(globalThis as any).__rangeLab.go());
 await expect.poll(()=>worker.evaluate(()=>(globalThis as any).__rangeLab.cutRead()),{timeout:30000}).toEqual({positions:2,held:true});
 await p.evaluate(()=>(window as any).b.flush());
 r.before=await worker.evaluate(()=>(globalThis as any).__rangeLab.read());r.hintBefore=await p.evaluate(()=>(window as any).b.historyStatus());
 r.outcomes=[];for(let n=0;n<20;n++){const v=await p.evaluate(()=>(window as any).b.compositionRemoveLocalHistory(0));r.outcomes.push(v);if(v.kind==='removed'||v.kind==='already-removed')break;if(!['preparation-saved','skipped'].includes(v.kind))throw Error('Unexpected maintenance '+JSON.stringify(v));}
 expect(r.outcomes.at(-1).kind).toBe('removed');r.hintAfter=await p.evaluate(()=>(window as any).b.historyStatus());r.guards.genuineBaselineCutAtTwo=true;
 await worker.evaluate(()=>(globalThis as any).__rangeLab.go());
 await expect.poll(()=>worker.evaluate(()=>(globalThis as any).__rangeLab.cutRead()),{timeout:30000}).toEqual({positions:4,held:true});
 await p.evaluate(()=>(window as any).b.flush());r.worker=await worker.evaluate(()=>(globalThis as any).__rangeLab.read());
 const receipts=r.worker.events.filter((e:any)=>e.kind==='denseReceiptStored');expect(receipts.length).toBe(2);r.splitExtents=receipts.map((e:any)=>[e.first,e.count]);r.sameOriginalPage=receipts[0].pageSha256===receipts[1].pageSha256;r.guards.cutSucceededButLiveTailWasSafelyRefetched=!r.sameOriginalPage;
 const expected=await p.evaluate(()=>(window as any).b.read());await p.evaluate(()=>(window as any).b.close());await empty(p);
 r.coldAttemptStarted=true;try{
  await p.evaluate(async()=>{(window as any).b=(window as any).__mirrorLab.createPublisher((window as any).spec);await(window as any).b.opening;});
  expect(await p.evaluate(()=>(window as any).b.read())).toBe(expected);r.guards.originalAccountReaderColdExact=true;await p.evaluate(()=>(window as any).b.close());
 }catch(error){r.coldFailure=true;throw error;}
},account.actors[1]));

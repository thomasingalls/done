from pathlib import Path
r=Path(__file__).parent;s=(r/'run-eb50.py').read_text();s=s.replace("key='eb50'","key=sys.argv[1]")
s=s.replace("'FAIR_VARIANT':'P-screen'","'FAIR_VARIANT':'EB-lab'")
s=s.replace(" if c.get('fixture'):env['FAIR_FIXTURE']=c['fixture']"," env['FAIR_FIXTURE']=str(fixture)")
s=s.replace(" assert sha(fixture)==sha(r/'private-fixture/fixture.json')"," assert sha(fixture)==frozen['fixtures'][str(fixture)]")
s=s.replace("};(r/(key+'-inputs.json'))",",'fixtures':{str(Path(c.get('fixture',r/'private-fixture/fixture.json'))):sha(Path(c.get('fixture',r/'private-fixture/fixture.json')))for c in plan}};(r/(key+'-inputs.json'))")
assert "'fixtures':"in s
(r/'run-stage.py').write_text(s)
print('Generic declared-stage driver prepared; each cell explicitly targets its actual fixture, including notification fault')

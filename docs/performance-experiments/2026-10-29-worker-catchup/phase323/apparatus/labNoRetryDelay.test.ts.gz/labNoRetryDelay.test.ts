// @vitest-environment node
import {afterEach,expect,it,vi} from 'vitest';
afterEach(()=>{vi.useRealTimers();vi.unstubAllGlobals();vi.resetModules();});
async function setup(mode='1N'){
 vi.useFakeTimers();vi.setSystemTime(0);vi.stubGlobal('location',{href:'https://lab.invalid/?labSY='+mode});vi.resetModules();
 const trace=await import('../src/crdt/maintenanceTraceLab');const {createAutomaticLocalRetention}=await import('../src/crdt/automaticLocalRetention');
 const calls:{at:number;resolve:(v:any)=>void;reject:(e:Error)=>void}[]=[];
 const run=createAutomaticLocalRetention({signal:new AbortController().signal,observe:()=>({ready:true,hint:{revision:1,records:2048}}),remove:()=>new Promise<any>((resolve,reject)=>calls.push({at:Date.now(),resolve,reject}))});
 const tick=(ms:number)=>vi.advanceTimersByTimeAsync(ms);
 run.wake();await tick(10000);expect(calls).toHaveLength(1);
 const priority={site:'accountCapture:baseline-shadow',queuePriority:true,suspended:false,shadowActivity:false,journal:false,handoff:false,authorityStamp:false};
 const interrupt=(extra:Record<string,unknown>={})=>trace.traceInterrupt(Error('lab interruption'),{...priority,...extra});
 const events=()=>((globalThis as any).__maintenanceTraceLab.read().events as any[]);
 return{run,calls,tick,interrupt,events,finish:async()=>{run.dispose();for(const c of calls)c.resolve({kind:'removed'});await tick(0);}};
}
it('removes only the extra pure-priority wait after the input quiet period has elapsed',async()=>{
 const f=await setup();f.run.wake();await f.tick(11000);f.interrupt();f.calls[0]!.resolve({kind:'skipped',reason:'activity-or-journal'});await f.tick(1);expect(f.calls).toHaveLength(2);expect(f.calls[1]!.at).toBeLessThanOrEqual(21001);expect(f.events().find(e=>e.kind==='retry-clock').retryMs).toBe(0);await f.finish();
});
it('keeps the full input quiet period even with a zero priority retry delay',async()=>{
 const f=await setup();f.run.wake();f.interrupt();f.calls[0]!.resolve({kind:'skipped',reason:'activity-or-journal'});await f.tick(9999);expect(f.calls).toHaveLength(1);await f.tick(1);expect(f.calls).toHaveLength(2);expect(f.calls[1]!.at).toBe(20000);await f.finish();
});
it('leaves the full-stack10s priority delay unchanged',async()=>{
 const f=await setup('11');f.run.wake();await f.tick(11000);f.interrupt();f.calls[0]!.resolve({kind:'skipped',reason:'activity-or-journal'});await f.tick(9999);expect(f.calls).toHaveLength(1);await f.tick(1);expect(f.calls).toHaveLength(2);expect(f.events().find(e=>e.kind==='retry-clock').retryMs).toBe(10000);await f.finish();
});
for(const extra of [{suspended:true},{shadowActivity:true},{journal:true},{handoff:true},{authorityStamp:true},{queuePriority:false}])it('keeps60s when another interruption condition is present: '+Object.keys(extra)[0],async()=>{
 const f=await setup();f.run.wake();await f.tick(11000);f.interrupt(extra);f.calls[0]!.resolve({kind:'skipped',reason:'activity-or-journal'});await f.tick(59999);expect(f.calls).toHaveLength(1);await f.tick(1);expect(f.calls).toHaveLength(2);expect(f.events().find(e=>e.kind==='retry-clock').retryMs).toBe(60000);await f.finish();
});
it('does not retry immediately when no classified interruption exists',async()=>{
 const f=await setup();f.run.wake();await f.tick(11000);f.calls[0]!.resolve({kind:'skipped',reason:'activity-or-journal'});await f.tick(59999);expect(f.calls).toHaveLength(1);await f.tick(1);expect(f.calls).toHaveLength(2);await f.finish();
});
it('keeps60s for a different refusal reason even with pure-priority trace evidence',async()=>{
 const f=await setup();f.run.wake();await f.tick(11000);f.interrupt();f.calls[0]!.resolve({kind:'skipped',reason:'durable-attempt'});await f.tick(59999);expect(f.calls).toHaveLength(1);await f.tick(1);expect(f.calls).toHaveLength(2);await f.finish();
});
it('still halts unknown owner failures rather than mapping them to retry',async()=>{
 const f=await setup();f.run.wake();f.interrupt();f.calls[0]!.reject(Error('owner failure'));await f.tick(60000);expect(f.run.status.phase).toBe('halted');f.run.wake();await f.tick(120000);expect(f.calls).toHaveLength(1);await f.finish();
});

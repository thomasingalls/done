from pathlib import Path
import json,hashlib,subprocess,math,collections
r=Path(__file__).parent;repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');old=Path('/private/tmp/done-queue-pipeline-lab-20261031');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();result={'labOnly':True,'acceptanceCredit':False}
start=json.loads((r/'canonical-start.json').read_text());assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==start['head'];assert subprocess.check_output(['git','diff','--cached','--name-only'],cwd=repo,text=True)=='';assert all(sha(repo/n)==h for n,h in start['files'].items());result['canonical']={'sourceInputsUnchanged':len(start['files']),'head':start['head'],'realIndexEmpty':True}
keys=['attach323','cut323','eb50','eb0','worker323','live323','parity323','intake323','removals323'];stages=[];deep=[]
for key in keys:
 ip=r/(key+'-inputs.json');rp=r/(key+'-results.json')
 if not ip.exists()or not rp.exists():continue
 inp=json.loads(ip.read_text());runs=json.loads(rp.read_text());assetRoot=old/'combined-dist'if key=='attach323'else r/'frozen-eb-build-2/combined-dist'if key in ['cut323','eb50','eb0','worker323','live323']else r/'combined-dist';assert all(sha(assetRoot/n)==h for n,h in inp['assets'].items())
 mismatches=[]
 for n,h in inp['sources'].items():
  p=old/'source'/n if key=='attach323'else r/'source'/n
  if key in ['cut323','eb50','eb0','worker323','live323']and(r/'frozen-eb-build-2/source'/n).is_file():p=r/'frozen-eb-build-2/source'/n
  if sha(p)!=h:mismatches.append(n)
 assert not mismatches,(key,mismatches)
 fixtureChecks=[]
 for n,h in inp.get('fixtures',{}).items():assert sha(Path(n))==h;fixtureChecks.append(n)
 # Current apparatus is independently checked for the final stages. Earlier revisions remain identified by their recorded frozen map.
 currentApparatus=all((r/n).is_file()and sha(r/n)==h for n,h in inp['apparatus'].items())
 if key in ['worker323','live323','parity323','intake323','removals323']:assert currentApparatus,key
 for c in runs:
  folder=r/c['name'];p=folder/c.get('result','result.json');p=p if p.exists()else folder/'partial-result.json';x=json.loads(p.read_text());assert c['coldFailure']==bool(x.get('coldFailure'))
  logs=[json.loads(v)for v in(folder/'host-load.jsonl').read_text().splitlines()];assert any(v.get('kind')=='load'for v in logs)
  if x.get('timeTo1025Ms')is not None:
   ev=[e for e in x['worker']['events']if e['kind']=='inboundCommit'and e['at']>=x['startedAt']];total=0;cross={}
   for e in ev:
    total+=e['positions']
    for n in [700,1025]:
     if total>=n and n not in cross:cross[n]=e['at']-x['startedAt']
   assert total==1025
   assert abs(cross[1025]-x['timeTo1025Ms'])<.1 and abs(cross[700]-x['timeTo700Ms'])<.1
   positions=sum(e['positions']for e in ev if e['at']<=x['startedAt']+30000);assert positions==x['positionsAt30']
   assert x['deep30Pass']==(positions>=1025)
   deep.append({'run':c['name'],'recomputedDrainMs':cross[1025],'recomputedPositions30':positions,'coldExact':x['guards'].get('originalAccountReaderColdExact'),'gate30Applied':c.get('rtt',0)==0 and not c.get('diagnosticOnly')and not c.get('profile')and not c.get('workerProfile')})
 stages.append({'key':key,'sourceFilesChecked':len(inp['sources']),'assetFilesChecked':len(inp['assets']),'currentApparatusMatchesRecordedMap':currentApparatus,'fixtureHashesChecked':len(fixtureChecks),'runsReached':len(runs),'runsDeclared':len(inp['plan']),'everyRunHasExternalLoadLog':True})
control=json.loads((r/'profile-attach-control-01/deep-gv/result.json').read_text());assert control['profilerKeptAttachedForCold']and control['profilerDetachedAfterCold']and control['guards']['originalAccountReaderColdExact'];worker=json.loads((r/'worker-profile-eb11-01/deep-gv/result.json').read_text());assert worker['workerProfileLifetime']['controlSessionRetainedThroughCold']and worker['guards']['originalAccountReaderColdExact']
# Independent generated-fixture contract; inspect private values only to emit sizes/hashes, never credentials.
base=json.loads((r/'private-fixture/fixture.json').read_text());grown=json.loads((r/'grown323/prepared-fixture/fixture.json').read_text());win=json.loads((r/'cohort-winning/fixture.json').read_text());a=base['accounts'][0];b=grown['accounts'][0];w=win['accounts'][0];suffix=''.join(str((i+3)%10)for i in range(1024));assert a['backlog']==1024 and b['backlog']==2048 and w['backlog']==2048;assert b['expected']==a['expected']+suffix;assert base['accounts'][1:]==grown['accounts'][1:]==win['accounts'][1:];assert b['actors'][1]==a['actors'][1]and b['actors'][3:]==a['actors'][3:];assert w['actors'][0:2]==b['actors'][0:2]and w['actors'][3:]==b['actors'][3:];assert w['archive']==b['archive'];expected={k:v.replace(a['expected'],b['expected'])for k,v in a['archive'].items()};assert expected==b['archive'];assert sum(v.count(a['expected'])for v in a['archive'].values())==1
fv={'baseFixtureSha256':sha(r/'private-fixture/fixture.json'),'grownFixtureSha256':sha(r/'grown323/prepared-fixture/fixture.json'),'winningFixtureSha256':sha(r/'cohort-winning/fixture.json'),'addedAcceptedPositions':1024,'onlyTargetArchiveChanged':True,'otherAccountsAndUnaffectedActorsUnchanged':True,'winningArchiveExact':True,'dates':[z['date']for z in base['accounts']],'actualArchives':[{'label':z['label'],'requestedGoals':z['goals'],'files':[{'name':k,'characters':len(v),'bytes':len(v.encode())}for k,v in z['archive'].items()]}for z in base['accounts']],'credentialsProfilesDatabasesNotEmitted':True};(r/'fixture323-verification.json').write_text(json.dumps(fv,indent=2)+'\n')
result.update(stages=stages,deepIndependentRecomputations=deep,attachedProfilersColdExact=True,fixtureChecks=fv,scopeNote='Earlier apparatus revisions are recorded by preflight frozen hash maps; current-map equality is only claimed where checked. All source and asset identities are independently checked against retained bytes. No timing or release credit.');(r/'independent323-check.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'canonical':result['canonical'],'stages':stages,'deepJourneysRecomputed':len(deep),'profilerColdExact':True},indent=2))

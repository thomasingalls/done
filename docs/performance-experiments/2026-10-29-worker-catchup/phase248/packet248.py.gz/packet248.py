from pathlib import Path
import json,gzip,hashlib
r=Path(__file__).parent;repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');p=repo/'docs/performance-experiments/2026-10-29-worker-catchup/phase248';p.mkdir();assert '2757 passed' in(r/'phase247/all-unit.log').read_text();assert '1 skipped'in(r/'phase247/all-unit.log').read_text();assert 'pass 108'in(r/'phase248/metadata.log').read_text();assert all(v['failedByAssertion']for v in json.loads((r/'phase248/fault-controls.json').read_text()));assert not(r/'phase248/types.log').read_text();ids={}
files=[*list((r/'phase248').glob('*')),*[r/'phase247'/n for n in ['first-green.log','green-timer-correct.log','focused.log','focused-final.log','all-unit.log','lint.log','typecheck.log','source-format.log']],Path(__file__)]
for f in files:
 if not f.is_file():continue
 name=str(f.relative_to(r));b=f.read_bytes();ids[name]=hashlib.sha256(b).hexdigest();d=p/(name+'.gz');d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(gzip.compress(b,mtime=0))
(p/'inputs.json').write_text(json.dumps(ids,indent=2)+'\n');(p/'README.md').write_text('''# Phase248 — yield to due publication between complete publisher checks

2026-10-30. Two runtime files and one new23-case unit file; old tests unchanged. The scheduler
passes a turn-scoped due-send predicate using actual send eligibility, publication batching,
failure backoff, halt, gate and stop state. After a fully completed empty check, the receive sweep
can yield its verified prefix and resume its remaining budget after sending. It claims no progress
or completed-idle success. Changed native authority identity/publisher count, adopted authority,
history installation, non-idle result or exception discards the scheduling continuation.

The context is an opaque object used for scheduling identity inside the same native module;
no native proof is cached, serialized or transferred. Native publisher selection, four-page turn
fairness, fresh Root/Task/authority/history/ledger/witness checks, final custody/Window promotion/
prefix/conflict checks, synchronous encrypted journal admission and local flush remain intact.
Publication quiet300/max2000ms and retry/halt policy unchanged. No mid-commit interruption.

A remote hint before yielding or during the intervening send stays dirty across continuation:
finishing the remaining checks forces a fresh sweep before idle polling. This prevents missing
writing on a publisher visited before the hint. Online/authority/retry expedites are also retained.
Old callbacks cannot yield a later turn; yielding cannot regress the retained prefix or erase
failure evidence. Every continued turn checks at least one publisher before yielding again.

Validation:95 focused cases pass, including23 new cases; complete units2757pass/one existing skip,
108 metadata cases, types, scoped lint/format and all seven original contract checks pass. Four
isolated source faults fail their expected assertions: disable yield, discard hint on continuation,
ignore turn identity, restart sweep budget. Fault copies restored exactly; no mutation enters build.
Initial candidate assertion ran before Vitest's newly queued zero-delay fake timer; final regression
uses the existing deterministic scheduler fixture and proves exact300ms due-send handoff/600ms
full sweep/5600ms idle deadline. Both attempts retained. A mistaken Node invocation of formatter's
shell shim was corrected; only new test/new type layout formatted, no old formatting rewrite.

503 runtime source records/198 domain homes remain. Only the two runtime hashes/line references
change; all1024 prior manifest rows and exclusions stay byte-identical. New test required/uncredited:
1025obligations/479unresolved (previous1024/478), no aggregate qualification claim. Initial review
incorrectly expected unchanged release selection; independently checked its sole addition is the
new required blocked test. Qualification remains paused. Implementation preserved in this patch;
matched browser protocol/apparatus and timed outcomes follow separately. No signing/push/release
prep, preview8443, service automation, CUA/phone or real-profile activity.
''')
for name,text in [('decisions.md','Yield only between complete verified empty publisher checks; hold native-context/count-scoped remaining sweep, use exact active-turn send eligibility and retain dirty/expedite hints across pause. Explicit yielded outcome claims no progress and preserves failure evidence. Keep batching/local flush/backoff and all authority/fence/commit checks.'),('completed.md','Implemented bounded due-send yielding in two runtime files;23 new/95 focused,2757 full unit cases pass with one existing skip;108 metadata/types/lint/format/seven contracts pass. Four deliberate faults detected and isolated sources restored. All1024 old manifest rows unchanged, new test required/uncredited. Timer/review/formatter construction mistakes retained. Browser comparison next.'),('product-backlog.md','Phase248 implementation/regressions complete. Run fixed before/after normal/withheld two-receiver comparison, original16ms/2.5s every-marker/30s/600s/cold guards; keep proof reuse separate until results identify next clear repair. No release prep.')]:
 with(repo/'docs'/name).open('a')as f:f.write('\n\n## 2026-10-30 — phase248: due-send publisher-check yield\n\n'+text+' [Evidence](performance-experiments/2026-10-29-worker-catchup/phase248/README.md).\n')
print('248 implementation closed, completed before backlog')

from pathlib import Path
import subprocess,json,os,hashlib
r=Path(__file__).parent;src=Path('/private/tmp/done-due-send-yield-20261030/source-after');file=src/'src/crdt/accountSyncDriver.ts';original=file.read_bytes();node='/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node';env={**os.environ,'PATH':str(Path(node).parent)+':'+os.environ['PATH'],'APP_BUILD_REVISION':'0ab9cbc8937e32c6542aaeeca697c87ba116c3be-dirty','APP_BUILD_DATE':'2026-10-30'};faults=[('no-yield','dueAt(\'send\') <= clock.now()','false','offers due sending'),('lose-hint','if (!lane.continuing) lane.dirty = lane.expedite = false;','lane.dirty = lane.expedite = false;','a hint.*survives continuation'),('stale-turn','turn === currentTurn &&','true &&','a retained callback cannot yield'),('restart-sweep','if (!held || held.context !== context || held.count !== count)','if (true || !held || held.context !== context || held.count !== count)','finishes all publishers')];rows=[]
for name,old,new,select in faults:
 s=original.decode();assert s.count(old)==1;(file).write_text(s.replace(old,new))
 try:
  with(r/('fault-'+name+'.log')).open('w')as log:p=subprocess.run([node,str(src/'node_modules/vitest/vitest.mjs'),'run','test/sendDueReceiveYield.test.ts','--testNamePattern',select],cwd=src,env=env,stdout=log,stderr=subprocess.STDOUT)
  log=(r/('fault-'+name+'.log')).read_text();assert p.returncode==1 and 'AssertionError:'in log,(name,p.returncode,log[-1200:]);rows.append({'fault':name,'selection':select,'exit':p.returncode,'failedByAssertion':True})
 finally:file.write_bytes(original)
 assert file.read_bytes()==original
(r/'fault-controls.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))

from pathlib import Path
import shutil,json,hashlib,subprocess,os,time
m=Path('/private/tmp/done-worker-catchup-matched-20261029');r=Path('/private/tmp/done-due-send-yield-20261030');repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');r.mkdir();sha=lambda b:hashlib.sha256(b).hexdigest();signed=json.loads((m/'after-source-inputs.json').read_text());assert signed['commit']=='0ab9cbc8937e32c6542aaeeca697c87ba116c3be'
for name in ['before','after']:
 src=r/('source-'+name);shutil.copytree(m/'source-after',src,symlinks=True)
 for p,h in signed['files'].items():assert sha((src/p).read_bytes())==h,p
 if name=='after':
  for p in ['src/crdt/accountSyncDriver.ts','src/crdt/accountReceive.ts']:(src/p).write_bytes((repo/p).read_bytes())
 files={p:sha((src/p).read_bytes())for p in signed['files']};changes=[p for p,h in files.items()if h!=signed['files'][p]];assert changes==([]if name=='before'else['src/crdt/accountReceive.ts','src/crdt/accountSyncDriver.ts']);(r/(name+'-source-inputs.json')).write_text(json.dumps({'baseCommit':signed['commit'],'uncommitted':name=='after','changedPaths':changes,'files':files},indent=2)+'\n')
for name in ['container-image.json','container-service.mjs','observer.mjs','notification-probe.mjs','notification-probe.d.mts','read-request.mjs','read-request.d.mts','playwright-storage-source.txt','analyze-case.py','build-flags.json']:(r/name).write_bytes((m/name).read_bytes().replace(str(m).encode(),str(r).encode()))
shutil.copytree(m/'harness',r/'harness',symlinks=True,ignore=shutil.ignore_patterns('node_modules','test-results','artifacts'));(r/'harness/node_modules').symlink_to(repo/'node_modules',target_is_directory=True);(r/'private-fixture').symlink_to(m/'private-fixture',target_is_directory=True)
for f in(r/'harness').rglob('*'):
 if f.is_file()and not f.is_symlink()and f.suffix in ['.mjs','.ts','.json']:
  b=f.read_bytes();f.write_bytes(b.replace(str(m).encode(),str(r).encode()))
# Server remains signed0ab before for every case, never client-variant dependent.
p=r/'harness/test/account-continuation-lab/runtime.mjs';s=p.read_text().replace("source='"+str(r/'source-after')+"'","source='"+str(r/'source-before')+"'");p.write_text(s)
# Same workload, only a real civil-calendar setting and pre-input validity guards.
h=r/'harness/test/account-continuation-lab';p=h/'late.spec.ts';s=p.read_text();assert s.count('viewport:{width:1440,height:1000}')==2;s=s.replace('viewport:{width:1440,height:1000}',"viewport:{width:1440,height:1000},timezoneId:'Etc/GMT+12'");old='const offerMarker=async()=>{const i=';assert s.count(old)==1;s=s.replace(old,"const offerMarker=async()=>{await expect(card(writer.p,'H',true)).toHaveAttribute('data-frozen','false');await expect(card(writer.p,'H',true)).toHaveAttribute('data-editing','true');const i=")
# Failure-safe existing DOM/notification observer snapshots; no new source-stage trace.
old=' finally{await Promise.all(contexts.map';assert s.count(old)==1;s=s.replace(old," finally{try{result.finalDiagnostics=await Promise.all(contexts.slice(0,2).map(async c=>{const p=c.pages()[0];return p&&!p.isClosed()?await p.evaluate(()=>({probe:(window as any).__late?.read(),civilDate:[new Date().getFullYear(),new Date().getMonth()+1,new Date().getDate()],timezone:Intl.DateTimeFormat().resolvedOptions().timeZone})):null;}));}catch(e){result.diagnosticError=String(e);}await Promise.all(contexts.map")
p.write_text(s)
# Own unit fault controls use actual complete candidate source, not production imports redirected to old code.
src=r/'source-after';(src/'test/account-sync').mkdir(parents=True);(src/'test/sendDueReceiveYield.test.ts').write_bytes((repo/'test/sendDueReceiveYield.test.ts').read_bytes());(src/'test/setup.ts').write_bytes((repo/'test/setup.ts').read_bytes());(src/'test/account-sync/scheduler-fixture.ts').write_bytes((repo/'test/account-sync/scheduler-fixture.ts').read_bytes())
flags=json.loads((r/'build-flags.json').read_text());node='/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node';env={**os.environ,**flags,'PATH':str(Path(node).parent)+':'+os.environ['PATH'],'APP_BUILD_DATE':'2026-10-30'};receipts=[]
for name in ['before','after']:
 src=r/('source-'+name);e={**env,'APP_BUILD_REVISION':signed['commit']+('-dirty'if name=='after'else'')};cmd=[node,str(src/'node_modules/vite/bin/vite.js'),'build','--outDir',str(r/(name+'-dist')),'--emptyOutDir','--sourcemap'];start=time.time_ns()//1000000
 with(r/(name+'-build.log')).open('w')as f:p=subprocess.run(cmd,cwd=src,env=e,stdout=f,stderr=subprocess.STDOUT)
 assert p.returncode==0,(name,p.returncode);assets={str(f.relative_to(r/(name+'-dist'))):sha(f.read_bytes())for f in(r/(name+'-dist')).rglob('*')if f.is_file()};(r/(name+'-assets.json')).write_text(json.dumps(assets,indent=2)+'\n');receipts.append({'client':name,'startedAt':start,'finishedAt':time.time_ns()//1000000,'command':cmd,'revision':e['APP_BUILD_REVISION'],'assetCount':len(assets)});print(name,'built',flush=True)
(r/'build-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print(r)

from pathlib import Path
import json,subprocess,time,os,sys,signal,hashlib,datetime
r=Path(__file__).parent;d=r/'diagnostic3072/grow';out=d/'run01';out.mkdir(mode=0o700,exist_ok=False);node='/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node';dist=Path('/private/tmp/done-civil-fixture-20261030-r1/dist');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert not(r/'STOP.json').exists();f=r/'cohort-P0/fixture.json';assert json.loads(f.read_text())['accounts'][0]['date']==datetime.datetime.now(datetime.timezone.utc).date().isoformat();inputs={'fixtureSha256':sha(f),'seedAppFiles':{str(p.relative_to(dist)):sha(p)for p in dist.rglob('*')if p.is_file()},'apparatus':{str(p):sha(p)for p in[d/'test/extend.spec.ts',d/'test/config.ts',r/'harness/test/account-continuation-lab/runtime.mjs',r/'harness/test/account-continuation-lab/common.ts',r/'harness/test/account-continuation-lab/seed-profile.ts',r/'harness/test/account-continuation-lab/devices.ts',r/'playwright-storage-source.txt',r/'diagnostic3072/PROTOCOL.md']},'backlogBefore':2048,'backlogAfter':3072,'newAcceptedEdits':1024,'apparatusOnly':True,'acceptanceCredit':False};(out/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n');env={k:v for k,v in os.environ.items()if not k.startswith(('FAIR_','RANGE_LAB_'))};env.update({'PATH':str(Path(node).parent)+':'+env['PATH'],'FAIR_OUT':str(out),'FAIR_DIST':str(dist),'QUIET_WITHHOLD':'0','CHROMIUM_PATH':'/private/tmp/done-civil-gates-browser-20261030/Chrome.app/Contents/MacOS/Google Chrome'});cmd=[node,'node_modules/@playwright/test/cli.js','test','--config','test/config.ts'];load=out/'host-load.jsonl';sampler=subprocess.Popen([sys.executable,str(r/'host_load.py'),'--out',str(load)]);start=time.time()
try:
 for i in range(500):
  if Path(str(load)+'.ready').exists():break
  if sampler.poll()is not None:raise RuntimeError('Sampler failed')
  time.sleep(.01)
 else:raise RuntimeError('Sampler not ready')
 print('START common3072 sender generation, actual UI/accepted uploads',flush=True)
 with(out/'console.log').open('w')as log:p=subprocess.run(cmd,cwd=d,env=env,stdout=log,stderr=subprocess.STDOUT)
finally:sampler.send_signal(signal.SIGTERM);sampler.wait(timeout=10)
x=json.loads((out/'result.json').read_text())if(out/'result.json').exists()else{};receipt={'childExit':p.returncode,'startedAt':start,'finishedAt':time.time(),'command':cmd,'outcome':x.get('outcome'),'coldFailure':x.get('coldFailure',False),'apparatusOnly':True,'acceptanceCredit':False};(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
if x.get('coldFailure'):(r/'STOP.json').write_text(json.dumps({'rule':'Any no-F cold failure stops immediately','case':receipt},indent=2)+'\n');sys.exit(3)

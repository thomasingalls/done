from pathlib import Path
import json,gzip,hashlib,re
m=Path(__file__).parent;r=Path('/private/tmp/done-verified-selection-control-20261030');repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');p=repo/'docs/performance-experiments/2026-10-29-worker-catchup/phase254';p.mkdir();names=['input-diagnostic-run.log','input-diagnostic-outcomes.json','analyze-input-diagnostic.py','input-attribution.json','input-attribution.log','input-diagnostic-cleanup.json'];names+=['04-input-diagnostic-withheld/'+n for n in ['result.json','partial-result.json','analysis.json','analysis.log','console.log','runner-receipt.json','container-identity.json','docker-command.json','services.log']];ids={}
for name in names:
 b=(r/name).read_bytes();ids[name]=hashlib.sha256(b).hexdigest();safe=re.sub(rb'(?<![A-Z0-9])[A-Z0-9]{5}(?:-[A-Z0-9]{5}){4}(?![A-Z0-9])',b'[disposable code redacted]',b);d=p/(name+'.gz');d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(gzip.compress(safe,mtime=0))
b=Path(__file__).read_bytes();(p/'packet254.py.gz').write_bytes(gzip.compress(b,mtime=0));ids['packet254.py']=hashlib.sha256(b).hexdigest();(p/'inputs.json').write_text(json.dumps(ids,indent=2)+'\n');(p/'README.md').write_text('''# Phase254 — input delay precedes browser event creation in this diagnostic

2026-10-30. Single frozen253 same248source/WARM1/withheld native journey, no source/asset changes.
Original functional/archive/same-profile offline-cold/no-reinjection guards pass. End-to-end local
input25.166ms p95 FAILS16ms; max71.156. Peer1477.623ms p95, all markers1017.714/1210.532/1586.576ms
pass2.5s. Backlog136.372s. Diagnostic instrumentation earns no acceptance credit, no old fail erased.

Actual Window metadata:244input events (120keydowns plus finalEscape and123beforeinputs),148event-
timing entries,14rAFgaps>20ms, zero LongTask entries, zero overflow. Both event/longtask APIs supported.
Same-Window raw event creation→keydown p950.6ms/max1ms; keydown→beforeinputp950.3/max0.5ms;
beforeinput→DOMp950.7/max1.8ms.17unambiguously matched slow-keydown EventTiming entries have queue
p950.6ms, processingp950.3ms; unmatched/censored entries stay missing, not zero. Event durations16ms
include presentation/rounding and are not CPU durations. Supported LongTask observation finds no
>=50ms task, not proof that all shorter UI work or physical-device problems are absent.

Offered-command→browser event creation upper p9524.066ms/max69.957ms accounts for most of the
end-to-end tail. Eight keys exceed16ms; four overlap driver heartbeat gaps. Driver loop max169.214ms.
No synchronous save interval overlaps a slow key; observed request-metadata handler max0.135ms.
This rules against those two specific synchronous handlers as the dominant per-key tail here,
not all driver work. Remaining delay can be in Playwright/client/server IPC, CDP/Browser process
routing or host scheduling before input creation. Do not rewrite application coordination based
on this measurement alone. Original user-reported mobile/refocus stalls are not disproved.

Independent pairing checks every trusted/focused/visible event against its actual command/clock
brackets; same-Window stamps avoid cross-clock assumptions. Diagnostic observers/extra allocations
can affect timing, one journey cannot identify a population cause. All original25/38ms failures
remain failed. Exact own container/browsers absent, no raw targets/keys/writing/factors/proofs stored.

Clear next experiment: balanced within-journey keyboard delivery crossover (Playwright keyboard
versus native CDP keyDown/keyUp), identical true characters/actual trusted events and original
Node-offer→DOM gate. Hold app/server/fixture/cadence/observers fixed, deterministic paired assignment
and all archives/security/deadlines. This diagnoses measurement delivery, not a product repair,
not replacing input time with post-event processing or an easier profile. No release preparation.
''')
for name,text in [('decisions.md','Do not alter application CPU yielding or coordination for observed pre-event input tails. Actual browser creation→handler0.6ms/EventTiming queue0.6ms and zero longtasks narrow this diagnostic to precreation delivery/host work; test delivery APIs within one balanced journey, keep original Node-offer→DOM16ms gate.'),('completed.md','253 native diagnostic retains local25.166ms failure; peer/markers/archive/offline-cold pass. Trusted creation→keydownp950.6ms, beforeinput→DOM0.7ms; offered→creation24.066ms. Eight slow keys, four driver-gap overlaps, no save overlap and metadatahandlermax0.135ms. No product edit; exact cleanup complete.'),('product-backlog.md','Phase254: next bounded delivery-backend crossover to distinguish Playwright path from remaining CDP/host scheduling. Keep all16ms/2.5s gates and previous physical/UI/input/cold failures; no blind application repair or release prep.')]:
 with(repo/'docs'/name).open('a')as f:f.write('\n\n## 2026-10-30 — phase254: pre-event input-delay attribution\n\n'+text+' [Evidence](performance-experiments/2026-10-29-worker-catchup/phase254/README.md).\n')

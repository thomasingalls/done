import {spawn,execFileSync}from'node:child_process';
import{createInterface}from'node:readline';
import{mkdirSync,writeFileSync,readFileSync,appendFileSync}from'node:fs';
import{startAccountGateway}from'../../scripts/lib/account-gateway.mjs';
const root='/private/tmp/done-unreduced-work-counts-20261030',source='/private/tmp/done-unreduced-work-counts-20261030/source-after',image=JSON.parse(readFileSync(root+'/container-image.json')).Id;
let child,app,statePath,readyResolve,rejectReady;let serial=0;const pending=new Map();export let resourceStop,readyIdentity;
export const control=kind=>new Promise((resolve,reject)=>{if(!child||child.exitCode!==null||child.signalCode||child.stdin.destroyed||child.stdin.writableEnded){reject(Error('Control unavailable '+kind));return;}const id=++serial;const timer=setTimeout(()=>{pending.delete(id);reject(Error('Control deadline '+kind))},15000);pending.set(id,{resolve,reject,timer});child.stdin.write(JSON.stringify({kind,id})+'\n')});
export async function start(state,dist){
 statePath=state;mkdirSync(state,{recursive:true,mode:0o700});const args=['run','--rm','--interactive','--cpus=1','--memory=1g','--memory-swap=1g','--pids-limit=128','--cap-drop=ALL','--security-opt=no-new-privileges','--read-only','--tmpfs','/tmp:rw,nosuid,nodev,size=64m','--user',String(process.getuid())+':'+String(process.getgid()),'--cidfile',process.env.FAIR_OUT+'/container.cid','--publish','127.0.0.1::53110','--volume',root+':/experiment:ro','--volume',state+':/state:rw'];
 for(const f of ['account-service','account-protocol','src','scripts'])args.push('--volume',(source+'/'+f)+':/app/'+f+':ro');
 args.push('--entrypoint','/usr/local/bin/node',image,'/experiment/container-service.mjs');writeFileSync(process.env.FAIR_OUT+'/docker-command.json',JSON.stringify(args,null,2)+'\n');
 child=spawn('docker',args,{stdio:['pipe','pipe','pipe']});child.stderr.on('data',b=>appendFileSync(process.env.FAIR_OUT+'/services.log',b));
 const ready=new Promise((resolve,reject)=>{readyResolve=resolve;rejectReady=reject});const timer=setTimeout(()=>rejectReady(Error('Container startup deadline')),20000);
 createInterface({input:child.stdout}).on('line',line=>{let msg;try{msg=JSON.parse(line)}catch{appendFileSync(process.env.FAIR_OUT+'/services.log',line+'\n');return}if(msg.ready){clearTimeout(timer);const id=readFileSync(process.env.FAIR_OUT+'/container.cid','utf8').trim(),x=JSON.parse(execFileSync('docker',['inspect',id]))[0],h=x.HostConfig;readyIdentity={...msg,Id:x.Id,Image:x.Image,Config:{User:x.Config.User,Entrypoint:x.Config.Entrypoint,Cmd:x.Config.Cmd},HostConfig:{NanoCpus:h.NanoCpus,Memory:h.Memory,MemorySwap:h.MemorySwap,PidsLimit:h.PidsLimit,ReadonlyRootfs:h.ReadonlyRootfs,CapDrop:h.CapDrop,SecurityOpt:h.SecurityOpt},Mounts:x.Mounts};writeFileSync(process.env.FAIR_OUT+'/container-identity.json',JSON.stringify(readyIdentity,null,2)+'\n');readyResolve(Number(x.NetworkSettings.Ports['53110/tcp'][0].HostPort));}else if(msg.resourceStop){resourceStop=msg.resourceStop;}else if(msg.id&&pending.has(msg.id)){const p=pending.get(msg.id);pending.delete(msg.id);clearTimeout(p.timer);msg.error?p.reject(Error(msg.error)):p.resolve(msg);}});
 child.on('exit',code=>{clearTimeout(timer);rejectReady?.(Error('Container exited '+code));for(const p of pending.values()){clearTimeout(p.timer);p.reject(Error('Container exited '+code))}pending.clear();});
 const port=await ready;app=await startAccountGateway({port:53781,origin:'http://localhost:53781',servicePort:port,packaged:dist});
}
export async function stop(){
 if(app){const oldApp=app;app=undefined;await oldApp.close();}
 if(!child)return;
 const old=child,cid=readFileSync(process.env.FAIR_OUT+'/container.cid','utf8').trim();
 try{if(old.exitCode===null&&!old.signalCode&&!old.stdin.destroyed&&!old.stdin.writableEnded)await control('stop');}
 finally{
  await new Promise(resolve=>{
   if(old.exitCode!==null||old.signalCode){resolve();return;}
   const timer=setTimeout(()=>{try{execFileSync('docker',['stop','--time','10',cid],{stdio:'ignore'})}catch{}},10000);
   old.once('exit',()=>{clearTimeout(timer);resolve();});
  });
  if(child===old)child=undefined;
 }
}

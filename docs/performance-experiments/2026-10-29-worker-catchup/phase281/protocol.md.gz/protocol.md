# Phase281 — requested cold work counts and one unreduced live publish

Use one rebuilt diagnostic artifact: exact cumulative275 runtime, only
VITE_ACCOUNT_LEDGER_PROFILE=1; warm stays unset/default on, original production16/session64/process.
No CPU, per-crypto, error hooks or periodic polling for cold. Original context/era case preserves
15s cold gate and full native journal/Undo/archive guards. One after-open numeric snapshot per
realm reads frozen editor milestone metrics, work baselineFullReplays/baselineExactReuses. Operator
hypothesis2full/3exact, not a pass assertion. This diagnostic receives no acceptance credit; prior
cold passes alone cannot establish the optimization's gain. Counts at editor are distinct from
later network work and whole-case durations.

Second preassigned case: real composed original owner, install unreduced baseline, verify no
unpublished captures before measurement, one synchronous Window input/new source, native admission,
flush and actual verified source acceptance within original30s total-from-input deadline. Read
numeric work/cost before/after and counter versions3/4 (never5) before/after. Source-coverage status
polls perform native loads; retain their count and qualify wall/work observations as including that
observer work. No exclusion or automation flag change to force a favorable unreduced result. Exact
writing/cold archive afterward.180s whole case unchanged; preserve all failures, no favorable rerun.

Both are fictional headless development profiles only. No release prep, service automation,
production/preview changes, signing/pushing or computer use. V2 receipt remains development-only;
all tag readers, range4/8 tests, stale-tab and rollback behavior are required before release work.
Normal Page/Worker comparison held; after these additions continue reader/planner/deep fairness,
Page deep64 and re-runnable fixture/withheld/normal gates. All existing gates/security/limits stay.

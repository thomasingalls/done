from pathlib import Path
import subprocess,json,time,sys,signal,hashlib,shutil
r=Path(__file__).parent;out=r/sys.argv[1];out.mkdir(exist_ok=False);node='/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node';cmd=[node,str(r/'source/node_modules/vitest/vitest.mjs'),'run','--config',str(r/'vitest.lab.config.mjs')];
for n in ['src','account-protocol']:shutil.copytree(r/'source'/n,out/'source'/n,symlinks=True)
shutil.copy2(r/'vitest.lab.config.mjs',out/'config.mjs');shutil.copy2(r/'source/test/labDenseReceipt.test.ts',out/'labDenseReceipt.test.ts');shutil.copy2(r/'source/test/labDenseReaders.test.ts',out/'labDenseReaders.test.ts');ident={str(p.relative_to(r/'source')):hashlib.sha256(p.read_bytes()).hexdigest()for n in ['src','account-protocol','test','docs/account-crypto']for p in(r/'source'/n).rglob('*')if p.is_file()};(out/'inputs.json').write_text(json.dumps(ident,indent=2)+'\n');sampler=subprocess.Popen([sys.executable,str(r/'host_load.py'),'--out',str(out/'host-load.jsonl')]);start=time.time()
try:
 with(out/'console.log').open('w')as f:p=subprocess.run(cmd,cwd=r/'source',stdout=f,stderr=subprocess.STDOUT,env={**__import__('os').environ,'P_COLD_RECEIPT_PATH':str(out/'cold.json')})
finally:sampler.send_signal(signal.SIGTERM);sampler.wait(timeout=10)
(out/'receipt.json').write_text(json.dumps({'command':cmd,'childExit':p.returncode,'startedAt':start,'finishedAt':time.time(),'labOnly':True,'acceptanceCredit':False,'nativeProfileColdAttempted':False,'sourceSnapshot':'source'},indent=2)+'\n');print('Probe child exit',p.returncode)

log=(out/'console.log').read_text()
if 'P_INTERIOR_COLD_ATTEMPT_STARTED' in log and 'P_INTERIOR_COLD_EXACT' not in log:
 (r/'STOP.json').write_text(json.dumps({'rule':'Any no-F cold failure stops immediately','case':out.name,'raw':'console.log'},indent=2)+'\n');sys.exit(3)

if (out/'cold.json').exists() and not json.loads((out/'cold.json').read_text()).get('exact'):
 (r/'STOP.json').write_text(json.dumps({'rule':'Any no-F cold failure stops immediately','case':out.name,'raw':'cold.json'},indent=2)+'\n');sys.exit(3)

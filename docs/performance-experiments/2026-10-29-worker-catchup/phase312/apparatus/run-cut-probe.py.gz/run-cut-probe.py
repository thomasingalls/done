from pathlib import Path
import json,subprocess,time,sys,os,signal,hashlib
r=Path(__file__).parent;out=r/'cut-probe-attempt4';out.mkdir(mode=0o700,exist_ok=False);node='/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node'
env={**os.environ,'PATH':str(Path(node).parent)+':'+os.environ['PATH'],'FAIR_OUT':str(out),'FAIR_LAB_BITS':'10101','FAIR_SY_BITS':'11','FAIR_IDLE_PAUSE':'1','CHROMIUM_PATH':'/private/tmp/done-civil-gates-browser-20261030/Chrome.app/Contents/MacOS/Google Chrome'}
import shutil
shutil.copytree(r/'source/src',out/'source/src');shutil.copytree(r/'source/account-protocol',out/'source/account-protocol');shutil.copytree(r/'combined-dist',out/'combined-dist');shutil.copy2(r/'harness/test/account-continuation-lab/dense-cut.spec.ts',out/'dense-cut.spec.ts')
cmd=[node,'node_modules/@playwright/test/cli.js','test','--config','test/account-continuation-lab/dense-cut.config.ts'];(out/'inputs.json').write_text(json.dumps({'sources':{str(p.relative_to(r/'source')):hashlib.sha256(p.read_bytes()).hexdigest()for d in ['src','account-protocol']for p in(r/'source'/d).rglob('*')if p.is_file()},'assets':json.loads((r/'build-identity.json').read_text())['files'],'labOnly':True,'acceptanceCredit':False},indent=2)+'\n')
sampler=subprocess.Popen([sys.executable,str(r/'host_load.py'),'--out',str(out/'host-load.jsonl')]);start=time.time()
try:
 for i in range(500):
  if(out/'host-load.jsonl.ready').exists():break
  if sampler.poll()is not None:raise RuntimeError('sampler failed')
  time.sleep(.01)
 else:raise RuntimeError('sampler deadline')
 with(out/'console.log').open('w')as f:p=subprocess.run(cmd,cwd=r/'harness',env=env,stdout=f,stderr=subprocess.STDOUT)
finally:sampler.send_signal(signal.SIGTERM);sampler.wait(timeout=10)
x=json.loads((out/'dense-cut/result.json').read_text())if(out/'dense-cut/result.json').exists()else{}
receipt={'childExit':p.returncode,'startedAt':start,'finishedAt':time.time(),'command':cmd,'coldFailure':x.get('coldFailure',False),'labOnly':True,'acceptanceCredit':False};(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
if x.get('coldFailure')or(x.get('coldAttemptStarted')and not x.get('guards',{}).get('originalAccountReaderColdExact')):
 (r/'STOP.json').write_text(json.dumps({'rule':'Any no-F cold failure stops immediately','case':'cut-probe-attempt4','receipt':receipt},indent=2)+'\n');sys.exit(3)

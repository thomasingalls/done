from pathlib import Path
import json,csv,hashlib
r=Path(__file__).parent;repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');d=repo/'docs/performance-experiments/2026-10-29-worker-catchup/phase329';summary=json.loads((r/'summary329.json').read_text());paired=json.loads((r/'paired329-analysis.json').read_text());grown=json.loads((r/'grown329-predicates-analysis.json').read_text());owners=json.loads((r/'grown329-owners-analysis.json').read_text());loads=json.loads((r/'host329-summary.json').read_text());historical=json.loads((r/'coordinated326-historical-markers.json').read_text())
sec=lambda x:'—'if x is None else f'{x/1000:.3f}'
text='''# Phase 329 — record-scoped retained receipts, lab evidence only

The proposed diagnosis is confirmed in the private prototype. The first warm-audit difference is `inbound.peers.map#3.retained[7].envelope` at 260 physical rows: full replay retained a stale dense page's envelope for a later legacy record. The byte lengths are 339 versus 383; the bounded walk took 2,699 visits. No other first differing path was observed in the initiating diagnostic.

The private record-scoped repair passes all 18 paired journeys, including actual automatic maintenance on both devices and 36 exact offline cold reopens. **All six paired latency cells still fail**: peer p95 and every-marker fail in every journey; one journey also fails input p95. The three repaired 2,048-position withheld runs and P0 pass their measured predicates and both-owner cold checks. The matched unrepaired P1 control reproduces `owner-error` during building, with `Local baseline refused: integrity` at `localBaselineReplay.ts:596`. The functional stop rule fires. Single-500 with Device 1 writing and the final deep control remain **not run**.

Nothing lands or earns acceptance credit. No default, format, security guard, gate, limit or deadline changes. No hardening, release preparation, production access or computer use. The full 25-run record includes the pre-repair diagnostic, common fixture preparation, 18 paired journeys and all five grown runs. Parent roots and failures stay intact.

## Contract and sequence

See [predeclared protocol](./PROTOCOL329.md), [summary](./summary329.json), [artifact index](./evidence-index.json) and [independent input check](./independent329-check.json). This executes the requested follow-up after phase327; phase328 is the intervening immutable evidence-provenance correction. The new root is `/private/tmp/done-retained-scope-lab-20261101`.

The operator's latest amendment is explicit: latency misses in every arm fail the predicate and cell, and do not stop subsequent runs. Owner closure, repair-required, maintenance owner-error, missing/lost writing and cold failure stop in any arm; unexpected first difference or a fault extending into shared main code also stops. This applies to the negative control too. It ran last, so its failure leaves item6 unrun; no expected-failure waiver was invented. No later experiment runs after that stop.

The selected lab stack stays G8/R1000/SY1N/P1/V0/D0/E+B, RECEIVE_QUIET_MS750, full prefix comparison, original per-entry crypto/expiry/authorization/chain/witness/commit checks, synchronous journal admission and chain-order commit. Server account64/s burst480/session16/s burst120, account/session active16/4, Worker RPC8, index32MiB/logical32768 and maintenance120s remain. Grown >=60-key overlap stays; no normal latency is relabeled report-only.

## Counterexample and repair

Before any repair, `source-before` adds a bounded first-difference observer and message/stack logging at the maintenance catch. It changes no comparison result or error behavior. The initiating native audit still closes repair-required. Critical observations stream before termination; high-volume ordinary crypto spans remain local. This avoids treating diagnostic Window exchanges as protocol performance evidence.

Two new real-crypto controls construct dense then legacy records for two publishers and compare a single full `verifyInboundLedger` call to continuations over exactly the same records using `sameAccountLedger`. They independently check every retained envelope's sequence against its ledger position. One extent starts at zero; the other has `first > 0`. Both fail unrepaired: the first retains sequence1 at own positions2/3 and peer position3; the second tries to use entry0 from an extent beginning at1. Both P1 controls and their P0 counterparts pass after the private repair.

The repair closes a cached turn when iteration leaves its creating physical record, and supplies `recordTurn` only when `pageRecord === record`. Both stored verification and the retained-envelope read use that scoped value. Legacy records use their own `decodeInboundPage(event.page)`. The turn's entry returns owned bytes, preserving erasure behavior. No unauthenticated input gains stored status, and no signature, ledger, witness, expiry, authority, coverage or commit check is removed.

Canonical `inboundLedger.ts` has no `pageTurn` optimization; all 1,552 canonical inputs are unchanged. The incorrect derived state is lab-only. The negative control reaches the existing shared `verifyReceipt` guard that checks publisher and sequence, exactly as predicted; that guard is preserved, not repaired or weakened. Its mapped stack is [retained separately](./retention329-mapped.json).

Focused validation is **122 cases in 17 files**, plus strict TypeScript (explicit final child exit0). It includes stored-mode/readers, transport quotas/queues, journal admission, batching/scheduler, automatic retention and the mixed-receipt controls. This is not a full-unit-suite or release-validation claim. The first post-repair run had 121 passes and one observer-test failure: caller-side critical-only streaming was corrected while preserving the old stream API and test assertions. The first strict run had two new-test `Uint8Array<ArrayBufferLike>` annotations; the new test's wire annotation was corrected. All failed logs remain, as does an initial postprocessing TypeError corrected before analysis; no run was discarded or regraded.

## Paired fixture and measurement boundary

The old two-card sender fixture leaves Device1 below the unchanged automatic1024-record threshold under coordinated sending. Waiting would not expose maintenance. A common fixture was therefore grown through native public typing on the repaired coordinated build: one known ` seed329:` plus700 `g` keys at150ms, in the SA card only; every other file remains exact. Both full archives were checked and profiles locked/saved before maintenance. Saved physical counts are Device1=1,675 and Device2=3,089. No storage rewrite, manual maintenance, threshold override or fake time. See [preparation receipt and metadata caveat](./GROW-RECEIPT329.json).

The original growth plan retains unused inherited reference/2-writer/300-key template fields. The frozen growth spec and build flags establish the actual coordinated/one-writer/700-key preparation; it is not a 300-key sender measurement. This caveat does not alter the plan's original bytes.

All three policies use this same maintenance-eligible fixture, distinct persistent Chrome processes/publishers, 300 keys/device at150ms and three markers per device, in the declared mixed three blocks at0/50ms. Native harmless pointer pulses keep the ordinary input-quiet timer active only during sequential setup; they stop and are awaited before measured typing. Both owners have zero maintenance attempts at typing start. Publication/receipt/position costs are captured before Undo and maintenance. Full original archives plus only offered appends, peer convergence, Undo, actual maintenance completion and offline cold editing/Undo are retained. The absolute120s-after-last-key maintenance limit is unchanged.

These larger-fixture timings are **not a matched before/after performance comparison** with phase326's small sender fixture. The scope repair's effect on latency is not identified. All six cells fail; the unexplained long Device2-to-Device1 peer delays remain a next diagnostic, not an accepted cost.

## Paired results — every run

Times below are seconds. Input and peer values list Device1/Device2 writing separately; peer is observed on the opposite device. Each functional pass includes both owners completing maintenance and exact offline cold reopens. Detailed counts, commands, all markers, read/write units, cold timing and predicates are in [direction CSV](./paired329-directions.csv), [maintenance CSV](./paired329-maintenance.csv) and [cell record](./paired329-cells.json). No missing key was observed in these18 journeys. All36 maintenance traces have zero overflow/capacity refusal/throw; completion was41.868–71.053s after the last measured key. Critical post-start observations contain64 equal-ledger audits and no first-difference/throw/native-close event; no observed stream gap/drop.

| Run | RTT ms | Policy | Functional/cold | Input p95 s D1/D2 | Peer p50 s D1/D2 | Peer p95 s D1/D2 | Failed latency predicates |
|---|---:|---|---|---|---|---|---|
'''
for x in sorted(paired,key=lambda x:(x['replicate'],x['rtt'],x['policy'])):
 ds=x['directions'];vals=lambda role,p:'/'.join(sec(z['latency'][role][p])for z in ds);failed=', '.join(k for k,v in x['metricPredicates'].items()if not v)
 text+=f"| r{x['replicate']} | {x['rtt']} | {x['policy']} | pass / exact both | {vals('local','p95')} | {vals('peer','p50')} | {vals('peer','p95')} | {failed} |\n"
text+='''
Input fails in r1/0ms/reference Device1 at1.422s p95; Device2 is5.969ms. It remains a failed predicate, not a stop or exclusion. All18 peer and all18 every-marker predicates fail. One failing replicate fails its cell, so all six cells stay failed.

### Immediate-inflight — all markers, positions and cold

Peer times are seconds; input is ms. The denominator is300 offered keys per writer;303 input commands includes three marker insertions. Position counts are accepted service tip deltas captured after complete delivery and before Undo/maintenance. The CSV also records positions per100 commands. All twelve rows below cold-reopen exact with offline edit/Undo.

| Replicate | RTT ms | Writer | Peer p50 s | Peer p95 s | Marker1/2/3 s | Input p95 ms | Positions/100keys | Cold |
|---|---:|---|---:|---:|---|---:|---:|---|
'''
for x in sorted([x for x in paired if x['policy']=='immediate-inflight'],key=lambda x:(x['replicate'],x['rtt'])):
 for z in x['directions']:
  text+=f"| {x['replicate']} | {x['rtt']} | D{z['stream']+1} | {sec(z['latency']['peer']['p50'])} | {sec(z['latency']['peer']['p95'])} | {' / '.join(sec(v)for v in z['markerLatency']['peer'])} | {z['latency']['local']['p95']:.3f} | {z['positionsPer100Keys']:.3f} | exact |\n"
text+='''
### Historical coordinated failure stays separate

Phase326 coordinated missed every-marker in **6/6** paired journeys, before this fixture change. The first marker was2.728–2.802s at0ms and3.038–3.125s at50ms across directions. This is not cured or regraded by functional successes here. [Every original marker and the immutable source hash](./coordinated326-historical-markers.json).

## Grown withheld — all five declared outcomes

Original writer120s wait/assertions, actual preparation+backlog at typing start, 120 keys500ms, >=60 overlap,30s new-delivery and original cold steps are unchanged. Reader completion uses the absolute120s-after-last-key diagnostic window; it is not substituted for the writer gate. A reader halt/close would stop. Per-owner journal peaks, every interruption by arriving job, retry clocks and waits are in [owners](./grown329-owners-analysis.json), [attempts](./grown329-attempts.csv), [retries](./grown329-retries.csv) and [conditions](./grown329-interruptions.csv). Journal values below are observed in-memory maps and saved durable delta payloads, not encrypted disk usage or RAM totals.

| Run | Child | Peer p95 s | Input p95 ms | Overlap keys | Backlog s | New delivery after final command s | Measured predicates | Cold |
|---|---:|---:|---:|---:|---:|---:|---|---|
'''
for x in grown:
 failed=[k for k,v in x['gatePredicates'].items()if not v]
 text+=f"| {x['name']} | {x['childExit']} | {sec(x.get('peerP95Ms'))} | {x.get('inputP95Ms',0):.3f} | {x.get('overlapKeys')} | {sec(x.get('backlogMs'))} | {sec(x.get('finalNewDeliveryMs'))} | {'pass all'if not failed else ', '.join(failed)} | {x['cold']} |\n"
text+='''
| Run / owner | Completion after last key s | Attempts | Interruptions | Peak map bytes | Peak durable payload bytes | Capacity | Cold |
|---|---:|---:|---:|---:|---:|---:|---|
'''
for x in owners:
 for o in x['owners']:
  cold=o.get('cold')or{}
  text+=f"| {x['name']} / {o['role']} | {sec(o['completionAfterLastKeyMs'])} | {o['attemptsThroughCutoff']} | {o['interruptedAttemptsThroughCutoff']} | {o['peakMapBytesObserved']} | {o['peakDurablePayloadBytesThroughCutoff']} | {o['capacityRefusalsThroughCutoff']} | {cold.get('outcome','not reached')} |\n"
text+='''
The repaired writers finish32.516–35.630s and readers54.003–55.417s after the last key, inside120s. P0 finishes46.112s/73.315s (writer/reader). The unrepaired writer halts on attempt4 while building: `Error: Local baseline refused: integrity`; its name is `Error`, as predicted. The mapped stack enters `verifyReceipt` at596, where envelope publisher/seq must equal the retained position, then snapshot-receipt collection at741. All earlier offered writing and Undo had converged, but maintenance/cold predicates fail and cold is not attempted. The reader is censored at that functional stop, not called passed or failed cold. No capacity refusal is measured in any grown owner.

The unrepaired control was built from source matching repaired source except restoring exact `source-before/src/crdt/inboundLedger.ts`; the independent check verifies that only this source file differs. Its recurrence, the mixed-record counterexamples and four successful repaired/P0 grown journeys support the common stale-retained-envelope cause. They do not prove every historical owner closure had that cause.

## Limits, preserved failures and next decision

All25 timed runs have external5s host CPU/top-process logs. [Load summaries](./host329-summary.json) qualify the measurements; no quiet-host guarantee or exclusion is inferred. No competing build/heavy analysis was launched during the timed cells. Browser is frozen Chrome156; this is not Android observation. The profiler session issue from322 is not retested here. Source/build identities and apparatus maps are retained for every stage. Historical pre-stop runner bytes are explicitly reconstructed by reversing only the later stop additions and matching their frozen input hash; no historical input identity is silently replaced with the current runner.

The final independent check verifies all1,552 canonical inputs, HEAD, every frozen runtime/asset/server/apparatus/fixture input map, matched negative source and the real empty Git index. The evidence pack contains inert private source differences, new controls, recipes and exact raw logs/JSON/CSV with hashes; it excludes compiled assets, profiles, database/state and credential fixtures. Raw roots remain intact. No running preservation output is snapshotted.

Next work requires operator direction: resume the unrun Device1 single-500 and deep control after the intentional negative-control stop, then isolate paired latency on this maintenance-eligible fixture, including the1.422s input outlier. No sender default is selected. Landing the record-scoping repair would require a separately authorized hardened patch/control series; the dense format's compatibility/rollback/handoff and other open landing contracts remain unchanged. No hardening starts here.
'''
(d/'README.md').write_text(text.rstrip()+'\n')
def append(name,addition):
 p=repo/name;p.write_bytes(p.read_bytes()+addition.encode())
# Durable outcome first, before advancing any queue entry. Another seat owns progress.md.
append('docs/completed.md','''
### 2026-11-01 — Phase329: mixed dense/legacy retained-record scope

Pre-repair warm audit first differs at inbound.peers.map#3.retained[7].envelope; two real-crypto full/continuation controls fail, including first>0. Private record-scoped turn repair passes P0/P1 controls,122focused cases/17files and strictTS. All18paired journeys complete actual maintenance on both owners and36exactofflinecoldchecks; all6latencycellsfail(peer/markers18of18,input1of18). Three repaired grown withheld runs and P0 pass all measured predicates/both cold; matched unrepairedP1 halts owner-error with integrity guard at localBaselineReplay:596. Functional stop leaves Device1single500/deep control unrun. All25runs/failures/hostlogs preserved,1552canonicalinputs unchanged,indexempty. Evidence/docs only; no landing/default/hardening/credit. [Phase329](./performance-experiments/2026-10-29-worker-catchup/phase329/README.md). Outcome recorded before queue advance.
''')
append('docs/decisions.md','''
### 2026-11-01 — Phase329: distinguish functional repair from failed latency cells

Apply the operator's clarification literally: latency misses keep predicates/cells failed and do not stop; functional failure in any arm, including the unrepaired control, stops. Preserve all old guards; scope the private parsed-page turn to its creating physical record and use each legacy record's own bytes. The stale retained state is generated by lab-only code; the unchanged shared publisher/seq integrity guard detects it. Use one public-typed maintenance-eligible paired fixture for all policies, exposing both owners without lowering the1024record threshold. Its timings are not a matched old-small-fixture before/after. Negative-control failure leaves later controls unrun; no default/hardening/landing decision is inferred from18functional successes or3grown measured passes. [Evidence](./performance-experiments/2026-10-29-worker-catchup/phase329/README.md).
''')
append('docs/product-backlog.md','''
### 2026-11-01 — Phase329: scope diagnosis confirmed; paired latency and unrun controls remain

The lab mixed dense/legacy replay reuses a stale turn; focused controls and a matched unrepaired grown recurrence confirm the retained receipt defect. Private repair passes18paired functional/both-maintenance/cold journeys and3repaired grown measured journeys. All6paired latencycells remain red, including one1.422sinputp95outlier; trace on the common larger fixture before selecting a sender policy. Device1single500 and finaldeep0 control are unrun because the unrepairedP1maintenance owner-error triggered the explicit functional stop. Resumption and hardening need operator direction; no main/source/default/format change or release work. [Allruns and separate limits](./performance-experiments/2026-10-29-worker-catchup/phase329/README.md).
''')
prefix=json.loads((r/'append-only329-before.json').read_text())
for name,old in prefix.items():
 raw=(repo/name).read_bytes();assert hashlib.sha256(raw[:old['bytes']]).hexdigest()==old['sha256'];assert len(raw)>old['bytes']
(d/'append-only-check.json').write_text(json.dumps({'oldPrefixesVerified':prefix,'completionAppendedBeforeQueue':True,'progressMdUntouched':True},indent=2)+'\n');print('Wrote report; prior documentation prefixes verified')

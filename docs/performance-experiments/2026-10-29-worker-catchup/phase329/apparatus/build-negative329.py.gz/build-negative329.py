from pathlib import Path
import shutil,subprocess,json,os
r=Path(__file__).parent;s=r/'source-unrepaired-control';shutil.copytree(r/'source-repaired',s,symlinks=True)
# Matched observation/source except the exact previously demonstrated stale-turn implementation.
(s/'src/crdt/inboundLedger.ts').write_bytes((r/'source-before/src/crdt/inboundLedger.ts').read_bytes())
b=r/'build-negative';b.mkdir();(b/'source').symlink_to(s,target_is_directory=True);shutil.copytree(r/'build-repaired/lab',b/'lab',symlinks=True)
for p in(b/'lab').rglob('*'):
 if p.is_file()and p.suffix in['.ts','.mjs','.html']:p.write_text(p.read_text().replace(str(r/'build-repaired'),str(b)))
for n in['build-lab.py','build.mjs','release-flags.json']:(b/n).write_text((r/'build-repaired'/n).read_text().replace(str(r/'build-repaired'),str(b)))
with(r/'build329-negative-coordinated.log').open('w')as f:q=subprocess.run(['python3',str(b/'build-lab.py')],cwd=b,env={**os.environ,'LAB_BATCH_POLICY':'coordinated-2000'},stdout=f,stderr=subprocess.STDOUT)
if q.returncode:raise SystemExit(q.returncode)
d=r/'unrepaired-control-coordinated';d.mkdir();shutil.move(str(b/'combined-dist'),d/'combined-dist')
for n in['build-identity.json','build-flags.json','frontend-build.log','lab-build.log']:shutil.copy2(b/n,d/n)
print('Built matched unrepaired control; no canonical source changes')

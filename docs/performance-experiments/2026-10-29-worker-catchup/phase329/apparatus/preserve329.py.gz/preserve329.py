from pathlib import Path
import json,gzip,hashlib,subprocess,shutil
r=Path(__file__).parent;repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');d=repo/'docs/performance-experiments/2026-10-29-worker-catchup/phase329';sha=lambda b:hashlib.sha256(b).hexdigest();items=[];seen=set()
# No redirected log inside this root: never snapshot this process's growing output.
def difference(left,right,name):
 names=set()
 for sub in['src','test','account-protocol']:
  names|={str(p.relative_to(left))for p in(left/sub).rglob('*')if p.is_file()}|{str(p.relative_to(right))for p in(right/sub).rglob('*')if p.is_file()}
 chunks=[]
 for n in sorted(names):
  a=left/n;b=right/n
  if a.exists()and b.exists()and a.read_bytes()==b.read_bytes():continue
  q=subprocess.run(['git','diff','--no-index','--binary','--',str(a)if a.exists()else'/dev/null',str(b)if b.exists()else'/dev/null'],capture_output=True);assert q.returncode in[0,1];chunks.append(q.stdout)
 (r/name).write_bytes(b''.join(chunks))
difference(Path('/private/tmp/done-owner-fault-trace-lab-20261101/source-tagged'),r/'source-before','observation329.diff');difference(r/'source-before',r/'source-repaired','repair329.diff');difference(r/'source-repaired',r/'source-unrepaired-control','negative-control329.diff')
d.mkdir(exist_ok=False)
def keep(p,category='evidence'):
 if not p.is_file()or p.is_symlink():return
 dest=d/category/(str(p.relative_to(r))+'.gz')
 if str(dest)in seen:return
 seen.add(str(dest));raw=p.read_bytes();packed=gzip.compress(raw,compresslevel=6,mtime=0);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(packed);items.append({'source':str(p),'copy':str(dest.relative_to(d)),'rawSha256':sha(raw),'bytes':len(raw),'gzipSha256':sha(packed)})
for p in sorted(r.iterdir()):
 if p.is_file()and not p.is_symlink()and p.suffix in['.json','.jsonl','.log','.md','.csv','.py','.mjs','.txt','.diff']and not p.name.startswith('freeze329-stderr'):keep(p,'apparatus'if p.suffix in['.py','.mjs','.diff']else'evidence')
for p in sorted(r.glob('*329-inputs.json')):
 x=json.loads(p.read_text())
 if 'plan'not in x:continue
 for c in x['plan']:
  out=r/c['name']
  for pattern in['*.json','*.jsonl','*.log','artifacts/**/error-context.md']:
   for f in out.glob(pattern):keep(f)
for p in(r/'harness/test/account-continuation-lab').rglob('*'):
 if p.is_file():keep(p,'apparatus')
for root in['source-before','source-repaired','source-unrepaired-control']:
 for p in(r/root/'test').glob('labMixed*329*.ts'):keep(p,'apparatus')
 keep(r/root/'src/crdt/ledgerDiff329.ts','apparatus')
for folder in['before-reference','repaired-coordinated-2000','repaired-reference','repaired-immediate-inflight','unrepaired-control-coordinated']:
 for name in['build-identity.json','build-flags.json','frontend-build.log','lab-build.log']:keep(r/folder/name)
for name in['PROTOCOL329.md','summary329.json','paired329-directions.csv','paired329-maintenance.csv','paired329-cells.json','grown329-owners.csv','grown329-attempts.csv','grown329-retries.csv','grown329-interruptions.csv','grown329-predicates-analysis.json','grown329-owners-analysis.json','retention329-mapped.json','coordinated326-historical-markers.json','independent329-check.json','host329-summary.json','GROW-RECEIPT329.json']:
 shutil.copy2(r/name,d/name)
index={'labRoot':str(r),'labOnly':True,'acceptanceCredit':False,'noApplicationPatch':True,'compiledBuildsBrowserProfilesCredentialsDatabasesNotCopied':True,'runningPreservationOutputNotCaptured':True,'items':items};(d/'evidence-index.json').write_text(json.dumps(index,indent=2)+'\n')
for x in items:
 raw=Path(x['source']).read_bytes();packed=(d/x['copy']).read_bytes();assert sha(raw)==x['rawSha256'];assert sha(packed)==x['gzipSha256'];assert gzip.decompress(packed)==raw
(d/'evidence-check.json').write_text(json.dumps({'copiesVerified':len(items),'allRawAndCompressedHashesMatch':True,'verificationBeforeFreeze':True},indent=2)+'\n');print('Preserved',len(items),'exact inert evidence files')

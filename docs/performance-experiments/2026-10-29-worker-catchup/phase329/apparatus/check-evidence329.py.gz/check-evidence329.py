from pathlib import Path
import json,hashlib,subprocess
r=Path(__file__).parent;repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');sha=lambda b:hashlib.sha256(b).hexdigest()
start=json.loads((r/'canonical-start.json').read_text());assert all(sha((repo/n).read_bytes())==h for n,h in start['files'].items());assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==start['head'];assert subprocess.check_output(['git','diff','--cached','--name-only'],cwd=repo,text=True)==''
support=(r/'run-stage.py').read_text();old=support.replace(";assert not(r/'STOP_FUNCTIONAL.json').exists()",'');old=old.replace(" if c.get('stopFunctional') and p.returncode:\n  (r/'STOP_FUNCTIONAL.json').write_text(json.dumps({'case':row,'reason':'Functional failure in a repaired/declared arm; do not continue. Latency alone is not a stop.'},indent=2)+'\\n');sys.exit(5)\n",'');(r/'run-stage329-before-stop-reconstructed.py').write_text(old)
checks=[];resolved=[]
for p in sorted(r.glob('*329-inputs.json')):
 x=json.loads(p.read_text())
 if 'plan' not in x:continue
 for family in ['sourceRoots','assetRoots']:
  for root,files in x[family].items():
   assert all(sha((Path(root)/n).read_bytes())==h for n,h in files.items()),(p.name,root);checks.append({'map':p.name,'family':family,'root':root,'count':len(files)})
 for family,root in [('serverSources',r/'source-server'),('apparatus',r)]:
  assert all(sha((root/n).read_bytes())==h for n,h in x[family].items()),(p.name,family);checks.append({'map':p.name,'family':family,'count':len(x[family])})
 for n,h in x['support'].items():
  if sha((r/n).read_bytes())!=h:
   assert n=='run-stage.py' and sha(old.encode())==h,(p.name,n);resolved.append({'inputMap':p.name,'support':n,'originalSha256':h,'reconstruction':'run-stage329-before-stop-reconstructed.py','reconstructionSha256':sha(old.encode()),'qualification':'Original bytes reconstructed by reversing only later functional-stop additions; matches independently frozen hash.'})
 for n,h in x['fixtures'].items():assert sha(Path(n).read_bytes())==h,(p.name,n)
a=r/'source-repaired';b=r/'source-unrepaired-control';changed=[]
for sub in ['src','account-protocol','test']:
 names={str(p.relative_to(a))for p in(a/sub).rglob('*')if p.is_file()}|{str(p.relative_to(b))for p in(b/sub).rglob('*')if p.is_file()}
 changed.extend(n for n in sorted(names)if not(a/n).exists()or not(b/n).exists()or(a/n).read_bytes()!=(b/n).read_bytes())
assert changed==['src/crdt/inboundLedger.ts'],changed
assert (b/changed[0]).read_bytes()==(r/'source-before'/changed[0]).read_bytes()
assert 'pageTurn'not in(repo/'src/crdt/inboundLedger.ts').read_text()
paired=json.loads((r/'paired329-analysis.json').read_text());assert len(paired)==18 and all(x['childExit']==0 and x['functional']and x['coldExact']for x in paired)
owners=json.loads((r/'paired329-owners.json').read_text());assert len(owners)==36 and all(o['completions']>=1 and o['coldArchiveExact']and o['offlineEditUndoExact']and not o['thrownOutcomes']for o in owners)
grown=json.loads((r/'grown329-results.json').read_text());assert len(grown)==5 and [x['childExit']for x in grown]==[0,0,0,0,1];assert (r/'STOP_FUNCTIONAL.json').exists()
value={'canonicalInputsUnchanged':len(start['files']),'head':start['head'],'realIndexEmpty':True,'frozenMapsVerified':checks,'historicalSupportReconstructions':resolved,'unrepairedMatchedSourceDifferences':changed,'oldInboundSourceExactlyRestored':True,'canonicalInboundHasNoPageTurn':True,'pairedRuns':len(paired),'pairedOwners':len(owners),'grownChildExits':[x['childExit']for x in grown],'functionalStopPreserved':True,'single500AndDeepAfterStop':'not run','applicationChanged':False,'labOnly':True,'acceptanceCredit':False};(r/'independent329-check.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps({k:v for k,v in value.items()if k!='frozenMapsVerified'},indent=2))

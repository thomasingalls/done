from pathlib import Path
import shutil,json
old=Path('/private/tmp/done-owner-fault-trace-lab-20261101');r=Path('/private/tmp/done-retained-scope-lab-20261101');r.mkdir(mode=0o700)
for src,dst in [('source-tagged','source-before'),('source-server','source-server'),('harness','harness')]:shutil.copytree(old/src,r/dst,symlinks=True)
(r/'source').symlink_to(r/'source-before',target_is_directory=True);(r/'source-R').symlink_to(r/'source-server',target_is_directory=True);(r/'source-after').symlink_to(r/'source-server',target_is_directory=True);(r/'node_modules').symlink_to(old/'node_modules',target_is_directory=True)
for name in ['run-stage.py','host_load.py','lab-context.mjs','observer.mjs','container-service.mjs','read-request.mjs','notification-probe.mjs','fixture-roles.mjs','playwright-storage-source.txt','container-image.json','canonical-start.json']:(r/name).write_bytes((old/name).read_bytes())
for p in [*(r/'harness').rglob('*'),*(r/'source-before').rglob('*'),*(r.glob('*.py')),*(r.glob('*.mjs'))]:
 if p.is_file()and not p.is_symlink()and p.suffix in ['.ts','.tsx','.mjs','.py','.json']:
  try:v=p.read_text()
  except UnicodeError:continue
  if str(old)in v:p.write_text(v.replace(str(old),str(r)))
(r/'sender-short-fixture').symlink_to(old/'sender-short-fixture',target_is_directory=True)
(r/'cohort-winning').symlink_to(Path('/private/tmp/done-page-reuse-repair-lab-20261101/cohort-winning'),target_is_directory=True)
b=r/'build-before';b.mkdir();(b/'source').symlink_to(r/'source-before',target_is_directory=True);shutil.copytree(old/'build-tagged/lab',b/'lab',symlinks=True)
for p in(b/'lab').rglob('*'):
 if p.is_file()and p.suffix in['.ts','.mjs','.html']:p.write_text(p.read_text().replace(str(old/'build-tagged'),str(b)).replace(str(old),str(r)))
for n in['build-lab.py','build.mjs','release-flags.json']:(b/n).write_text((old/'build-tagged'/n).read_text().replace(str(old/'build-tagged'),str(b)).replace(str(old),str(r)))
t=json.loads((old/'tsconfig.tagged327.json').read_text());t['extends']='./source-before/tsconfig.app.json';t['include']=[v.replace('source-tagged/','source-before/',1)for v in t['include']];(r/'tsconfig.before329.json').write_text(json.dumps(t,indent=2)+'\n')
(r/'PROTOCOL329.md').write_text('''# Phase329 — dense/legacy retained-page scope, lab only

Nothing lands or earns credit; no hardening/default/release change. New root leaves all parents intact. Preserve all guards/caps/2.5s/16ms/deep30s/maintenance120s and >=60 grown overlap. Before repair, add exact first-difference path to baseline comparison and message+stack to retention catch; reproduce on the existing unrepaired P1 source. Stop if first difference is outside inbound retained or if defect extends into shared main implementation. Shared guards firing on lab-only malformed derived state are retained; canonical inboundLedger has no pageTurn optimization.

Then construct real-crypto dense->legacy replay controls comparing one full verifyInboundLedger call with continuation calls over the same records, sameAccountLedger equality and every retained envelope seq=position. Cover two publishers and an extent with first>0. They must fail before repair. Use separately preserved source-before and source-repaired. Repair only scope of pageTurn to the exact record which created it; legacy decodes its own event.page. No verification, authority, expiry, witness, ledger, commit, coverage or erasure check is relaxed.

After controls, paired150 three policies x0/50ms x3 replicates, mixed blocks declared before measurements. Wait until automatic maintenance has actually attempted on both devices, reporting its outcome/bytes/errors; retain120s-after-last-key maintenance deadline. Then grown2048 withheld repaired x3 plus P0 and unrepaired P1 controls, followed by device1 single500 and one repaired E1B1P1 deep0 control, unless stopped. Preserve original cold exactness/Undo/input/peer/marker/position checks. No UI/manual maintenance shortcut.

Operator clarifies: latency misses (every marker/input/peer in any arm) fail predicates and cells but do not stop. Any functional owner closure, repair-required, maintenance owner-error, missing/lost writing or cold failure in any arm stops; also unexpected first-difference path or shared-main fault. This applies literally to the negative control too; no expected-failure waiver is invented. Repaired grown runs and P0 precede the unrepaired control. If it functionally fails, later work remains not run. All timed runs get external host CPU/top-process logs every5s, no competing build/analysis, and child exits.

Observation uses existing critical-only fault transport: disable high-volume regular Worker event streaming, keep channel/failure/first-difference/retention exception records. This reduces diagnostic perturbation without changing protocol work. First difference reports bounded structural path/type/length only, no plaintext. Record the previous coordinated every-marker failure separately from new outcomes; never regrade it.
''')
print(r)

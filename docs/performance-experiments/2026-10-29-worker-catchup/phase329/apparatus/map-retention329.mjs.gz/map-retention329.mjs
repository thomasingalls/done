import {readFileSync,writeFileSync} from 'node:fs';
import {TraceMap,originalPositionFor} from '/Users/thomasingalls/.codex/worktrees/7fda/done/node_modules/.pnpm/@jridgewell+trace-mapping@0.3.31/node_modules/@jridgewell/trace-mapping/dist/trace-mapping.mjs';
const root='/private/tmp/done-retained-scope-lab-20261101',name='grown329-withheld-unrepaired-P1-control',dist=root+'/unrepaired-control-coordinated/combined-dist',x=JSON.parse(readFileSync(root+'/'+name+'/result.json')),maps=new Map(),out=[];
for(const [owner,realms] of x.finalMaintenanceTraces.entries())for(const realm of realms)for(const a of realm.value?.attempts??[])if(a.outcome?.kind==='threw'){
 const frames=(a.outcome.stack??'').split('\n').slice(1).map(frame=>{const m=/(http:\/\/localhost:53781\/[^ )]+):(\d+):(\d+)/.exec(frame);if(!m)return{frame};const path=dist+new URL(m[1]).pathname+'.map';if(!maps.has(path))maps.set(path,new TraceMap(JSON.parse(readFileSync(path))));return{frame,original:originalPositionFor(maps.get(path),{line:+m[2],column:+m[3]-1})};});out.push({case:name,owner:['reader','writer'][owner],attempt:a.id,stage:a.stage,outcome:a.outcome,mappedFrames:frames});
}
writeFileSync(root+'/retention329-mapped.json',JSON.stringify(out,null,2)+'\n');console.log(JSON.stringify(out.map(z=>({owner:z.owner,message:z.outcome.message,frames:z.mappedFrames.map(f=>f.original)})),null,2));

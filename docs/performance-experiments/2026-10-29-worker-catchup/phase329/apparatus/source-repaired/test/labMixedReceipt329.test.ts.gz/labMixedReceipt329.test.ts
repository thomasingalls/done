// @vitest-environment node
import { afterEach, expect, it, vi } from 'vitest';
vi.hoisted(()=>Object.defineProperty(globalThis,'location',{configurable:true,value:{href:'https://lab.invalid/?lab=10101&labSY=1N&labPP=1'}}));
import {sign} from 'node:crypto';
// @ts-expect-error Shared real-crypto JavaScript fixture.
import {memberFixture} from './local-baseline/fixtures.mjs';
import {inspectInbound,verifyInboundLedger,type InboundState} from '../src/crdt/inboundLedger';
import {decodeInboundRecord,encodeDenseInbound} from '../src/crdt/inboundRecord';
import {sameAccountLedger} from '../src/crdt/incrementalAccountLedger';
import {verifyDelivery} from '../src/crdt/deliveryRecord';
import {decodeSpoolEntry} from '../src/crdt/spoolRecord';
import {decodeNetworkEnvelope} from '../account-protocol/envelope';
import {decodePositionResponse} from '../account-protocol/positionDecision';
import {hash} from './account-inbound/fixtures';
import type {OpenedRecord}from'../src/crdt/contentRecord';
const clean:(()=>void)[]=[];afterEach(()=>{for(const f of clean.splice(0))f();});
const json=(v:unknown)=>new Uint8Array(Buffer.from(JSON.stringify(v))),hex=(b:Uint8Array)=>Buffer.from(b).toString('hex');
async function mixed(nonzero:boolean){
 const f=await memberFixture();clean.push(f.clear);const rows=f.rows as OpenedRecord[],base=f.ctx.inbound,route=f.ctx.route;
 const signed=(v:unknown[],key:any)=>json([...v,sign(null,json(v),key).toString('hex')]);
 const peer:OpenedRecord[]=[],own:OpenedRecord[]=[];
 const addPeer=async()=>{await f.appendPeer();peer.push(rows.at(-1)!);};
 let previous='00'.repeat(32);
 const addOwn=async()=>{const{proof}=await f.appendOwn();let wire:Uint8Array<ArrayBuffer>|undefined;for(const row of rows){if(row.kind!=='outbound')continue;try{const e=decodeSpoolEntry(row.bytes,route);if(e.type==='envelope')wire=e.wire;}catch{/* genuine source capsule is a distinct record family */}}
  expect(wire).toBeDefined();const e=decodeNetworkEnvelope(wire!),decision=decodePositionResponse(proof);expect(decision.kind).toBe('accepted');if(decision.kind!=='accepted')throw Error('fixture decision');
  const request=signed(['done/private-read/v2',2,base.service.id,base.service.origin,route.workspace,base.reader.id,base.publisher.id,base.authority.lineage,base.authority.head,route.epoch,e.seq-1,1,'94'.repeat(32),30000],f.f.keys.existing),page=signed(['done/private-read-page/v2',2,hash(request),e.seq,e.seq,[[hex(wire!),hex(proof)]]],f.f.f.keys.acceptance);
  const record=json(['done/account-inbound/v1',1,base.baseline.id,base.authority.lineage,base.authority.head,base.reader.id,base.publisher.id,'received',e.seq,previous,decision.head.link,hex(request),hex(page)]),row={seq:rows.at(-1)!.seq+1,gen:1,kind:'heads' as const,bytes:record};rows.push(row);own.push(row);previous=decision.head.link;
 };
 await addPeer();await addPeer();await addOwn();await addOwn();await addOwn();await addPeer();
 const pack=(pageRows:OpenedRecord[],selected:OpenedRecord[])=>{const events=pageRows.map(r=>decodeInboundRecord(r.bytes)),requestFields=JSON.parse(Buffer.from(events[0]!.request).toString());requestFields.pop();requestFields[10]=events[0]!.position-1;requestFields[11]=4;const request=signed(requestFields,f.f.keys.existing),page=signed(['done/private-read-page/v2',2,hash(request),events.at(-1)!.position,events.at(-1)!.position,events.map(e=>{const p=JSON.parse(Buffer.from(e.page).toString());return p[5][0];})],f.f.f.keys.acceptance),chosen=selected.map(row=>{const index=pageRows.indexOf(row);return{...events[index]!,request,page,entry:index};}),packed=encodeDenseInbound(chosen),keep=selected.at(-1)!;keep.bytes=packed;for(const row of selected.slice(0,-1))rows.splice(rows.indexOf(row),1);return chosen[0]!.entry;};
 expect(pack(peer.slice(0,2),peer.slice(0,2))).toBe(0);if(nonzero)expect(pack(own.slice(0,2),[own[1]!])).toBe(1);
 const census=inspectInbound(rows,route,base),delivery=await verifyDelivery(census.delivery,route,base.authority,f.ctx.signer,crypto.subtle),life={assertCurrent(){},now:()=>61000};
 let state:InboundState|undefined,after=0;const physical=[...new Map(census.entries.map(e=>[e.record.seq,e.record])).values()].sort((a,b)=>a.seq-b.seq);
 for(const row of physical){const partial=inspectInbound(rows.filter(r=>r.seq<=row.seq),route,base);state=await verifyInboundLedger(partial,rows,base,life,undefined,state?{state,after}:undefined);after=row.seq;}
 expect(state).toBeDefined();expect(state!.peers!.size).toBe(1);expect(state!.prefix.position).toBe(3);expect([...state!.peers!.values()][0]!.prefix.position).toBe(3);
 return{rows,base,census,delivery,life,continuation:state!};
}
function retainedViolations(s:InboundState){const bad:any[]=[];for(const [publisher,state]of [['own',s],...[...(s.peers??[])]] as [string,InboundState][]){for(const[position,e]of state.retained){const env=decodeNetworkEnvelope(e.envelope);if(env.seq!==position)bad.push({publisher,position,seq:env.seq});}}return bad;}
for(const nonzero of[false,true])it(`mixed two-publisher dense then legacy full replay equals continuation and retains envelope seq=position (first ${nonzero?'>0':'0'})`,async()=>{const f=await mixed(nonzero);expect(retainedViolations(f.continuation)).toEqual([]);const full=await verifyInboundLedger(f.census,f.rows,f.base,f.life),equivalent=sameAccountLedger({census:f.census,delivery:f.delivery,inbound:full},{census:f.census,delivery:f.delivery,inbound:f.continuation});expect({equivalent,retainedViolations:retainedViolations(full)}).toEqual({equivalent:true,retainedViolations:[]});});

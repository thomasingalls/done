from pathlib import Path
import shutil,subprocess,os,json,hashlib
r=Path(__file__).parent;b=r/'build-repaired';b.mkdir();(b/'source').symlink_to(r/'source-repaired',target_is_directory=True);shutil.copytree(r/'build-before/lab',b/'lab',symlinks=True)
for p in(b/'lab').rglob('*'):
 if p.is_file()and p.suffix in['.ts','.mjs','.html']:p.write_text(p.read_text().replace(str(r/'build-before'),str(b)))
for n in['build-lab.py','build.mjs','release-flags.json']:(b/n).write_text((r/'build-before'/n).read_text().replace(str(r/'build-before'),str(b)))
s=r/'source-repaired';inputs={str(p.relative_to(s)):hashlib.sha256(p.read_bytes()).hexdigest()for sub in['src','account-protocol','test']for p in(s/sub).rglob('*')if p.is_file()};(r/'repaired329-source-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
for policy in['coordinated-2000','reference','immediate-inflight']:
 with(r/f'build329-repaired-{policy}.log').open('w')as f:q=subprocess.run(['python3',str(b/'build-lab.py')],cwd=b,env={**os.environ,'LAB_BATCH_POLICY':policy},stdout=f,stderr=subprocess.STDOUT)
 if q.returncode:raise SystemExit(q.returncode)
 dest=r/('repaired-'+policy);dest.mkdir();shutil.move(str(b/'combined-dist'),dest/'combined-dist')
 for n in['build-identity.json','build-flags.json','frontend-build.log','lab-build.log']:shutil.copy2(b/n,dest/n)
 assert all(hashlib.sha256((s/n).read_bytes()).hexdigest()==h for n,h in inputs.items());print('Built',policy,flush=True)

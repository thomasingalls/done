from pathlib import Path
from collections import Counter,defaultdict
import json,math,statistics,csv,sqlite3,hashlib
r=Path(__file__).parent

def stats(v):
 s=sorted(v)
 return {'n':len(s),'p50':s[math.ceil(.5*len(s))-1],'p95':s[math.ceil(.95*len(s))-1],'max':s[-1]} if s else None

def clocks(x,device):
 b=[z for g in x.get('clocks',[]) for z in g['rows'][device]]
 lo=max(z['renderer']-z['after']-1 for z in b);hi=min(z['renderer']-z['before']+1 for z in b)
 assert lo<=hi
 return lo,hi

def all_events(realms):
 return [e for z in realms for e in (z.get('value')or{}).get('events',[])]

def analyze(row):
 p=r/row['name']/'result.json';x=json.loads(p.read_text());out={**row,'functional':x['outcome']=='passed'and row['childExit']==0,'coldExact':bool(x['guards'].get('bothOfflineColdProfilesExact')),'cold':x.get('cold',[]),'error':x.get('error'),'directions':[],'labOnly':True,'acceptanceCredit':False}
 start=x.get('typingStartedAt');end=x.get('newDeliveryAt',x.get('typingFinishedAt'));out['measurementEnd']='newDeliveryAt' if 'newDeliveryAt'in x else'last key only; failed delivery, diagnostic costs only'
 net=[z for z in x.get('network',[]) if start is not None and start<=z['at']<=end]
 out['httpAttempts']=dict(Counter(z['path'] for z in net));out['httpStatus']=dict(Counter(str(z.get('status','missing')) for z in net))
 out['requestedLogicalReadUnits']=sum(max(1,len(z.get('reads',[]))) for z in net if '/delivery/read' in z['path']);out['writeAttempts']=sum(z['path']=='/account/delivery/submit'for z in net)
 budget=x.get('budgetAfter',{}).get('budget');out['admittedBudget']=None
 if budget:
  ev=[z for z in budget['events']if start<=z['at']<=end];out['admittedBudget']={'acquired':sum(z['units']for z in ev if z['kind']in ['acquire','reserve']),'refunded':sum(z['units']for z in ev if z['kind']=='refund'),'netUnits':sum(z['units']for z in ev),'refusals':sum(z['kind']=='refuse'for z in ev),'refusalQualification':'event counter is not exhaustive; HTTP 429/503 and refusal replies remain separately visible','byRoute':{k:sum(z['units']for z in ev if z.get('route')==k and z['kind']in ['acquire','reserve'])for k in sorted(set(z.get('route','')for z in ev))}}
 probes=x.get('probes')or [d.get('probe')for d in x.get('failureDiagnostics',[])];out['probeCompleteness']='all streams exact/cold' if out['functional']else'failure observations only; partial latency never earns a cell pass'
 lab=x.get('labAfter')or[d.get('lab',[])for d in x.get('failureDiagnostics',[])];out['ownerClosedAtMs']=[min((z['at']-start for z in all_events(a)if z['kind']in ['port:call:setupClose','port:closed:undefined']and z['at']>=start),default=None)for a in lab]if start else[]
 out['quietReadsDelta']=[]
 for a,b in zip(lab,x.get('labBefore',[])):
  out['quietReadsDelta'].append(sum((z.get('value')or{}).get('quietReads',0)for z in a)-sum((z.get('value')or{}).get('quietReads',0)for z in b))
 for stream,offers in enumerate(x['offers']):
  keys=[z for z in offers if z['kind']=='key'];marks=[z for z in offers if z['kind']=='marker']
  if not keys:continue
  d={'stream':stream,'keysOffered':len(keys),'commandsOffered':len(offers),'actualKeyIntervalsMs':stats([b['at']-a['at']for a,b in zip(keys,keys[1:])]),'dispatchLatenessMs':stats([z['at']-z['scheduledAt']for z in keys]),'latency':{},'markerLatency':{}}
  for device in range(2):
   if len(probes)<=device or not probes[device]:continue
   s=probes[device]['streams'][stream];lo,hi=clocks(x,device);baseline=x['baselines'][device][stream];vals=[];missing=[]
   for i,o in enumerate(keys,1):
    found=next((z['at']for z in s['counts']if z['at']>=o['at']-5 and z['count']>=baseline+i),None)
    if found is None:missing.append(i)
    else:vals.append(found-o['at']-lo)
   role='local'if device==stream else'peer';d['latency'][role]=stats(vals);d[role+'MissingKeys']=missing;d['markerLatency'][role]=[None if s['markers'][i]is None else s['markers'][i]-o['at']-lo for i,o in enumerate(marks)];d[role+'ClockOffsetMs']=[lo,hi]
  events=[e for e in (probes[stream]or{}).get('events',[])if e.get('stream')==stream]if len(probes)>stream else[];d['beforeinputCount']=len(events);d['trustedFocusedVisible']=len(events)==len(offers)and all(e['trusted']and e['focused']and e['visible']=='visible'for e in events)
  if 'serverAfter'in x:
   pos=x['serverAfter'][stream]['tip']-x['serverBefore'][stream]['tip'];d.update(acceptedPositions=pos,positionsPer100Keys=100*pos/len(keys),positionsPer100InputCommands=100*pos/len(offers),acceptedRowDelta=x['serverAfter'][stream]['acceptedRows']-x['serverBefore'][stream]['acceptedRows'])
  else:
   db=sqlite3.connect('file:'+str(r/row['name']/'state/account.sqlite')+'?mode=ro',uri=True)
   try:
    candidates=[z for z in db.execute("SELECT credential_id,MAX(position),COUNT(*),account_id FROM publisher_decisions WHERE kind='accepted' GROUP BY account_id,credential_id")if hashlib.sha256(z[0].encode()).hexdigest()==x['serverBefore'][stream]['publisherSha256']]
    assert len(candidates)==1
    pos=candidates[0][1]-x['serverBefore'][stream]['tip'];d.update(acceptedPositions=pos,positionsPer100Keys=100*pos/len(keys),positionsPer100InputCommands=100*pos/len(offers),acceptedRowDelta=candidates[0][2]-x['serverBefore'][stream]['acceptedRows'],acceptedPositionsMeaning='Read-only final service state on failed journey, no UI/complete-stream reconciliation. Denominator is offered keys including commands after workspace closed, so this is not a coalescing gain.')
   finally:db.close()
  fd=x.get('failureDiagnostics',[])
  if len(fd)>stream:
   kfacts=fd[stream].get('keys',[]);d['cardTargetedKeydowns']=sum(z.get('key')==['x','w'][stream]and bool(z.get('card'))for z in kfacts);d['pageTargetedKeydowns']=sum(z.get('key')==['x','w'][stream]and not z.get('card')for z in kfacts)

  out['directions'].append(d)
 out['metricPredicates']={'functional':out['functional'],'coldExact':out['coldExact'],'allOfferedKeysObserved':all(not d.get('localMissingKeys',[1])and not d.get('peerMissingKeys',[1])for d in out['directions'])and bool(out['directions']),'trustedFocusedVisible':all(d['trustedFocusedVisible']for d in out['directions'])and bool(out['directions']),'input16ms':all(d['latency'].get('local')and d['latency']['local']['p95']<=16 and not d.get('localMissingKeys')for d in out['directions'])and bool(out['directions']),'peer2500ms':all(d['latency'].get('peer')and d['latency']['peer']['p95']<=2500 and not d.get('peerMissingKeys')for d in out['directions'])and bool(out['directions']),'everyMarker2500ms':all(all(v is not None and v<=2500 for v in d['markerLatency'].get('peer',[None]))for d in out['directions'])and bool(out['directions'])};out['allMeasuredPredicates']=all(out['metricPredicates'].values());return out

rows=[]
for n in ['pairedFirst329-results.json','pairedRest329-results.json']:
 p=r/n
 if p.exists():rows+=json.loads(p.read_text())
out=[analyze(z)for z in rows];(r/'paired329-analysis.json').write_text(json.dumps(out,indent=2)+'\n');groups=defaultdict(list)
for x in out:groups[(x['policy'],x['workload'],x['rtt'])].append(x)
cells=[]
for (policy,workload,rtt),vals in groups.items():
 cells.append({'policy':policy,'workload':workload,'rtt':rtt,'n':len(vals),'functionalPasses':sum(v['functional']for v in vals),'coldExact':sum(v['coldExact']for v in vals),'allMeasuredPasses':sum(v['allMeasuredPredicates']for v in vals),'cellPass':len(vals)==3 and all(v['allMeasuredPredicates']for v in vals),'runs':[{k:v[k]for k in ['name','functional','coldExact','allMeasuredPredicates','ownerClosedAtMs','requestedLogicalReadUnits','writeAttempts','quietReadsDelta','admittedBudget','directions']}for v in vals]})
(r/'paired329-cells.json').write_text(json.dumps(cells,indent=2)+'\n');print(json.dumps([{k:v for k,v in x.items()if k!='runs'}for x in cells],indent=2))
fields=['name','policy','workload','rtt','replicate','functional','coldExact','allMeasuredPredicates','stream','keysOffered','commandsOffered','localP50','localP95','peerP50','peerP95','localMissing','peerMissing','acceptedPositions','positionsPer100Keys','positionsPer100InputCommands','requestedLogicalReadUnits','writeAttempts','quietReadsDelta','coldUnlockMs','coldNavigationMs']
with(r/'paired329-runs.csv').open('w',newline='')as f:
 w=csv.DictWriter(f,fieldnames=fields,lineterminator='\n');w.writeheader()
 for x in out:
  for d in x['directions']:
   row={k:x.get(k)for k in fields if k in x};row.update({k:d.get(k)for k in fields if k in d});local=d['latency'].get('local')or{};peer=d['latency'].get('peer')or{};cold=next((z for z in x['cold']if z['actor']==d['stream']+1),{});row.update(localP50=local.get('p50'),localP95=local.get('p95'),peerP50=peer.get('p50'),peerP95=peer.get('p95'),localMissing=len(d.get('localMissingKeys',[])),peerMissing=len(d.get('peerMissingKeys',[])),coldUnlockMs=cold.get('unlockToEditableMs'),coldNavigationMs=cold.get('navigationToEditableMs'));w.writerow(row)

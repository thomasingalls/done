from pathlib import Path
import subprocess,os,shutil,json
r=Path(__file__).parent;node='/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node'
with(r/'type329-before.log').open('w')as f:q=subprocess.run([node,str(r/'source-before/node_modules/typescript/bin/tsc'),'-p',str(r/'tsconfig.before329.json')],stdout=f,stderr=subprocess.STDOUT)
if q.returncode:raise SystemExit(q.returncode)
with(r/'build329-before-reference.log').open('w')as f:q=subprocess.run(['python3',str(r/'build-before/build-lab.py')],cwd=r/'build-before',env={**os.environ,'LAB_BATCH_POLICY':'reference'},stdout=f,stderr=subprocess.STDOUT)
if q.returncode:raise SystemExit(q.returncode)
dest=r/'before-reference';dest.mkdir();shutil.move(str(r/'build-before/combined-dist'),dest/'combined-dist')
for n in['build-identity.json','build-flags.json','frontend-build.log','lab-build.log']:shutil.copy2(r/'build-before'/n,dest/n)
print('Built unrepaired observation source')

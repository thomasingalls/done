from pathlib import Path
import json,statistics,hashlib
r=Path(__file__).parent;plans=['firstDiff329','grow329','pairedFirst329','pairedRest329','grownFirst329','grownRest329'];loads=[]
for stage in plans:
 for row in json.loads((r/(stage+'-results.json')).read_text()):
  samples=[json.loads(line)for line in(r/row['name']/'host-load.jsonl').read_text().splitlines()];samples=[s for s in samples if s.get('kind')=='load'];busy=[100-s['hostPercent']['idle']for s in samples]
  loads.append({'case':row['name'],'stage':stage,'childExit':row['childExit'],'samples':len(samples),'busyMedian':statistics.median(busy),'busyMax':max(busy),'hostLog':row['name']+'/host-load.jsonl','qualification':'Aggregate host load, not browser-only; top-process samples retained. No quiet-host guarantee or noise exclusion.'})
(r/'host329-summary.json').write_text(json.dumps(loads,indent=2)+'\n')
repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');prefix={n:{'bytes':len((repo/n).read_bytes()),'sha256':hashlib.sha256((repo/n).read_bytes()).hexdigest()}for n in['docs/completed.md','docs/decisions.md','docs/product-backlog.md']};(r/'append-only329-before.json').write_text(json.dumps(prefix,indent=2)+'\n')
growth=json.loads((r/'grow329-results.json').read_text())[0];(r/'GROW-RECEIPT329.json').write_text(json.dumps({'case':growth['name'],'childExit':growth['childExit'],'nativeGrowthKeys':700,'keyIntervalMs':150,'actualPolicy':'coordinated-2000','actualWriters':1,'knownWritingAdded':' seed329: followed by 700 g characters on SA card only','savedPhysicalRowsByDevice':[1675,3089],'fullArchiveComparedBeforeSaving':True,'scope':'Apparatus preparation, not a sender-study run','metadataCaveat':'Original grow plan inherited unused policy=reference/writers=2/keys=300 template fields. The frozen grow spec hardcodes one writer/700 native keys and build flags identify coordinated. Preserve the original plan unchanged; it is not a 300-key reference measurement.'},indent=2)+'\n')
print('Retained host summaries for',len(loads),'timed runs')

from pathlib import Path
import subprocess,json
r=Path(__file__).parent;s=r/'source-repaired';node='/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node'
tests=['test/labMixedReceipt329.test.ts','test/labMixedReceipt329-P0.test.ts','test/labPageParse324.test.ts','test/labStoredMode326.test.ts','test/labStoredReaders326-P0.test.ts','test/labStoredReaders326-P1.test.ts','test/labStoredExternal326-P0.test.ts','test/labStoredExternal326-P1.test.ts','test/labFault327.test.ts','test/labFaultStream327.test.ts','test/workerChannel.test.ts','test/workerWorkspaceQueues.test.ts','test/windowCeremonyUi.test.ts','test/accountBatching.test.ts','test/accountSyncDriver.test.ts','test/admissionJournalFence.test.ts','test/automaticLocalRetention.test.ts']
with(r/'unit329-after-attempt2.log').open('w')as f:q=subprocess.run([node,'node_modules/vitest/vitest.mjs','run',*tests,'--reporter=verbose'],cwd=s,stdout=f,stderr=subprocess.STDOUT)
if q.returncode:raise SystemExit(q.returncode)
with(r/'type329-repaired-attempt1.log').open('w')as f:q=subprocess.run([node,str(s/'node_modules/typescript/bin/tsc'),'-p',str(r/'tsconfig.repaired329.json')],stdout=f,stderr=subprocess.STDOUT)
if q.returncode:raise SystemExit(q.returncode)
print('Repair focused tests and strict types pass')

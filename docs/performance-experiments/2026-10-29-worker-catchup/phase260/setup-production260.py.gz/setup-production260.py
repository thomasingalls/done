from pathlib import Path
import json,shutil,subprocess,os,hashlib
m=Path(__file__).parent;old=Path('/private/tmp/done-worker-conversion-20261028/native237');baseline=Path('/private/tmp/done-production-worker-baseline-20261030');r=Path('/private/tmp/done-production-native-compatibility-20261030');repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');r.mkdir();sha=lambda b:hashlib.sha256(b).hexdigest()
(r/'source-after').symlink_to(baseline/'source-after',target_is_directory=True);(r/'frontend').symlink_to(baseline/'after-dist',target_is_directory=True);(r/'node_modules').symlink_to(repo/'node_modules',target_is_directory=True)
for name in ['container-image.json','container-service.mjs','observer.mjs']:(r/name).write_bytes((baseline/name).read_bytes().replace(str(baseline).encode(),str(r).encode()))
shutil.copytree(old/'harness',r/'harness',symlinks=True,ignore=shutil.ignore_patterns('node_modules','test-results','artifacts'));(r/'harness/node_modules').symlink_to(repo/'node_modules',target_is_directory=True)
shutil.copytree(old/'lab',r/'lab',symlinks=True)
for name in ['src','account-protocol','wasm']:
 p=r/'lab'/name;assert p.is_symlink();p.unlink();p.symlink_to(r/'source-after'/name,target_is_directory=True)
p=r/'lab/node_modules';assert p.is_symlink();p.unlink();p.symlink_to(repo/'node_modules',target_is_directory=True)
for f in(r/'harness').rglob('*'):
 if f.is_file()and not f.is_symlink()and f.suffix in ['.mjs','.ts','.json']:
  b=f.read_bytes().replace(str(old).encode(),str(r).encode()).replace((str(repo)+'/test/').encode(),(str(r)+'/harness/test/').encode()).replace((str(repo)+'/').encode(),(str(r)+'/source-after/').encode());f.write_bytes(b)
p=r/'harness/test/account-continuation-lab/runtime.mjs';s=p.read_text().replace("source='"+str(repo)+"'","source='"+str(r/'source-after')+"'").replace("['account-service','account-protocol','src','scripts','docs']","['account-service','account-protocol','src','scripts']");p.write_text(s)
# Preserve original lab-only all-zero preparation verifier; actual public frontend has real identity.
# This is an explicit fixture exception, not an authority or local row verification bypass.
import re
s=(old/'build.mjs').read_text().replace(str(old),str(r));s,n=re.subn(r"'import.meta.env.VITE_ACCOUNT_WARM_LOADS':[^,]*,",'',s);assert n==1;(r/'build.mjs').write_text(s)
flags=json.loads((baseline/'build-flags.json').read_text());assert 'VITE_ACCOUNT_WARM_LOADS'not in flags;(r/'build-flags.json').write_text(json.dumps(flags,indent=2)+'\n');(r/'release-flags.json').write_bytes((baseline/'release-flags.json').read_bytes());(r/'source-inputs.json').write_bytes((baseline/'after-source-inputs.json').read_bytes())
node='/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node';env={k:v for k,v in os.environ.items()if not k.startswith('VITE_ACCOUNT_')};env.update(flags);assert not list((r/'lab').glob('.env*'));assert{k:v for k,v in env.items()if k.startswith('VITE_ACCOUNT_')}==flags
with(r/'build.log').open('w')as f:p=subprocess.run([node,str(r/'build.mjs')],env=env,cwd=r,stdout=f,stderr=subprocess.STDOUT)
assert p.returncode==0,p.returncode
# Verify current shipping frontend is the exact production258 build, and original cases only relocated.
original=(old/'harness/test/account-continuation-lab/worker-owner.spec.ts').read_text();new=(r/'harness/test/account-continuation-lab/worker-owner.spec.ts').read_text();expected=original.replace(str(old),str(r)).replace(str(repo)+'/test/',str(r)+'/harness/test/').replace(str(repo)+'/',str(r)+'/source-after/');assert expected==new
(r/'fixture-exceptions.json').write_text(json.dumps({'lab':'original unmodified lab fixture except closed absolute-root relocation and warmunset setting','preparationVerifier':'original all-zero lab identity preserved; shipping public frontend uses actual source/flag digest','originalBodiesExactAfterRootRelocation':True,'explicitLabDefaults':{'VITE_ACCOUNT_LEDGER':'incremental','VITE_ACCOUNT_TEXT_ADMISSION':'direct'},'warmLoads':'unset/default-on; no .env or inherited flags'},indent=2)+'\n')
# Reuse original runner, four-case selection supplied when starting. No deadline or case edits.
s=(old/'run.py').read_text().replace("r=Path(__file__).parent", "r=Path(__file__).parent");s=s.replace("Path('/Users/thomasingalls/.codex/worktrees/7fda/done')/f", "r/'source-after'/f");s=s.replace("'test/packaged-account/devices.ts','test/device-enrollment/helpers.ts','test/geometry/openApp.ts'", "")
(r/'run.py').write_text(s)
print('Original case bodies/deadlines preserved, production frontend exact, lab warm flag removed, pinned0ab closure')

from pathlib import Path
import json,gzip,hashlib,csv,re,subprocess,statistics
r=Path(__file__).parent;repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');out=repo/'docs/performance-experiments/2026-10-29-worker-catchup/phase309';load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();idx=load(out/'evidence-index.json');analysis=load(out/'trace-analysis.json');seen=set()
for q in idx['files']:
 b=gzip.decompress((out/q['artifact']).read_bytes());assert hashlib.sha256(b).hexdigest()==q['sourceSha256'];assert sha(out/q['artifact'])==q['artifactSha256'];assert b==Path(q['source']).read_bytes();seen.add(q['source'])
results=load(r/'trace-results.json');frozen=load(r/'trace-inputs.json');assert len(results)==len(frozen['cases'])==4;assert {x['name']for x in results}=={x['name']for x in frozen['cases']};assert all(sha(r/'source'/n)==h for n,h in frozen['sources'].items());assert all(sha(r/'combined-dist'/n)==h for n,h in frozen['assets'].items());assert all(sha(r/n)==h for n,h in frozen['apparatus'].items())
old=repo/'docs/performance-experiments/2026-10-29-worker-catchup/phase308';oi=load(old/'evidence-index.json')
for q in oi['files']:assert sha(Path(q['source']))==q['sourceSha256']
oldlab=Path('/private/tmp/done-range-vgr-lab-20261030');of=load(oldlab/'deep-inputs.json');assert all(sha(oldlab/'source'/n)==h for n,h in of['sources'].items());assert all(sha(oldlab/'combined-dist'/n)==h for n,h in of['assets'].items())
start=load(r/'canonical-start.json');assert all(sha(repo/n)==h for n,h in start['files'].items());assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=repo,text=True)
unit=load(r/'step0-full-units/receipt.json');assert unit['childExitCode']==0;ut=(r/'step0-full-units/console.log').read_text();assert re.search(r'Test Files\s+283 passed',ut)and re.search(r'Tests\s+2855 passed\s*\|\s*1 skipped',ut)
rows=list(csv.DictReader((out/'attempts.csv').open()));count=0;causes=0;pollcauses=0;typingflush=0
for rr in results:
 name=rr['name'];raw=load(r/name/'result.json');assert str(r/name/'result.json')in seen;assert not raw.get('coldFailure');assert (r/name/'host-load.jsonl').exists();ll=[json.loads(x)for x in(r/name/'host-load.jsonl').read_text().splitlines()];assert ll[0]['revision']==2 and ll[-1]['kind']=='end';assert all(z['intervalSeconds']>=5 for z in ll if z['kind']=='load');groups=raw.get('finalMaintenanceTraces')or[raw.get('traces',[])];aa=[]
 for owner,realms in enumerate(groups):
  for realm in realms:
   v=realm.get('value')
   if not v or not v['attempts']:continue
   assert v['overflow']==0
   for a in v['attempts']:
    aa.append(a);count+=1;assert a.get('endedAt')is not None
    row=next(z for z in rows if z['case']==name and int(z['owner'])==owner and int(z['attempt'])==a['id']);assert row['stage']==a.get('stage');assert int(row['deltasSaved'])==sum(e['kind']=='checkpoint-saved'and e.get('attempt')==a['id']for e in v['events'])
    for j in a['journals']:
     assert j['lookupMisses']>=j['misses'];assert j['pending']<=j['entries'];assert j['bytes']<=j['byteCap'];assert int(row['entries'])==j['entries'];assert int(row['completedMisses'])==j['misses'];assert float(row['firstMissFromJournalMs'])==j['firstMiss']['elapsedMs']if j.get('firstMiss')else row['firstMissFromJournalMs']==''
    assert len(a['interruptions'])==(1 if a['outcome'].get('reason')=='activity-or-journal'else 0)
    for c in a['interruptions']:
     causes+=1;assert c['site']=='accountCapture:baseline-shadow'and c['queuePriority']is True and c['suspended']is False and c['shadowActivity']is False
     job=c['arrivingJob']['name']
     if job=='accountReceive.ts:2487:prepared':
      pollcauses+=1;prior=[e for e in v['events']if e['kind']=='receive-turn-start'and e['at']<=c['at']][-1];assert 0<=c['at']-prior['at']<7 and not any(prior[k]for k in ['continuing','dirty','expedite'])
     else:
      assert job=='accountCapture.ts:615:flushJournal';typingflush+=1;assert 0<c['at']-raw['typingStartedAt']<1000
 if name.startswith('trace-grown'):
  keys=[k for k in raw['offers']if k['kind']=='key'];assert [k['index']for k in keys]==list(range(120));assert sum(k['at']<raw['catchups'][0]['completedAt']for k in keys)==120;assert raw['guards']['fullOriginalArchivePlusOnlyOfferedAppend']and raw['guards']['undoAndPeerConvergence'];assert not raw.get('coldAttemptStarted')and'120000ms'in raw['error'];assert rr['childExitCode']==1
 if name=='trace-idle-polls':assert raw['outcome']=='maintenance-timeout'and not raw['completed']and'120000ms'in raw['maintenanceWaitError']and not raw.get('coldAttemptStarted')
 if name=='trace-idle-paused':
  assert raw['completed']and raw['guards']['offlineColdProfileExact'];assert len(aa)==11;assert sum(a['outcome']['kind']=='removed'for a in aa)==1;assert not any(a['interruptions']for a in aa);ms=aa[-1]['endedAt']-aa[0]['startedAt'];assert 36011<ms<36013;assert [a['journals'][0]['misses']for a in aa[-5:]]==[171,298,247,200,78];assert len([e for e in v['events']if e['kind']=='receive-turn-start'])==3
assert count==len(rows)==66 and causes==14 and pollcauses==12 and typingflush==2
for p in out.glob('*.md'):
 for target in re.findall(r'\]\(([^)]+)\)',p.read_text()):
  if target.startswith(('http:','https:','#')):continue
  assert(p.parent/target.split('#')[0]).exists(),(p,target)
assert all(q['exit']==0 for q in load(r/'contract-checks.json'))
result={'rawCopiesAndOriginalsVerified':len(idx['files']),'phase308RawOriginalsStillMatch':len(oi['files']),'phase308SourcesAssetsUnchanged':True,'canonicalInputsUnchanged':len(start['files']),'frozenTraceSourceAssetsApparatusMatch':True,'applicationJourneys':4,'plansAndResultsBothDirections':True,'attemptRowsIndependentlyChecked':count,'interruptionCausesChecked':causes,'unhintedPollCauses':pollcauses,'typingFlushCauses':typingflush,'bothOverlapKeys':120,'coldAttempts':1,'coldExactPasses':1,'actualUnitChildExit':0,'contractChecksPassed':7,'markdownLinksExist':True,'realIndexEmpty':True,'SYPorHardeningBuilt':False,'labOnly':True,'acceptanceCredit':False};(out/'evidence-check.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

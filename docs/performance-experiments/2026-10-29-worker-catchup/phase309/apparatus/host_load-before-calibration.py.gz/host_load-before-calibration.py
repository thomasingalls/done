from pathlib import Path
import argparse,ctypes as c,json,os,time,signal,threading,sys
p=argparse.ArgumentParser();p.add_argument('--out',required=True);p.add_argument('--period',type=float,default=5);p.add_argument('--samples',type=int,default=0);a=p.parse_args();assert a.period>0
system=c.CDLL('/usr/lib/libSystem.B.dylib');proc=c.CDLL('/usr/lib/libproc.dylib')
system.mach_host_self.restype=c.c_uint32;host=system.mach_host_self();system.host_statistics.argtypes=[c.c_uint32,c.c_int,c.POINTER(c.c_int),c.POINTER(c.c_uint32)]
class Task(c.Structure):_fields_=[(n,c.c_uint64)for n in ['virtual','resident','user','system','threadsUser','threadsSystem']]+[(n,c.c_int32)for n in ['policy','faults','pageins','cowfaults','sent','received','machcalls','unixcalls','switches','threads','running','priority']]
proc.proc_listallpids.argtypes=[c.c_void_p,c.c_int];proc.proc_pidinfo.argtypes=[c.c_int,c.c_int,c.c_uint64,c.c_void_p,c.c_int];proc.proc_name.argtypes=[c.c_int,c.c_void_p,c.c_uint32]
def snapshot():
 ticks=(c.c_uint32*4)();count=c.c_uint32(4);code=system.host_statistics(host,3,c.cast(ticks,c.POINTER(c.c_int)),c.byref(count));assert code==0,(code,count.value)
 size=proc.proc_listallpids(None,0)+256;ids=(c.c_int*size)();n=proc.proc_listallpids(ids,c.sizeof(ids));rows={};missed=0
 for pid in ids[:max(0,n)]:
  if pid<=0:continue
  info=Task();got=proc.proc_pidinfo(pid,4,0,c.byref(info),c.sizeof(info))
  if got!=c.sizeof(info):missed+=1;continue
  name=c.create_string_buffer(256);proc.proc_name(pid,name,c.sizeof(name));rows[pid]=(name.value.decode('utf-8','replace'),int(info.user+info.system),int(info.resident))
 return time.monotonic_ns(),list(ticks),rows,missed
stop=threading.Event();signal.signal(signal.SIGTERM,lambda *_:stop.set());signal.signal(signal.SIGINT,lambda *_:stop.set());path=Path(a.out);path.parent.mkdir(parents=True,exist_ok=True)
with path.open('x')as f:
 def emit(v):f.write(json.dumps(v,separators=(',',':'))+'\n');f.flush()
 emit({'kind':'method','periodSeconds':a.period,'host':'Mach HOST_CPU_LOAD_INFO interval deltas','processes':'libproc PROC_PIDTASKINFO user+system nanoseconds interval deltas; proc_name only, NEVER arguments/environment','topCount':15,'percentMeaning':'Process100percent=one core; host percentages aggregate all cores','newProcesses':'TotalCPU since birth used only for newly observed PID; PID reset/name change marked','pidCoverage':'Denied/disappeared processes counted; kernel CPU still includes whole host','clock':'Unix epoch milliseconds plus monotonic interval','samplerPid':os.getpid(),'cpuCount':os.cpu_count()})
 old=snapshot();Path(str(path)+'.ready').write_text('ready\n');samples=0
 while not stop.wait(a.period):
  cpu=time.process_time_ns();now=snapshot();elapsed=(now[0]-old[0])/1e9;diff=[(x-y)&0xffffffff for x,y in zip(now[1],old[1])];total=sum(diff);rows=[]
  for pid,(name,ns,rss)in now[2].items():
   before=old[2].get(pid);reset=before is None or before[0]!=name or ns<before[1];used=ns if reset else ns-before[1];rows.append({'pid':pid,'name':name,'cpuPercent':100*used/1e9/elapsed,'newOrReset':reset,'residentBytes':rss})
  rows.sort(key=lambda z:z['cpuPercent'],reverse=True);emit({'kind':'load','at':time.time_ns()/1e6,'monotonicNs':now[0],'intervalSeconds':elapsed,'hostPercent':{k:100*v/total if total else 0 for k,v in zip(['user','system','idle','nice'],diff)},'top':rows[:15],'accessibleProcesses':len(now[2]),'unreadableProcesses':now[3],'samplerCpuMs':(time.process_time_ns()-cpu)/1e6});old=now;samples+=1
  if a.samples and samples>=a.samples:break
 emit({'kind':'end','at':time.time_ns()/1e6,'samples':samples,'stopped':stop.is_set()})

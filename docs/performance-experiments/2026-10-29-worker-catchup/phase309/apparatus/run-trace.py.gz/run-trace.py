from pathlib import Path
import json,subprocess,time,sys,os,signal,hashlib,datetime
r=Path(__file__).parent;node='/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node';cases=[{'name':'trace-grown-normal','config':'grown-maintenance','withhold':False,'idlePause':False},{'name':'trace-grown-withheld','config':'grown-maintenance','withhold':True,'idlePause':False},{'name':'trace-idle-polls','config':'idle-maintenance','withhold':False,'idlePause':False},{'name':'trace-idle-paused','config':'idle-maintenance','withhold':False,'idlePause':True}]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
frozen={'sources':{str(p.relative_to(r/'source')):sha(p)for folder in ['src','account-protocol']for p in(r/'source'/folder).rglob('*')if p.is_file()},'assets':json.loads((r/'build-identity.json').read_text())['files'],'apparatus':{str(p.relative_to(r)):sha(p)for base in [r/'harness/test/account-continuation-lab']for p in base.rglob('*')if p.is_file()},'cases':cases,'gatesUnchanged':True,'noSYPorRetryChanges':True,'bits':'1010'}
(r/'trace-inputs.json').write_text(json.dumps(frozen,indent=2)+'\n');results=[]
for c in cases:
 assert not(r/'STOP.json').exists();assert all(sha(r/'source'/n)==h for n,h in frozen['sources'].items());assert all(sha(r/'combined-dist'/n)==h for n,h in frozen['assets'].items());assert json.loads((r/'prepared-fixture/fixture.json').read_text())['accounts'][0]['date']==datetime.datetime.now(datetime.timezone.utc).date().isoformat()
 out=r/c['name'];out.mkdir(mode=0o700,exist_ok=False);env={k:v for k,v in os.environ.items()if not k.startswith(('RANGE_LAB_','FAIR_PREP_'))};env.update({'PATH':str(Path(node).parent)+':'+env['PATH'],'FAIR_OUT':str(out),'FAIR_DIST':str(r/'combined-dist'),'FAIR_LAB_BITS':'1010','FAIR_VARIANT':'C','QUIET_WITHHOLD':'1'if c['withhold']else'0','FAIR_IDLE_PAUSE':'1'if c['idlePause']else'0','CHROMIUM_PATH':'/private/tmp/done-civil-gates-browser-20261030/Chrome.app/Contents/MacOS/Google Chrome'});cmd=[node,'node_modules/@playwright/test/cli.js','test','--config','test/account-continuation-lab/'+c['config']+'.config.ts']
 with(out/'list.log').open('w')as f:pre=subprocess.run(cmd+['--list'],cwd=r/'harness',env=env,stdout=f,stderr=subprocess.STDOUT)
 if pre.returncode:print('PREFLIGHT REFUSED',c['name'],flush=True);sys.exit(4)
 load=out/'host-load.jsonl';sampler=subprocess.Popen([sys.executable,str(r/'host_load.py'),'--out',str(load)])
 try:
  for i in range(500):
   if Path(str(load)+'.ready').exists():break
   if sampler.poll()is not None:raise RuntimeError('Load sampler failed')
   time.sleep(.01)
  else:raise RuntimeError('Load sampler not ready')
  print('START',c['name'],flush=True);start=time.time()
  with(out/'console.log').open('w')as f:child=subprocess.Popen(cmd,cwd=r/'harness',env=env,stdout=f,stderr=subprocess.STDOUT);child_exit=child.wait()
 finally:sampler.send_signal(signal.SIGTERM);sampler.wait(timeout=10)
 x=json.loads((out/'result.json').read_text())if(out/'result.json').exists()else{};row={**c,'command':cmd,'childExitCode':child_exit,'startedAt':start,'finishedAt':time.time(),'outcome':x.get('outcome'),'labOnly':True,'acceptanceCredit':False,'externalLoadLog':'host-load.jsonl'};(out/'receipt.json').write_text(json.dumps(row,indent=2)+'\n');results.append(row);(r/'trace-results.json').write_text(json.dumps(results,indent=2)+'\n');print('RESULT',json.dumps(row),flush=True)
 if x.get('coldFailure')or(x.get('coldAttemptStarted')and not(x.get('guards',{}).get('bothOfflineColdProfilesExact')or x.get('guards',{}).get('offlineColdProfileExact'))):
  (r/'STOP.json').write_text(json.dumps({'rule':'Any no-F cold failure stops immediately','case':row},indent=2)+'\n');sys.exit(3)
print('ALL FOUR UNFIXED TRACE CASES RETAINED. Review predictions before S/Y.',flush=True)

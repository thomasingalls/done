from pathlib import Path
import json,subprocess,time,sys,os,signal,hashlib
r=Path(__file__).parent;out=r/'step0-full-units';out.mkdir(mode=0o700,exist_ok=False);repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');node='/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node';command=[node,'node_modules/vitest/vitest.mjs','run'];log=out/'host-load.jsonl';sampler=subprocess.Popen([sys.executable,str(r/'host_load.py'),'--out',str(log)])
try:
 for i in range(500):
  if Path(str(log)+'.ready').exists():break
  if sampler.poll()is not None:raise RuntimeError('Host load logger failed')
  time.sleep(.01)
 else:raise RuntimeError('Host load logger not ready')
 start=time.time();print('START quiet full unit suite',flush=True)
 with(out/'console.log').open('w')as f:child=subprocess.Popen(command,cwd=repo,stdout=f,stderr=subprocess.STDOUT);child_exit=child.wait()
 result={'childExitCode':child_exit,'childPid':child.pid,'startedAt':start,'finishedAt':time.time(),'command':command,'oneRun':True,'noParallelAgentBenchmarkOrBuild':True,'externalLoadLog':'host-load.jsonl','sourceAtStart':'../canonical-start.json','labOnly':True,'acceptanceCredit':False};(out/'receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
finally:
 sampler.send_signal(signal.SIGTERM);sampler.wait(timeout=10)
raise SystemExit(child_exit)

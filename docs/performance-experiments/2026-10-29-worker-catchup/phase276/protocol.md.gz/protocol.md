# Phase 276 — actual unreduced cold-open after-check

Run once each the original context/journal-rebind public-cold case and the original full resumable
maintenance/reduction case on the exact cumulative phase275 runtime. This compares the phase273
failure/pass at the same production flags, warm unset, default16/session64/process, original15s
public cold gate and180s case deadline. No profiling/diagnostic hooks. Full native authentication,
admission, synchronous journal fence, Undo, archive equality, saved preparation resume, removal and
shipping public passkey reopen guards remain. Deep and normal Page/Worker comparisons are held;
no fixture date refresh is required by these native cases. No favorable retry or threshold change.

This is a desktop fictional-profile check, not evidence of phone latency or original mobile stalls.
First verification remains independent in every carrier; the23new unitcases and three faultcontrols
establish only exact same-carrier semantics. Preserve failures and source/build identities. No
production service, preview, real profile, release preparation, signing, pushing or computer use.

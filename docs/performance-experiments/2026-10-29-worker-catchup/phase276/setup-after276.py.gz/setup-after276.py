from pathlib import Path
import shutil,json,hashlib,subprocess,os,time
m=Path(__file__).parent;old=Path('/private/tmp/done-production-native-compatibility-20261030');r=Path('/private/tmp/done-unreduced-baseline-after-20261030');repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');r.mkdir();sha=lambda b:hashlib.sha256(b).hexdigest()
shutil.copytree(old/'source-after',r/'source-after',symlinks=True);manifest=json.loads((old/'source-inputs.json').read_text());changed=[]
for n,h in manifest['files'].items():
 actual=(repo/n).read_bytes()
 if sha(actual)!=h:changed.append(n);(r/'source-after'/n).write_bytes(actual)
assert changed==['src/crdt/accountReceive.ts','src/crdt/accountSyncDriver.ts','src/crdt/accountWorkerRecoveryStream.ts','src/crdt/contentStore.ts'];(r/'source-inputs.json').write_text(json.dumps({'baseCommit':manifest['commit'],'changes':changed,'files':{n:sha((r/'source-after'/n).read_bytes())for n in manifest['files']}},indent=2)+'\n')
(r/'source-R').symlink_to(r/'source-after',target_is_directory=True);(r/'node_modules').symlink_to(repo/'node_modules',target_is_directory=True);(r/'test-inputs').symlink_to((old/'test-inputs').resolve(),target_is_directory=True);(r/'private-fixture').symlink_to((old/'private-fixture').resolve(),target_is_directory=True)
shutil.copytree(old/'harness',r/'harness',symlinks=True,ignore=shutil.ignore_patterns('node_modules','test-results','artifacts'));(r/'harness/node_modules').symlink_to(repo/'node_modules',target_is_directory=True)
for f in(r/'harness').rglob('*'):
 if f.is_file()and not f.is_symlink()and f.suffix in ['.mjs','.ts','.json']:f.write_bytes(f.read_bytes().replace(str(old).encode(),str(r).encode()))
shutil.copytree(old/'lab',r/'lab',symlinks=True)
for n in ['src','account-protocol','wasm']:
 p=r/'lab'/n;p.unlink();p.symlink_to(r/'source-after'/n,target_is_directory=True)
for n in ['container-image.json','container-service.mjs','observer.mjs','run.py','smoke.mjs','release-flags.json','build-flags.json']:(r/n).write_bytes((old/n).read_bytes().replace(str(old).encode(),str(r).encode()))
p=r/'container-service.mjs';s=p.read_text();s="import {REQUEST_LIMITS} from '/app/account-service/requestBudget.ts';\n"+s;s=s.replace('node:process.version,cgroup:cg()', 'node:process.version,requestLimits:REQUEST_LIMITS,cgroup:cg()');p.write_text(s)
flags=json.loads((r/'build-flags.json').read_text());assert 'VITE_ACCOUNT_LEDGER_PROFILE'not in flags and 'VITE_ACCOUNT_WARM_LOADS'not in flags;node='/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node';env={k:v for k,v in os.environ.items()if not k.startswith('VITE_ACCOUNT_')};env.update(flags);env.update({'APP_BUILD_REVISION':manifest['commit']+'-dirty','APP_BUILD_DATE':'2026-10-30','PATH':str(Path(node).parent)+':'+os.environ['PATH']});start=time.time_ns()//1000000
with(r/'frontend-build.log').open('w')as f:p=subprocess.run([node,str(r/'source-after/node_modules/vite/bin/vite.js'),'build','--outDir',str(r/'frontend'),'--emptyOutDir','--sourcemap'],cwd=r/'source-after',env=env,stdout=f,stderr=subprocess.STDOUT)
assert p.returncode==0;s=(old/'build.mjs').read_text().replace(str(old),str(r));(r/'build.mjs').write_text(s)
with(r/'lab-build.log').open('w')as f:p=subprocess.run([node,str(r/'build.mjs')],cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
assert p.returncode==0;(r/'build-receipt.json').write_text(json.dumps({'baseCommit':manifest['commit'],'candidate':'exact cumulative275runtime, including existing248yield and narrowstreamrepair','flags':flags,'diagnosticHooks':False,'startedAt':start,'finishedAt':time.time_ns()//1000000},indent=2)+'\n')
# Verify original complete case bodies, provider/Undo/archive/deadline helpers all unchanged except roots.
for n in ['worker-owner.spec.ts','worker-owner.config.ts','devices.ts','common.ts']:
 expected=(old/'harness/test/account-continuation-lab'/n).read_bytes().replace(str(old).encode(),str(r).encode());assert expected==(r/'harness/test/account-continuation-lab'/n).read_bytes()
print('Exact cumulative275candidate built at released flags; originalcases/limits; no diagnostics')

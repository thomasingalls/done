from pathlib import Path
import json,hashlib,subprocess
r=Path(__file__).parent;repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');sha=lambda b:hashlib.sha256(b).hexdigest();out={'sourceMaps':{},'checks':[]}
for variant in ['before','after']:
 src=r/('source-'+variant);manifest=json.loads((r/(variant+'-source-inputs.json')).read_text());assert all(sha((src/p).read_bytes())==h for p,h in manifest['files'].items());matched={}
 for f in(r/(variant+'-dist')).rglob('*.map'):
  m=json.loads(f.read_text())
  for path,body in zip(m['sources'],m.get('sourcesContent',[])):
   key=next((prefix+'/'+path.split('/'+prefix+'/',1)[1]for prefix in ['src','account-protocol','private','wasm']if'/'+prefix+'/'in path),None)
   if key and(src/key).is_file():assert body.encode()==(src/key).read_bytes(),(variant,key);matched[key]=sha(body.encode())
 assert 'src/crdt/accountSyncDriver.ts'in matched and 'src/crdt/accountReceive.ts'in matched;out['sourceMaps'][variant]=len(matched)
 assets=json.loads((r/(variant+'-assets.json')).read_text());assert assets=={str(f.relative_to(r/(variant+'-dist'))):sha(f.read_bytes())for f in(r/(variant+'-dist')).rglob('*')if f.is_file()}
for name in ['src/crdt/accountSyncDriver.ts','src/crdt/accountReceive.ts']:assert(r/'source-after'/name).read_bytes()==(repo/name).read_bytes()
assert b'__ownerTrace'not in(r/'source-after/src/crdt/accountSyncDriver.ts').read_bytes();out['browserExecutableSha256']=sha(Path('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome').read_bytes());out['fixtureSha256']=sha((r/'private-fixture/fixture.json').read_bytes());out['fixedServerSource']='signed0ab source-server for all client variants';out['flags']={v:json.loads((r/(v+'-flags.json')).read_text())for v in ['before','after']};assert {k for k in out['flags']['before']if out['flags']['before'][k]!=out['flags']['after'][k]}=={'VITE_ACCOUNT_WARM_LOADS'};assert json.loads((r/'before-source-inputs.json').read_text())==json.loads((r/'after-source-inputs.json').read_text());out['checks']=['all source manifest bytes exact','both emitted map closures exact','both asset populations exact','candidate native source matches cumulative checkout','no owner-stage instrumentation'];(r/'qa.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))

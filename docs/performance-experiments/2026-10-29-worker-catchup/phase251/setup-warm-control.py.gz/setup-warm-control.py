from pathlib import Path
import shutil,json,hashlib,subprocess,os,time
old=Path('/private/tmp/done-due-send-yield-20261030');r=Path('/private/tmp/done-verified-selection-control-20261030');repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');r.mkdir();sha=lambda b:hashlib.sha256(b).hexdigest()
# Both client source populations identical; server stays the original signed population.
for name in ['source-before','source-after']:shutil.copytree(old/'source-after',r/name,symlinks=True)
shutil.copytree(old/'source-before',r/'source-server',symlinks=True);(r/'source-R').symlink_to(r/'source-server',target_is_directory=True);(r/'private-fixture').symlink_to(old/'private-fixture',target_is_directory=True)
for name in ['container-image.json','container-service.mjs','observer.mjs','notification-probe.mjs','notification-probe.d.mts','read-request.mjs','read-request.d.mts','playwright-storage-source.txt','analyze-case.py','build-flags.json']:(r/name).write_bytes((old/name).read_bytes().replace(str(old).encode(),str(r).encode()))
shutil.copytree(old/'harness',r/'harness',symlinks=True,ignore=shutil.ignore_patterns('node_modules','test-results','artifacts'));(r/'harness/node_modules').symlink_to(repo/'node_modules',target_is_directory=True)
for f in(r/'harness').rglob('*'):
 if f.is_file()and not f.is_symlink()and f.suffix in ['.mjs','.ts','.json']:
  b=f.read_bytes();f.write_bytes(b.replace(str(old).encode(),str(r).encode()))
p=r/'harness/test/account-continuation-lab/runtime.mjs';p.write_text(p.read_text().replace("source='"+str(r/'source-before')+"'","source='"+str(r/'source-server')+"'"))
identity=json.loads((old/'after-source-inputs.json').read_text());baseFlags=json.loads((old/'build-flags.json').read_text());assert baseFlags['VITE_ACCOUNT_WARM_LOADS']=='0'
for name in ['before','after']:
 src=r/('source-'+name);assert all(sha((src/p).read_bytes())==h for p,h in identity['files'].items());(r/(name+'-source-inputs.json')).write_text(json.dumps(identity,indent=2)+'\n');flags={**baseFlags,'VITE_ACCOUNT_WARM_LOADS':'0'if name=='before'else'1'};(r/(name+'-flags.json')).write_text(json.dumps(flags,indent=2)+'\n')
# Reuse exact freshly rebuilt disabled assets. They are the reference for completed250 trajectories.
shutil.copytree(old/'after-dist',r/'before-dist');(r/'before-assets.json').write_bytes((old/'after-assets.json').read_bytes())
node='/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node';src=r/'source-after';flags=json.loads((r/'after-flags.json').read_text());env={**os.environ,**flags,'PATH':str(Path(node).parent)+':'+os.environ['PATH'],'APP_BUILD_REVISION':identity['baseCommit']+'-dirty','APP_BUILD_DATE':'2026-10-30'};cmd=[node,str(src/'node_modules/vite/bin/vite.js'),'build','--outDir',str(r/'after-dist'),'--emptyOutDir','--sourcemap'];start=time.time_ns()//1000000
with(r/'after-build.log').open('w')as f:p=subprocess.run(cmd,cwd=src,env=env,stdout=f,stderr=subprocess.STDOUT)
assert p.returncode==0;assets={str(f.relative_to(r/'after-dist')):sha(f.read_bytes())for f in(r/'after-dist').rglob('*')if f.is_file()};(r/'after-assets.json').write_text(json.dumps(assets,indent=2)+'\n');(r/'build-receipt.json').write_text(json.dumps({'source':'same phase248 candidate as disabled reference','newBuild':'existing guarded warm/selection path enabled','flagsOnlyChange':{'VITE_ACCOUNT_WARM_LOADS':['0','1']},'command':cmd,'startedAt':start,'finishedAt':time.time_ns()//1000000,'beforeAssetSource':str(old/'after-dist'),'afterAssetCount':len(assets)},indent=2)+'\n')
# Three fixed new trajectories: two enabled modes, one disabled normal drift control; never replace old results.
plan=[{'name':'01-enabled-normal','mode':'late','variant':'after','withhold':False,'config':'late.config.ts'},{'name':'02-enabled-withheld','mode':'late','variant':'after','withhold':True,'config':'late.config.ts'},{'name':'03-disabled-normal-control','mode':'late','variant':'before','withhold':False,'config':'late.config.ts'}];(r/'run-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
# Actual original primitive and scheduling metadata collector. No owner stage traces.
s=(old/'qa.py').read_text().replace(str(old),str(r));(r/'qa.py').write_text(s)
s=(old/'run.py').read_text();(r/'run.py').write_text(s)
s=(Path('/private/tmp/done-worker-catchup-matched-20261029')/'smoke.mjs').read_text().replace('/private/tmp/done-worker-catchup-matched-20261029',str(r)).replace('apparatus-smoke-correct','apparatus-smoke');(r/'smoke.mjs').write_text(s)
print('Warm control built; exact disabled reference retained; source unchanged, one existing flag varied')

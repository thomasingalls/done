from pathlib import Path
import json,gzip,hashlib,re
m=Path(__file__).parent;r=Path('/private/tmp/done-due-send-yield-20261030');repo=Path('/Users/thomasingalls/.codex/worktrees/7fda/done');p=repo/'docs/performance-experiments/2026-10-29-worker-catchup/phase250';p.mkdir();report=json.loads((r/'comparison.json').read_text());assert len(report['rows'])==4;assert all(v['gates']['archiveAndColdGuards']for v in report['rows']);ids={};names=['run.log','run-outcomes.json','compare.py','comparison.json','comparison.log','cleanup.json','followup-control-notes.md']
for case in ['01-before-normal','02-after-normal','03-after-withheld','04-before-withheld']:names +=[case+'/'+n for n in ['result.json','partial-result.json','analysis.json','analysis.log','console.log','runner-receipt.json','container-identity.json','docker-command.json','services.log']]
for name in names:
 b=(r/name).read_bytes();ids[name]=hashlib.sha256(b).hexdigest();safe=re.sub(rb'(?<![A-Z0-9])[A-Z0-9]{5}(?:-[A-Z0-9]{5}){4}(?![A-Z0-9])',b'[disposable code redacted]',b);d=p/(name+'.gz');d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(gzip.compress(safe,mtime=0))
b=Path(__file__).read_bytes();(p/'packet250.py.gz').write_bytes(gzip.compress(b,mtime=0));ids['packet250.py']=hashlib.sha256(b).hexdigest();(p/'inputs.json').write_text(json.dumps(ids,indent=2)+'\n');(p/'README.md').write_text('''# Phase250 — due-send yield improves peer p95 but costs catch-up throughput

2026-10-30. Fixed249 four journeys complete, no retries. Actual native Worker clients, server,
source/assets/cgroup/fixture/guarded civil date and existing observers as frozen. All480keys/12markers,
full archives/no added writing, both receiver convergence and same-profile offline cold/no reinjection
pass. All local16ms and peer2500ms p95,30s final delivery and600s backlog guards pass.

| Mode/client | Backlog s | Local p95 ms | Peer p95 ms | Markers ms | H2 uploads |
| --- | ---: | ---: | ---: | --- | ---: |
| normal before |205.248|7.029|1945.214|921.388 /2404.377 /2961.333|68|
| normal after |236.067|6.692|1461.389|900.028 /1537.572 /2268.649|109|
| withheld after |244.416|5.835|1865.042|1167.604 /1491.726 /2526.722|104|
| withheld before |225.919|7.979|2366.324|1366.753 /2517.071 /1974.550|65|

Normal after clears every gate. Withheld after late2526.722ms FAILS original every-marker2500ms.
Before fails normal late2961.333 and withheld mid2517.071. No near-miss waiver or passing diagnostic
replacement. Aggregate acceptance remains BLOCKED. Peer p95 improves24.9%/21.2% descriptively, while
backlog ratios1.150156 (+30.819s) and1.081875 (+18.497s) retain throughput cost. Normal pair crosses
predeclared1.10 investigation signal. One pair per mode/one host: no powered population effect or
claim that every marker improves. Source handoff causality is unit-tested; whole-run timing still
has thermal/cache/host/observer variation. Mode cannot be treated as an interchangeable replicate.

H2 uploads68→109 and65→104, roughly60% more. Earlier scheduler opportunities produce more envelopes;
extra crypto/retention/receipt work is a plausible throughput mechanism, not fully attributed here.
Service requests2452→2679 normal and2414→2497 withheld; server CPU67.741→74.232s normal and75.975→
75.717s withheld. Do not claim server CPU alone explains the client delay. Raw local maxima15.762/
183.942/50.162/39.597ms (table order) remain visible despite passing p95: rare input stalls are not
proved solved. Original Goals/refocus/hardware limitations remain; no Android equivalence claim.

Independent reconstruction checks every raw key/marker/clock bracket and asset identity, real ready
frames/withholding, actual date/timezone, cgroup/noOOM and original gates. All five exact own containers
and own browsers absent. No source changes during measurement or heavy concurrent work.

Clear next experiment: inherited flags explicitly disable WARM_LOADS, which disables existing native
verified selection reuse. Source default permits it. Before adding new proof reuse, compare same248
code with explicit1 against these exact0 references, retaining ALL original misses and guards. Reuse
these completed0 trajectories, add enabled normal/withheld plus one fixed0 normal drift control, not
an opportunistic replacement. First exercise existing native warm/resume/audit/authority refusals.
No product default/config change, proof shortcut, release preparation or claim about deployed flags.
''')
for name,text in [('decisions.md','Retain yield latency/throughput tradeoff: peerp95 better in both modes, uploads~60% more, backlog+15.0%/+8.2%, withheld late2526.722ms still fails2.5s. Do not waive near-miss or hide raw input tails. Compare pre-existing verified selection path before designing another reuse mechanism; completed0 references remain authoritative.'),('completed.md','Four matched249 journeys complete with full writing/archive/offline-cold guards. Normal after passes every gate; withheld after late2526.722ms fails. Backlog ratios1.150156/1.081875 and upload counts68→109/65→104 retained. Independent reconstruction and exact cleanup pass; rare local maxima remain. No concurrent changes or retries.'),('product-backlog.md','Phase250: yielding improves peerp95 but not aggregate acceptance; throughput cost requires investigation. Next same-source verified warm/selection0vs1 configuration control with native security guards, then follow clear evidence. Original2.5s/16ms gates and all old failures stay; no release prep.')]:
 with(repo/'docs'/name).open('a')as f:f.write('\n\n## 2026-10-30 — phase250: due-send comparison outcomes\n\n'+text+' [Evidence](performance-experiments/2026-10-29-worker-catchup/phase250/README.md).\n')

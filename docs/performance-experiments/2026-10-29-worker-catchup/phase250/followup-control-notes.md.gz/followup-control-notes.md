# Clear follow-up after the fixed four journeys: inherited warm-loads-off control

Static observation only, no outcome yet. accountCapture.ts:110 requires version9, WARM_LOADS!==0,
and ledger!==reference to activate warm loads. contentStore.ts:190 requires selectiveLoads,
warmLoads,reuseOpened AND validate for canSelect. The frozen249 benchmark explicitly sets
VITE_ACCOUNT_WARM_LOADS=0, so readState cannot take the private verified selection path even
though accountReceive has already implemented it. The source's default (flag absent) permits it.
No inference here about a particular running production image's build flags.

This suggests a discriminating configuration experiment before reimplementing proof reuse:
same248 source, existing WARM_LOADS0 versus explicit1 (same source path as absent default),
same native authority/custody/ledger/witness validation. Do not edit product defaults, remove
checks or let enabled-profile passes replace disabled-profile misses. Both exact builds,
fresh fictional states/profiles and a separate fixed counterbalanced normal/withheld plan.
Record whether verification/selection work and whole catch-up/gates actually improve.

Receiver status duplication remains real: driveReceiveStep calls receiveStatus before and after;
prepareRead also obtains a fresh authenticated ledger view; successful receivePage already derives
native post-commit/readback status. But empty responses only describe their pre-verification state,
and preflight currently checks conflicts across ALL publishers. Those checks cannot be silently
omitted by consuming a convenient status field. Any consolidation requires native owner-bound
freshness across awaits, global conflict checks and final current validation, with tamper/regression
controls. Prefer measuring the existing guarded path before designing a new reuse mechanism.

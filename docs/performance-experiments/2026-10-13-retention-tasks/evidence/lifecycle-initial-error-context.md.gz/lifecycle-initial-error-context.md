# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: removal-checkpoint.spec.ts >> reduced original and joined owners exchange/undo writing, refuse an unfinished checkpoint cut, then retain its installation through another cut and cold open
- Location: test/local-baseline/removal-checkpoint.spec.ts:33:1

# Error details

```
Error: expect(locator).toBeEnabled() failed

Locator: getByRole('region', { name: 'History maintenance', exact: true }).getByRole('button', { name: 'Check history', exact: true })
Expected: enabled
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeEnabled" with timeout 5000ms
  - waiting for getByRole('region', { name: 'History maintenance', exact: true }).getByRole('button', { name: 'Check history', exact: true })
    4 × locator resolved to <button disabled class="menu-button">Check history</button>
      - unexpected value "disabled"

```

```yaml
- main:
  - region "Choose an account":
    - text: done
    - heading "Choose an account" [level=1]
    - paragraph: Select a saved account, connect devices, or create a new account.
    - region "Saved on this device":
      - heading "Saved on this device" [level=2]
      - list "Saved accounts":
        - listitem:
          - button "Resume device connection, workspace a24964ed8e387388a78d4832a1d9ae39":
            - text: Device connection Workspace ID
            - code: a24964ed8e387388a78d4832a1d9ae39
    - button "Open local-only workspace"
    - button "Use another account"
    - paragraph: Connect devices, or recover using your saved recovery code and account passkey.
    - button "Create a new account"
    - paragraph: Start with an empty list and a new passkey.
```

# Test source

```ts
  1   | import { test, expect, type Page } from '@playwright/test';
  2   | import { build } from 'vite';
  3   | import { resolve } from 'node:path';
  4   | import { pairedEditors, openSaved, add } from '../packaged-account/devices';
  5   | import { startService, stopService } from '../packaged-account/server';
  6   | import type { AdmittedWorkspace } from '../../src/crdt/admittedWorkspace';
  7   | 
  8   | type Owner = {
  9   |   removeLocalHistory(revision: number): Promise<{ kind: string; revision?: number }>;
  10  |   workspace: Pick<AdmittedWorkspace, 'whenDurable' | 'command' | 'status'>;
  11  | };
  12  | const removal = (p: Page, revision: number) =>
  13  |   p.evaluate(async (r) => {
  14  |     const owner = (globalThis as unknown as { __retentionOwner: Owner }).__retentionOwner;
  15  |     try {
  16  |       return await owner.removeLocalHistory(r);
  17  |     } catch (e) {
  18  |       if (
  19  |         e instanceof Error &&
  20  |         e.message === 'Receive authority was superseded' &&
  21  |         owner.workspace.status.state === 'active'
  22  |       )
  23  |         return { kind: 'retired-flight' };
  24  |       throw e;
  25  |     }
  26  |   }, revision);
  27  | const panel = (p: Page) => p.getByRole('region', { name: 'History maintenance', exact: true });
  28  | async function inspect(p: Page) {
  29  |   await p.getByRole('button', { name: 'History maintenance', exact: true }).click();
  30  |   await panel(p).getByRole('button', { name: 'Check history', exact: true }).click();
> 31  |   await expect(panel(p).getByRole('button', { name: 'Check history', exact: true })).toBeEnabled();
      |                                                                                      ^ Error: expect(locator).toBeEnabled() failed
  32  | }
  33  | test('reduced original and joined owners exchange/undo writing, refuse an unfinished checkpoint cut, then retain its installation through another cut and cold open', async ({
  34  |   page,
  35  |   browser,
  36  | }, info) => {
  37  |   test.setTimeout(120000);
  38  |   const outDir = info.outputPath('build');
  39  |   let hits = 0;
  40  |   await build({
  41  |     logLevel: 'error',
  42  |     build: { outDir },
  43  |     define: {
  44  |       'import.meta.env.VITE_ACCOUNT_BASELINE_INSTALL': JSON.stringify('1'),
  45  |       'import.meta.env.VITE_ACCOUNT_BASELINE_READ': JSON.stringify('1'),
  46  |       'import.meta.env.VITE_ACCOUNT_RETENTION': JSON.stringify('1'),
  47  |     },
  48  |     plugins: [
  49  |       {
  50  |         name: 'private-retention-checkpoint',
  51  |         enforce: 'pre',
  52  |         transform(code, id) {
  53  |           if (!id.endsWith('/src/crdt/accountReceive.ts')) return;
  54  |           const at = '  clearAccountTransition(result.accountId);';
  55  |           if (code.split(at).length !== 2) throw Error('Owner test anchor changed');
  56  |           hits++;
  57  |           return code.replace(at, at + '\n  globalThis.__retentionOwner = result;');
  58  |         },
  59  |       },
  60  |     ],
  61  |   });
  62  |   expect(hits).toBe(1);
  63  |   const service = await startService(info.outputPath('service'), resolve(outDir), true, true);
  64  |   let pair: Awaited<ReturnType<typeof pairedEditors>> | undefined;
  65  |   try {
  66  |     pair = await pairedEditors(page, browser, true);
  67  |     const second = pair.second;
  68  |     for (const p of [page, second])
  69  |       await expect
  70  |         .poll(() => removal(p, 0), { timeout: 20000 })
  71  |         .toMatchObject({ kind: 'removed', revision: 1 });
  72  |     await add(page, 'Original writing after actual removal');
  73  |     await expect(second.locator('.shell')).toContainText('Original writing after actual removal');
  74  |     await add(second, 'Joined writing after actual removal');
  75  |     await expect(page.locator('.shell')).toContainText('Joined writing after actual removal');
  76  |     for (const kind of ['undo', 'redo'] as const) {
  77  |       await second.evaluate(async (kind) => {
  78  |         const owner = (globalThis as unknown as { __retentionOwner: Owner }).__retentionOwner;
  79  |         await owner.workspace.command({ kind }).accepted;
  80  |       }, kind);
  81  |       if (kind === 'undo')
  82  |         await expect(page.locator('.shell')).not.toContainText(
  83  |           'Joined writing after actual removal',
  84  |         );
  85  |       else
  86  |         await expect(page.locator('.shell')).toContainText('Joined writing after actual removal');
  87  |     }
  88  |     await inspect(page);
  89  |     await panel(page).getByRole('button', { name: 'Create history snapshot' }).click();
  90  |     await expect(panel(page)).toContainText(
  91  |       'Snapshot saved. Verify it from another approved device.',
  92  |     );
  93  |     expect(await removal(page, 1)).toEqual({ kind: 'skipped', reason: 'durable-attempt' });
  94  |     await inspect(second);
  95  |     await panel(second).getByRole('button', { name: 'Verify history snapshot' }).click();
  96  |     await expect(panel(second)).toContainText('Verified snapshot 1 is saved.');
  97  |     await panel(page).getByRole('button', { name: 'Check history', exact: true }).click();
  98  |     await panel(page).getByRole('button', { name: 'Resume history snapshot', exact: true }).click();
  99  |     await expect(panel(page)).toContainText('Verified snapshot 1 is saved.');
  100 |     for (const p of [page, second])
  101 |       await expect
  102 |         .poll(() => removal(p, 1), { timeout: 20000 })
  103 |         .toMatchObject({ kind: 'removed', revision: 2 });
  104 |     for (const [p, code, joining] of [
  105 |       [page, pair.first.code, false],
  106 |       [second, pair.next.code, true],
  107 |     ] as const) {
  108 |       await p.getByRole('button', { name: 'Lock workspace', exact: true }).click();
  109 |       await p.goto('/');
  110 |       await openSaved(p, code, joining);
  111 |       await expect(p.locator('.shell')).toContainText('Joined writing after actual removal');
  112 |       await inspect(p);
  113 |       await expect(panel(p)).toContainText('Verified snapshot 1 is saved.');
  114 |       await expect
  115 |         .poll(() => removal(p, 1), { timeout: 15000 })
  116 |         .toEqual({ kind: 'already-removed' });
  117 |     }
  118 |     await add(second, 'Cold reduced checkpoint continues');
  119 |     await expect(page.locator('.shell')).toContainText('Cold reduced checkpoint continues');
  120 |   } finally {
  121 |     await pair?.other.close();
  122 |     await stopService(service);
  123 |   }
  124 | });
  125 | 
```
from pathlib import Path
import json,hashlib,os,subprocess,time
r=Path(__file__).parent;s=r/'source';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();start=json.loads((r/'starting.json').read_text());baseline=json.loads(Path('/private/tmp/done-request-authority-20261022/starting.json').read_text())['runtimeFiles'];client=json.loads(Path('/private/tmp/done-late-ledger-20261022/starting.json').read_text())['clientFiles']
assert json.loads((r/'source-review.json').read_text())['status']=='passed';assert json.loads((r/'challenge.json').read_text())['status']=='passed';assert(r/'types.log').read_text()==''and(r/'lint.log').read_text()=='';assert 'tests 46'in(r/'cache-and-races.log').read_text()and'fail 0'in(r/'cache-and-races.log').read_text();assert 'tests 24'in(r/'new-final.log').read_text()and'fail 0'in(r/'new-final.log').read_text()
for f,h in baseline.items():
 if f.startswith('account-service/'):assert sha(r/'reference-account-service'/f.removeprefix('account-service/'))==h,f
 else:assert sha(s/f)==h,f
for f,h in client.items():assert sha(s/'dist'/f)==h,f
assert len(client)==110
for p in(s/'account-service').glob('*.ts'):assert "'/experiment/observer"not in p.read_text()
files=[r/'protocol.md',r/'container-service.mjs',r/'observer.mjs',r/'freeze-and-run.py',*list((s/'test/account-continuation-lab').glob('*'))];plan=[{'name':str(i+1)+'-'+v,'variant':v}for i,v in enumerate(['R','C','C','R'])];(r/'run-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
identity={'baselineTree21':'666a30cdf054315524f2da9efe2a1ed62bc5b190','base22':start['baseTree22'],'baselineInputs':baseline,'candidateInputs':{f:sha(s/f)for f in baseline},'changedRuntimeFilesSince21':sorted(f for f,h in baseline.items()if sha(s/f)!=h),'onlyChangedRuntimeFileSince22':'account-service/delivery.ts','clientFiles':client,'files':{str(p.relative_to(r)):sha(p)for p in files if p.is_file()},'testFiles':{f:sha(s/f)for f in ['test/account-service-delivery/publisher-commit-races.test.mjs','test/account-ceremony/content-transfer.test.mjs']},'privateFixtureSha256':start['privateFixtureSha256'],'image':json.loads((r/'container-image.json').read_text())['Id'],'plan':plan,'observation':'same closed HTTP wrapper in both arms; complete request SHA and error labels only; no native/client/crypto instrumentation'};assert identity['changedRuntimeFilesSince21']==sorted(['account-service/delivery.ts','account-service/historyCheckpoint.ts','account-service/membershipHistory.ts','account-service/membershipLocator.ts']);(r/'measurement-identity.json').write_text(json.dumps(identity,indent=2)+'\n');rows=[]
for c in plan:
 for f,h in identity['files'].items():assert sha(r/f)==h,f
 for f,h in identity['candidateInputs'].items():assert sha(s/f)==h,f
 for f,h in client.items():assert sha(s/'dist'/f)==h,f
 for p in(r/'reference-account-service').glob('*.ts'):assert sha(p)==baseline['account-service/'+p.name]
 out=r/c['name'];out.mkdir(mode=0o700);env={**os.environ,'PATH':'/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin:'+os.environ['PATH'],'FAIR_OUT':str(out),'FAIR_VARIANT':c['variant'],'FAIR_OBSERVED':'0','FAIR_DIST':str(s/'dist')};cmd=['node','node_modules/@playwright/test/cli.js','test','--config','test/account-continuation-lab/playwright.config.ts'];at=int(time.time()*1000)
 with(out/'invocation.log').open('w')as log:v=subprocess.run(cmd,cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT)
 rows.append({**c,'command':cmd,'startedAt':at,'completedAt':int(time.time()*1000),'exitCode':v.returncode});(r/'run-receipts.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows[-1]),flush=True)
 if v.returncode:raise Exception('Journey failed; preserve and investigate. No replacement '+c['name'])

from pathlib import Path
import subprocess,os,json,time,sys,hashlib
s=Path(__file__).parent;node='/private/tmp/done-node24-runtime/node-v24.18.0-darwin-arm64/bin/node';plan=json.loads((s/'baseline-plan.json').read_text());env={**os.environ,'PATH':str(Path(node).parent)+':'+os.environ['PATH'],'CHROMIUM_PATH':'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'}
identity=json.loads((s/'baseline-identity.json').read_text())
assert all(hashlib.sha256((s/p).read_bytes()).hexdigest()==h for p,h in identity['apparatus'].items())
rows=[]
def run(case):
 out=s/case['name'];out.mkdir(mode=0o700,exist_ok=False);e={**env,'FAIR_OUT':str(out),'FAIR_VARIANT':case['variant'],'FAIR_DIST':str(s/('source-'+case['variant'])/'dist'),'QUIET_WITHHOLD':'1'if case['withhold']else'0'};cmd=[node,'node_modules/@playwright/test/cli.js','test','--config','test/account-continuation-lab/late.config.ts'];receipt={'case':case,'startedAt':time.time_ns()//1000000,'command':cmd}
 with(out/'console.log').open('w')as f:p=subprocess.run(cmd,cwd=s/'harness',env=e,stdout=f,stderr=subprocess.STDOUT)
 receipt.update(exit=p.returncode,finishedAt=time.time_ns()//1000000);(out/'runner-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(case['name'],'functional exit',p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
 c={**case,'mode':'late'}
 with(out/'analysis.log').open('w')as f:p=subprocess.run([sys.executable,str(s/'analyze-case.py'),json.dumps(c)],stdout=f,stderr=subprocess.STDOUT)
 assert p.returncode==0
 row=json.loads((out/'analysis.json').read_text());rows.append(row);print(case['name'],'local',row['localUpperMs'],'peer',row['peerUpperMs'],'gates',row['gates'],flush=True)
for case in plan['primary']:run(case)
conditional=any(not r['gates']['local16ms']for r in rows)
if conditional:
 for case in plan['conditionalPriorAsset']:run(case)
(s/'baseline-summary.json').write_text(json.dumps({'kind':'diagnostic original-workload comparison, no activation credit','conditionalPriorAssetExecuted':conditional,'runs':rows},indent=2)+'\n')
print('Frozen baseline sequence complete; all results retained.',flush=True)

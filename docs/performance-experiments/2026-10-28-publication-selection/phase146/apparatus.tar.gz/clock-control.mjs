import {chromium}from'/Users/thomasingalls/.codex/worktrees/7fda/done/node_modules/@playwright/test/index.mjs';
import{clockBrackets}from'./harness/test/account-continuation-lab/dispatch-probe.ts';
import{writeFileSync,readFileSync}from'node:fs';import assert from'node:assert/strict';
const root='/private/tmp/done-publication-selection-monotonic-20261028';
const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'});
const original=Date.now;const rows=[];let shift=0;
const bounds=rows=>{const lo=Math.max(...rows.map(q=>q.renderer-q.after-1)),hi=Math.min(...rows.map(q=>q.renderer-q.before+1));return{lo,hi,valid:lo<=hi}};
try{
 const page=await browser.newPage();Date.now=()=>original()+shift;
 rows.push(...await clockBrackets(page));const oldBefore=original();shift=10000;await new Promise(r=>setTimeout(r,200));rows.push(...await clockBrackets(page));
 assert(bounds(rows).valid,'Monotonic brackets did not intersect across simulated wall step');
 const broken=structuredClone(rows);broken[0].renderer+=10000;assert(!bounds(broken).valid,'Malformed bracket was not refused');
 const wall=[];for(const value of[0,10000]){shift=value;const before=Date.now();const renderer=await page.evaluate(()=>performance.timeOrigin+performance.now());wall.push({before,renderer,after:Date.now()});}assert(!bounds(wall).valid,'Wall-clock control did not fail');
 for(const n of['maintenance.spec.ts','late.spec.ts','dispatch-probe.ts'])assert(!readFileSync(root+'/harness/test/account-continuation-lab/'+n,'utf8').includes('Date.now()'));
 writeFileSync(root+'/clock-control.json',JSON.stringify({status:'passed',monotonicRows:rows,monotonicIntersection:bounds(rows),wallClockControl:wall,wallControlIntersection:bounds(wall),malformedBracketRefused:true,allowanceMsUnchanged:1,applicationNotLoaded:true},null,2)+'\n');
 console.log('Actual headless browser: monotonic brackets survive 10s host wall-clock step; old clock and malformed bracket controls refuse.');
}finally{Date.now=original;await browser.close();}

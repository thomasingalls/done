//#region source-C/src/crdt/accountLedgerMetrics.ts
var e = {
	full: 0,
	incremental: 0,
	sourceDecodes: 0,
	events: 0,
	audits: 0,
	auditCompletions: 0,
	auditInterruptions: 0,
	mismatches: 0
}, t = {
	BASE_URL: "/",
	DEV: !1,
	MODE: "production",
	PROD: !0,
	SSR: !1,
	VITE_ACCOUNT_BATCH: "coordinated-2000"
}.VITE_ACCOUNT_LEDGER_PROFILE === "1", n = Object.fromEntries((/* @__PURE__ */ "startupValidations.joinedStartupValidations.deliveryVerifications.inboundVerifications.inboundCensuses.deliveryPrefixLinks.coverageBaselines.coverageDirectProofs.loads.warmLoads.baselineFullReplays.baselineWarmReuses.baselineIncrementalReuses.selectedLoads.warmAuditRows.warmAuditBytes.loadedRows.loadedBytes.authorityChecks.authorityAuthentications.authorityReuses.membershipProofTransfers.positions.sourceParses.sourceParseBytes.recordCopies.recordCopyBytes.journalFlushes.dirtyJournalFlushes.projectionChecks.directTextPreparations.finalApplyEarlyChecks.finalApplyImmediate.finalApplyQueueMisses.finalApplyActivityMisses.finalApplyFallbacks.finalApplySkipped".split(".")).map((e) => [e, 0])), r = {}, i = (e, r = 1) => {
	t && (n[e] = (n[e] ?? 0) + r);
}, a = () => t ? performance.now() : 0, o = (e, n) => {
	if (!t) return;
	let i = performance.now() - n, a = r[e] ??= {
		calls: 0,
		totalMs: 0,
		maxMs: 0
	};
	a.calls++, a.totalMs += i, a.maxMs = Math.max(a.maxMs, i), e.startsWith("retention") && (performance.measure(e, {
		start: n,
		duration: i
	}), performance.clearMeasures(e));
}, s = Object.fromEntries([
	"full",
	"incremental",
	"coverageCheck",
	"coverageRebuild",
	"compaction"
].map((e) => [e, {
	calls: 0,
	totalMs: 0,
	maxMs: 0
}])), c = {
	local: 0,
	remote: 0,
	flush: 0
};
({
	BASE_URL: "/",
	DEV: !1,
	MODE: "production",
	PROD: !0,
	SSR: !1,
	VITE_ACCOUNT_BATCH: "coordinated-2000"
}).VITE_ACCOUNT_LEDGER_PROFILE === "1" && Object.defineProperty(globalThis, "__doneLedgerMetrics", {
	value: () => ({
		queuePeaks: { ...c },
		...e,
		timings: structuredClone(s),
		work: { ...n },
		costs: structuredClone(r)
	}),
	configurable: !0
});
var l = {};
t && Object.defineProperty(globalThis, "__doneOpenMilestones", {
	value: () => structuredClone(l),
	configurable: !0
});
//#endregion
//#region source-C/src/crdt/verificationOwnership.ts
function u(e, t, n = /* @__PURE__ */ new Set()) {
	if (!(!e || typeof e != "object" || n.has(e))) if (n.add(e), e instanceof Uint8Array) t(e);
	else if (e instanceof Map) for (let [r, i] of e) u(r, t, n), u(i, t, n);
	else if (e instanceof Set) for (let r of e) u(r, t, n);
	else for (let r of Object.values(e)) u(r, t, n);
}
function d(e, t) {
	let n = /* @__PURE__ */ new Set();
	u(t, (e) => n.add(e.buffer));
	let r = /* @__PURE__ */ new Set();
	u(e, (e) => {
		n.has(e.buffer) || r.has(e.buffer) || (r.add(e.buffer), new Uint8Array(e.buffer).fill(0));
	});
}
//#endregion
//#region source-C/src/crdt/contentSelection.ts
var f = /* @__PURE__ */ new WeakMap();
function p(e) {
	let t = f.get(e);
	if (!t) throw Error("Content selection expired");
	return t();
}
//#endregion
//#region source-C/src/crdt/verifiedRecords.ts
var m = (e, t, n, r) => {
	let i = n;
	if (r - n >= 256 && (e.byteOffset + n) % 4 == 0 && (t.byteOffset + n) % 4 == 0) {
		let a = Math.floor((r - n) / 4), o = new Uint32Array(e.buffer, e.byteOffset + n, a), s = new Uint32Array(t.buffer, t.byteOffset + n, a);
		for (let e = 0; e < a; e++) if (o[e] !== s[e]) return !1;
		i += a * 4;
	}
	for (; i < r; i++) if (e[i] !== t[i]) return !1;
	return !0;
}, h = (e, t) => e.length === t.length ? e.length ? e === t || m(e, t, 0, e.length) : (e.subarray(0, 0), !0) : !1, g = (e) => {
	let t = a(), n = e.map((e) => (i("recordCopies"), i("recordCopyBytes", e.bytes.length), {
		...e,
		bytes: e.bytes.slice()
	}));
	return o("copyRecords", t), n;
}, _ = (e, t) => e.length === t.length && e.every((e, n) => {
	let r = t[n];
	return e.kind === r.kind && e.gen === r.gen && e.seq === r.seq && h(e.bytes, r.bytes);
});
async function v(e, t, n) {
	if (e.length !== t.length) return !1;
	for (let r = 0; r < e.length; r++) {
		let i = e[r], a = t[r];
		if (i.kind !== a.kind || i.seq !== a.seq || i.gen !== a.gen || i.bytes.length !== a.bytes.length) return !1;
		if (i.bytes.length || i.bytes.subarray(0, 0), i.bytes !== a.bytes) for (let e = 0; e < i.bytes.length; e += 65536) {
			let t = Math.min(e + 65536, i.bytes.length);
			if (!m(i.bytes, a.bytes, e, t)) return !1;
			let r = n();
			r && await r;
		}
		let o = n();
		o && await o;
	}
	return !0;
}
function y(e) {
	if (e instanceof Uint8Array) e.fill(0);
	else if (e instanceof Map) for (let t of e.values()) y(t);
	else if (e && typeof e == "object") for (let t of Object.values(e)) y(t);
}
function b(e = {}) {
	let t = e.ownResults === !0, n, r, i, s = 0, c = !1, l = () => {
		s++, t ? d([n, r]) : (y(n), y(r)), n = void 0, r = void 0, i = void 0;
	};
	return {
		clear: l,
		select(e, t) {
			if (!n || i !== p(e)) throw Error("No verified view for this selection");
			let a = structuredClone(t(r));
			return p(e), a;
		},
		matches: (e) => !!n && _(n, e),
		readIfMatches(e, t) {
			if (!n || !_(n, e)) return;
			let i = a(), s = { value: structuredClone(t(r)) };
			return o("readProjection", i), s;
		},
		read(e, t = (e) => e) {
			if (!n || !_(n, e)) throw Error("No verified view for these records");
			let i = a(), s = structuredClone(t(r));
			return o("readProjection", i), s;
		},
		async verify(e, u, f, p, m, b) {
			if (c) throw Error("Concurrent verification is not allowed");
			c = !0;
			try {
				try {
					p();
				} catch (e) {
					throw l(), e;
				}
				let c = s;
				if (n && i === u) {
					let t = b ? await v(n, e, b) : _(n, e);
					if (p(), c !== s) throw Error("Verification view was invalidated");
					if (t) return;
				}
				let x = r, S = n, C = ++s, w = 0;
				if (t && S) for (; w < Math.min(S.length, e.length);) {
					let t = S[w], n = e[w];
					if (t.kind !== n.kind || t.gen !== n.gen || t.seq !== n.seq || !(b ? await v([t], [n], b) : h(t.bytes, n.bytes))) break;
					w++;
				}
				if (p(), C !== s) throw Error("Verification view was invalidated");
				let T = t ? [...S?.slice(0, w) ?? [], ...g(e.slice(w))] : g(e), E, D = !1;
				try {
					if (E = x !== void 0 && S && m ? await m(x, S, T) : void 0, E ??= await f(T), p(), C !== s) throw Error("Verification view was invalidated");
					let e = a();
					if (t) d([r, n], [E, T]), r = E, n = T, D = !0, o("installOwned", e);
					else {
						let t = structuredClone(E);
						o("installClone", e);
						let i = g(T);
						y(r), y(n), r = t, n = i;
					}
					i = u;
				} catch (e) {
					throw C === s && l(), e;
				} finally {
					D || (t ? d([E, T], [r, n]) : (y(E), y(T)));
				}
			} finally {
				c = !1;
			}
		}
	};
}
//#endregion
export { g as copyRecords, b as createVerifiedRecords, y as eraseVerified, h as sameBytes, _ as sameRecords, v as sameRecordsCooperatively };

//# sourceMappingURL=helper.js.map
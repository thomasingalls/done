import { build } from "<repo>/node_modules/.pnpm/vite@8.1.5_@types+node@26.1.2/node_modules/vite/dist/node/index.js";
import { writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { release, cpus } from 'node:os';

const load = async (baseline) => {
const root = process.cwd();

const source = `export * from '${root}/src/crdt/yjs.ts'; export {createAdmittedWorkspace} from '${root}/src/crdt/admittedWorkspace.ts'; export {createAdmissionOwner} from '${root}/src/crdt/admissionQueue.ts'; export {serializeCollections} from '${root}/src/crdt/serialize.ts';`;
const result = await build({
  configFile: false,
  logLevel: 'error',
  plugins: [
    {
      name: 'profile',
      enforce: 'pre',
      transform(code, id) {
        if (
          baseline &&
          ['/src/crdt/yjs.ts', '/src/crdt/admittedWorkspace.ts'].some((p) => id.endsWith(p))
        )
          return execFileSync('git', ['show', baseline + ':' + id.slice(root.length + 1)], {
            encoding: 'utf8',
          });
      },
      resolveId(id) {
        if (id === 'profile' || id.endsWith('/profile')) return '\0profile';
      },
      load(id) {
        if (id === '\0profile') return source;
      },
    },
  ],
  build: {
    write: false,
    minify: false,
    lib: { entry: 'profile', name: 'Product', formats: ['iife'] },
  },
});
const code = (Array.isArray(result) ? result[0] : result).output.find(
  (o) => o.type === 'chunk',
).code;
return {h:Function(code + ';return Product;')(),hash:createHash('sha256').update(code).digest('hex')};

};

const base=await load('5ffce895'), candidate=await load();const rows=[];
for(const items of [1000,10000,100000]) {
 const subjects=[base,candidate].map(({h})=>{const d=new h.Y.Doc({gc:false});d.clientID=77;const t=d.getText('master');for(let i=0;i<items;i++)t.insert(0,'x'.repeat(100000/items));return {h,d,copy:h.forkDoc(d,false)};});
 try {
  for(let warm=0;warm<10;warm++)for(const {h,d,copy} of subjects)if(!h.sameDocState(d,copy))throw Error('Warmup mismatch');
  const samples=[];
  for(let block=0;block<20;block++)for(const variant of (block%2?[1,0]:[0,1])){const {h,d,copy}=subjects[variant];const at=performance.now();const equal=h.sameDocState(d,copy);const ms=performance.now()-at;if(!equal)throw Error('Comparison mismatch');samples.push({block,variant:variant?'candidate':'baseline',ms});}
  rows.push({items,chars:100000,samples});
 }finally{for(const {d,copy}of subjects){d.destroy();copy.destroy();}}
}
const out={baseline:'5ffce895',baselineBundle:base.hash,candidateBundle:candidate.hash,node:process.version,cpu:cpus()[0].model,design:'Secondary precision check: separate bundles; 10 warmups each; 20 alternating AB/BA pairs at each fixed item count. Descriptive, dependent observations; comparison only.',rows};writeFileSync(process.argv[2],JSON.stringify(out,null,2)+'\n');

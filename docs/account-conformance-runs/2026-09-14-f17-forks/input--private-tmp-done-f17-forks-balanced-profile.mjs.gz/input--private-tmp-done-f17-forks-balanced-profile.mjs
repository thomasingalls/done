import { build } from "<repo>/node_modules/.pnpm/vite@8.1.5_@types+node@26.1.2/node_modules/vite/dist/node/index.js";
import { writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { release, cpus } from 'node:os';

const load = async (baseline) => {
const root = process.cwd();

const source = `export * from '${root}/src/crdt/yjs.ts'; export {createAdmittedWorkspace} from '${root}/src/crdt/admittedWorkspace.ts'; export {createAdmissionOwner} from '${root}/src/crdt/admissionQueue.ts'; export {serializeCollections} from '${root}/src/crdt/serialize.ts';`;
const result = await build({
  configFile: false,
  logLevel: 'error',
  plugins: [
    {
      name: 'profile',
      enforce: 'pre',
      transform(code, id) {
        if (
          baseline &&
          ['/src/crdt/yjs.ts', '/src/crdt/admittedWorkspace.ts'].some((p) => id.endsWith(p))
        )
          return execFileSync('git', ['show', baseline + ':' + id.slice(root.length + 1)], {
            encoding: 'utf8',
          });
      },
      resolveId(id) {
        if (id === 'profile' || id.endsWith('/profile')) return '\0profile';
      },
      load(id) {
        if (id === '\0profile') return source;
      },
    },
  ],
  build: {
    write: false,
    minify: false,
    lib: { entry: 'profile', name: 'Product', formats: ['iife'] },
  },
});
const code = (Array.isArray(result) ? result[0] : result).output.find(
  (o) => o.type === 'chunk',
).code;
return {h:Function(code + ';return Product;')(),hash:createHash('sha256').update(code).digest('hex')};

};

const base=await load('e2c93b05'), candidate=await load();const rows=[];
for(const items of [1000,10000,100000]) {
 const subjects=[base,candidate].map(({h})=>{const d=new h.Y.Doc({gc:false});d.clientID=77;const t=d.getText('master');for(let i=0;i<items;i++)t.insert(0,'x'.repeat(100000/items));return {h,d};});
 try {
  for(let warm=0;warm<10;warm++)for(const {h,d} of subjects){const copy=h.forkDoc(d,false);if(!h.sameDocState(d,copy))throw Error('Warmup mismatch');copy.destroy();}
  const samples=[];
  for(let block=0;block<20;block++)for(const variant of (block%2?[1,0]:[0,1])){const {h,d}=subjects[variant];const at=performance.now();const copy=h.forkDoc(d,false);const ms=performance.now()-at;if(!h.sameDocState(d,copy))throw Error('Fork mismatch');copy.destroy();samples.push({block,variant:variant?'candidate':'baseline',ms});}
  rows.push({items,chars:100000,samples});
 }finally{for(const {d}of subjects)d.destroy();}
}
const out={baseline:'e2c93b05',baselineBundle:base.hash,candidateBundle:candidate.hash,node:process.version,cpu:cpus()[0].model,design:'Fork-only precision check: separate bundles; 10 warmups each; 20 alternating AB/BA pairs at each fixed item count. Correctness check and disposal outside timing. Descriptive, dependent observations.',rows};writeFileSync(process.argv[2],JSON.stringify(out,null,2)+'\n');

import base from "<repo>/vite.config.ts";
import {execFileSync} from "node:child_process";
export default {...base,root:"<repo>",plugins:[...base.plugins,{name:"skip-redone",enforce:"pre",transform(code,id){if(!id.endsWith("/src/crdt/yjs.ts"))return;const from="copied.redone = Y.createID(item.redone.client, item.redone.clock);";if(code.split(from).length!==2)throw Error("mutation must match exactly once");return code.replace(from,"/* deliberately omit redone links */");}}],test:{...base.test,include:["test/pendingProjection.test.ts"],maxWorkers:1,fileParallelism:false,retry:0}};

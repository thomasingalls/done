import base from "<repo>/vite.config.ts";
import {execFileSync} from "node:child_process";
export default {...base,root:"<repo>",plugins:[...base.plugins,{name:"baseline",enforce:"pre",transform(code,id){if(!id.endsWith("/src/crdt/yjs.ts"))return;return execFileSync("git",["show","e2c93b05:src/crdt/yjs.ts"],{encoding:"utf8"});}}],test:{...base.test,include:["test/pendingProjection.test.ts"],maxWorkers:1,fileParallelism:false,retry:0}};

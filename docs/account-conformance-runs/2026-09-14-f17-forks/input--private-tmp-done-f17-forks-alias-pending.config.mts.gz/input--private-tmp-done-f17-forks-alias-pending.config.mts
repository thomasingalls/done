import base from "<repo>/vite.config.ts";
import {execFileSync} from "node:child_process";
export default {...base,root:"<repo>",plugins:[...base.plugins,{name:"alias-pending",enforce:"pre",transform(code,id){if(!id.endsWith("/src/crdt/yjs.ts"))return;const from="missing: new Map(pending.missing)";if(code.split(from).length!==2)throw Error("mutation must match exactly once");return code.replace(from,"missing: pending.missing");}}],test:{...base.test,include:["test/pendingProjection.test.ts"],maxWorkers:1,fileParallelism:false,retry:0}};

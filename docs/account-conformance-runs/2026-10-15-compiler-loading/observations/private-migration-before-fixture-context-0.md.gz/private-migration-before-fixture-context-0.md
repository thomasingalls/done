# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: rehearsal.spec.ts >> saved files, renderer death, resumed selection and ordinary editor cold recovery preserve the ledger
- Location: test/private-migration/rehearsal.spec.ts:204:1

# Error details

```
Test timeout of 90000ms exceeded.
```

```
Error: locator.fill: Test timeout of 90000ms exceeded.
Call log:
  - waiting for getByLabel('Device-lock code', { exact: true })

```

# Page snapshot

```yaml
- main [ref=f1e3]:
  - generic:
    - complementary:
      - generic: done
      - generic: Today
      - generic: Yesterday
      - generic: Tomorrow
      - generic: Your space, at your pace.
    - generic:
      - generic: Today
      - generic:
        - generic:
          - generic:
            - text: Next
            - generic: 2 / 3
          - generic:
            - generic:
              - generic: Make a little room for the big idea
              - generic:
                - text: Done
                - generic: Later
            - generic:
              - generic: Take the long way home
              - generic:
                - text: Done
                - generic: Later
        - generic:
          - generic: Done
          - generic:
            - generic: Got the idea out of my head
            - generic: Sent the message I was putting off
            - generic: Made time for a walk
          - generic:
            - text: What got done?
            - generic: +
    - complementary:
      - generic: Goals
      - generic:
        - strong: A little space for everything
        - generic: Ideas, plans, loose ends.
        - generic: Things to come back to.
        - strong: Make something of my own
        - generic: Write down the spark
        - generic: Find one small place to start
        - generic: Share a first draft
        - strong: Outside of work
        - generic: Learn to make really good bread
        - generic: Plan a weekend with no plans
        - generic: More dinners with friends
  - generic [ref=f1e4]:
    - text: done
    - heading "Unlock your workspace" [level=1] [ref=f1e5]
    - paragraph [ref=f1e6]: Enter your unlock code to open the writing saved in this browser.
    - generic [ref=f1e7]:
      - generic [ref=f1e8]: Unlock code
      - textbox "Unlock code" [ref=f1e9]
      - button "Unlock" [ref=f1e10] [cursor=pointer]
    - button "Remove from this device" [ref=f1e11] [cursor=pointer]
    - button "Use another account" [ref=f1e12] [cursor=pointer]
```

# Test source

```ts
  145 |   const code = await confirm(page);
  146 |   await phase(page, 'authenticated');
  147 |   await finishImport(page);
  148 |   const before = await census(page);
  149 |   await page.getByRole('button', { name: 'Open Local editor' }).click();
  150 |   await page.getByLabel('Device-lock code', { exact: true }).fill(code);
  151 |   await page.getByRole('button', { name: 'Unlock', exact: true }).click();
  152 |   const master = page.locator('.goals .cm-content');
  153 |   await master.click();
  154 |   await master.press('ControlOrMeta+End');
  155 |   await page.keyboard.insertText('Later writing survives the cleanup helper');
  156 |   await expect(master).toContainText('Later writing survives the cleanup helper');
  157 |   await page.getByRole('button', { name: 'Lock workspace' }).click();
  158 |   await expect(page.locator('.local-startup')).toHaveAttribute('data-state', 'unlock-required');
  159 |   const modernJournals = await page.evaluate(
  160 |     (sourceKeys) =>
  161 |       Object.fromEntries(
  162 |         Object.entries(localStorage).filter(
  163 |           ([key]) => key.startsWith('done.pending-update.done.') && !sourceKeys.includes(key),
  164 |         ),
  165 |       ),
  166 |     Object.keys(before.local),
  167 |   );
  168 |   await page.addScriptTag({ content: helper });
  169 |   const dialog = page.locator('#done-private-cleanup');
  170 |   await dialog.getByLabel('Recovery packet').setInputFiles(files.packet);
  171 |   await dialog.getByLabel('Saved binding').setInputFiles(files.binding);
  172 |   await dialog.getByLabel('Device-lock code').fill('wrong code');
  173 |   await dialog.getByRole('button', { name: 'Clean up source' }).click();
  174 |   await expect(dialog.getByRole('button', { name: 'Clean up source' })).toBeEnabled();
  175 |   expect(await census(page)).toEqual(before);
  176 |   await dialog.getByLabel('Device-lock code').fill(code);
  177 |   await dialog.getByRole('button', { name: 'Clean up source' }).click();
  178 |   await expect(dialog.getByRole('status')).toContainText('Source cleanup complete');
  179 |   expect(
  180 |     await page.evaluate(async () => (await indexedDB.databases()).some((db) => db.name === 'done')),
  181 |   ).toBe(false);
  182 |   expect(
  183 |     await page.evaluate(
  184 |       (keys) => keys.every((key) => localStorage.getItem(key) === null),
  185 |       Object.keys(before.local),
  186 |     ),
  187 |   ).toBe(true);
  188 |   expect(
  189 |     await page.evaluate(
  190 |       (keys) => Object.fromEntries(keys.map((key) => [key, localStorage.getItem(key)])),
  191 |       Object.keys(modernJournals),
  192 |     ),
  193 |   ).toEqual(modernJournals);
  194 |   await dialog.getByRole('button', { name: 'Close', exact: true }).click();
  195 |   await page.reload();
  196 |   await page.getByLabel('Device-lock code', { exact: true }).fill(code);
  197 |   await page.getByRole('button', { name: 'Unlock', exact: true }).click();
  198 |   await expect(page.locator('.goals .cm-content')).toContainText(
  199 |     'Later writing survives the cleanup helper',
  200 |   );
  201 |   await expect(page.locator('.goals .cm-content')).toContainText('journal-only ✔');
  202 | });
  203 | 
  204 | test('saved files, renderer death, resumed selection and ordinary editor cold recovery preserve the ledger', async ({
  205 |   page,
  206 |   context,
  207 | }, info) => {
  208 |   const errors: string[] = [];
  209 |   page.on('pageerror', (error) => errors.push(error.message));
  210 |   await seed(page);
  211 |   const before = await census(page);
  212 |   const files = await capture(page, info);
  213 |   const preview = unzip(files.preview);
  214 |   // The external input-string oracle never reads the Y.Doc or either produced archive.
  215 |   const ledger: { path: string; content: string }[] = JSON.parse(
  216 |     execFileSync(
  217 |       'node',
  218 |       [
  219 |         '--input-type=module',
  220 |         '-e',
  221 |         "import {expected} from './scripts/legacy-export/oracle.mjs'; process.stdout.write(JSON.stringify(expected(JSON.parse(process.argv[1]))));",
  222 |         JSON.stringify(source),
  223 |       ],
  224 |       { encoding: 'utf8' },
  225 |     ),
  226 |   );
  227 |   expect(preview).toEqual(ledger);
  228 |   await load(page, files);
  229 |   const code = await confirm(page);
  230 |   await phase(page, 'authenticated');
  231 |   await expect(page.getByRole('button', { name: 'Continue import' })).toBeVisible();
  232 |   const cdp = await context.newCDPSession(page);
  233 |   const crashed = page.waitForEvent('crash', { timeout: 10_000 });
  234 |   // A crashed renderer cannot reply to this command. Observe the independent crash event.
  235 |   void cdp.send('Page.crash').catch(() => {});
  236 |   await crashed;
  237 |   await page.close();
  238 |   const reopened = await context.newPage();
  239 |   reopened.on('pageerror', (error) => errors.push(error.message));
  240 |   await resume(reopened, files, code);
  241 |   await finishImport(reopened);
  242 |   expect(await census(reopened)).toEqual(before);
  243 |   await reopened.getByRole('button', { name: 'Open Local editor' }).click();
  244 |   await expect(reopened.locator('.local-startup')).toHaveAttribute('data-state', 'unlock-required');
> 245 |   await reopened.getByLabel('Device-lock code', { exact: true }).fill(code);
      |                                                                  ^ Error: locator.fill: Test timeout of 90000ms exceeded.
  246 |   await reopened.getByRole('button', { name: 'Unlock', exact: true }).click();
  247 |   await expect(reopened.locator('.goals .cm-content')).toContainText('journal-only ✔');
  248 |   await reopened.getByLabel('Go to date', { exact: true }).fill('2026-01-02');
  249 |   await expect(
  250 |     reopened.locator('.day-panel[data-active="true"] .collection[data-section="next"] .card'),
  251 |   ).toHaveCount(4);
  252 |   await expect(reopened.locator('.day-panel[data-active="true"]')).toHaveAttribute(
  253 |     'data-frozen',
  254 |     'true',
  255 |   );
  256 |   const output = info.outputPath('destination.zip');
  257 |   await save(reopened, 'Export markdown', output);
  258 |   const exported = unzip(output);
  259 |   expect(exported.filter((e) => e.path !== 'unfiled.md')).toEqual(
  260 |     ledger.filter((e) => e.path !== 'unfiled.md'),
  261 |   );
  262 |   expect(exported.find((e) => e.path === 'unfiled.md')?.content.split('\n\n## Provenance')[0]).toBe(
  263 |     ledger.find((e) => e.path === 'unfiled.md')?.content.split('\n\n## Provenance')[0],
  264 |   );
  265 |   const master = reopened.locator('.goals .cm-content');
  266 |   await master.click();
  267 |   await master.press('ControlOrMeta+End');
  268 |   await reopened.keyboard.insertText('Later accepted edit');
  269 |   await expect(master).toContainText('Later accepted edit');
  270 |   await reopened.getByRole('button', { name: 'Lock workspace' }).click();
  271 |   await expect(reopened.locator('.cm-editor')).toHaveCount(0);
  272 |   await reopened.reload();
  273 |   await reopened.getByLabel('Device-lock code', { exact: true }).fill(code);
  274 |   await reopened.getByRole('button', { name: 'Unlock', exact: true }).click();
  275 |   await expect(reopened.locator('.goals .cm-content')).toContainText('Later accepted edit');
  276 |   expect(await census(reopened)).toEqual(before);
  277 |   expect(errors).toEqual([]);
  278 |   await info.attach('source-input', {
  279 |     body: JSON.stringify(source),
  280 |     contentType: 'application/json',
  281 |   });
  282 |   await info.attach('source-preservation', {
  283 |     body: JSON.stringify(before),
  284 |     contentType: 'application/json',
  285 |   });
  286 |   await reopened.close();
  287 | });
  288 | 
  289 | test('wrong saved digest and origin refuse before enrollment; source drift refuses first intent', async ({
  290 |   page,
  291 | }, info) => {
  292 |   await seed(page);
  293 |   const files = await capture(page, info);
  294 |   const original = JSON.parse(await readFile(files.binding, 'utf8'));
  295 |   const before = await census(page);
  296 |   for (const patch of [
  297 |     { recoveryDigest: '0'.repeat(64) },
  298 |     { sourceOrigin: 'https://different.invalid' },
  299 |   ]) {
  300 |     const altered = info.outputPath('altered-binding.json');
  301 |     await writeFile(altered, JSON.stringify({ ...original, ...patch }));
  302 |     await load(page, { ...files, binding: altered });
  303 |     await expect(page.getByRole('alert')).toBeVisible();
  304 |     await expect(page.getByRole('button', { name: 'Generate device-lock code' })).toHaveCount(0);
  305 |     expect(await census(page)).toEqual(before);
  306 |   }
  307 |   await load(page, files);
  308 |   await phase(page, 'verified');
  309 |   await page.evaluate(() => localStorage.setItem('done.actor', 'source changed after capture'));
  310 |   await confirm(page);
  311 |   await expect(page.getByRole('alert')).toContainText('migration-source-changed');
  312 |   const databases = await page.evaluate(async () =>
  313 |     (await indexedDB.databases()).map((db) => db.name),
  314 |   );
  315 |   expect(databases).toEqual(['done']);
  316 | });
  317 | 
  318 | test('an aborted first content write offers resume with the original factor and retains source', async ({
  319 |   page,
  320 | }, info) => {
  321 |   await seed(page);
  322 |   const before = await census(page);
  323 |   const files = await capture(page, info);
  324 |   await load(page, files);
  325 |   await phase(page, 'verified');
  326 |   await page.evaluate(() => {
  327 |     let once = true;
  328 |     const add = IDBObjectStore.prototype.add;
  329 |     IDBObjectStore.prototype.add = function (value, key) {
  330 |       const r = add.call(this, value, key);
  331 |       if (once && this.name === 'content') {
  332 |         once = false;
  333 |         r.addEventListener('success', () => {
  334 |           this.transaction.abort();
  335 |           Object.assign(window, { migrationAbortObserved: true });
  336 |         });
  337 |       }
  338 |       return r;
  339 |     };
  340 |   });
  341 |   const code = await confirm(page);
  342 |   await expect(page.getByRole('alert')).toBeVisible();
  343 |   expect(await page.evaluate(() => 'migrationAbortObserved' in window)).toBe(true);
  344 |   await expect(page.getByRole('button', { name: 'Generate device-lock code' })).toHaveCount(0);
  345 |   await resume(page, files, code);
```
# F-17: residual preparation profile

Prospective follow-up at signed `1fd04afa`, after complete-comparison and detached-fork repairs.
The application budget remains failed on CPU-4x Android card typing at 69.4 ms; desktop met its
bound at 15.2 ms in the last observation. Both private drafts and deep undo-history copying remain.
This phase identifies the next bounded target. Do not assume that the earlier profile's cost split
still applies to the revised runtime.

## Browser observation

Run the existing owned `browser-latency-diagnosis` selection unchanged, alone. Its fixed design in
[latency-diagnosis.md](./latency-diagnosis.md) still governs: two reverse-order blocks of 120 trusted
keys on textarea, bare CodeMirror and admitted card; separate 60-key typing and ten-cycle focus
profiles; exact sample/text checks and cold reopen. Keep all raw samples, source maps, profiles and
process receipts. This repeat is justified by the production changes since the first profile,
not by a search for passing timings. It does not replace the unchanged application budget gate.

Inspect active stacks within private preparation, `forkWorkspaceHistory`, detached document
construction, metadata/selection copying, complete comparison and UI publication. Sum sampled
inclusive time per relevant stack without adding nested totals. Attribution is descriptive and
includes profiler perturbation; it does not identify a causal speedup or per-key quantile. If
mapped samples do not distinguish the candidate costs, retain that uncertainty and use the Node
probe below before choosing an implementation change.

## Controlled history-scaling probe

Use the signed runtime, with no product changes. Hold the document and mutation history fixed
within a pair; compare a document-only fork and a full history fork. Vary human undo depth over
0, 100 and 1,000 distinct groups. Use the same fixed visible master text and deterministic edits
for each history, and record actual integrated item count, encoded bytes, undo/redo depth and
metadata entries so history growth is not silently treated as fixed document complexity.

At each depth include metadata absent and before/after selection metadata with 1 and 100 target
entries per group. These are declared diagnostic stress strata, not a claimed distribution of
personal workspaces. Metadata uses the production relative-selection shape. Record five warmups
and twenty alternating document/history pairs, with correctness checks and disposal outside timing.
Report medians and retained sample ranges. These dependent observations share host/JIT/GC state;
no population confidence interval, significance test or universal performance claim follows.

The unit of observation is a fork; the analysis unit is a fixed history/metadata stratum on this
host. Varying metadata at a fixed document/history state can localize copying cost, but subtracting
medians is not a per-command causal estimate. A full history fork also restores redone links and
copies deletion sets; retain those confounds. No concurrent tests/profiles during timing. Stop at
the declared counts, retain negative/mixed results and do not resample for a desired answer.

## Decision and scope

Choose a follow-up implementation only when browser attribution and controlled scaling identify
useful avoidable work. Prefer a repair that keeps private staging, source/destination metadata
isolation, human undo/redo, refused-input behavior and full per-transition verification. Define
its semantic oracle and a mutation control before changing production code. If duplicate drafts
are the target, specify the ownership and verification handoff before removing either one.

This phase produces evidence and a concrete next design, not an optimization or a new performance
pass. It cannot establish physical-device capacity, deep-history product limits, Account release
readiness or immutable qualification. The personal browser, package, server and deployment remain
untouched. Preserve append-only records and signed intermediate commits; stop if signing blocks.

import { build } from '<repo>/node_modules/vite/dist/node/index.js';
import { writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { cpus, release } from 'node:os';
import assert from 'node:assert/strict';
const root = process.cwd();
const moduleSource = `export * from '${root}/src/crdt/yjs.ts'; export {relativeSelection} from '${root}/src/crdt/workspaceCommands.ts';`;
const built = await build({
  configFile: false, logLevel: 'error',
  plugins: [{ name: 'history-probe', resolveId(id) { if (id === 'history-probe' || id.endsWith('/history-probe')) return '\0history-probe'; }, load(id) { if (id === '\0history-probe') return moduleSource; } }],
  build: { write: false, minify: false, lib: { entry: 'history-probe', name: 'Product', formats: ['iife'] } },
});
const code = (Array.isArray(built) ? built[0] : built).output.find(o => o.type === 'chunk').code;
const h = Function(code + ';return Product;')();
const rows = [], visibleLength = 100000;
for (const groups of [0, 100, 1000]) {
  const doc = new h.Y.Doc({ gc: false });
  doc.clientID = 117;
  const text = doc.getText('master');
  text.insert(0, 'x'.repeat(visibleLength));
  const history = h.workspaceUndo(doc, 'human');
  for (let group = 0; group < groups; group++) {
    history.stopCapturing();
    // Deliberately retain distinct edit groups at fixed visible length; item count is recorded.
    doc.transact(() => { const at = group * 97 % visibleLength; text.delete(at, 1); text.insert(at, String.fromCharCode(65 + group % 26)); }, 'human');
  }
  assert.equal(history.undoStack.length, groups);
  assert.equal(text.length, visibleLength);
  const encoded = h.Y.encodeStateAsUpdate(doc);
  const items = [...doc.store.clients.values()].reduce((n, rows) => n + rows.length, 0);
  const redone = [...doc.store.clients.values()].flat().filter(item => item instanceof h.Y.Item && item.redone).length;
  try {
    for (const targets of [0, 1, 100]) {
      for (const [index, item] of history.undoStack.entries()) {
        item.meta.clear();
        if (targets) {
          const positions = new Map();
          for (let target = 0; target < targets; target++) {
            const at = (index * 97 + target) % visibleLength;
            positions.set(target ? 'card:diagnostic-' + target : 'master', h.relativeSelection(text, {ranges:[{anchor:at,head:at+1}],main:0}));
          }
          // Production before/after values are separately captured, not shared across groups.
          item.meta.set('before', structuredClone(positions));
          item.meta.set('after', structuredClone(positions));
        }
      }
      const make = variant => variant === 'document' ? h.forkDoc(doc, false) : h.forkWorkspaceHistory(history, 'human');
      const verifyAndDispose = (copy, variant) => {
        const forked = variant === 'document' ? copy : copy.doc;
        try {
          assert.deepEqual(h.Y.encodeStateAsUpdate(forked), encoded);
          assert.equal(forked.getText('master').toString(), text.toString());
          if (variant === 'history') {
            assert.equal(copy.undoStack.length, groups);
            assert.equal(copy.redoStack.length, 0);
            for (const i of new Set([0, Math.max(0, groups - 1)])) if (groups) assert.deepEqual(copy.undoStack[i].meta, history.undoStack[i].meta);
          }
        } finally {
          if (variant === 'history') copy.destroy();
          forked.destroy();
        }
      };
      for (let warm = 0; warm < 5; warm++) for (const variant of ['document','history']) verifyAndDispose(make(variant),variant);
      const samples = [];
      for (let block = 0; block < 20; block++) for (const variant of (block % 2 ? ['history','document'] : ['document','history'])) {
        const at = performance.now(), copy = make(variant), ms = performance.now() - at;
        verifyAndDispose(copy, variant);
        samples.push({block,variant,ms});
      }
      rows.push({groups,targetsPerSelection:targets,selectionEntries:groups*targets*2,visibleChars:visibleLength,items,encodedBytes:encoded.length,undo:history.undoStack.length,redo:history.redoStack.length,redone,sourceStateSha256:createHash('sha256').update(encoded).digest('hex'),samples});
      console.log('Completed history stratum', groups, targets);
    }
  } finally {history.destroy();doc.destroy();encoded.fill(0);}
}
writeFileSync(process.argv[2], JSON.stringify({base:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),bundleSha256:createHash('sha256').update(code).digest('hex'),node:process.version,cpu:cpus()[0].model,os:release(),design:'Nine declared history/metadata strata, five warmups per variant, twenty alternating document/history pairs; correctness and disposal outside timing; fixed visible length, measured item growth; metadata target keys share the master text basis to isolate metadata size at fixed document content.',rows}, null, 2)+'\n');

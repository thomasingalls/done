"""Derive descriptive summaries; retained case attachments are the source of browser evidence."""
from pathlib import Path
import json,gzip,base64,hashlib,collections,statistics,sys
raw=Path(sys.argv[1]); probe=Path(sys.argv[2]); out=Path(sys.argv[3])
sha=lambda b:hashlib.sha256(b).hexdigest()
cases_file=next(raw.glob('stages/*/cases.json'))
cases=json.loads(cases_file.read_text());assert cases['status']=='passed' and len(cases['cases'])==4
measurements=[json.loads(s) for s in next(raw.glob('stages/*/measurements.jsonl')).read_text().splitlines()]
assert len(measurements)==12 and all(m['samples']==120 for m in measurements)
# Exact source-map entry locations at signed 1fd04afa; node names in the build are minified.
entries={
 'prepareIntent':('src/crdt/admissionDocument.ts',28),
 'workspacePrepare':('src/crdt/admittedWorkspace.ts',162),
 'forkWorkspaceHistory':('src/crdt/yjs.ts',486),
 'forkDoc':('src/crdt/yjs.ts',101),
 'copyStack':('src/crdt/yjs.ts',514),
 'stackItemConstruction':('src/crdt/yjs.ts',515),
 'copyDeleteSet':('src/crdt/yjs.ts',505),
 'sameDocState':('src/crdt/yjs.ts',222),
 'publicationListeners':('src/crdt/admittedWorkspace.ts',277),
 'mountEditor':('src/editor/admittedEditor.ts',18),
}
profiles=[];timings=0
for case in cases['cases']:
 assert case['status']=='passed' and case['retry']==0
 for a in case['attachments']:
  body=base64.b64decode(a['base64']);assert len(body)==a['size'] and sha(body)==a['sha256']
  if a['name'].endswith('.cpuprofile.json.gz'):
   p=json.loads(gzip.decompress(body));nodes={n['id']:n for n in p['mapped']};parents={}
   for n in p['mapped']:
    for child in n['children']:
     assert child not in parents;parents[child]=n['id']
   assert len(p['raw']['samples'])==len(p['raw']['timeDeltas'])
   rawself=collections.Counter()
   for ident,us in zip(p['raw']['samples'],p['raw']['timeDeltas']):rawself[ident]+=us
   assert all(n['selfUs']==rawself[n['id']] for n in p['mapped'])
   def location(n):return (n.get('source','').split('/checkout/')[-1],n.get('line'))
   totals=collections.Counter();own=collections.Counter();sourceTotals=collections.Counter();sourceSelf=collections.Counter()
   for node in p['mapped']:
    ident=node['id'];seen=set();matched=set();sourceKeys=set()
    while ident is not None:
     assert ident not in seen;seen.add(ident);n=nodes[ident];loc=location(n)
     matched.update(label for label,entry in entries.items() if loc==entry)
     if loc[0].startswith('src/'):sourceKeys.add((*loc,n['function']))
     ident=parents.get(ident)
    # Inclusive categories may overlap, but each sampled leaf contributes only once per category.
    for label in matched:totals[label]+=node['selfUs']
    for key in sourceKeys:sourceTotals[key]+=node['selfUs']
    for label,entry in entries.items():
     if location(node)==entry:own[label]+=node['selfUs']
    if location(node)[0].startswith('src/'):sourceSelf[(*location(node),node['function'])]+=node['selfUs']
    if 'forkDoc' in matched:
     totals['historyDocumentFork' if 'forkWorkspaceHistory' in matched else 'admissionDocumentFork']+=node['selfUs']
   profiles.append({'project':p['project'],'label':p['label'],'attachmentSha256':sha(body),'intervalUs':p['intervalUs'],'samples':len(p['raw']['samples']),'sampledWindowUs':sum(p['raw']['timeDeltas']),'inclusiveUs':dict(totals),'ownUs':dict(own),'sourceFunctions':[{'source':key[0],'line':key[1],'function':key[2],'inclusiveUs':us,'ownUs':sourceSelf[key]} for key,us in sourceTotals.most_common()]})
  elif a['name'].endswith('.json'):
   p=json.loads(body)
   if 'samples' in p and isinstance(p['samples'],list):timings+=len(p['samples'])
assert len(profiles)==4 and timings==1440
scaling=json.loads(probe.read_text());assert len(scaling['rows'])==9
rows=[]
for row in scaling['rows']:
 assert len(row['samples'])==40
 summaries={}
 for variant in ['document','history']:
  s=[a['ms'] for a in row['samples'] if a['variant']==variant];assert len(s)==20
  summaries[variant]={'medianMs':statistics.median(s),'minMs':min(s),'maxMs':max(s),'count':len(s)}
 rows.append({**{k:v for k,v in row.items() if k!='samples'},'summaries':summaries})
result={'rawOutput':str(raw),'casesSha256':sha(cases_file.read_bytes()),'probeSha256':sha(probe.read_bytes()),'definition':'Each leaf contributes its sampled time once per matching ancestor category. Inclusive categories overlap; do not add them. Own time at a mapped callback does not isolate native structuredClone from other inline work. Source-map entries are tied to the signed baseline. CPU samples describe separate 60-key typing or ten-cycle focus windows, not input quantiles.','entryLocations':entries,'cases':4,'rawTimingCount':timings,'measurements':measurements,'profiles':profiles,'historyProbe':{k:v for k,v in scaling.items() if k!='rows'},'historyRows':rows}
out.write_text(json.dumps(result,indent=2)+'\n')
for p in profiles:
 print(p['project'],p['label'],{k:round(v/1000,1) for k,v in p['inclusiveUs'].items()})
for row in rows:print(row['groups'],row['targetsPerSelection'],{v:{k:round(x,3) if isinstance(x,float) else x for k,x in d.items()} for v,d in row['summaries'].items()})

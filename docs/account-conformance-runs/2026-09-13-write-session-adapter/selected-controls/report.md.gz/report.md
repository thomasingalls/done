# Encrypted-store conformance execution

Scope: C04-component-browser; candidates: write-session. Exit: 0.

Run: 2026-09-13T13:54:04.127Z · harness 2c5f4b95d21b165ad2610d8ddf5b09ff0319eade (working-tree changes)

Subcase passes establish only the named oracle. Remaining obligations prevent a whole-contract pass.

| Scenario | write-session |
| --- | --- |
| C04.freeze-barrier | pass |
| C04.drain-cleanup | pass |
| C04.detached-work | pass |
| C04.stale-task | pass |

Mutation controls:
- split-coordination-domain: detected (frozen-writer-blocks-exclusive)
- ignore-session-invalidation: detected (closing-callback-cannot-write)
- release-before-drain: detected (detached-work-precedes-disposal)
- skip-cache-cleanup: detected (cache-cleared-before-exclusive)
- reuse-finished-task: detected (finished-task-cannot-write)

Detailed assertions, fault schedules, source/adapter hashes, browser version and storage inventories are in report.json and the per-case artifacts.

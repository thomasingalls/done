# Encrypted-store conformance execution

Scope: custody-component-browser; candidates: custody. Exit: 0.

Run: 2026-09-13T13:54:12.852Z · harness 2c5f4b95d21b165ad2610d8ddf5b09ff0319eade (working-tree changes)

Subcase passes establish only the named oracle. Remaining obligations prevent a whole-contract pass.

| Scenario | custody |
| --- | --- |
| C12.session-lifetime | pass |
| C12.cancel-crypto | pass |

Mutation controls:
- skip-nested-crypto-guard: detected (cancel-prevents-private-export)

Detailed assertions, fault schedules, source/adapter hashes, browser version and storage inventories are in report.json and the per-case artifacts.

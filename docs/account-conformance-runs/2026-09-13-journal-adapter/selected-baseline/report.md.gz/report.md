# Encrypted-store conformance execution

Scope: journal-carrier-browser; candidates: journal. Exit: 0.

Run: 2026-09-13T10:05:08.933Z · harness b9f09847a2790f10f86be9c05f6de26ee4b91738 (working-tree changes)

Subcase passes establish only the named oracle. Remaining obligations prevent a whole-contract pass.

| Scenario | journal |
| --- | --- |
| C01.handoff-race | pass |

Mutation controls:

Detailed assertions, fault schedules, source/adapter hashes, browser version and storage inventories are in report.json and the per-case artifacts.

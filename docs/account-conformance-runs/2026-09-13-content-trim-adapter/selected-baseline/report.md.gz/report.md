# Encrypted-store conformance execution

Scope: content-trim-browser; candidates: trim. Exit: 0.

Run: 2026-09-13T13:31:01.815Z · harness f1926f960e32c6a96358f193e551d29352c0b261 (working-tree changes)

Subcase passes establish only the named oracle. Remaining obligations prevent a whole-contract pass.

| Scenario | trim |
| --- | --- |
| T13.kill-publication | pass |

Mutation controls:

Detailed assertions, fault schedules, source/adapter hashes, browser version and storage inventories are in report.json and the per-case artifacts.

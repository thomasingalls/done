import assert from 'node:assert/strict';
import { isDeepStrictEqual } from 'node:util';
import { pathToFileURL } from 'node:url';
const { encodeEvidence, validateEvidence } = await import(pathToFileURL(process.cwd() + '/scripts/release-validation/assertion-evidence.mjs'));
const initial = { seals: [{ ct: new Uint8Array([0, 128, 255]) }], mac: new Uint8Array([7, 8]) };
const encode = (v) => JSON.parse(JSON.stringify(encodeEvidence(v)));
try {
 const left = encode(initial), same = encode(structuredClone(initial));
 validateEvidence(left);assert.deepEqual(left, same);
 const changed = structuredClone(initial);changed.mac[0] ^= 1;
 assert.equal(isDeepStrictEqual(left, encode(changed)), false);
 assert.notDeepEqual(encode(new Uint8Array([0, 128, 255])), encode([0, 128, 255]));
 console.log('passed: nested Uint8Array identity survives JSON; changed bytes and arrays remain distinct');
} catch (e) { console.error(e); process.exitCode = 1; }

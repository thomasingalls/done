# Encrypted-store conformance execution

Scope: local-genesis-browser; candidates: genesis. Exit: running.

Run: 2026-09-13T12:04:03.802Z · harness 6348b6cc93ca99f9703561c094eb779510e5bade (working-tree changes)

Subcase passes establish only the named oracle. Remaining obligations prevent a whole-contract pass.

| Scenario | genesis |
| --- | --- |
| G01.confirm | pass |

Mutation controls:

Detailed assertions, fault schedules, source/adapter hashes, browser version and storage inventories are in report.json and the per-case artifacts.

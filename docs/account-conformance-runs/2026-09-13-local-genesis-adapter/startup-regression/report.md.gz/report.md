# Encrypted-store conformance execution

Scope: owned-startup-browser; candidates: startup. Exit: 0.

Run: 2026-09-13T12:09:31.216Z · harness 6348b6cc93ca99f9703561c094eb779510e5bade (working-tree changes)

Subcase passes establish only the named oracle. Remaining obligations prevent a whole-contract pass.

| Scenario | startup |
| --- | --- |
| O11.recheck | pass |
| O12.replay | pass |

Mutation controls:
- skip-open-classification: detected (open-rechecks-after-grant)

Detailed assertions, fault schedules, source/adapter hashes, browser version and storage inventories are in report.json and the per-case artifacts.

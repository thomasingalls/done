# Encrypted-store conformance execution

Scope: local-clear-browser; candidates: clear. Exit: 0.

Run: 2026-09-13T13:23:26.083Z · harness be5d6a0f8b7dc5fddbc455e121a7d805460b0cda (working-tree changes)

Subcase passes establish only the named oracle. Remaining obligations prevent a whole-contract pass.

| Scenario | clear |
| --- | --- |
| L02.blocked | pass |
| L03.refused | pass |
| L13.factor | pass |
| L14.guards | pass |

Mutation controls:
- blocked-as-success: detected (blocked-delete-not-complete)
- journal-before-content: detected (delete-refusal-keeps-journal)
- skip-resume-authentication: detected (wrong-factor-cannot-finish-keyless-clear)
- allow-component-open: detected (component-refuses-before-key-access)

Detailed assertions, fault schedules, source/adapter hashes, browser version and storage inventories are in report.json and the per-case artifacts.

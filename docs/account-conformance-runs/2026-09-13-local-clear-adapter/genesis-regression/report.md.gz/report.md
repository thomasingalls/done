# Encrypted-store conformance execution

Scope: local-genesis-browser; candidates: genesis. Exit: 0.

Run: 2026-09-13T13:23:34.756Z · harness be5d6a0f8b7dc5fddbc455e121a7d805460b0cda (working-tree changes)

Subcase passes establish only the named oracle. Remaining obligations prevent a whole-contract pass.

| Scenario | genesis |
| --- | --- |
| G03.kill-claim | pass |
| G15.auth | pass |

Mutation controls:
- skip-progress-authentication: detected (damaged-progress-refuses)

Detailed assertions, fault schedules, source/adapter hashes, browser version and storage inventories are in report.json and the per-case artifacts.

from pathlib import Path
import json,difflib
root=Path.cwd();out=Path('<tmp>/done-f17-local-handoff');path='src/crdt/admissionQueue.ts';s=(root/path).read_text()
cases=[
('skip-adoption-comparison','sameDocState(canonical, prepared.state.history.doc)','true','Local post-promotion mismatch closes before publication and cannot be retried','promise resolved'),
('erase-leased-write','if (job.preparation) return;','/* fault: erase even leased prepared buffers */','Local leases preserve an in-flight write through close without late publication','write must not observe erased handoff bytes')]
rows=[]
for name,old,new,title,marker in cases:
 assert s.count(old)==1,(name,s.count(old))
 (out/(name+'.patch')).write_text(''.join(difflib.unified_diff(s.splitlines(True),s.replace(old,new).splitlines(True),fromfile='a/'+path,tofile='b/'+path)))
 (out/(name+'.config.mts')).write_text('import base from '+json.dumps(str(root/'vite.config.ts'))+';\nexport default {...base,root:'+json.dumps(str(root))+',plugins:[...base.plugins,{name:'+json.dumps(name)+',enforce:"pre",transform(code,id){if(!id.endsWith('+json.dumps('/'+path)+'))return;const from='+json.dumps(old)+';if(code.split(from).length!==2)throw Error("mutation must match exactly once");return code.replace(from,'+json.dumps(new)+');}}],test:{...base.test,include:["test/workspaceAdmission.test.ts"],maxWorkers:1,fileParallelism:false,retry:0}};\n')
 rows.append({'name':name,'title':title,'marker':marker})
(out/'controls.json').write_text(json.dumps(rows,indent=2)+'\n')

from pathlib import Path
import json,subprocess,time
p=Path('<tmp>/done-f17-local-handoff');rows=json.loads((p/'controls.json').read_text());results=[]
for row in rows:
 argv=['node','node_modules/vitest/vitest.mjs','run','--config',str(p/(row['name']+'.config.mts')),'-t',row['title']]
 start=time.monotonic();r=subprocess.run(argv,capture_output=True,timeout=30);b=r.stdout+r.stderr;(p/('control-'+row['name']+'.log')).write_bytes(b)
 results.append({**row,'argv':argv,'exitCode':r.returncode,'elapsedMs':round((time.monotonic()-start)*1000),'intendedFailure':r.returncode==1 and row['marker'] in b.decode()})
 print(row['name'],r.returncode,results[-1]['intendedFailure'],flush=True)
(p/'control-results.json').write_text(json.dumps(results,indent=2)+'\n')
assert all(r['intendedFailure'] for r in results)

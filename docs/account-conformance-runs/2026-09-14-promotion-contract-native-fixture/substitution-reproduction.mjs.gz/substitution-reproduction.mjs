import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {createRequire} from 'node:module';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
const root=process.cwd(), fc=createRequire(root+'/package.json')('fast-check');
const phase=process.argv[2];assert(['before','after'].includes(phase));
const baseline=process.argv[3];if(phase==='before')assert(/^[a-f0-9]{40}$/.test(baseline));
const file='test/account-promotion-contract/native.test.mjs',source=phase==='before'?execFileSync('git',['show',baseline+':'+file],{encoding:'utf8'}):readFileSync(file,'utf8');
const start=source.indexOf('// Change the omitted value after signing:');
const end=source.indexOf('\n            }\n            await PromotionContract.put',start);
assert(start>=0 && end>start);
const body=source.slice(start,end),substitute=Function('signed','p',body);
const exercise=(receiptId,id)=>{
 for(const p of [['pending'],[3],[16,'destination','account','promotionId']]) {
  const signed={id,account:{confirmation:{receiptId}},handoff:{destination:{account:{promotionId:id}}}};
  const original=p[0]==='pending'?receiptId:id;
  substitute(signed,p);
  const result=p[0]==='pending'?signed.account.confirmation.receiptId:p.length===1?signed.id:signed.handoff.destination.account.promotionId;
  assert.notEqual(result,original,'Omitted binding must actually change');
  assert.equal(result.length,original.length,'Keep binding extent');
  assert.match(result,p[0]==='pending'?/^[a-zA-Z0-9_-]{43}$/:/^[0-9a-f]{32}$/,'Keep binding alphabet');
 }
};
const property=fc.property(fc.uint8Array({minLength:32,maxLength:32}),fc.uint8Array({minLength:16,maxLength:16}),(receipt,id)=>{
 const r=Buffer.from(receipt).toString('base64url'),i=Buffer.from(id).toString('hex');
 for(const prefix of ['a','b','0'])exercise(prefix+r.slice(1),prefix+i.slice(1));
});
const checked=fc.check(property,{seed:140902,numRuns:160});
const report={phase,file,sourceSha256:createHash('sha256').update(source).digest('hex'),mutationBody:body,seed:checked.seed,numRuns:checked.numRuns,failed:checked.failed,counterexample:checked.counterexample,counterexamplePath:checked.counterexamplePath,error:checked.errorInstance?String(checked.errorInstance):null};
writeFileSync('/private/tmp/done-promotion-contract-native-fixture-substitution-'+phase+'.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
assert.equal(checked.failed,phase==='before');

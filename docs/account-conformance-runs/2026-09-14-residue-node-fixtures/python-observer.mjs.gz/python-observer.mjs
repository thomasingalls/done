import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {readFileSync,writeFileSync,existsSync,realpathSync} from 'node:fs';
import {dirname,join} from 'node:path';
const env={PATH:dirname(process.execPath)+':/usr/bin:/bin',LANG:'C.UTF-8',TZ:'UTC'};
const code=`import sys,io,zipfile
paths=set()
for module in list(sys.modules.values()):
 for key in ('__file__','__cached__'):
  value=getattr(module,key,None)
  if isinstance(value,str): paths.add(value)
import json
print(json.dumps(dict(executable=sys.executable,version=sys.version,paths=sorted(paths))))`;
const result=JSON.parse(execFileSync('python3',['-c',code],{env,timeout:5000,maxBuffer:2*1024*1024}));
const launch=env.PATH.split(':').map(p=>join(p,'python3')).find(p=>existsSync(p));
const paths=[...new Set([launch,realpathSync(launch),result.executable,realpathSync(result.executable),...result.paths].filter(p=>existsSync(p)))].sort();
const files=paths.map(path=>{const b=readFileSync(path);return {path,bytes:b.length,sha256:createHash('sha256').update(b).digest('hex')}});
writeFileSync(process.argv[2],JSON.stringify({env,launcher:launch,executable:result.executable,version:result.version,files,note:'Observed host ZIP producer and loaded module/cache files. Not part of the general stage frozen Node input identity; OS/shared-library qualification remains separate.'},null,2)+'\n');
console.log(result.version.split('\n')[0],files.length,'file pins');

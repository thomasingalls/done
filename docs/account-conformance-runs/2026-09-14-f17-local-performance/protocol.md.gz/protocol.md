# F-17: Local preparation performance and activation decision

## Prospective protocol

Freeze this protocol and the measurement harness before recording timings. The decision is whether
to activate the private Local preparation handoff by default. Account remains separately gated.
The preceding functional checkpoint passes reference, generated, native and mutation controls;
performance does not substitute for those controls.

Compare three implementations: **B**, all runtime source from signed `0c84e5cc`; **R**, the current
functional checkpoint with `reference`; **C**, that same checkpoint with `local-handoff`. Build B
from a complete signed source snapshot, not a partial substitution of two modules into current code.
Use identical installed dependencies, build settings, identity and seed bytes. Retain source,
dependency, runtime and bundle hashes. The workspace's default opener remains unchanged while testing.

The controlled Node benchmark measures elapsed milliseconds from calling one text insertion to its
accepted promise resolving, including private preparation, memory-carrier append, canonical promotion
and publication. It does not measure encryption, IndexedDB, browser scheduling, rendering or paint.
All three synthetic strata have 100,000 visible master-text characters, constructed as 1,000, 10,000
or 100,000 reverse-inserted Yjs items. These stress strata are not a distribution of personal writing.
Each fresh process creates a new workspace, performs 24 warmup insertions and 64 measured insertions,
each with a distinct command group and one master selection target. History therefore grows from
24 to 88 groups during measurement; this is not a deep-history capacity test. Record actual item
counts, encoded sizes, history depths and every warmup and measurement duration.

Use six blocks with variant orders BRC, RCB, CBR, CRB, RBC and BCR. Rotate item-stratum order by block
over the three cyclic permutations. Each variant/stratum session runs in a fresh Node process; no
other tests, browser runs or profiles run concurrently. Build outside timing. The assignment unit is
the session's implementation, the observation is an accepted command, and the analysis unit is the
paired block within a stratum. Host, JIT, GC and sequential-history dependence preclude treating the
3,456 measured commands as independent experimental replicates. Report six session medians and
nearest-rank p95s per variant/stratum, their medians and paired ratios; do not manufacture population
confidence intervals or physical-device claims from this one host.

Outside timing, check exact text, caret, revision advance and undo depth after each insertion. At
session end check undo/redo, replay all captured durable bytes in a fresh document and compare the
complete canonical state. Assert that only C registered the private handoff and that every insertion
prepared once. Any semantic failure invalidates performance acceptance. Keep partial rows/errors.
Stop at six blocks, or after the fixed 30-minute overall deadline or a session's 120-second deadline.
Do not discard outliers or repeat an unfavorable valid observation. An infrastructure failure may be
diagnosed separately, with the original evidence retained; it is not a passing sample.

For this bounded engineering decision, require C's median paired session-median ratio to be at most
0.90 against **each** of R and B in **both** the 10,000- and 100,000-item strata, and C faster in at
least five of six blocks in each comparison. Ten percent is the prospective minimum worthwhile
whole-command improvement, not a product budget or significance threshold. In every stratum, refuse
activation if C's median or p95 is more than 10% slower than either comparator in four or more blocks.
Apply the same regression guardrail to R versus B: sharing command code must not quietly regress the
default reference. Mixed results mean no activation in this phase, not more sampling.

Regardless of the relative benchmark outcome, run the existing owned
`browser-application-latency` selection once on a disposable candidate snapshot. Its sole runtime
variant adds `local-handoff` to the Local opener; retain that exact patch. Preserve the original
adapter, seven cases per project, desktop/CPU-4x Android projects, production build, corpus,
120 trusted keys, measurement contract, numerical budgets, one worker, zero retries and deadlines.
Capture all measurement artifacts, stdout, case report, receipts and process drain, including failure.
The existing strict typing budget is <16 ms on both projects; all other existing budgets also apply.
No simultaneous profiler and no application-gate rerun to seek a pass. Older application measurements
provide context only; they are not a counterbalanced estimate of this candidate's browser speedup.

Default Local activation requires functional preservation, the relative criteria above, **and** a
fully passing unchanged application gate. If the gate fails, retain the candidate privately and leave
F-17 open. Identify the next bounded decision from the evidence instead of broadening this phase into
another optimization. A pass would authorize only Local activation and its focused regressions, not
Account activation, deployment, physical-device qualification or immutable release qualification.

## Retention and boundaries

Keep a bounded evidence packet (250,000 bytes before any exception), with lossless compressed logs,
raw observations, protocol/harness, hashes and reconstructable source variants. Large duplicate
inputs may use verified references to the preceding functional packet; record raw local output paths
and hashes. Preserve append-only records from their current working-tree bytes, all 52 personal/vector
pins, the historical L-2 section and the preceding functional packet. Personal browser, installed
package, server, routing, recovery files and unrelated root files remain untouched. The 96 command /
63 campaign integration obligations and immutable aggregate are not reduced by this performance work.

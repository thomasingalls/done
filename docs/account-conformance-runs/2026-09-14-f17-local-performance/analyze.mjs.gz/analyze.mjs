import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
const out='/private/tmp/done-f17-local-performance';
const med=a=>{const b=a.toSorted((a,b)=>a-b);return(b[Math.floor((b.length-1)/2)]+b[Math.ceil((b.length-1)/2)])/2;};
const p95=a=>a.toSorted((a,b)=>a-b)[Math.ceil(a.length*.95)-1];
const rows=[];let accepted=true;
for(const items of [1000,10000,100000]){
 const sessions={};
 for(const v of ['B','R','C']){sessions[v]=[];for(let block=0;block<6;block++){
 const r=JSON.parse(readFileSync(out+'/measure-'+block+'-'+items+'-'+v+'.json'));assert.equal(r.status,'passed');assert.equal(r.samples.length,88);
 const ms=r.samples.filter(s=>s.phase==='measured').map(s=>s.ms);assert.equal(ms.length,64);sessions[v].push({block,median:med(ms),p95:p95(ms),seed:r.seed,initial:r.initial,final:r.final});
 }}
 const comparisons=[];
 for(const [a,b]of[['C','R'],['C','B'],['R','B']]){
 const ratios=sessions[a].map((r,i)=>({block:i,median:r.median/sessions[b][i].median,p95:r.p95/sessions[b][i].p95}));
 const ratioMedian=med(ratios.map(r=>r.median)),faster=ratios.filter(r=>r.median<1).length,medianRegressions=ratios.filter(r=>r.median>1.10).length,p95Regressions=ratios.filter(r=>r.p95>1.10).length;
 const guardrail=medianRegressions<4&&p95Regressions<4,benefit=a!=='C'||items===1000||ratioMedian<=.90&&faster>=5;
 accepted&&=guardrail&&benefit;comparisons.push({a,b,ratios,ratioMedian,faster,medianRegressions,p95Regressions,guardrail,benefit});
 }
 rows.push({items,sessions,summary:Object.fromEntries(['B','R','C'].map(v=>[v,{median:med(sessions[v].map(s=>s.median)),p95:med(sessions[v].map(s=>s.p95))}])),comparisons});
}
const result={nodeCriteriaPassed:accepted,applicationGateStillRequired:true,rows};writeFileSync(out+'/analysis.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));

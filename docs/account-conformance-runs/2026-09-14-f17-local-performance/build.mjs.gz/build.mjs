import assert from 'node:assert/strict';
import {build} from '/Users/thomasingalls/.codex/worktrees/c030/done/node_modules/vite/dist/node/index.js';
import {execFileSync} from 'node:child_process';
import {existsSync,mkdirSync,writeFileSync,readFileSync,copyFileSync,symlinkSync} from 'node:fs';
import {join,dirname} from 'node:path';
import {gzipSync} from 'node:zlib';
import {sourcePaths,filePins,dependencyPins,hash,canonical,digest} from '/Users/thomasingalls/.codex/worktrees/c030/done/scripts/release-validation/identity.mjs';
const root=process.cwd(), out='/private/tmp/done-f17-local-performance';
const base=execFileSync('git',['rev-parse','0c84e5cc'],{encoding:'utf8'}).trim();
writeFileSync(join(out,'signature.log'),execFileSync('git',['verify-commit',base],{encoding:'utf8',stdio:['ignore','pipe','pipe']}));
const current=join(out,'current-source'), signed=join(out,'signed-source');
for(const dir of [current,signed])mkdirSync(dir,{recursive:true});
execFileSync('git',['archive','--output='+join(out,'signed.tar'),base]);
execFileSync('tar',['-xf',join(out,'signed.tar'),'-C',signed]);
const sourcePins=filePins(root,sourcePaths(root));
for(const p of sourcePins){if(p.absent)continue;const dest=join(current,p.path);mkdirSync(dirname(dest),{recursive:true});if(p.link){if(!existsSync(dest))symlinkSync(p.link,dest);}else copyFileSync(join(root,p.path),dest);}
for(const dir of [current,signed])if(!existsSync(join(dir,'node_modules')))symlinkSync(join(root,'node_modules'),join(dir,'node_modules'));
const inputs={base,sourcePins,dependencies:dependencyPins(root),protocol:hash(readFileSync(join(root,'docs/f17-local-performance.md'))),build:hash(readFileSync(import.meta.filename)),worker:hash(readFileSync(join(out,'worker.mjs'))),run:hash(readFileSync(join(out,'run.mjs'))),analysis:hash(readFileSync(join(out,'analyze.mjs'))),runtime:{node:process.version,binary:hash(readFileSync(process.execPath))},variants:{}};
for(const v of ['B','R','C']){
 const src=v==='B'?signed:current;
 const source=`export * from '${src}/src/crdt/yjs.ts'; export {createAdmittedWorkspace} from '${src}/src/crdt/admittedWorkspace.ts'; export {createAdmissionOwner} from '${src}/src/crdt/admissionQueue.ts'; ${v==='B'?'export const localWorkspacePreparation = undefined;':`export {localWorkspacePreparation} from '${src}/src/crdt/workspacePreparation.ts';`}`;
 const modules=[];
 const result=await build({root:src,configFile:false,logLevel:'error',plugins:[{name:'benchmark',resolveId(id){if(id==='bench'||id.endsWith('/bench'))return '\0bench';},load(id){if(id==='\0bench')return source;},transform(code,id){if(!id.startsWith('\0'))modules.push({path:id.startsWith(src)?id.slice(src.length+1):id,sha256:hash(code)});}}],build:{write:false,minify:false,target:'es2022',lib:{entry:'bench',name:'Product',formats:['iife']}}});
 const code=(Array.isArray(result)?result[0]:result).output.find(o=>o.type==='chunk').code;
 writeFileSync(join(out,v+'.js'),code);
 inputs.variants[v]={strategy:v==='C'?'local-handoff':'reference',bundle:hash(code),entry:source,modules};
 console.log('Built '+v+': '+code.length+' bytes, '+modules.length+' modules');
}
assert.equal(digest(filePins(root,sourcePaths(root))),digest(sourcePins),'Source drift during build');
writeFileSync(join(out,'inputs.json.gz'),gzipSync(canonical(inputs)+'\n'));
copyFileSync(join(root,'docs/f17-local-performance.md'),join(out,'protocol.md'));
writeFileSync(join(out,'frozen.json'),JSON.stringify({at:new Date().toISOString(),inputsSha256:hash(readFileSync(join(out,'inputs.json.gz'))),protocol:inputs.protocol,build:inputs.build,worker:inputs.worker,run:inputs.run,analysis:inputs.analysis},null,2)+'\n');

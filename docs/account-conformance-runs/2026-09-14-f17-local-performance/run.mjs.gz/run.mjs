import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {cpus,release,loadavg,totalmem} from 'node:os';
const out='/private/tmp/done-f17-local-performance', frozen=JSON.parse(readFileSync(out+'/frozen.json'));
const hash=b=>createHash('sha256').update(b).digest('hex');
for(const f of ['protocol','worker','build','run','analysis']){const name=f==='protocol'?'protocol.md':f==='analysis'?'analyze.mjs':f+'.mjs';assert.equal(hash(readFileSync(out+'/'+name)),frozen[f]);}
const orders=['BRC','RCB','CBR','CRB','RBC','BCR'],strata=[1000,10000,100000],at=Date.now();
const report={startedAt:new Date().toISOString(),frozen,host:{node:process.version,os:release(),cpu:cpus()[0].model,cpus:cpus().length,totalmem:totalmem(),loadavg:loadavg()},orders,sessions:[],status:'running'};
try{for(let block=0;block<orders.length;block++){
 for(let n=0;n<3;n++){const items=strata[(n+block)%3];for(const v of orders[block]){
 assert(Date.now()-at<1800000,'Overall deadline');
 const child=spawnSync(process.execPath,[out+'/worker.mjs',out,v,String(items),String(block)],{encoding:'utf8',timeout:Math.min(120000,1800000-(Date.now()-at)),maxBuffer:1024*1024});
 const log={stdout:child.stdout,stderr:child.stderr,status:child.status,signal:child.signal,error:child.error?.message};writeFileSync(out+'/session-'+block+'-'+items+'-'+v+'.json',JSON.stringify(log,null,2)+'\n');
 assert.equal(child.status,0,JSON.stringify(log));
 report.sessions.push({block,items,v,logFile:'session-'+block+'-'+items+'-'+v+'.json'});writeFileSync(out+'/run.json',JSON.stringify(report,null,2)+'\n');
 }console.log('Completed block '+(block+1)+' / 6, '+items+' items, order '+orders[block]);}
 }report.status='passed';}catch(e){report.status='failed';report.error=String(e.stack??e);report.stdout=e.stdout?.toString();report.stderr=e.stderr?.toString();process.exitCode=1;}finally{report.completedAt=new Date().toISOString();report.hostEnd={loadavg:loadavg()};writeFileSync(out+'/run.json',JSON.stringify(report,null,2)+'\n');console.log(report.status);}

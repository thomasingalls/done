import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const [out,v,itemsArg,blockArg,mode='measure']=process.argv.slice(2), items=Number(itemsArg), block=Number(blockArg);
const code=readFileSync(out+'/'+v+'.js','utf8'), h=Function(code+';return Product;')();
const result={block,variant:v,items,mode,bundleSha256:createHash('sha256').update(code).digest('hex'),samples:[],startedAt:new Date().toISOString(),status:'running'};
let w,seed;
try {
 seed=new h.Y.Doc({gc:false});seed.clientID=12345;
 const t=seed.getText('master');for(let i=0;i<items;i++)t.insert(0,'x'.repeat(100000/items));
 const seedBytes=h.encodeState(seed), disk=[seedBytes.slice()],wal=[],abort=new AbortController();
 result.seed={items:[...seed.store.clients.values()].reduce((n,r)=>n+r.length,0),bytes:seedBytes.length,sha256:createHash('sha256').update(seedBytes).digest('hex')};
 const carrier={state:'active',signal:abort.signal,loadRecovery:async()=>({records:disk.map(bytes=>({kind:'update',bytes:bytes.slice()})),journal:wal.map(bytes=>({bytes:bytes.slice()}))}),appendLocal(bytes){wal.push(bytes.slice());return {status:'journalled'};},async appendBatch(rs){disk.push(...rs.map(r=>r.bytes.slice()));},async flushJournal(){const removed=wal.length;disk.push(...wal.splice(0));return{retained:0,removed};},async close(){abort.abort();}};
 let count=0,handoff=false;
 w=await h.createAdmittedWorkspace(options=>{const local=h.localWorkspacePreparation&&options[h.localWorkspacePreparation];handoff=!!local;assert.equal(handoff,v==='C');return h.createAdmissionOwner(carrier,{...options,prepare(...args){count++;return options.prepare(...args);},...(local?{[h.localWorkspacePreparation]:{...local,command(...args){count++;return local.command(...args);}}}:{})});},{identity:{id:'human',actor:{kind:'human',name:'Test',color:'#3f8fd6'},device:{id:'device',name:'Test'}},validateReceive(){},today:()=> '2026-09-14'},v==='C'?'local-handoff':'reference');
 const surface=w.text({kind:'master'}), initial=w.read();
 const warm=mode==='check'?2:24, measured=mode==='check'?2:64;
 result.initial={undo:initial.undo,redo:initial.redo,revision:w.status.revision,handoff};
 let expected=initial.master;
 const initialRevision=w.status.revision;
 for(let i=0;i<warm+measured;i++){
  const text=String.fromCharCode(97+i%26), priorCount=count;
  let ms=null;
  if(mode==='measure'){
   const at=performance.now();await surface.input({name:'insert',text}).accepted;ms=performance.now()-at;
  }else await surface.input({name:'insert',text}).accepted;
  result.samples.push({index:i,phase:i<warm?'warmup':'measured',ms});
  expected=expected.slice(0,i)+text+expected.slice(i);
  const actual=surface.read();
  assert.equal(actual.text,expected);assert.deepEqual(actual.selection,{ranges:[{anchor:i+1,head:i+1}],main:0});
  assert.equal(w.status.revision,initialRevision+i+1);assert.equal(actual.undo,initial.undo+i+1);assert.equal(actual.redo,0);assert.equal(count,priorCount+1);
 }
 const final=surface.read();result.final={undo:final.undo,redo:final.redo,revision:w.status.revision,preparations:count};
 await surface.input({name:'undo'}).accepted;assert.equal(surface.read().text,expected.slice(0,warm+measured-1)+expected.slice(warm+measured));assert.equal(surface.read().redo,1);
 await surface.input({name:'redo'}).accepted;assert.equal(surface.read().text,expected);assert.equal(surface.read().undo,final.undo);
 const replay=h.createDoc(), canonical=h.createDoc();
 try{for(const bytes of [...disk,...wal])h.applyUpdate(replay,bytes);h.applyUpdate(canonical,w.snapshot());assert(h.sameDocState(replay,canonical));assert.equal(replay.getText('master').toString(),expected);result.final.replayItems=[...replay.store.clients.values()].reduce((n,r)=>n+r.length,0);result.final.replayBytes=h.encodeState(replay).length;}finally{replay.destroy();canonical.destroy();}
 result.status='passed';
}catch(e){result.status='failed';result.error=String(e.stack??e);process.exitCode=1;}
finally{await w?.close();seed?.destroy();result.completedAt=new Date().toISOString();writeFileSync(out+'/'+mode+'-'+block+'-'+items+'-'+v+'.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({block,items,v,mode,status:result.status,error:result.error}));}

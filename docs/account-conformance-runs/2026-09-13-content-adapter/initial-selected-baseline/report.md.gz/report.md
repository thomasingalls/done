# Encrypted-store conformance execution

Scope: content-carrier-browser; candidates: content. Exit: 0.

Run: 2026-09-13T09:40:59.116Z · harness f14c68f51b10105374fe911783185be8246c2be1 (working-tree changes)

Subcase passes establish only the named oracle. Remaining obligations prevent a whole-contract pass.

| Scenario | content |
| --- | --- |
| C09.unreadable-load | pass |

Mutation controls:

Detailed assertions, fault schedules, source/adapter hashes, browser version and storage inventories are in report.json and the per-case artifacts.

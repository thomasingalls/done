import json,time,os,hashlib
from pathlib import Path
prefix='<tmp>/done-residue-generated-fixture-';start=time.time();until=start+400;root=Path(os.environ['TMPDIR']);last=0
while time.time()<until:
 for f in root.glob('done-release-validation-*/checkout/test-results/account-residue-focused/*/generated.json'):
  try:
   if f.stat().st_mtime<start:continue
   first=f.read_bytes();data=json.loads(first)
   h=f.with_name('generated-histories.json');histories=h.read_bytes()
   if first!=f.read_bytes() or histories!=h.read_bytes():continue
   assert len(first)<65536 and len(histories)<65536
   meta=dict(capturedAt=time.time(),observerStartedAt=start,source=str(f),sha256=hashlib.sha256(first).hexdigest(),historySource=str(h),historySha256=hashlib.sha256(histories).hexdigest())
   Path(prefix+'observed-result.json').write_bytes(first);Path(prefix+'observed-histories.json').write_bytes(histories);Path(prefix+'observed-source.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(data),flush=True);raise SystemExit(0)
  except (FileNotFoundError,json.JSONDecodeError):pass
 time.sleep(.1)
raise SystemExit('No final auxiliary generated report observed within 400 seconds')

from pathlib import Path
root=Path.cwd()
def change(name,changes):
 p=root/name;s=p.read_text()
 for before,after,count in changes:
  assert s.count(before)==count,(name,before,s.count(before),count)
  s=s.replace(before,after)
 p.write_text(s)
change('test/local-app/startup.spec.ts',[
 ("const app =", "// Explicit protected startup stays covered for compatible stored workspaces.\n// Current automatic first-run and optional protection use the shipped entries in\n// packaged.spec.ts and packaged-account/welcome.spec.ts.\nconst app =",1),
 ("'/local.html'", "'/test/local-app/protected-startup.html'",4),
 ('Generated device-lock code','Generated unlock code',4),
 ('Device-lock code','Unlock code',7),
])
p=root/'test/local-app/protected-startup.html'
assert not p.exists()
p.write_text('''<!doctype html>
<html lang="en">
  <head><meta charset="utf-8" /><title>Protected startup compatibility fixture</title></head>
  <body>
    <div id="root"></div>
    <script type="module">
      import { createElement } from 'react';
      import { createRoot } from 'react-dom/client';
      import { LocalApp } from '/src/ui/LocalApp';
      import '/src/styles/index.css';
      import '/src/styles/local-startup.css';
      // Exercise the retained explicit-code owner with the real component and storage.
      // This test fixture is not a packaged entry and is not the current first-run UX.
      createRoot(document.getElementById('root')).render(
        createElement(LocalApp, { automaticFirstRun: false }),
      );
    </script>
  </body>
</html>
''')
change('test/local-app/packaged.spec.ts',[
 ("import { expect } from '@playwright/test';", "import { expect } from '@playwright/test';\nimport { protectApp } from '../geometry/openApp';",1),
 ('''    await expect(page.locator('.local-startup')).toHaveAttribute('data-state', 'fresh');
    await page.getByRole('button', { name: 'Create a local-only workspace' }).click();
    const code = (await page.getByLabel('Generated device-lock code').textContent())!;
    await page.getByRole('button', { name: 'I saved my code' }).click();
    await page.getByLabel('Device-lock code', { exact: true }).fill(code);
    await page.getByRole('button', { name: 'Confirm and create' }).click();''',
 '''    await expect(page.locator('.shell[data-local-workspace]')).toBeVisible();
    const code = await protectApp(page);''',1),
 ('Device-lock code','Unlock code',2),
])
change('test/local-app/editor.spec.ts',[
 ("import { openApp, reloadApp }", "import { openApp, reloadApp, protectApp }",1),
 ("  await openApp(page);\n  const content = page.locator('.goals .cm-content');\n  await content.click();\n  await page.keyboard.insertText('accepted');", "  await openApp(page);\n  await protectApp(page);\n  const content = page.locator('.goals .cm-content');\n  await content.click();\n  await page.keyboard.insertText('accepted');",1),
 ("page.getByRole('button', { name: 'Open Goals', exact: true })", "page.locator('.day-panel[data-active=\"true\"] .panel-header').getByRole('button', { name: 'Open Goals', exact: true })",2)
])
change('test/geometry/sync.spec.ts',[
 ('Off. This Local workspace is not connected to a relay.','Saved only in this browser. Sync is off.',1)
])
change('test/local-baseline/reader-first.spec.ts',[
 ("      await d.page.getByRole('button', { name: 'I already have a workspace', exact: true }).click();\n",'',1),
 ("getByLabel('Device-lock code',", "getByLabel('Unlock code',",1)
])

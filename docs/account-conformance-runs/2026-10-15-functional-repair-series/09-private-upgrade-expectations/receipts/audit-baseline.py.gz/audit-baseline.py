from pathlib import Path
import subprocess,json,hashlib
root=Path('<scratch>/done-upgrade-baseline-7dab01cc');sha='7dab01cc413f8657b54c0d308e374632910f0595'
assert subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip()==sha
assert not subprocess.check_output(['git','-C',str(root),'status','--porcelain','--untracked-files=no'],text=True).strip()
rows=subprocess.check_output(['git','-C',str(root),'ls-tree','-r',sha],text=True).splitlines();pins={}
for row in rows:
 attrs,path=row.split('\t',1);mode,kind,oid=attrs.split()
 if kind!='blob' or not (path.split('/')[0] in ['src','account-service','account-protocol','private','scripts','vite','wasm','public'] or path in ['package.json','pnpm-lock.yaml','vite.config.ts','index.html','local.html']):continue
 p=root/path;data=p.read_bytes();actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest();assert actual==oid,(path,oid,actual)
 pins[path]={'gitBlob':oid,'sha256':hashlib.sha256(data).hexdigest()}
pkg=json.loads((root/'package.json').read_text());versions={}
for name,declared in pkg.get('dependencies',{}).items():
 p=root/'node_modules'/name/'package.json';assert p.exists(),name;versions[name]={'declared':declared,'installed':json.loads(p.read_text())['version']}
Path('<scratch>/done-series-phase09/baseline-identity.json').write_text(json.dumps({'revision':sha,'root':str(root),'trackedWorktreeClean':True,'runtimeSourceFiles':pins,'dependencies':versions,'scope':'Original clean source and preserved installed dependencies; current Node/browser, not a historical deployment binary.'},indent=2)+'\n')
print('Verified original schema-five runtime source files:',len(pins))

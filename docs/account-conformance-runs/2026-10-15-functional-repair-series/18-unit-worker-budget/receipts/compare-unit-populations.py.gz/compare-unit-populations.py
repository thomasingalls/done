from pathlib import Path
import json
paths=[Path('<scratch>/done-series-phase17/unit-node24-after-results.json'),Path('<scratch>/done-series-phase18/unit-node24-bounded-results.json'),Path('<scratch>/done-series-phase18/unit-node26-bounded-results.json')]
results=[]
for p in paths:
 if not p.exists():raise SystemExit('Pending: '+str(p))
 r=json.loads(p.read_text());cases={}
 for f in r['testResults']:
  name='test/'+f['name'].split('/test/',1)[1] if '/test/' in f['name'] else 'vite/'+f['name'].split('/vite/',1)[1]
  for t in f['assertionResults']:
   key=name+' :: '+t['fullName'];assert key not in cases;cases[key]=t['status']
 assert len(r['testResults'])==151 and r['numPassedTests']==1779 and r['numPendingTests']==1 and r['numFailedTests']==0
 results.append((p.name,cases))
assert all(c==results[0][1] for _,c in results)
print(json.dumps({'files':151,'cases':len(results[0][1]),'passed':1779,'skipped':[k for k,v in results[0][1].items() if v!='passed'],'caseIdentitiesAndStatusesEqual':True,'reports':[n for n,_ in results]},indent=2))

from pathlib import Path
p=Path('test/first-device-setup/setup.spec.ts');s=p.read_text()
s=s.replace("import { test, expect, type Page } from '@playwright/test';", "import { test, expect, type Page } from '@playwright/test';\nimport { protectApp } from '../geometry/openApp';")
s=s.replace('Generated device-lock code','Generated unlock code').replace('I saved my device-lock code','I saved my unlock code').replace("'Device-lock code'","'Unlock code'").replace('Confirm device-lock code','Confirm unlock code')
a=s.index('  await page.goto(path);');b=s.index('  const compose =',a)
s=s[:a]+'''  await page.goto(path);
  await expect(page.locator('.shell')).toBeVisible();
  const code = await protectApp(page);
'''+s[b:]
a=s.index('async function start(page:');b=s.index('async function authenticator',a)
s=s[:a]+'''async function start(page: Page, code: string) {
  await page.getByRole('button', { name: 'Set up sync', exact: true }).click();
  await page.getByRole('button', { name: 'Sync this list', exact: true }).click();
  if (['', 'You'].includes(await page.getByLabel('Your name', { exact: true }).inputValue()))
    await page.getByLabel('Your name', { exact: true }).fill('Alex');
  await page.getByRole('button', { name: 'Continue to passkey setup', exact: true }).click();
  await expect.poll(() => page.locator('.account-setup').getAttribute('data-setup-state'))
    .toMatch(/^(passkey|unlock)$/);
  if (await page.getByLabel('Unlock code', { exact: true }).isVisible()) {
    await page.getByLabel('Unlock code', { exact: true }).fill(code);
    await page.getByRole('button', { name: 'Continue', exact: true }).click();
  }
  await phase(page, 'passkey');
}
// Follow at most the two explicit approvals. A refusal returns to the caller's
// existing error assertion; it must not retry or bypass a failed ceremony.
async function confirmAndApprove(page: Page) {
  await page.getByRole('button', { name: 'Confirm recovery and use passkey', exact: true }).click();
  for (let approvals = 0; approvals <= 2; approvals++) {
    await expect.poll(async () => {
      if (await page.locator('.shell').isVisible()) return 'ready';
      if (await page.getByRole('alert').isVisible()) return 'refused';
      return await page.locator('.account-setup').getAttribute('data-setup-state');
    }).toMatch(/^(ready|refused|approve-passkey)$/);
    if (await page.locator('.shell').isVisible() || await page.getByRole('alert').isVisible()) return;
    expect(approvals, 'setup must not request more than two connection approvals').toBeLessThan(2);
    await expect(page.getByRole('heading', { name: /^(Enable encrypted sync|Open your list and connect sync)$/ })).toBeVisible();
    await page.getByRole('button', { name: 'Approve with passkey', exact: true }).click();
  }
}
'''+s[b:]
s=s.replace("await page.getByRole('button', { name: 'Finish account setup', exact: true }).click();",'await confirmAndApprove(page);')
s=s.replace("await page.getByRole('button', { name: 'Confirm and connect' }).click();",'await confirmAndApprove(page);')
s=s.replace("await page.getByRole('button', { name: 'I already have a workspace', exact: true }).click();", "await page.getByRole('button', { name: 'Use another account', exact: true }).click();")
s=s.replace("page.getByRole('button', { name: 'Finish account setup', exact: true })", "page.getByRole('button', { name: 'Confirm recovery and use passkey', exact: true })")
# Root is now the selected saved entry. Keep explicit account choice and all factor gates.
a=s.index("test('homepage welcome");b=s.index("test('root splash",a)
part=s[a:b].replace('homepage welcome opens account choice and a first account reopens through either entry','homepage opens the app, account choice stays explicit, and a first account reopens through either entry')
part=part.replace("await expect(page.getByRole('heading', { name: 'Your Workspace', exact: true })).toBeVisible();", "await expect(page.locator('.shell')).toBeVisible();")
a1=part.index("    if (url === '/') {");b1=part.index("    await phase(page, 'unlock');",a1)
part=part[:a1]+part[b1:]
s=s[:a]+part+s[b:]
# Root keeps the chosen draft; returning to the independent Local list still requires its factor.
a=s.index("test('root splash");b=s.index("test('create a second",a)
part=s[a:b].replace('root splash preserves Local writing and an unfinished account until explicitly selected','root entry and explicit account choice preserve Local writing while a separate unfinished account resumes')
part=part.replace("await expect(page.getByRole('heading', { name: 'Your Workspace', exact: true })).toBeVisible();", "await expect(page.getByLabel('Unlock code', { exact: true })).toBeVisible();",2)
part=part.replace("  await expect(page.getByRole('heading', { name: 'Your Workspace', exact: true })).toBeVisible();\n  await expect(\n    page.getByRole('heading', { name: 'Create a new account', exact: true }),\n  ).toHaveCount(0);\n  await page.getByRole('button', { name: 'Use another account', exact: true }).click();", "  await phase(page, 'intro');\n  await expect(page.locator('.shell')).toHaveCount(0);\n  expect(await slot(page)).toEqual(before);\n  await page.getByRole('button', { name: 'Choose an account', exact: true }).click();")
s=s[:a]+part+s[b:]
# A cold setup link deliberately discards the optional live-code handoff so this
# existing wrong-code-before-registration test still reaches the actual gate.
a=s.index("test('wrong local code never");b=s.index("test('an unsaved recovery",a)
part=s[a:b].replace("  await page.getByRole('button', { name: 'Connect this workspace' }).click();", "  await page.goto('/setup/local/intro');")
part=part.replace("name: 'Get started'", "name: 'Continue to passkey setup'")
s=s[:a]+part+s[b:]
# Local protection uses explicit in-flow redisplay; account setup remains history-owned.
a=s.index("test('browser Back retains unconfirmed");b=s.index("  const before = await slot(page);",a)
replacement='''test('local protection retains its unconfirmed code; browser Back retains account code and name drafts and skips committed creation', async ({
  page,
}) => {
  await page.goto('/');
  await expect(page.locator('.shell')).toBeVisible();
  await page.getByRole('button', { name: 'Add an unlock code', exact: true }).click();
  await page.getByRole('button', { name: 'Continue', exact: true }).click();
  const localCode = (await page.getByLabel('Generated unlock code').textContent())!;
  await page.getByRole('button', { name: 'I saved my unlock code', exact: true }).click();
  await page.getByRole('button', { name: 'Show my code again', exact: true }).click();
  await expect(page.getByLabel('Generated unlock code')).toHaveText(localCode);
  await page.getByRole('button', { name: 'I saved my unlock code', exact: true }).click();
  expect(await page.evaluate(() => JSON.stringify({ history: history.state, local: { ...localStorage }, session: { ...sessionStorage } }))).not.toContain(localCode);
  await page.getByLabel('Unlock code', { exact: true }).fill(localCode);
  await page.getByRole('button', { name: 'Confirm and protect' }).click();
  await expect(page.getByRole('heading', { name: 'Protection is enabled' })).toBeVisible();
  await page.getByRole('button', { name: 'Back to Today' }).click();
  await expect(page.locator('.shell')).toBeVisible();
'''
s=s[:a]+replacement+s[b:]
a=s.index("test('local protection retains");b=s.index("test('browser Back redisplays",a)
part=s[a:b].replace("  await back(page);\n  await phase(page, 'account-choice');", "  await page.getByRole('button', { name: 'Use another account', exact: true }).click();\n  await phase(page, 'account-choice');",1)
s=s[:a]+part+s[b:]
# The conservative read-error route stays explicit, with no fresh editor or guessed account.
a=s.index("test('legacy entry read failure");part=s[a:]
part=part.replace("  await expect(page.getByRole('heading', { name: 'Your Workspace' })).toBeVisible();", "  await expect(page.getByRole('alert')).toHaveText('Saved accounts and device connections could not be read. Reload to try again.');\n  await expect(page.locator('.shell')).toHaveCount(0);")
s=s[:a]+part
p.write_text(s)

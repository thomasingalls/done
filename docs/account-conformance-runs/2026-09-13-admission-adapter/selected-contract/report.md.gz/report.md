# Encrypted-store conformance execution

Scope: ordered-admission-browser; candidates: admission. Exit: 0.

Run: 2026-09-13T10:48:50.472Z · harness 1a86453c6b8cc63a224c6389895a9d4048b2fd2f (working-tree changes)

Subcase passes establish only the named oracle. Remaining obligations prevent a whole-contract pass.

| Scenario | admission |
| --- | --- |
| C03.ordered-refusal | pass |

Mutation controls:
- publish-before-forced-commit: detected (refused-prefix-is-private)
- prepare-queued-input-early: detected (only-head-prepared)

Detailed assertions, fault schedules, source/adapter hashes, browser version and storage inventories are in report.json and the per-case artifacts.

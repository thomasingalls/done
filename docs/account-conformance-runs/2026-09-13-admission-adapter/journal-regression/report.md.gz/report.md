# Encrypted-store conformance execution

Scope: journal-carrier-browser; candidates: journal. Exit: 0.

Run: 2026-09-13T10:48:51.377Z · harness 1a86453c6b8cc63a224c6389895a9d4048b2fd2f (working-tree changes)

Subcase passes establish only the named oracle. Remaining obligations prevent a whole-contract pass.

| Scenario | journal |
| --- | --- |
| C01.handoff-race | pass |

Mutation controls:
- reread-journal-after-content: detected (handoff-cannot-fall-between-reads)

Detailed assertions, fault schedules, source/adapter hashes, browser version and storage inventories are in report.json and the per-case artifacts.

import { mkdtempSync, mkdirSync, writeFileSync, copyFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
const root = process.cwd();
const { createStageRunner } = await import(pathToFileURL(join(root,'scripts/release-validation/stage.mjs')));
const { boundedStage } = await import(pathToFileURL(join(root,'scripts/release-validation/manifest.mjs')));
const base=mkdtempSync(join(tmpdir(),'done-flood-probe-')),checkout=join(base,'checkout');
mkdirSync(join(checkout,'scripts/release-validation'),{recursive:true});
copyFileSync('scripts/release-validation/process-guard.mjs',join(checkout,'scripts/release-validation/process-guard.mjs'));
writeFileSync(join(checkout,'subject.mjs'),"setInterval(() => console.log('x'.repeat(10000)), 1);");
const run=createStageRunner({root:checkout,output:join(base,'reports'),fingerprint:()=>({revision:'probe',sourceDigest:'same',dependencyDigest:'same',runtime:{node:process.version}})});
const rows=[];let calls=[];const original=process.kill;
process.kill=function(pid,signal){try{const value=original.call(process,pid,signal);calls.push({pid,signal,result:'ok'});return value;}catch(e){calls.push({pid,signal,result:e.code});throw e;}};
for(let i=0;i<30;i++){
 calls=[];
 const receipt=await run(boundedStage('flood',['node','subject.mjs'],{kind:'exit',exitCodes:[0]},{variant:String(i),maxLogBytes:4096,deadlineMs:1500,graceMs:300}));
 rows.push({i,reason:receipt.result.reason,groupDrained:receipt.result.groupDrained,calls});
}
process.kill=original;
const output=join(root,'test-results','validation-flood-probe-'+process.argv[2]+'.json');
writeFileSync(output,JSON.stringify({label:process.argv[2],rows},null,2)+'\n');
console.log(JSON.stringify({output,runs:rows.length,uncertain:rows.filter(r=>!r.groupDrained).length,reasons:[...new Set(rows.map(r=>r.reason))]}));
rmSync(base,{recursive:true,force:true});

from pathlib import Path
import subprocess,datetime,hashlib,json,os,signal,time,gzip
root=Path.cwd()
out=root/'test-results/validation-runner-gates'/datetime.datetime.now(datetime.timezone.utc).isoformat().replace(':','-')
out.mkdir(parents=True)
node='/opt/homebrew/bin/node'
paths=sorted(set(str(p.relative_to(root)) for d in ['scripts/release-validation','test/release-validation'] for p in (root/d).glob('*') if p.is_file())|{'scripts/account-crypto-audit/run.mjs','docs/release-validation-graph.json','docs/release-validation-manifest.json','docs/release-validation-execution.md'})
def pins():return [{'path':p,'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest()} for p in paths]
before=pins()
(out/'sources.json.gz').write_bytes(gzip.compress((json.dumps(before,indent=2)+'\n').encode(),mtime=0))
commands=[
 ('inventory',[node,'scripts/release-validation/check.mjs'],0),
 ('manifest',[node,'scripts/release-validation/plan.mjs'],0),
 ('controls',[node,'--test','--test-concurrency=1',*sorted(str(p.relative_to(root)) for p in (root/'test/release-validation').glob('*.test.mjs'))],0),
 ('types',[node,'node_modules/typescript/bin/tsc','-b','--noEmit'],0),
 ('lint',[node,'node_modules/oxlint/bin/oxlint','scripts/release-validation','test/release-validation','scripts/account-crypto-audit/run.mjs'],0),
 ('format',[node,'node_modules/oxfmt/bin/oxfmt','--check','scripts/release-validation','test/release-validation','scripts/account-crypto-audit/run.mjs','docs/release-validation-execution.md','docs/release-validation-graph.json','docs/release-validation-manifest.json'],0),
 ('authority',[node,'scripts/check-authority-map.mjs'],0),
 ('release-refusal',[node,'scripts/release-validation/plan.mjs','--require-complete'],1),
]
summary={'status':'running','claim':'Bounded validation runner gates only; no native campaign or aggregate','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stages':[]}
def save():(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
save()
print(str(out),flush=True)
for name,args,expected in commands:
 start=time.monotonic();timed=False
 with (out/(name+'.log')).open('wb') as log:
  p=subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=p.wait(timeout=90)
  except subprocess.TimeoutExpired:
   timed=True;os.killpg(p.pid,signal.SIGTERM)
   try:code=p.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait(timeout=5)
 text=(out/(name+'.log')).read_text()
 passed=not timed and code==expected
 if name=='controls':passed=passed and 'tests 32' in text and 'pass 32' in text and 'fail 0' in text and 'skipped 0' in text and 'cancelled 0' in text
 if name=='release-refusal':passed=passed and 'Unresolved execution obligation:' in text
 summary['stages'].append({'name':name,'argv':args,'expectedExit':expected,'exit':code,'timedOut':timed,'elapsedMs':round((time.monotonic()-start)*1000),'status':'passed' if passed else 'failed'})
 save();print(name+': '+('passed' if passed else 'FAILED'),flush=True)
 if not passed:print(text[-5000:],flush=True)
summary['sourcesUnchanged']=before==pins()
summary['status']='passed' if summary['sourcesUnchanged'] and all(s['status']=='passed' for s in summary['stages']) else 'failed'
summary['completedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
print(summary['status']+': '+str(out),flush=True)
raise SystemExit(0 if summary['status']=='passed' else 1)

import { build } from '<repo>/node_modules/vite/dist/node/index.js';
import { writeFileSync, readFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { cpus, release } from 'node:os';
import assert from 'node:assert/strict';
const root=process.cwd(), sha=b=>createHash('sha256').update(b).digest('hex');
const base=readFileSync('<tmp>/done-f17-metadata/base','utf8').trim();
const original=execFileSync('git',['show',base+':src/crdt/yjs.ts'],{encoding:'utf8'});
const modules={}, bundles={};
for(const variant of ['baseline','candidate']) {
 const built=await build({configFile:false,logLevel:'error',plugins:[
  {name:'probe',resolveId(id){if(id==='history-probe'||id.endsWith('/history-probe'))return '\0history-probe';},load(id){if(id==='\0history-probe')return `export * from '${root}/src/crdt/yjs.ts'; export {relativeSelection} from '${root}/src/crdt/workspaceCommands.ts';`; }},
  {name:'baseline',enforce:'pre',transform(code,id){if(variant==='baseline'&&id.endsWith('/src/crdt/yjs.ts'))return original;}},
 ],build:{write:false,minify:false,lib:{entry:'history-probe',name:'Product',formats:['iife']}}});
 const code=(Array.isArray(built)?built[0]:built).output.find(o=>o.type==='chunk').code;
 modules[variant]=Function(code+';return Product;')();bundles[variant]=sha(code);
}
const result={base,bundles,node:process.version,cpu:cpus()[0].model,os:release(),candidateSourceSha256:sha(readFileSync('src/crdt/yjs.ts')),design:'Nine fixed strata; five warmups per variant; twenty alternating AB/BA pairs. Separate baseline/candidate bundles and identical seeded histories; full encoding, counts and first/last metadata checked outside timing. Increasing stratum order, shared host/JIT/GC, synthetic target keys on master text, no redo/redone in this probe.',status:'running',rows:[]};
const save=()=>writeFileSync(process.argv[2],JSON.stringify(result,null,2)+'\n');save();
try {
 for(const groups of [0,100,1000]) {
  const states={};
  for(const variant of ['baseline','candidate']) {
   const h=modules[variant],doc=new h.Y.Doc({gc:false});doc.clientID=117;
   const text=doc.getText('master');text.insert(0,'x'.repeat(100000));
   const history=h.workspaceUndo(doc,'human');
   for(let group=0;group<groups;group++){history.stopCapturing();doc.transact(()=>{const at=group*97%100000;text.delete(at,1);text.insert(at,String.fromCharCode(65+group%26));},'human');}
   const encoded=h.Y.encodeStateAsUpdate(doc);assert.equal(history.undoStack.length,groups);
   states[variant]={h,doc,text,history,encoded};
  }
  assert.deepEqual(states.baseline.encoded,states.candidate.encoded);
  try {
   for(const targets of [0,1,100]) {
    for(const {h,text,history} of Object.values(states))for(const [index,item] of history.undoStack.entries()) {
     item.meta.clear();if(targets){const positions=new Map();for(let target=0;target<targets;target++){const at=(index*97+target)%100000;positions.set(target?'card:diagnostic-'+target:'master',h.relativeSelection(text,{ranges:[{anchor:at,head:at+1}],main:0}));}item.meta.set('before',structuredClone(positions));item.meta.set('after',structuredClone(positions));}
    }
    const make=variant=>states[variant].h.forkWorkspaceHistory(states[variant].history,'human');
    const dispose=(copy,variant)=>{const s=states[variant];try{assert.deepEqual(s.h.Y.encodeStateAsUpdate(copy.doc),s.encoded);assert.equal(copy.doc.getText('master').toString(),s.text.toString());assert.equal(copy.undoStack.length,groups);assert.equal(copy.redoStack.length,0);for(const i of new Set([0,Math.max(0,groups-1)]))if(groups)assert.deepEqual(copy.undoStack[i].meta,s.history.undoStack[i].meta);}finally{copy.destroy();copy.doc.destroy();}};
    for(let i=0;i<5;i++)for(const variant of ['baseline','candidate'])dispose(make(variant),variant);
    const s=states.candidate;
    const row={groups,targetsPerSelection:targets,selectionEntries:groups*targets*2,visibleChars:s.text.length,items:[...s.doc.store.clients.values()].reduce((n,items)=>n+items.length,0),encodedBytes:s.encoded.length,stateSha256:sha(s.encoded),undo:groups,redo:0,redone:0,samples:[]};result.rows.push(row);
    for(let block=0;block<20;block++)for(const variant of (block%2?['candidate','baseline']:['baseline','candidate'])){const at=performance.now(),copy=make(variant),ms=performance.now()-at;dispose(copy,variant);row.samples.push({block,variant,ms});}
    save();console.log('Completed paired stratum',groups,targets);
   }
  }finally{for(const s of Object.values(states)){s.history.destroy();s.doc.destroy();s.encoded.fill(0);}}
 }
 result.status='passed';save();
}catch(error){result.status='failed';result.error=String(error);save();throw error;}

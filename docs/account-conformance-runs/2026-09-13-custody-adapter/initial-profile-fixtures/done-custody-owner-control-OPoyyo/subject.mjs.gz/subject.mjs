
    import assert from 'node:assert/strict';
    import { createServer } from 'node:http';
    import { writeFileSync } from 'node:fs';
    import { join } from 'node:path';
    import { ownedProfiles } from './profiles.mjs';
    const server = createServer((req,res) => res.end('<title>Persistent profile control</title>'));
    await new Promise(r => server.listen(0,'127.0.0.1',r));
    const origin = 'http://127.0.0.1:' + server.address().port, records=[];
    const save = () => writeFileSync(process.env.OWNER_RECORDS, JSON.stringify(records));
    const owner = ownedProfiles({directory:join(process.env.RELEASE_CUSTODY_OUTPUT,'custody','profiles'),origin,records,save});
    const source = await owner.profile('source-false');
    const page = await source.newPage(); await page.goto(origin);
    await page.evaluate(() => localStorage.setItem('native-control','cold-copied-value'));
    await assert.rejects(owner.copyProfile('source-false','copy-false'),/live or failed source/);
    writeFileSync(process.env.OWNER_MARKER,JSON.stringify({worker:process.pid,port:server.address().port,profile:records[0].profile,endpoint:records[0].endpoint,pid:records[0].pid}));
    if (process.env.MODE === 'normal') {
      await source.close();
      const clone = await owner.copyProfile('source-false','copy-false');
      const next = await clone.newPage(); await next.goto(origin);
      assert.equal(await next.evaluate(() => localStorage.getItem('native-control')),'cold-copied-value');
      await clone.close(); await owner.close(); await new Promise(r => server.close(r));
    } else if (process.env.MODE === 'death') process.exit(9);
    else { process.on('SIGTERM',()=>{}); setInterval(()=>{},100); }
  
# Encrypted-store conformance execution

Scope: content-trim-browser; candidates: trim. Exit: 0.

Run: 2026-09-13T13:43:12.406Z · harness d65bda01e6e9d0cff984c58b905a6f156af1990a (working-tree changes)

Subcase passes establish only the named oracle. Remaining obligations prevent a whole-contract pass.

| Scenario | trim |
| --- | --- |
| T11.delete-abort | pass |
| T15.close | pass |

Mutation controls:
- early-delete-receipt: detected (delete-abort-has-no-success-receipt)

Detailed assertions, fault schedules, source/adapter hashes, browser version and storage inventories are in report.json and the per-case artifacts.

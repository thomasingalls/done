# Encrypted-store conformance execution

Scope: custody-component-browser; candidates: custody. Exit: 0.

Run: 2026-09-13T13:42:58.232Z · harness d65bda01e6e9d0cff984c58b905a6f156af1990a (working-tree changes)

Subcase passes establish only the named oracle. Remaining obligations prevent a whole-contract pass.

| Scenario | custody |
| --- | --- |
| C12.genesis | pass |
| C12.reservation-abort | pass |
| C12.interrupted-creation | pass |
| C12.metadata-authentication | pass |
| C12.cancel-crypto | pass |

Mutation controls:
- skip-nested-crypto-guard: detected (cancel-prevents-private-export)
- accept-unconfirmed-code: detected (wrong-confirmation-refused)
- skip-reservation-commit: detected (durable-reservation-before-encrypt)
- trust-unverified-metadata: detected (modified-count-refuses)
- request-success-as-commit: detected (no-encryption-before-reservation-completes)

Detailed assertions, fault schedules, source/adapter hashes, browser version and storage inventories are in report.json and the per-case artifacts.

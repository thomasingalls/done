import {installedChromium} from '<repo>/scripts/release-validation/browser.mjs';
import {createStageRunner} from '<repo>/scripts/release-validation/stage.mjs';
import {boundedStage} from '<repo>/scripts/release-validation/manifest.mjs';
import {digest} from '<repo>/scripts/release-validation/identity.mjs';
const runtime=installedChromium();const run=createStageRunner({root:process.cwd(),output:'<tmp>/done-residue-worker-probe-result',fingerprint:()=>({revision:'diagnostic-only',sourceDigest:'no-qualification',dependencyDigest:'no-qualification',runtime:{node:process.version},tools:{chromium:digest(runtime.snapshot)}}),browserRuntime:runtime});
const receipt=await run(boundedStage('worker-probe',['node','<tmp>/done-residue-worker-probe.mjs'],{kind:'exit',exitCodes:[0]},{fixture:{kind:'chromium-cdp',startupMs:15000},deadlineMs:30000,graceMs:1000}));console.log(JSON.stringify(receipt));

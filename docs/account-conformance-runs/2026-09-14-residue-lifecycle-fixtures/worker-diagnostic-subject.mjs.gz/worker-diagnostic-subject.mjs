import {fixture} from '<repo>/test/account-residue/fixtures.mjs';
const cleanup=[];
const f=await fixture({after:fn=>cleanup.push(fn)});
try {console.log(JSON.stringify({workers:await f.workers(),diagnostics:await f.diagnostics()}));} finally {for(const fn of cleanup.reverse()) await fn();}

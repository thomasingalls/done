# Encrypted-store conformance execution

Scope: ordered-admission-browser; candidates: admission. Exit: 0.

Run: 2026-09-13T11:15:24.240Z · harness 4fc3af06fc863cc87776cb922b2efc7c49f59e0d (working-tree changes)

Subcase passes establish only the named oracle. Remaining obligations prevent a whole-contract pass.

| Scenario | admission |
| --- | --- |
| C03.ordered-refusal | pass |

Mutation controls:
- publish-before-forced-commit: detected (refused-prefix-is-private)
- prepare-queued-input-early: detected (only-head-prepared)

Detailed assertions, fault schedules, source/adapter hashes, browser version and storage inventories are in report.json and the per-case artifacts.

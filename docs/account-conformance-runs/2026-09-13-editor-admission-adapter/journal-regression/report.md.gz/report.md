# Encrypted-store conformance execution

Scope: journal-carrier-browser; candidates: journal. Exit: 0.

Run: 2026-09-13T11:15:26.433Z · harness 4fc3af06fc863cc87776cb922b2efc7c49f59e0d (working-tree changes)

Subcase passes establish only the named oracle. Remaining obligations prevent a whole-contract pass.

| Scenario | journal |
| --- | --- |
| C01.handoff-race | pass |

Mutation controls:
- reread-journal-after-content: detected (handoff-cannot-fall-between-reads)

Detailed assertions, fault schedules, source/adapter hashes, browser version and storage inventories are in report.json and the per-case artifacts.

# Encrypted-store conformance execution

Scope: editor-admission-browser; candidates: editor. Exit: 0.

Run: 2026-09-13T11:21:42.752Z · harness 4fc3af06fc863cc87776cb922b2efc7c49f59e0d (working-tree changes)

Subcase passes establish only the named oracle. Remaining obligations prevent a whole-contract pass.

| Scenario | editor |
| --- | --- |
| E11.repair | pass |
| E12.multicaret | pass |
| E09.pending-death | pass |
| E10.checkbox | pass |
| E01.typing | pass |
| E02.pressure | pass |
| E03.remote | pass |
| E04.cross-tab | pass |
| E05.paste | pass |
| E06.composition | pass |
| E07.close | pass |
| E08.profile | pass |

Mutation controls:
- history-before-receipt: detected (pending-not-in-history)
- ordinary-view-before-receipt: detected (pending-not-in-editor)
- remote-in-undo: detected (undo-preserves-remote)

Detailed assertions, fault schedules, source/adapter hashes, browser version and storage inventories are in report.json and the per-case artifacts.

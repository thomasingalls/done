import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { readFileSync, writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
const file = 'test/account-counter-contract/native.test.mjs';
const baseline = process.argv[2];
assert(/^[a-f0-9]{40}$/.test(baseline));
const old = execFileSync('git', ['show', baseline + ':' + file], { encoding: 'utf8' });
const current = readFileSync(file, 'utf8');
const hash = (s) => createHash('sha256').update(s).digest('hex');
function load(source, fail) {
  const start = source.indexOf('async function fixture('), end = source.indexOf('\nconst run =', start);
  assert(start >= 0 && end > start);
  const calls = [], cleanups = [];
  const step = (name) => { calls.push(name); if (fail === name) throw Error('injected ' + name); };
  const server = new EventEmitter();
  server.listening = false;
  server.listen = (_port, _host, callback) => queueMicrotask(() => {
    calls.push('listen');
    if (fail === 'listen') server.emit('error', Error('injected listen'));
    else { server.listening = true; callback(); }
  });
  server.address = () => ({ port: 12345 });
  server.close = (callback) => { calls.push('server-close'); server.listening = false; callback(); };
  const page = { goto: async () => step('goto'), evaluate: async () => step('evaluate') };
  const context = { newPage: async () => { step('page'); return page; }, close: async () => step('context-close') };
  const browser = { newContext: async () => { step('context'); return context; }, newPage: context.newPage, close: async () => step('browser-close') };
  const open = async () => { step('browser'); return browser; };
  const fixture = Function('createServer', 'chromium', 'openFixtureBrowser', 'scripts', 'process', source.slice(start, end) + '; return fixture;')(
    () => server, { launch: open }, open, { base: 'synthetic script' }, { env: {} },
  );
  return { fixture, t: { after: (f) => cleanups.push(f) }, calls, cleanups, server };
}
const before = load(old, 'browser');
await assert.rejects(before.fixture(before.t), /injected browser/);
assert.equal(before.cleanups.length, 0);
assert.equal(before.server.listening, true);
const results = [{ phase: 'before', fault: 'browser', cleanupRegistered: 0, listenerLeftOpen: true }];
before.server.close(() => {}); // Dispose the synthetic model after recording the reproduction.
for (const fail of ['listen', 'browser', 'context', 'page', 'goto', 'evaluate', 'context-close', 'browser-close', null]) {
  const f = load(current, fail);
  if (fail && !fail.endsWith('-close')) await assert.rejects(f.fixture(f.t), new RegExp('injected ' + fail));
  else await f.fixture(f.t);
  assert.equal(f.cleanups.length, 1);
  if (fail?.endsWith('-close')) await assert.rejects(f.cleanups[0](), new RegExp('injected ' + fail));
  else await f.cleanups[0]();
  assert.equal(f.server.listening, false);
  if (fail !== 'listen') assert(f.calls.includes('server-close'));
  if (!['listen', 'browser'].includes(fail)) assert(f.calls.includes('browser-close'));
  if (!['listen', 'browser', 'context'].includes(fail)) assert(f.calls.includes('context-close'));
  results.push({ phase: 'after', fault: fail, calls: f.calls, cleanupRegistered: 1, listenerLeftOpen: false });
}
const report = { baseline, file, beforeSha256: hash(old), afterSha256: hash(current), results,
  scope: 'Extracted trusted fixture with mocked resources: setup rejection and cleanup ordering only. Native CDP/process ownership is tested separately.' };
writeFileSync('/private/tmp/done-counter-contract-native-fixture-cleanup.json', JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report, null, 2));

import { defineConfig } from '<workspace>/node_modules/@playwright/test/index.mjs';
export default defineConfig({
  testDir: '/private/tmp/done-suite-triage-20261015',
  testMatch: 'session-diagnostic.spec.ts',
  outputDir: '/private/tmp/done-suite-triage-20261015/artifacts',
  timeout: 120000,
  workers: 1,
  retries: 0,
  reporter: [['json', { outputFile: '/private/tmp/done-suite-triage-20261015/session-report.json' }]],
  use: { baseURL: 'http://localhost:53221', viewport: { width: 1280, height: 900 } },
});

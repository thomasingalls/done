import { test } from '<workspace>/node_modules/@playwright/test/index.mjs';
import { writeFile } from 'node:fs/promises';
import '<workspace>/test/packaged-account/sessions.spec.ts';

const observations: unknown[] = [];
test.beforeEach(async ({ browser, context }) => {
  let contextId = 0;
  function attach(c: any) {
    const id = ++contextId;
    c.on('requestfailed', (r: any) => observations.push({ context: id, event: 'requestfailed', path: new URL(r.url()).pathname, error: r.failure()?.errorText }));
    c.on('response', async (r: any) => {
      const path = new URL(r.url()).pathname;
      if (!path.startsWith('/account/') && !path.startsWith('/__account-setup/')) return;
      const entry: any = { context: id, event: 'response', path, status: r.status(), type: r.headers()['content-type'] };
      observations.push(entry);
      if (r.status() >= 400) {
        try {
          const value = await r.json();
          entry.refusal = value.refusal;
          entry.reason = value.reason;
          entry.kind = value.kind;
        } catch {}
      }
    });
    c.on('page', (p: any) => p.on('pageerror', (error: Error) => observations.push({ context: id, event: 'pageerror', message: error.message })));
    for (const p of c.pages()) p.on('pageerror', (error: Error) => observations.push({ context: id, event: 'pageerror', message: error.message }));
  }
  attach(context);
  const original = browser.newContext.bind(browser);
  browser.newContext = async (...args: Parameters<typeof original>) => {
    const c = await original(...args);
    attach(c);
    return c;
  };
});
test.afterEach(async () => {
  await writeFile('/private/tmp/done-suite-triage-20261015/session-network.json', JSON.stringify(observations, null, 2) + '\n');
});

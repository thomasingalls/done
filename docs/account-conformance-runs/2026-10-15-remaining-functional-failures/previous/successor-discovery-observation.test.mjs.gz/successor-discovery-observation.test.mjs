import test from 'node:test';
import fs from 'node:fs';
import {
  nativeOwner, selected, syncing, settled, online, close, cold, marker,
} from '<workspace>/test/account-successor/owner-fixtures.mjs';
test('observe cold discovery settlement without changing the old assertion', {timeout:60000}, async t => {
  const f=await nativeOwner(t,undefined,true), item=await selected(f,'triage-discovery-close');
  await syncing(f.page,item);await settled(f.page);await online(f.page,false);
  await f.successor(item);
  let release, hit;
  const held=new Promise(r=>{release=r}), reached=new Promise(r=>{hit=r});
  const path=f.server.origin+'/account/authority/discover';
  await f.context.route(path,async route=>{const response=await route.fetch();hit();await held;await route.fulfill({response}).catch(()=>{});});
  await online(f.page,true);await reached;await close(f.page);release();
  await f.context.unroute(path);await cold(f);await syncing(f.page,item);await settled(f.page);
  const before=await marker(f.page,item);
  const refresh=await f.page.evaluate(()=>opened.refreshAuthority());
  await close(f.page);
  const after=await marker(f.page,item);
  const result={successorAtOldSettlement:!!before.successor,explicitRefresh:refresh.kind,successorAfterAwaitedDiscovery:!!after.successor};
  fs.writeFileSync('/private/tmp/done-suite-triage-20261015/successor-discovery-observation.json',JSON.stringify(result,null,2)+'\n');
  console.log(JSON.stringify(result));
});

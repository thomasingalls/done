import { ready, mutate, inventory } from '<workspace>/test/account-service-delivery/fixtures.mjs';
import { query, read } from '<workspace>/test/account-service-inbound/oracle.mjs';
import fs from 'node:fs';
const cleanup = [];
const t = { after: f => cleanup.push(f) };
const result = {};
try {
  const x = await ready(t);
  const brief = r => ({ kind: r.kind, reason: r.reason });
  result.firstAppend = brief(await x.call(x.make(1, 'triage-first')));
  x.f.restart();
  x.authority.restart();
  const before = inventory(x);
  const ordinal = x.f.rows('delivery_decisions').at(-1).ordinal;
  mutate(x, db => db.prepare('UPDATE delivery_decisions SET ordinal=? WHERE ordinal=?').run(ordinal + 1, ordinal));
  result.corruptedRead = brief(await read(x, query(x)));
  mutate(x, db => db.prepare('UPDATE delivery_decisions SET ordinal=? WHERE ordinal=?').run(ordinal, ordinal + 1));
  result.oldInventoryRestored = inventory(x) === before;
  result.appendAfterRestore = brief(await x.call(x.make(2, 'triage-second')));
  result.readAfterRestore = brief(await read(x, query(x)));
  x.f.restart();
  x.authority.restart();
  result.appendAfterColdRestart = brief(await x.call(x.make(2, 'triage-second-cold')));
  fs.writeFileSync('/private/tmp/done-suite-triage-20261015/service-inbound-observation.json', JSON.stringify(result, null, 2) + '\n');
  console.log(JSON.stringify(result));
} finally {
  for (const close of cleanup.reverse()) await close();
}

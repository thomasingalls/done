from pathlib import Path
import json,difflib
root=Path.cwd(); out=Path('<tmp>/done-f17-preparation-contract')
cases=[
('stale-draft','src/crdt/admissionDocument.ts','const draft = cloneDocument(canonical),','const draft = createDoc(),','test/admissionQueue.test.ts','80 generated preparation traces preserve the accepted basis through retry discard and remote delivery','preparation must use the accepted predecessor'),
('premature-promotion','src/crdt/admissionQueue.ts',"    await carrier.appendBatch([\n      { kind: 'update', bytes: job.prepared!.carrierBytes ?? job.prepared!.update },\n    ]);", "    promote(job, job.prepared!.update);\n    await carrier.appendBatch([\n      { kind: 'update', bytes: job.prepared!.carrierBytes ?? job.prepared!.update },\n    ]);",'test/workspaceAdmission.test.ts','private prepared histories remain unpublished under pressure and are disposed on discard and drained close','refused history must not be published'),
('leaked-history','src/crdt/admittedWorkspace.ts',"    discardPending: () => {\n      session.discardPending();\n      dispose(pending);\n      pending = undefined;", "    discardPending: () => {\n      session.discardPending();\n      pending = undefined;",'test/workspaceAdmission.test.ts','private prepared histories remain unpublished under pressure and are disposed on discard and drained close','discard must dispose its private history'),
('omitted-source-check','src/crdt/admissionDocument.ts','if (!sameDocState(sourced, draft))','if (false)','test/sourceCapture.test.ts','160 generated source coverage checks include preexisting pending structs missing clocks and delete sets','source verification must cover the complete pending basis')]
rows=[]
for name,path,old,new,test,title,marker in cases:
 s=(root/path).read_text(); assert s.count(old)==1,(name,s.count(old))
 (out/(name+'.patch')).write_text(''.join(difflib.unified_diff(s.splitlines(True),s.replace(old,new).splitlines(True),fromfile='a/'+path,tofile='b/'+path)))
 (out/(name+'.config.mts')).write_text('import base from '+json.dumps(str(root/'vite.config.ts'))+';\nexport default {...base,root:'+json.dumps(str(root))+',plugins:[...base.plugins,{name:'+json.dumps(name)+',enforce:"pre",transform(code,id){if(!id.endsWith('+json.dumps('/'+path)+'))return;const from='+json.dumps(old)+';if(code.split(from).length!==2)throw Error("mutation must match exactly once");return code.replace(from,'+json.dumps(new)+');}}],test:{...base.test,include:['+json.dumps(test)+'],maxWorkers:1,fileParallelism:false,retry:0}};\n')
 rows.append({'name':name,'file':path,'test':test,'title':title,'marker':marker})
(out/'controls.json').write_text(json.dumps(rows,indent=2)+'\n')

# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: sync.spec.ts >> Local editing and reload work with no relay or plaintext identity cache
- Location: test/geometry/sync.spec.ts:6:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText('Off. This Local workspace is not connected to a relay.')
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for getByText('Off. This Local workspace is not connected to a relay.')

```

```yaml
- complementary "Menu":
  - heading "Day" [level=2]
  - paragraph: Thu 15 Oct 2026
  - button "Thu 8 Oct"
  - button "Tue 13 Oct"
  - button "Yesterday"
  - button "Today"
  - button "Tomorrow"
  - button "Sat 17 Oct"
  - button "Thu 22 Oct"
  - text: Go to date
  - textbox "Go to date": 2026-10-15
  - heading "Data" [level=2]
  - text: Local data Best-effort
  - paragraph: Writing is encrypted in this browser. Export a readable backup when you need one.
  - button "Export markdown"
  - button "Remove from this device"
  - button "Undo" [disabled]
  - button "Redo" [disabled]
  - heading "Protection" [level=2]
  - paragraph: Opens automatically. Anyone using this browser can open your list.
  - button "Add an unlock code"
  - heading "Sync" [level=2]
  - button "Use another account"
  - paragraph: Saved only in this browser. Sync is off.
  - button "Set up sync"
  - heading "Personalize" [level=2]
  - text: Actor You Version 5afdd0ad Device
  - textbox "Device name": Chrome - Android
  - text: Name
  - textbox "Actor name": You
  - text: Color
  - textbox "Actor color": "#e0662f"
  - text: Day rollover
  - combobox "Day rollover hour":
    - option "00:00" [selected]
    - option "01:00"
    - option "02:00"
    - option "03:00"
    - option "04:00"
    - option "05:00"
    - option "06:00"
    - option "07:00"
    - option "08:00"
    - option "09:00"
    - option "10:00"
    - option "11:00"
    - option "12:00"
    - option "13:00"
    - option "14:00"
    - option "15:00"
    - option "16:00"
    - option "17:00"
    - option "18:00"
    - option "19:00"
    - option "20:00"
    - option "21:00"
    - option "22:00"
    - option "23:00"
  - button "Save preferences"
  - region "Install":
    - heading "Install" [level=2]
    - paragraph: Check permission to keep local writing in this browser.
    - paragraph: You can also install done from your browser’s menu.
    - button "Install"
- button "Close unfiled cards"
- main "Days":
  - button "Go to Yesterday"
  - button "Go to Tomorrow"
  - region "Today":
    - heading "Thu 15 Oct" [level=1]
    - complementary "Getting started":
      - paragraph: Write everything in Goals. Choose three things for Next. Record what got done.
      - button "Open Goals"
      - button "Dismiss introduction": Dismiss
    - heading "Next 0 of 3" [level=2]: Next 0/3
    - paragraph: The three most important things to focus on next.
    - heading "Done" [level=2]
    - paragraph: Anything you finished counts, planned or unplanned.
    - textbox "What got done?"
    - button "Add" [disabled]
    - heading "Scheduled" [level=2]
    - paragraph: Things planned for this day.
    - textbox "What’s scheduled?"
    - button "Add" [disabled]
- complementary "Goals":
  - heading "Goals. Open document outline" [level=2]:
    - button "Goals. Open document outline": Goals
  - status
  - textbox
  - group "Selected lines":
    - group "Transfer selected lines":
      - text: Transfer selected lines
      - radio "Copy to" [checked]
      - text: Copy to
      - radio "Move to"
      - text: Move to
    - button "More Goals actions"
    - button "Next" [disabled]
    - button "Scheduled" [disabled]
    - button "Done" [disabled]
```

# Test source

```ts
  1  | import { test } from '../release-validation/browser-fixture';
  2  | /** The Local build has no transport attached; the legacy provider stays covered by its core harnesses. */
  3  | import { expect } from '@playwright/test';
  4  | import { openApp, reloadApp } from './openApp';
  5  | 
  6  | test('Local editing and reload work with no relay or plaintext identity cache', async ({
  7  |   page,
  8  | }) => {
  9  |   await page.setViewportSize({ width: 1280, height: 900 });
  10 |   const sockets: string[] = [];
  11 |   page.on('websocket', (socket) => sockets.push(socket.url()));
  12 |   await openApp(page);
  13 |   await expect(
  14 |     page.getByText('Off. This Local workspace is not connected to a relay.'),
> 15 |   ).toBeVisible();
     |     ^ Error: expect(locator).toBeVisible() failed
  16 |   await expect(page.getByRole('textbox', { name: 'Relay endpoint' })).toHaveCount(0);
  17 |   const compose = page.locator(
  18 |     '.day-panel[data-active="true"] .collection[data-section="done"] .compose-field',
  19 |   );
  20 |   await compose.fill('Local writing without a relay');
  21 |   await compose.press('Enter');
  22 |   await expect(page.locator('.day-panel[data-active="true"] .card')).toContainText(
  23 |     'Local writing without a relay',
  24 |   );
  25 |   await reloadApp(page);
  26 |   await expect(page.locator('.day-panel[data-active="true"] .card')).toContainText(
  27 |     'Local writing without a relay',
  28 |   );
  29 |   expect(sockets).toEqual([]);
  30 |   expect(
  31 |     await page.evaluate(() => [
  32 |       localStorage.getItem('done.actor'),
  33 |       localStorage.getItem('done.device'),
  34 |     ]),
  35 |   ).toEqual([null, null]);
  36 | });
  37 | 
```
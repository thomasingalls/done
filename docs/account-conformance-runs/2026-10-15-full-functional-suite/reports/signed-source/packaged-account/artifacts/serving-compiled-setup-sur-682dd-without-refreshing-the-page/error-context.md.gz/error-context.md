# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: serving.spec.ts >> compiled setup survives independent API and application restarts without refreshing the page
- Location: test/packaged-account/serving.spec.ts:11:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('button', { name: 'I already have a workspace', exact: true })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for getByRole('button', { name: 'I already have a workspace', exact: true })

```

```yaml
- complementary "Menu":
  - heading "Day" [level=2]
  - paragraph: Thu 15 Oct 2026
  - button "Thu 8 Oct"
  - button "Tue 13 Oct"
  - button "Yesterday"
  - button "Today"
  - button "Tomorrow"
  - button "Sat 17 Oct"
  - button "Thu 22 Oct"
  - text: Go to date
  - textbox "Go to date": 2026-10-15
  - heading "Data" [level=2]
  - text: Local data Best-effort
  - paragraph: Writing is encrypted in this browser. Export a readable backup when you need one.
  - button "Export markdown"
  - button "Remove from this device"
  - button "Undo" [disabled]
  - button "Redo" [disabled]
  - heading "Protection" [level=2]
  - paragraph: Opens automatically. Anyone using this browser can open your list.
  - button "Add an unlock code"
  - heading "Sync" [level=2]
  - button "Use another account"
  - paragraph: Saved only in this browser. Sync is off.
  - button "Set up sync"
  - heading "Personalize" [level=2]
  - text: Actor You Version 5afdd0ad Device
  - textbox "Device name": Chrome - macOS
  - text: Name
  - textbox "Actor name": You
  - text: Color
  - textbox "Actor color": "#e0662f"
  - text: Day rollover
  - combobox "Day rollover hour":
    - option "00:00" [selected]
    - option "01:00"
    - option "02:00"
    - option "03:00"
    - option "04:00"
    - option "05:00"
    - option "06:00"
    - option "07:00"
    - option "08:00"
    - option "09:00"
    - option "10:00"
    - option "11:00"
    - option "12:00"
    - option "13:00"
    - option "14:00"
    - option "15:00"
    - option "16:00"
    - option "17:00"
    - option "18:00"
    - option "19:00"
    - option "20:00"
    - option "21:00"
    - option "22:00"
    - option "23:00"
  - button "Save preferences"
  - region "Install":
    - heading "Install" [level=2]
    - paragraph: Check permission to keep local writing in this browser.
    - paragraph: You can also install done from your browser’s menu.
    - button "Install"
- button "Close unfiled cards"
- main "Days":
  - button "Go to Yesterday"
  - button "Go to Tomorrow"
  - region "Today":
    - heading "Thu 15 Oct" [level=1]
    - complementary "Getting started":
      - paragraph: Write everything in Goals. Choose three things for Next. Record what got done.
      - button "Open Goals"
      - button "Dismiss introduction": Dismiss
    - heading "Next 0 of 3" [level=2]: Next 0/3
    - paragraph: The three most important things to focus on next.
    - heading "Done" [level=2]
    - paragraph: Anything you finished counts, planned or unplanned.
    - textbox "What got done?"
    - button "Add" [disabled]
    - heading "Scheduled" [level=2]
    - paragraph: Things planned for this day.
    - textbox "What’s scheduled?"
    - button "Add" [disabled]
- complementary "Goals":
  - heading "Goals. Open document outline" [level=2]:
    - button "Goals. Open document outline": Goals
  - status
  - textbox
  - group "Selected lines":
    - group "Transfer selected lines":
      - text: Transfer selected lines
      - radio "Copy to" [checked]
      - text: Copy to
      - radio "Move to"
      - text: Move to
    - button "More Goals actions"
    - button "Next" [disabled]
    - button "Scheduled" [disabled]
    - button "Done" [disabled]
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | import { account } from '../device-enrollment/helpers';
  3  | import {
  4  |   startService,
  5  |   stopService,
  6  |   startBackend,
  7  |   startApplication,
  8  |   stopProcess,
  9  |   origin,
  10 | } from './server';
  11 | test('compiled setup survives independent API and application restarts without refreshing the page', async ({
  12 |   page,
  13 |   request,
  14 | }, info) => {
  15 |   const state = info.outputPath('service');
  16 |   const service = await startService(state);
  17 |   try {
  18 |     await page.goto('/');
  19 |     await expect(
  20 |       page.getByRole('button', { name: 'I already have a workspace', exact: true }),
> 21 |     ).toBeVisible();
     |       ^ Error: expect(locator).toBeVisible() failed
  22 |     const first = await account(page);
  23 |     await page.evaluate(() => navigator.serviceWorker.ready.then(() => true));
  24 |     await stopProcess(service.backend);
  25 |     expect((await request.get('/')).status()).toBe(200);
  26 |     const unavailable = await request.post('/__account-setup/config', {
  27 |       headers: { Origin: origin, 'Content-Type': 'application/json' },
  28 |       data: {},
  29 |     });
  30 |     expect(unavailable.status()).toBe(503);
  31 |     expect(unavailable.headers()['cache-control']).toBe('no-store');
  32 |     service.backend = await startBackend(state);
  33 |     const renewed = page.waitForResponse(
  34 |       (r) => r.url().endsWith('/__account-setup/access') && r.status() === 200,
  35 |     );
  36 |     const resumed = page.waitForResponse(
  37 |       (r) => r.url().endsWith('/__account-setup/ceremony/bootstrap') && r.status() === 200,
  38 |     );
  39 |     await page.getByRole('button', { name: 'Check again', exact: true }).click();
  40 |     await renewed;
  41 |     await resumed;
  42 |     await expect(page.getByLabel('Device invitation link')).toHaveValue(first.link);
  43 |     const before = await request.post('/__account-setup/access', {
  44 |       headers: { Origin: origin, 'Content-Type': 'application/json' },
  45 |       data: {},
  46 |     });
  47 |     const beforeConfig = await before.json();
  48 |     await stopProcess(service.app);
  49 |     service.app = await startApplication();
  50 |     const after = await request.post('/__account-setup/access', {
  51 |       headers: { Origin: origin, 'Content-Type': 'application/json' },
  52 |       data: {},
  53 |     });
  54 |     expect(await after.json()).toEqual(beforeConfig);
  55 |     const afterAppRestart = page.waitForResponse(
  56 |       (r) => r.url().endsWith('/__account-setup/ceremony/bootstrap') && r.status() === 200,
  57 |     );
  58 |     await page.getByRole('button', { name: 'Check again', exact: true }).click();
  59 |     await afterAppRestart;
  60 |     await expect(page.getByLabel('Device invitation link')).toHaveValue(first.link);
  61 |     const wrongOrigin = await request.post('/__account-setup/access', {
  62 |       headers: { Origin: 'https://unrelated.invalid', 'Content-Type': 'application/json' },
  63 |       data: {},
  64 |     });
  65 |     expect(wrongOrigin.status()).toBe(403);
  66 |     const direct = await request.post('/__account-setup/access', {
  67 |       headers: { Origin: origin, 'Content-Type': 'application/json' },
  68 |       data: {},
  69 |     });
  70 |     expect(direct.status()).toBe(200);
  71 |     expect(direct.headers()['cache-control']).toBe('no-store');
  72 |     for (const path of ['/.dev/account.sqlite', '/src/main.tsx', '/assets/missing.js'])
  73 |       expect((await request.get(path)).status()).toBe(404);
  74 |     const cacheUrls = await page.evaluate(async () =>
  75 |       (
  76 |         await Promise.all(
  77 |           (
  78 |             await caches.keys()
  79 |           ).map(async (k) => (await (await caches.open(k)).keys()).map((r) => r.url)),
  80 |         )
  81 |       ).flat(),
  82 |     );
  83 |     expect(cacheUrls.length).toBeGreaterThan(5);
  84 |     expect(
  85 |       cacheUrls.some(
  86 |         (url) => url.includes('__account-setup') || url.includes('/account/delivery/'),
  87 |       ),
  88 |     ).toBe(false);
  89 |   } finally {
  90 |     await stopService(service);
  91 |   }
  92 | });
  93 | 
```
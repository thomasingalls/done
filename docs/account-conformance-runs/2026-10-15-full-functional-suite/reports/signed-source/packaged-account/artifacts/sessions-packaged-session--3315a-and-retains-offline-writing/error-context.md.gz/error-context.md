# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: sessions.spec.ts >> packaged session host enrolls both devices, renews after restart and retains offline writing
- Location: test/packaged-account/sessions.spec.ts:5:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: locator('.shell')
Expected substring: "Session transport A to B"
Received string:    "DayThu 15 Oct 2026Thu 8 OctTue 13 OctYesterdayTodayTomorrowSat 17 OctThu 22 OctGo to dateDataLocal dataBest-effortWriting is encrypted in this browser. Export a readable backup when you need one.Export markdownRemove from this deviceUndoRedoProtectionUnlock code enabled. Your local copy requires an unlock code.Lock workspaceAccountNameDevice ownerAccount IDU7pTTrDGCzHZybq17dDy2ryiDNqz5URjpkwbn6rKl1wSending: idleLast accepted upload: 1:18:33 PMAccepted position: 1Receiving: retryingLast successful receive check: None since openingReceived positions: 5Reason: receive:network-unavailableRetry receivingDevicesHistory maintenanceUse another accountAccount login remembered on this device.Sign outPersonalizeActorDevice ownerVersion5afdd0adDeviceDevice code13d3e60bNameColorDay rollover00:0001:0002:0003:0004:0005:0006:0007:0008:0009:0010:0011:0012:0013:0014:0015:0016:0017:0018:0019:0020:0021:0022:0023:00Save preferencesInstallCheck permission to keep local writing in this browser.You can also install done from your browser’s menu.InstallUnfiled0CloseThese cards were retained because their original collection can no longer display them. Choose a new home or remove them explicitly.Wed 14 OctTodayNext0/3The three most important things to focus on next.DoneAnything you finished counts, planned or unplanned.AddScheduledThings planned for this day.AddThu 15 OctNext0/3The three most important things to focus on next.DoneKeep the first device writingUnlockRemoveAddScheduledThings planned for this day.AddFri 16 OctTodayNext0/3The three most important things to focus on next.DoneAnything you finished counts, planned or unplanned.AddScheduledThings planned for this day.AddGoalsRetry storageDiscard pending inputYour running list of tasks, projects, someday-maybes, notes to self, and ideas.Transfer selected linesCopy toMove toNextScheduledDone"
Timeout: 20000ms

Call log:
  - Expect "toContainText" with timeout 20000ms
  - waiting for locator('.shell')
    43 × locator resolved to <div class="shell" data-select="on" data-menu="closed" data-goals="closed" data-unfiled="closed" data-breakpoint="wide" data-local-workspace="true">…</div>
       - unexpected value "DayThu 15 Oct 2026Thu 8 OctTue 13 OctYesterdayTodayTomorrowSat 17 OctThu 22 OctGo to dateDataLocal dataBest-effortWriting is encrypted in this browser. Export a readable backup when you need one.Export markdownRemove from this deviceUndoRedoProtectionUnlock code enabled. Your local copy requires an unlock code.Lock workspaceAccountNameDevice ownerAccount IDU7pTTrDGCzHZybq17dDy2ryiDNqz5URjpkwbn6rKl1wSending: idleLast accepted upload: 1:18:33 PMAccepted position: 1Receiving: retryingLast successful receive check: None since openingReceived positions: 5Reason: receive:network-unavailableRetry receivingDevicesHistory maintenanceUse another accountAccount login remembered on this device.Sign outPersonalizeActorDevice ownerVersion5afdd0adDeviceDevice code13d3e60bNameColorDay rollover00:0001:0002:0003:0004:0005:0006:0007:0008:0009:0010:0011:0012:0013:0014:0015:0016:0017:0018:0019:0020:0021:0022:0023:00Save preferencesInstallCheck permission to keep local writing in this browser.You can also install done from your browser’s menu.InstallUnfiled0CloseThese cards were retained because their original collection can no longer display them. Choose a new home or remove them explicitly.Wed 14 OctTodayNext0/3The three most important things to focus on next.DoneAnything you finished counts, planned or unplanned.AddScheduledThings planned for this day.AddThu 15 OctNext0/3The three most important things to focus on next.DoneKeep the first device writingUnlockRemoveAddScheduledThings planned for this day.AddFri 16 OctTodayNext0/3The three most important things to focus on next.DoneAnything you finished counts, planned or unplanned.AddScheduledThings planned for this day.AddGoalsRetry storageDiscard pending inputYour running list of tasks, projects, someday-maybes, notes to self, and ideas.Transfer selected linesCopy toMove toNextScheduledDone"

```

```yaml
- complementary "Menu":
  - heading "Day" [level=2]
  - paragraph: Thu 15 Oct 2026
  - button "Thu 8 Oct"
  - button "Tue 13 Oct"
  - button "Yesterday"
  - button "Today"
  - button "Tomorrow"
  - button "Sat 17 Oct"
  - button "Thu 22 Oct"
  - text: Go to date
  - textbox "Go to date": 2026-10-15
  - heading "Data" [level=2]
  - text: Local data Best-effort
  - paragraph: Writing is encrypted in this browser. Export a readable backup when you need one.
  - button "Export markdown"
  - button "Remove from this device"
  - button "Undo" [disabled]
  - button "Redo" [disabled]
  - heading "Protection" [level=2]
  - paragraph: Unlock code enabled. Your local copy requires an unlock code.
  - button "Lock workspace"
  - heading "Account" [level=2]
  - text: Name Device owner Account ID
  - code: U7pTTrDGCzHZybq17dDy2ryiDNqz5URjpkwbn6rKl1w
  - complementary "Sync status":
    - paragraph: "Sending: idle"
    - paragraph: "Last accepted upload: 1:18:33 PM"
    - paragraph: "Accepted position: 1"
    - paragraph: "Receiving: retrying"
    - paragraph: "Last successful receive check: None since opening"
    - paragraph: "Received positions: 5"
    - paragraph:
      - text: "Reason:"
      - code: receive:network-unavailable
    - button "Retry receiving"
  - button "Devices"
  - button "History maintenance"
  - button "Use another account"
  - status: Account login remembered on this device.
  - button "Sign out"
  - heading "Personalize" [level=2]
  - text: Actor Device owner Version 5afdd0ad Device
  - textbox "Device name": Chrome - macOS
  - text: Device code
  - code: 13d3e60b
  - text: Name
  - textbox "Actor name": Device owner
  - text: Color
  - textbox "Actor color": "#e0662f"
  - text: Day rollover
  - combobox "Day rollover hour":
    - option "00:00" [selected]
    - option "01:00"
    - option "02:00"
    - option "03:00"
    - option "04:00"
    - option "05:00"
    - option "06:00"
    - option "07:00"
    - option "08:00"
    - option "09:00"
    - option "10:00"
    - option "11:00"
    - option "12:00"
    - option "13:00"
    - option "14:00"
    - option "15:00"
    - option "16:00"
    - option "17:00"
    - option "18:00"
    - option "19:00"
    - option "20:00"
    - option "21:00"
    - option "22:00"
    - option "23:00"
  - button "Save preferences"
  - region "Install":
    - heading "Install" [level=2]
    - paragraph: Check permission to keep local writing in this browser.
    - paragraph: You can also install done from your browser’s menu.
    - button "Install"
- button "Close unfiled cards"
- main "Days":
  - button "Go to Yesterday"
  - button "Go to Tomorrow"
  - region "Today":
    - heading "Thu 15 Oct" [level=1]
    - heading "Next 0 of 3" [level=2]: Next 0/3
    - paragraph: The three most important things to focus on next.
    - heading "Done" [level=2]
    - article:
      - text: Keep the first device writing
      - button "Unlock"
      - 'button "Remove this card: Keep the first device writing"': Remove
    - textbox "What got done?"
    - button "Add" [disabled]
    - heading "Scheduled" [level=2]
    - paragraph: Things planned for this day.
    - textbox "What’s scheduled?"
    - button "Add" [disabled]
- complementary "Goals":
  - heading "Goals. Open document outline" [level=2]:
    - button "Goals. Open document outline": Goals
  - status
  - textbox
  - group "Selected lines":
    - group "Transfer selected lines":
      - text: Transfer selected lines
      - radio "Copy to" [checked]
      - text: Copy to
      - radio "Move to"
      - text: Move to
    - button "More Goals actions"
    - button "Next" [disabled]
    - button "Scheduled" [disabled]
    - button "Done" [disabled]
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | import { pairedEditors, credentials, restoreAuthenticator, openSaved, add } from './devices';
  3  | import { startService, stopService, startBackend, stopProcess, origin } from './server';
  4  | 
  5  | test('packaged session host enrolls both devices, renews after restart and retains offline writing', async ({
  6  |   page,
  7  |   browser,
  8  |   request,
  9  | }, info) => {
  10 |   const state = info.outputPath('service');
  11 |   const service = await startService(state, undefined, true);
  12 |   let pair: Awaited<ReturnType<typeof pairedEditors>> | undefined;
  13 |   const errors: string[] = [],
  14 |     paths: string[] = [];
  15 |   let streams = 0;
  16 |   page.on('pageerror', (e) => errors.push(e.message));
  17 |   page.on('request', (r) => paths.push(new URL(r.url()).pathname));
  18 |   page.on('response', (r) => {
  19 |     if (new URL(r.url()).pathname === '/account/notifications/v1/subscribe' && r.status() === 200)
  20 |       streams++;
  21 |   });
  22 |   try {
  23 |     pair = await pairedEditors(page, browser, true, {
  24 |       beforeCompare: async () => {
  25 |         await expect.poll(() => streams).toBeGreaterThan(0);
  26 |         const input = page.getByLabel('Code on the new device');
  27 |         await input.fill('AB');
  28 |         // The comparison state starts a newly scoped subscription. Let its mandatory
  29 |         // ready/catch-up finish before measuring the subsequent idle interval.
  30 |         await page.waitForTimeout(1500);
  31 |         const before = paths.filter((p) => p === '/__account-setup/ceremony/exchange').length;
  32 |         // Deliberate observation window: ordinary 2.5s polling or a replay/hint loop would
  33 |         // run here. A live subscription preserves the comparison and focus without either.
  34 |         await page.waitForTimeout(5500);
  35 |         expect(
  36 |           paths.filter((p) => p === '/__account-setup/ceremony/exchange').length - before,
  37 |         ).toBe(0);
  38 |         await expect(input).toHaveValue('AB');
  39 |         await expect(input).toBeFocused();
  40 |       },
  41 |     });
  42 |     const config = await request.post('/__account-setup/config', {
  43 |       headers: { Origin: origin },
  44 |       data: {},
  45 |     });
  46 |     expect(await config.json()).toMatchObject({ v: 2, networkSessions: true });
  47 |     expect(
  48 |       (
  49 |         await request.post('/__account-setup/access', { headers: { Origin: origin }, data: {} })
  50 |       ).status(),
  51 |     ).toBe(404);
  52 |     await add(page, 'Session transport A to B');
> 53 |     await expect(pair.second.locator('.shell')).toContainText('Session transport A to B', {
     |                                                 ^ Error: expect(locator).toContainText(expected) failed
  54 |       timeout: 20000,
  55 |     });
  56 |     await add(pair.second, 'Session transport B to A');
  57 |     await expect(page.locator('.shell')).toContainText('Session transport B to A', {
  58 |       timeout: 20000,
  59 |     });
  60 |     // After catch-up, a healthy stream replaces the old five-second read loop.
  61 |     await page.waitForTimeout(1000);
  62 |     const reads = paths.filter((p) => p === '/account/delivery/read-v2').length;
  63 |     await page.waitForTimeout(6000);
  64 |     expect(paths.filter((p) => p === '/account/delivery/read-v2')).toHaveLength(reads);
  65 |     await stopProcess(service.backend);
  66 |     await add(page, 'Queued across session service restart');
  67 |     service.backend = await startBackend(state, true);
  68 |     await expect(pair.second.locator('.shell')).toContainText(
  69 |       'Queued across session service restart',
  70 |       { timeout: 20000 },
  71 |     );
  72 |     const saved = await credentials(pair.next.auth);
  73 |     await pair.second.getByRole('button', { name: 'Lock workspace', exact: true }).click();
  74 |     await pair.other.setOffline(true);
  75 |     await pair.second.close();
  76 |     const reopened = await pair.other.newPage();
  77 |     await restoreAuthenticator(reopened, saved);
  78 |     await reopened.goto(origin + '/');
  79 |     await openSaved(reopened, pair.next.code, true);
  80 |     await add(reopened, 'Offline session reopening');
  81 |     await pair.other.setOffline(false);
  82 |     await expect(page.locator('.shell')).toContainText('Offline session reopening', {
  83 |       timeout: 20000,
  84 |     });
  85 |     expect(paths).toContain('/account/grant/v1/finish');
  86 |     expect(paths).not.toContain('/__account-setup/access');
  87 |     expect(errors).toEqual([]);
  88 |   } finally {
  89 |     await pair?.other.close();
  90 |     await stopService(service);
  91 |   }
  92 | });
  93 | 
```
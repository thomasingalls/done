# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: missed-rotations.spec.ts >> an offline device resumes two missed rotations in order and delivers its old-generation writing
- Location: test/packaged-account/missed-rotations.spec.ts:8:1

# Error details

```
TimeoutError: locator.click: Timeout 15000ms exceeded.
Call log:
  - waiting for locator('.account-device-list li').filter({ hasText: 'Device 79ace397' }).getByRole('button', { name: 'Remove device', exact: true })

```

# Page snapshot

```yaml
- main "Devices" [ref=e4]:
  - generic [ref=e5]:
    - paragraph [ref=e6]: done
    - heading "Devices" [active] [level=1] [ref=e7]
    - generic [ref=e8]:
      - generic [ref=e9]: Account ID
      - code [ref=e10]: 8hWzpkycJG9LQ57h9pjnH3Dvem9IrzqPprrvMqu5E1w
    - paragraph [ref=e11]: Devices in this account’s last verified state, saved on this device. Changes made elsewhere may not appear here yet.
    - list [ref=e12]:
      - listitem [ref=e13]:
        - heading [level=2] [ref=e14]:
          - text: Chrome - macOS · This device ·
          - code [ref=e15]: 27f3c9d8
        - paragraph [ref=e16]: Approved for content and sync
        - paragraph [ref=e17]: Protected here by your device-lock code.
      - listitem [ref=e18]:
        - heading [level=2] [ref=e19]:
          - text: Chrome - macOS ·
          - code [ref=e20]: 39c54c8f
        - paragraph [ref=e21]: Approved for content and sync
        - paragraph [ref=e22]: Key-storage details are not recorded for this device.
        - button "Remove device" [ref=e23] [cursor=pointer]
      - listitem [ref=e24]:
        - heading [level=2] [ref=e25]:
          - text: Chrome - macOS ·
          - code [ref=e26]: 79ace397
        - paragraph [ref=e27]: Approved for content and sync
        - paragraph [ref=e28]: Key-storage details are not recorded for this device.
        - button "Remove device" [ref=e29] [cursor=pointer]
      - listitem [ref=e30]:
        - heading [level=2] [ref=e31]:
          - text: Chrome - macOS ·
          - code [ref=e32]: d26fcf3d
        - paragraph [ref=e33]: Approved for content and sync
        - paragraph [ref=e34]: Key-storage details are not recorded for this device.
        - button "Remove device" [ref=e35] [cursor=pointer]
    - button "Connect another device" [ref=e36] [cursor=pointer]
    - button "Back to writing" [ref=e37] [cursor=pointer]
```

# Test source

```ts
  13  |   page.setDefaultTimeout(15000);
  14  |   const built = await build({
  15  |     configFile: false,
  16  |     logLevel: 'error',
  17  |     build: {
  18  |       write: false,
  19  |       minify: false,
  20  |       lib: {
  21  |         entry: resolve('test/account-membership/custody-entry.ts'),
  22  |         name: 'MembershipCustody',
  23  |         formats: ['iife'],
  24  |       },
  25  |     },
  26  |   });
  27  |   const result = Array.isArray(built) ? built[0]! : built;
  28  |   if (!('output' in result)) throw Error('No probe');
  29  |   const chunk = result.output.find((o) => o.type === 'chunk');
  30  |   if (!chunk || chunk.type !== 'chunk') throw Error('No probe');
  31  |   const service = await startService(info.outputPath('service'), undefined, true, true);
  32  |   const thirdContext = await browser.newContext(),
  33  |     fourthContext = await browser.newContext();
  34  |   const third = await thirdContext.newPage(),
  35  |     fourth = await fourthContext.newPage();
  36  |   for (const p of [third, fourth]) p.setDefaultTimeout(15000);
  37  |   let pair: Awaited<ReturnType<typeof pairedEditors>> | undefined;
  38  |   try {
  39  |     pair = await pairedEditors(page, browser, true);
  40  |     const connect = async (owner: Page, code: string, joining: Page) => {
  41  |       await owner.getByRole('button', { name: 'Devices', exact: true }).click();
  42  |       await owner.getByRole('button', { name: 'Connect another device', exact: true }).click();
  43  |       await unlock(owner, code);
  44  |       const next = await pending(
  45  |         joining,
  46  |         await owner.getByLabel('Device invitation link').inputValue(),
  47  |         pair!.next.auth,
  48  |       );
  49  |       await expect
  50  |         .poll(
  51  |           async () => {
  52  |             for (const p of [owner, joining]) {
  53  |               if (
  54  |                 await p
  55  |                   .getByText('The account service is busy. Saved progress can be retried.', {
  56  |                     exact: true,
  57  |                   })
  58  |                   .isVisible()
  59  |               ) {
  60  |                 const retry = p.getByRole('button', { name: 'Check again', exact: true });
  61  |                 if (await retry.isEnabled()) await retry.click();
  62  |               }
  63  |             }
  64  |             return owner.getByLabel('Code on the new device').isVisible();
  65  |           },
  66  |           { timeout: 45000, intervals: [2000] },
  67  |         )
  68  |         .toBe(true);
  69  |       const comparison = await compared(owner, joining);
  70  |       await owner.getByLabel('Code on the new device').fill(comparison);
  71  |       await owner.getByRole('button', { name: 'Compare and approve', exact: true }).click();
  72  |       await joining
  73  |         .getByRole('button', { name: 'Open your writing', exact: true })
  74  |         .click({ timeout: 30000 });
  75  |       await expect(owner.getByText('The device is connected.', { exact: false })).toBeVisible({
  76  |         timeout: 30000,
  77  |       });
  78  |       await owner.getByRole('link', { name: 'Close and return to accounts' }).click();
  79  |       return next;
  80  |     };
  81  |     const three = await connect(pair.second, pair.next.code, third);
  82  |     const four = await connect(third, three.code, fourth);
  83  |     await add(fourth, 'Four devices before rotation');
  84  |     await expect(page.locator('.shell')).toContainText('Four devices before rotation', {
  85  |       timeout: 20000,
  86  |     });
  87  |     const targets: string[] = [];
  88  |     for (const [p, code] of [
  89  |       [pair.second, pair.next.code],
  90  |       [third, three.code],
  91  |     ] as const) {
  92  |       await p.goto('/');
  93  |       await p.evaluate(chunk.code);
  94  |       targets.push(
  95  |         await p.evaluate(
  96  |           async (code) =>
  97  |             window.MembershipCustody.participant(
  98  |               'joined',
  99  |               await window.MembershipCustody.accountSlot(),
  100 |               code,
  101 |             ),
  102 |           code,
  103 |         ),
  104 |       );
  105 |     }
  106 |     await fourthContext.setOffline(true);
  107 |     await add(fourth, 'Offline across two membership rotations');
  108 |     for (const [i, target] of targets.entries()) {
  109 |       await page.getByRole('button', { name: 'Devices', exact: true }).click();
  110 |       const row = page
  111 |         .locator('.account-device-list li')
  112 |         .filter({ hasText: 'Device ' + target.slice(0, 8) });
> 113 |       await row.getByRole('button', { name: 'Remove device', exact: true }).click();
      |                                                                             ^ TimeoutError: locator.click: Timeout 15000ms exceeded.
  114 |       await page.getByRole('button', { name: 'Confirm removal', exact: true }).click();
  115 |       await expect(
  116 |         page.getByText(/^(The device was removed\.|Device removal is saved but not confirmed\.)/),
  117 |       ).toBeVisible({ timeout: 25000 });
  118 |       await expect(page.locator('.shell')).toHaveCount(0, { timeout: 25000 });
  119 |       await page.goto('/');
  120 |       await openSaved(page, pair.first.code);
  121 |       await page.getByRole('button', { name: 'Devices', exact: true }).click();
  122 |       await expect(page.locator('.account-device-list li')).toHaveCount(3 - i);
  123 |       await page.getByRole('button', { name: 'Back to writing', exact: true }).click();
  124 |       console.log('Repeated UI removal completed', i + 1);
  125 |     }
  126 |     await fourthContext.setOffline(false);
  127 |     await expect(fourth.locator('.shell')).toHaveCount(0, { timeout: 25000 });
  128 |     await fourth.goto('/');
  129 |     await openSaved(fourth, four.code, true);
  130 |     await expect(fourth.locator('.shell')).toContainText('Offline across two membership rotations');
  131 |     await expect(page.locator('.shell')).toContainText('Offline across two membership rotations', {
  132 |       timeout: 20000,
  133 |     });
  134 |     await add(page, 'Current generation after skipped rotations');
  135 |     await expect(fourth.locator('.shell')).toContainText(
  136 |       'Current generation after skipped rotations',
  137 |       { timeout: 20000 },
  138 |     );
  139 |     await add(fourth, 'Rejoined survivor sends generation three');
  140 |     await expect(page.locator('.shell')).toContainText('Rejoined survivor sends generation three', {
  141 |       timeout: 20000,
  142 |     });
  143 |     await fourth.getByRole('button', { name: 'Lock workspace', exact: true }).click();
  144 |     await fourth.goto('/');
  145 |     await openSaved(fourth, four.code, true);
  146 |     await expect(fourth.locator('.shell')).toContainText(
  147 |       'Rejoined survivor sends generation three',
  148 |     );
  149 |   } finally {
  150 |     await pair?.other.close();
  151 |     await thirdContext.close();
  152 |     await fourthContext.close();
  153 |     await stopService(service);
  154 |   }
  155 | });
  156 | 
```
# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: packaged.spec.ts >> packaged /local.html locks and cold-opens offline with accepted writing
- Location: test/local-app/packaged.spec.ts:36:3

# Error details

```
Error: expect(locator).toHaveAttribute(expected) failed

Locator: locator('.local-startup')
Expected: "fresh"
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toHaveAttribute" with timeout 5000ms
  - waiting for locator('.local-startup')
    - locator resolved to <main data-state="checking" class="local-startup workspace-gate">…</main>
    - unexpected value "checking"

```

```yaml
- complementary "Menu":
  - heading "Day" [level=2]
  - paragraph: Thu 15 Oct 2026
  - button "Thu 8 Oct"
  - button "Tue 13 Oct"
  - button "Yesterday"
  - button "Today"
  - button "Tomorrow"
  - button "Sat 17 Oct"
  - button "Thu 22 Oct"
  - text: Go to date
  - textbox "Go to date": 2026-10-15
  - heading "Data" [level=2]
  - text: Local data Best-effort
  - paragraph: Writing is encrypted in this browser. Export a readable backup when you need one.
  - button "Export markdown"
  - button "Remove from this device"
  - button "Undo" [disabled]
  - button "Redo" [disabled]
  - heading "Protection" [level=2]
  - paragraph: Opens automatically. Anyone using this browser can open your list.
  - button "Add an unlock code"
  - heading "Sync" [level=2]
  - paragraph: Saved only in this browser. Sync is off.
  - heading "Personalize" [level=2]
  - text: Actor You Version 5afdd0ad Device
  - textbox "Device name": Chrome - macOS
  - text: Name
  - textbox "Actor name": You
  - text: Color
  - textbox "Actor color": "#e0662f"
  - text: Day rollover
  - combobox "Day rollover hour":
    - option "00:00" [selected]
    - option "01:00"
    - option "02:00"
    - option "03:00"
    - option "04:00"
    - option "05:00"
    - option "06:00"
    - option "07:00"
    - option "08:00"
    - option "09:00"
    - option "10:00"
    - option "11:00"
    - option "12:00"
    - option "13:00"
    - option "14:00"
    - option "15:00"
    - option "16:00"
    - option "17:00"
    - option "18:00"
    - option "19:00"
    - option "20:00"
    - option "21:00"
    - option "22:00"
    - option "23:00"
  - button "Save preferences"
  - region "Install":
    - heading "Install" [level=2]
    - paragraph: Check permission to keep local writing in this browser.
    - paragraph: You can also install done from your browser’s menu.
    - button "Install"
- button "Close unfiled cards"
- main "Days":
  - button "Go to Yesterday"
  - button "Go to Tomorrow"
  - region "Today":
    - heading "Thu 15 Oct" [level=1]
    - complementary "Getting started":
      - paragraph: Write everything in Goals. Choose three things for Next. Record what got done.
      - button "Open Goals"
      - button "Dismiss introduction": Dismiss
    - heading "Next 0 of 3" [level=2]: Next 0/3
    - paragraph: The three most important things to focus on next.
    - heading "Done" [level=2]
    - paragraph: Anything you finished counts, planned or unplanned.
    - textbox "What got done?"
    - button "Add" [disabled]
    - heading "Scheduled" [level=2]
    - paragraph: Things planned for this day.
    - textbox "What’s scheduled?"
    - button "Add" [disabled]
- complementary "Goals":
  - heading "Goals. Open document outline" [level=2]:
    - button "Goals. Open document outline": Goals
  - status
  - textbox
  - group "Selected lines":
    - group "Transfer selected lines":
      - text: Transfer selected lines
      - radio "Copy to" [checked]
      - text: Copy to
      - radio "Move to"
      - text: Move to
    - button "More Goals actions"
    - button "Next" [disabled]
    - button "Scheduled" [disabled]
    - button "Done" [disabled]
```

# Test source

```ts
  1   | import { test } from '../release-validation/browser-fixture';
  2   | import { expect } from '@playwright/test';
  3   | import { readFile, access } from 'node:fs/promises';
  4   | import { join, resolve } from 'node:path';
  5   | 
  6   | const releaseRoot = resolve(process.env['LOCAL_STARTUP_PREVIEW_ROOT'] ?? 'dist');
  7   | 
  8   | test('packaged precache names real files and serves their exact bytes', async ({ request }) => {
  9   |   const worker = await readFile(join(releaseRoot, 'sw.js'), 'utf8');
  10  |   const entries = JSON.parse(
  11  |     worker.match(/const PRECACHE = ([\s\S]*?);\nconst URLS/)![1]!,
  12  |   ) as string[];
  13  |   expect(entries).toEqual(expect.arrayContaining(['/', '/index.html', '/local.html']));
  14  |   for (const path of entries) {
  15  |     const file = join(releaseRoot, path === '/' ? 'index.html' : path.slice(1));
  16  |     await access(file); // A preview server's HTML fallback must not disguise a missing asset.
  17  |     const response = await request.get(path);
  18  |     expect(response.status()).toBe(200);
  19  |     expect(await response.body()).toEqual(await readFile(file));
  20  |   }
  21  |   expect(entries).toEqual(
  22  |     expect.arrayContaining([
  23  |       '/manifest.webmanifest',
  24  |       '/favicon.svg',
  25  |       '/icon-192.png',
  26  |       '/icon-512.png',
  27  |       '/icon-maskable-512.png',
  28  |     ]),
  29  |   );
  30  |   expect(entries.some((path) => /private|migration|recovery|binding|\.map$/u.test(path))).toBe(
  31  |     false,
  32  |   );
  33  | });
  34  | 
  35  | for (const entry of ['/', '/local.html']) {
  36  |   test(`packaged ${entry} locks and cold-opens offline with accepted writing`, async ({
  37  |     page,
  38  |     context,
  39  |   }) => {
  40  |     const errors: string[] = [];
  41  |     page.on('pageerror', (error) => errors.push(error.message));
  42  |     await page.goto(entry);
> 43  |     await expect(page.locator('.local-startup')).toHaveAttribute('data-state', 'fresh');
      |                                                  ^ Error: expect(locator).toHaveAttribute(expected) failed
  44  |     await page.getByRole('button', { name: 'Create a local-only workspace' }).click();
  45  |     const code = (await page.getByLabel('Generated device-lock code').textContent())!;
  46  |     await page.getByRole('button', { name: 'I saved my code' }).click();
  47  |     await page.getByLabel('Device-lock code', { exact: true }).fill(code);
  48  |     await page.getByRole('button', { name: 'Confirm and create' }).click();
  49  |     const compose = page.locator(
  50  |       '.day-panel[data-active="true"] .collection[data-section="done"] .compose-field',
  51  |     );
  52  |     await expect(compose).toBeVisible();
  53  |     await compose.fill('Offline encrypted writing');
  54  |     await compose.press('Enter');
  55  |     await expect(page.locator('.day-panel[data-active="true"] .card')).toContainText(
  56  |       'Offline encrypted writing',
  57  |     );
  58  |     await page.getByRole('button', { name: 'Lock workspace' }).click();
  59  |     await expect(page.locator('.local-startup')).toHaveAttribute('data-state', 'unlock-required');
  60  |     await expect(page.getByText('Offline encrypted writing')).toHaveCount(0);
  61  |     await page.evaluate(() => navigator.serviceWorker.ready.then(() => {}));
  62  |     await context.setOffline(true);
  63  |     await page.close();
  64  |     const offline = await context.newPage();
  65  |     offline.on('pageerror', (error) => errors.push(error.message));
  66  |     await offline.goto(entry);
  67  |     await expect(offline.locator('.local-startup')).toHaveAttribute(
  68  |       'data-state',
  69  |       'unlock-required',
  70  |     );
  71  |     await offline.getByLabel('Device-lock code', { exact: true }).fill(code);
  72  |     await offline.getByRole('button', { name: 'Unlock', exact: true }).click();
  73  |     await expect(offline.locator('.day-panel[data-active="true"] .card')).toContainText(
  74  |       'Offline encrypted writing',
  75  |     );
  76  |     await offline
  77  |       .locator('.day-panel[data-active="true"] .collection[data-section="done"] .compose-field')
  78  |       .fill('Written while offline');
  79  |     await offline
  80  |       .locator('.day-panel[data-active="true"] .collection[data-section="done"] .compose-field')
  81  |       .press('Enter');
  82  |     await expect(
  83  |       offline.locator('.card').filter({ hasText: 'Written while offline' }),
  84  |     ).toBeVisible();
  85  |     await offline.getByRole('button', { name: 'Lock workspace' }).click();
  86  |     await expect(offline.locator('.local-startup')).toHaveAttribute(
  87  |       'data-state',
  88  |       'unlock-required',
  89  |     );
  90  |     await offline.close();
  91  |     const reopened = await context.newPage();
  92  |     reopened.on('pageerror', (error) => errors.push(error.message));
  93  |     await reopened.goto(entry);
  94  |     await reopened.getByLabel('Device-lock code', { exact: true }).fill(code);
  95  |     await reopened.getByRole('button', { name: 'Unlock', exact: true }).click();
  96  |     await expect(
  97  |       reopened.locator('.card').filter({ hasText: 'Written while offline' }),
  98  |     ).toBeVisible();
  99  |     expect(
  100 |       await reopened.evaluate(async () =>
  101 |         (await indexedDB.databases()).some((db) => db.name === 'done'),
  102 |       ),
  103 |     ).toBe(false);
  104 |     expect(errors).toEqual([]);
  105 |     await reopened.close();
  106 |   });
  107 | }
  108 | 
```
# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: upgrade.spec.ts >> schema-five account retains its original passkey, authority, name, code and writing after upgrade
- Location: test/first-device-upgrade/upgrade.spec.ts:59:1

# Error details

```
Error: expect(received).toContain(expected) // indexOf

Expected substring: "schema 5 → 8"
Received string:    "Account preview upgraded: schema 5 → 11. Backup: <test-checkout>/test-results/account-upgrade-recheck/artifacts/upgrade-schema-five-accoun-6e62f-e-and-writing-after-upgrade/service/backups/schema-5-AP60g3
"
```

# Test source

```ts
  60  |   page,
  61  | }, testInfo) => {
  62  |   const baseline = process.env['ACCOUNT_SETUP_UPGRADE_BASE'];
  63  |   if (!baseline)
  64  |     throw Error(
  65  |       'Set ACCOUNT_SETUP_UPGRADE_BASE to a schema-five preview checkout (7dab01cc). Run this test after integrating the schema-eight backend.',
  66  |     );
  67  |   const state = testInfo.outputPath('service');
  68  |   mkdirSync(state, { recursive: true, mode: 0o700 });
  69  |   const env = { ...process.env, ACCOUNT_SETUP_PORT: port, ACCOUNT_SETUP_STATE: state };
  70  |   const children: ChildProcess[] = [];
  71  |   async function start(root: string) {
  72  |     const child = spawn(process.execPath, ['scripts/dev-account-setup.mjs'], {
  73  |       cwd: root,
  74  |       env,
  75  |       stdio: ['ignore', 'pipe', 'pipe'],
  76  |     });
  77  |     children.push(child);
  78  |     await new Promise<void>((accept, reject) => {
  79  |       let output = '';
  80  |       const timer = setTimeout(() => reject(Error(`Preview startup timed out: ${output}`)), 30000);
  81  |       child.once('error', reject);
  82  |       child.once('exit', (code) => {
  83  |         clearTimeout(timer);
  84  |         reject(Error(`Preview exited (${code}): ${output}`));
  85  |       });
  86  |       const chunk = (data: Buffer) => {
  87  |         output = (output + data.toString()).slice(-8000);
  88  |         if (output.includes('Account setup development:')) {
  89  |           clearTimeout(timer);
  90  |           accept();
  91  |         }
  92  |       };
  93  |       child.stdout!.on('data', chunk);
  94  |       child.stderr!.on('data', chunk);
  95  |     });
  96  |     return child;
  97  |   }
  98  |   try {
  99  |     const old = await start(resolve(baseline));
  100 |     await page.goto(entry);
  101 |     const cdp = await page.context().newCDPSession(page);
  102 |     await cdp.send('WebAuthn.enable');
  103 |     const { authenticatorId } = await cdp.send('WebAuthn.addVirtualAuthenticator', {
  104 |       options: {
  105 |         protocol: 'ctap2',
  106 |         transport: 'internal',
  107 |         hasResidentKey: true,
  108 |         hasUserVerification: true,
  109 |         isUserVerified: true,
  110 |         automaticPresenceSimulation: true,
  111 |       },
  112 |     });
  113 |     await page.getByRole('button', { name: 'I already have a workspace', exact: true }).click();
  114 |     await page.getByRole('button', { name: 'Create a new account', exact: true }).click();
  115 |     await page.getByLabel('Your name', { exact: true }).fill('Alex');
  116 |     await page.getByRole('button', { name: 'Create account', exact: true }).click();
  117 |     const code = (await page.getByLabel('Generated device-lock code').textContent())!;
  118 |     await page.getByRole('button', { name: 'I saved my device-lock code' }).click();
  119 |     await page.getByLabel('Device-lock code', { exact: true }).fill(code);
  120 |     await page.getByRole('button', { name: 'Confirm device-lock code' }).click();
  121 |     await page.getByRole('button', { name: 'Create passkey', exact: true }).click();
  122 |     await page.getByRole('button', { name: 'Use my passkey', exact: true }).click();
  123 |     const recovery = (await page.getByLabel('Generated recovery code').textContent())!;
  124 |     await page.getByRole('button', { name: 'I saved my recovery code' }).click();
  125 |     await page.getByLabel('Recovery code', { exact: true }).fill(recovery);
  126 |     await page.getByRole('button', { name: 'Finish account setup', exact: true }).click();
  127 |     await expect(page.locator('.shell')).toBeVisible();
  128 |     const id = (await page.getByLabel('Account ID', { exact: true }).textContent())!;
  129 |     const compose = page.locator(
  130 |       '.day-panel[data-active="true"] .collection[data-section="done"] .compose-field',
  131 |     );
  132 |     await compose.fill('Writing saved before the service upgrade');
  133 |     await compose.press('Enter');
  134 |     await expect(page.locator('.day-panel[data-active="true"] .card')).toContainText(
  135 |       'Writing saved before the service upgrade',
  136 |     );
  137 |     const credentials = await cdp.send('WebAuthn.getCredentials', { authenticatorId });
  138 |     expect(credentials.credentials).toHaveLength(1);
  139 |     await page.getByRole('button', { name: 'Lock workspace' }).click();
  140 |     await expect(page.getByLabel('Device-lock code', { exact: true })).toBeVisible();
  141 |     await page.goto('about:blank');
  142 |     await stop(old);
  143 |     const before = retainedRows(join(state, 'account.sqlite'));
  144 |     const authority = retainedRows(join(state, 'authority.sqlite'));
  145 |     const key = readFileSync(join(state, 'operator.key'));
  146 |     const pin = readFileSync(join(state, 'pin.json'));
  147 |     // Normal startup must not migrate implicitly, and a failed startup must release its lock.
  148 |     expect(() =>
  149 |       execFileSync(process.execPath, ['scripts/dev-account-setup.mjs'], {
  150 |         env,
  151 |         timeout: 15000,
  152 |         stdio: 'pipe',
  153 |       }),
  154 |     ).toThrow(/explicit offline upgrade/);
  155 |     const output = execFileSync(process.execPath, ['scripts/upgrade-account-setup.mjs'], {
  156 |       env,
  157 |       encoding: 'utf8',
  158 |       timeout: 30000,
  159 |     });
> 160 |     expect(output).toContain('schema 5 → 8');
      |                    ^ Error: expect(received).toContain(expected) // indexOf
  161 |     const snapshot = output.split('Backup: ')[1]!.trim();
  162 |     expect(retainedRows(join(snapshot, 'account.sqlite'))).toEqual(before);
  163 |     expect(retainedRows(join(snapshot, 'authority.sqlite'))).toEqual(authority);
  164 |     expect(readFileSync(join(snapshot, 'operator.key'))).toEqual(key);
  165 |     expect(readFileSync(join(snapshot, 'pin.json'))).toEqual(pin);
  166 |     expect(retainedRows(join(state, 'account.sqlite'), before.columns)).toEqual(before);
  167 |     expect(retainedRows(join(state, 'authority.sqlite'))).toEqual(authority);
  168 |     expect(readFileSync(join(state, 'operator.key'))).toEqual(key);
  169 |     expect(readFileSync(join(state, 'pin.json'))).toEqual(pin);
  170 |     const second = execFileSync(process.execPath, ['scripts/upgrade-account-setup.mjs'], {
  171 |       env,
  172 |       encoding: 'utf8',
  173 |       timeout: 30000,
  174 |     });
  175 |     expect(second).toContain('already uses schema 8');
  176 |     await start(process.cwd());
  177 |     await page.goto(entry);
  178 |     await expect(page.getByLabel('Account ID', { exact: true })).toHaveText(id);
  179 |     await page.getByLabel('Device-lock code', { exact: true }).fill(code);
  180 |     await page
  181 |       .getByRole('button', { name: 'Confirm code and unlock with passkey', exact: true })
  182 |       .click();
  183 |     await expect(page.locator('.shell')).toBeVisible();
  184 |     await expect(page.getByLabel('Actor name', { exact: true })).toHaveValue('Alex');
  185 |     await expect(page.locator('.day-panel[data-active="true"] .card')).toContainText(
  186 |       'Writing saved before the service upgrade',
  187 |     );
  188 |     await page.getByRole('button', { name: 'Use another account', exact: true }).click();
  189 |     await page.getByRole('button', { name: 'Use another account', exact: true }).click();
  190 |     await expect(page.getByRole('heading', { name: 'Account verified' })).toBeVisible();
  191 |     expect(await page.getByLabel('Account ID', { exact: true }).allTextContents()).toEqual([
  192 |       id,
  193 |       id,
  194 |     ]);
  195 |     const after = await cdp.send('WebAuthn.getCredentials', { authenticatorId });
  196 |     expect(after.credentials.map((credential) => credential.credentialId)).toEqual(
  197 |       credentials.credentials.map((credential) => credential.credentialId),
  198 |     );
  199 |   } finally {
  200 |     await page.goto('about:blank');
  201 |     for (const child of children) await stop(child);
  202 |   }
  203 | });
  204 | 
```
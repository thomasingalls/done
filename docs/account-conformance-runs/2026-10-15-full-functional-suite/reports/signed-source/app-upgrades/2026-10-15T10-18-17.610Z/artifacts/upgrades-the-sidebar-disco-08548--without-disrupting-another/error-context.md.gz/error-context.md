# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: upgrades.spec.ts >> the sidebar discovers an update on reconnect and reloads one tab without disrupting another
- Location: test/app-upgrades/upgrades.spec.ts:176:1

# Error details

```
Test timeout of 35000ms exceeded.
```

```
Error: locator.click: Test timeout of 35000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: 'Create a local-only workspace' })

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - complementary "Menu" [ref=e4]:
    - generic [ref=e5]:
      - heading "Day" [level=2] [ref=e6]
      - paragraph [ref=e7]: Thu 15 Oct 2026
      - generic [ref=e8]:
        - button "Thu 8 Oct" [ref=e9] [cursor=pointer]
        - button "Tue 13 Oct" [ref=e10] [cursor=pointer]
        - button "Yesterday" [ref=e11] [cursor=pointer]
        - button "Today" [ref=e12] [cursor=pointer]
        - button "Tomorrow" [ref=e13] [cursor=pointer]
        - button "Sat 17 Oct" [ref=e14] [cursor=pointer]
        - button "Thu 22 Oct" [ref=e15] [cursor=pointer]
      - generic [ref=e16]:
        - text: Go to date
        - textbox "Go to date" [ref=e17]: 2026-10-15
    - generic [ref=e18]:
      - heading "Data" [level=2] [ref=e19]
      - generic [ref=e20]:
        - generic [ref=e21]: Local data
        - generic [ref=e22]: Best-effort
      - paragraph [ref=e23]: Writing is encrypted in this browser. Export a readable backup when you need one.
      - button "Export markdown" [ref=e24] [cursor=pointer]
      - button "Remove from this device" [ref=e25] [cursor=pointer]
      - generic [ref=e26]:
        - button "Undo" [disabled] [ref=e27] [cursor=pointer]
        - button "Redo" [disabled] [ref=e28] [cursor=pointer]
    - generic [ref=e29]:
      - heading "Protection" [level=2] [ref=e30]
      - paragraph [ref=e31]: Opens automatically. Anyone using this browser can open your list.
      - button "Add an unlock code" [ref=e32] [cursor=pointer]
    - generic [ref=e33]:
      - heading "Sync" [level=2] [ref=e34]
      - button "Use another account" [ref=e35] [cursor=pointer]
      - paragraph [ref=e36]: Saved only in this browser. Sync is off.
      - button "Set up sync" [ref=e37] [cursor=pointer]
    - generic [ref=e38]:
      - heading "Personalize" [level=2] [ref=e39]
      - generic [ref=e40]:
        - generic [ref=e41]: Actor
        - generic [ref=e42]: You
      - generic [ref=e44]:
        - generic [ref=e45]: Version
        - generic [ref=e46]: upgrade-a
      - generic [ref=e47]:
        - generic [ref=e48]:
          - generic [ref=e49]: Device
          - textbox "Device name" [ref=e50]: Chrome - macOS
        - generic [ref=e51]:
          - generic [ref=e52]: Name
          - textbox "Actor name" [ref=e53]: You
        - generic [ref=e54]:
          - generic [ref=e55]: Color
          - textbox "Actor color" [ref=e56]: "#e0662f"
        - generic [ref=e57]:
          - generic [ref=e58]: Day rollover
          - combobox "Day rollover hour" [ref=e59]:
            - option "00:00" [selected]
            - option "01:00"
            - option "02:00"
            - option "03:00"
            - option "04:00"
            - option "05:00"
            - option "06:00"
            - option "07:00"
            - option "08:00"
            - option "09:00"
            - option "10:00"
            - option "11:00"
            - option "12:00"
            - option "13:00"
            - option "14:00"
            - option "15:00"
            - option "16:00"
            - option "17:00"
            - option "18:00"
            - option "19:00"
            - option "20:00"
            - option "21:00"
            - option "22:00"
            - option "23:00"
        - button "Save preferences" [ref=e60] [cursor=pointer]
    - region "Install" [ref=e61]:
      - heading "Install" [level=2] [ref=e62]
      - paragraph [ref=e63]: Check permission to keep local writing in this browser.
      - paragraph [ref=e64]: You can also install done from your browser’s menu.
      - button "Install" [ref=e65] [cursor=pointer]
  - complementary [ref=e66]:
    - generic [ref=e67]:
      - heading [level=2] [ref=e68]: Unfiled
      - generic [ref=e69]: "0"
      - button [ref=e70] [cursor=pointer]: Close
    - paragraph [ref=e72]: These cards were retained because their original collection can no longer display them. Choose a new home or remove them explicitly.
  - button "Close unfiled cards"
  - main "Days" [ref=e74]:
    - generic:
      - button "Go to Yesterday" [ref=e75] [cursor=pointer]
      - button "Go to Tomorrow" [ref=e76] [cursor=pointer]
    - generic [ref=e77]:
      - region:
        - generic:
          - heading [level=1]: Wed 14 Oct
          - button: Today
        - generic:
          - generic:
            - heading [level=2]:
              - generic: Next
              - generic: 0/3
            - paragraph: The three most important things to focus on next.
          - generic:
            - heading [level=2]:
              - generic: Done
            - paragraph: Anything you finished counts, planned or unplanned.
            - generic:
              - textbox:
                - /placeholder: What got done?
              - button [disabled]: Add
          - generic:
            - heading [level=2]:
              - generic: Scheduled
            - paragraph: Things planned for this day.
            - generic:
              - textbox:
                - /placeholder: What’s scheduled?
              - button [disabled]: Add
      - region "Today" [ref=e78]:
        - heading "Thu 15 Oct" [level=1] [ref=e80]
        - generic [ref=e81]:
          - complementary "Getting started" [ref=e82]:
            - paragraph [ref=e83]: Write everything in Goals. Choose three things for Next. Record what got done.
            - button "Open Goals" [ref=e84] [cursor=pointer]
            - button "Dismiss introduction" [ref=e85] [cursor=pointer]: Dismiss
          - generic [ref=e86]:
            - heading "Next 0 of 3" [level=2] [ref=e87]:
              - generic [ref=e88]: Next
              - generic "0 of 3" [ref=e89]: 0/3
            - paragraph [ref=e90]: The three most important things to focus on next.
          - generic [ref=e91]:
            - heading "Done" [level=2] [ref=e92]
            - paragraph [ref=e94]: Anything you finished counts, planned or unplanned.
            - generic [ref=e95]:
              - textbox "What got done?" [ref=e96]
              - button "Add" [disabled] [ref=e97]
          - generic [ref=e98]:
            - heading "Scheduled" [level=2] [ref=e99]
            - paragraph [ref=e101]: Things planned for this day.
            - generic [ref=e102]:
              - textbox "What’s scheduled?" [ref=e103]
              - button "Add" [disabled] [ref=e104]
      - region:
        - generic:
          - heading [level=1]: Fri 16 Oct
          - button: Today
        - generic:
          - generic:
            - heading [level=2]:
              - generic: Next
              - generic: 0/3
            - paragraph: The three most important things to focus on next.
          - generic:
            - heading [level=2]:
              - generic: Done
            - paragraph: Anything you finished counts, planned or unplanned.
            - generic:
              - textbox:
                - /placeholder: What got done?
              - button [disabled]: Add
          - generic:
            - heading [level=2]:
              - generic: Scheduled
            - paragraph: Things planned for this day.
            - generic:
              - textbox:
                - /placeholder: What’s scheduled?
              - button [disabled]: Add
  - complementary "Goals" [ref=e105]:
    - heading [level=2] [ref=e107]:
      - button "Goals. Open document outline" [ref=e108] [cursor=pointer]:
        - generic [ref=e109]: Goals
    - generic [ref=e114]:
      - status
      - textbox [ref=e117]:
        - generic [ref=e118]: Your running list of tasks, projects, someday-maybes, notes to self, and ideas.
    - group "Selected lines" [ref=e120]:
      - generic [ref=e121]:
        - group "Transfer selected lines" [ref=e122]:
          - generic [ref=e124] [cursor=pointer]:
            - radio "Copy to" [checked] [ref=e125]
            - generic: Copy to
          - generic [ref=e126] [cursor=pointer]:
            - radio "Move to" [ref=e127]
            - generic: Move to
        - button "More Goals actions" [ref=e129] [cursor=pointer]
      - generic [ref=e134]:
        - button "Next" [disabled] [ref=e135]
        - button "Scheduled" [disabled] [ref=e136]
        - button "Done" [disabled] [ref=e137]
```

# Test source

```ts
  1   | import { test } from '../release-validation/browser-fixture';
  2   | import { expect, type Page } from '@playwright/test';
  3   | import { readFile } from 'node:fs/promises';
  4   | import { join } from 'node:path';
  5   | 
  6   | const unlock = async (page: Page, code: string) => {
  7   |   await page.getByLabel('Device-lock code', { exact: true }).fill(code);
  8   |   await page.getByRole('button', { name: 'Unlock', exact: true }).click();
  9   |   await expect(page.locator('.compose-field').first()).toBeVisible();
  10  | };
  11  | const write = async (page: Page, text: string) => {
  12  |   const compose = page.locator(
  13  |     '.day-panel[data-active="true"] .collection[data-section="done"] .compose-field',
  14  |   );
  15  |   await compose.fill(text);
  16  |   await compose.press('Enter');
  17  |   await expect(page.locator('.card').filter({ hasText: text })).toBeVisible();
  18  | };
  19  | const lock = async (page: Page) => {
  20  |   await page.getByRole('button', { name: 'Lock workspace' }).click();
  21  |   await expect(page.locator('.local-startup')).toHaveAttribute('data-state', 'unlock-required');
  22  | };
  23  | const ready = (page: Page) =>
  24  |   page.evaluate(async () => {
  25  |     await navigator.serviceWorker.ready;
  26  |   });
  27  | const waiting = (page: Page) =>
  28  |   page.evaluate(
  29  |     async () => (await navigator.serviceWorker.getRegistration())?.waiting?.state ?? null,
  30  |   );
  31  | const update = (page: Page) =>
  32  |   page.evaluate(async () => {
  33  |     const registration = await navigator.serviceWorker.getRegistration();
  34  |     if (!registration) throw Error('Missing registration');
  35  |     await registration.update();
  36  |   });
  37  | const create = async (page: Page, controlled = true, expectedVersion = 'upgrade-a') => {
  38  |   await page.goto('/');
> 39  |   await page.getByRole('button', { name: 'Create a local-only workspace' }).click();
      |                                                                             ^ Error: locator.click: Test timeout of 35000ms exceeded.
  40  |   const code = (await page.getByLabel('Generated device-lock code').textContent())!;
  41  |   await page.getByRole('button', { name: 'I saved my code' }).click();
  42  |   await page.getByLabel('Device-lock code', { exact: true }).fill(code);
  43  |   await page.getByRole('button', { name: 'Confirm and create' }).click();
  44  |   await write(page, 'Before update');
  45  |   await lock(page);
  46  |   await ready(page);
  47  |   if (controlled) {
  48  |     await page.reload(); // First install deliberately does not claim an already loaded page.
  49  |     await unlock(page, code);
  50  |     if (expectedVersion) await expect(page.locator('body')).toContainText(expectedVersion);
  51  |   }
  52  |   return code;
  53  | };
  54  | 
  55  | test.beforeEach(async ({ request }) => {
  56  |   await request.post('/__release', { data: { version: 'a' } });
  57  | });
  58  | 
  59  | test('every cached URL is a real file with exactly matching HTTP bytes', async ({ request }) => {
  60  |   const root = join(process.env['APP_UPGRADE_OUTPUT']!, 'a');
  61  |   const worker = await readFile(join(root, 'sw.js'), 'utf8');
  62  |   const paths = JSON.parse(
  63  |     worker.match(/const PRECACHE = ([\s\S]*?);\nconst URLS/)![1]!,
  64  |   ) as string[];
  65  |   for (const path of paths) {
  66  |     const bytes = await readFile(join(root, path === '/' ? 'index.html' : path.slice(1)));
  67  |     const response = await request.get(path);
  68  |     expect(response.status()).toBe(200);
  69  |     expect(await response.body()).toEqual(bytes);
  70  |   }
  71  |   expect(paths).toEqual(
  72  |     expect.arrayContaining(['/manifest.webmanifest', '/icon-192.png', '/local.html']),
  73  |   );
  74  |   expect(paths.some((path) => /private|cleanup|recovery|\.map$/u.test(path))).toBe(false);
  75  | });
  76  | 
  77  | test('first installation closes and reopens offline without taking over its original page', async ({
  78  |   page,
  79  |   context,
  80  | }) => {
  81  |   const code = await create(page, false);
  82  |   expect(await page.evaluate(() => navigator.serviceWorker.controller)).toBe(null);
  83  |   await page.close();
  84  |   await context.setOffline(true);
  85  |   const offline = await context.newPage();
  86  |   await offline.goto('/local.html');
  87  |   await unlock(offline, code);
  88  |   await expect(offline.locator('.card').filter({ hasText: 'Before update' })).toBeVisible();
  89  |   await expect(offline.locator('body')).toContainText('upgrade-a');
  90  | });
  91  | 
  92  | test('the supplied predecessor upgrades into the new policy with its later writing intact', async ({
  93  |   page,
  94  |   context,
  95  |   request,
  96  | }) => {
  97  |   test.skip(
  98  |     process.env['APP_UPGRADE_HAS_PRIOR'] !== '1',
  99  |     'Supply APP_UPGRADE_PREDECESSOR_DIR to exercise the actual prior build.',
  100 |   );
  101 |   await request.post('/__release', { data: { version: 'prior' } });
  102 |   const code = await create(page, true, '');
  103 |   const beforeCaches = await page.evaluate(() => caches.keys());
  104 |   await request.post('/__release', { data: { version: 'b' } });
  105 |   await update(page);
  106 |   await expect.poll(() => waiting(page)).toBe('installed');
  107 |   await write(page, 'Written on the actual predecessor while update waits');
  108 |   await lock(page);
  109 |   await page.close();
  110 |   await context.setOffline(true);
  111 |   const next = await context.newPage();
  112 |   await next.goto('/');
  113 |   await unlock(next, code);
  114 |   await expect(next.locator('body')).toContainText('upgrade-b');
  115 |   await expect(
  116 |     next
  117 |       .locator('.card')
  118 |       .filter({ hasText: 'Written on the actual predecessor while update waits' }),
  119 |   ).toBeVisible();
  120 |   // Unscoped predecessor caches are retained, not guessed to belong to this new namespace.
  121 |   expect(await next.evaluate(() => caches.keys())).toEqual(expect.arrayContaining(beforeCaches));
  122 | });
  123 | 
  124 | test('two old tabs retain their release and writing until final close; new release reopens offline', async ({
  125 |   page,
  126 |   context,
  127 |   request,
  128 | }) => {
  129 |   const code = await create(page);
  130 |   const second = await context.newPage();
  131 |   await second.goto('/local.html');
  132 |   await unlock(second, code);
  133 |   await page.evaluate(async () => {
  134 |     const other = await caches.open('unrelated-cache');
  135 |     await other.put('/unrelated', new Response('retain me'));
  136 |   });
  137 |   await request.post('/__release', { data: { version: 'b' } });
  138 |   await update(page);
  139 |   await expect.poll(() => waiting(page)).toBe('installed');
```
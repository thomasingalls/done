# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: compatibility.spec.ts >> a future document schema held only in the journal refuses without rewriting carriers
- Location: test/storage-compatibility/compatibility.spec.ts:183:1

# Error details

```
Test timeout of 35000ms exceeded.
```

```
Error: locator.fill: Test timeout of 35000ms exceeded.
Call log:
  - waiting for getByLabel('Device-lock code', { exact: true })

```

# Page snapshot

```yaml
- main [ref=f1e3]:
  - generic:
    - complementary:
      - generic: done
      - generic: Today
      - generic: Yesterday
      - generic: Tomorrow
      - generic: Your space, at your pace.
    - generic:
      - generic: Today
      - generic:
        - generic:
          - generic:
            - text: Next
            - generic: 2 / 3
          - generic:
            - generic:
              - generic: Make a little room for the big idea
              - generic:
                - text: Done
                - generic: Later
            - generic:
              - generic: Take the long way home
              - generic:
                - text: Done
                - generic: Later
        - generic:
          - generic: Done
          - generic:
            - generic: Got the idea out of my head
            - generic: Sent the message I was putting off
            - generic: Made time for a walk
          - generic:
            - text: What got done?
            - generic: +
    - complementary:
      - generic: Goals
      - generic:
        - strong: A little space for everything
        - generic: Ideas, plans, loose ends.
        - generic: Things to come back to.
        - strong: Make something of my own
        - generic: Write down the spark
        - generic: Find one small place to start
        - generic: Share a first draft
        - strong: Outside of work
        - generic: Learn to make really good bread
        - generic: Plan a weekend with no plans
        - generic: More dinners with friends
  - generic [ref=f1e4]:
    - text: done
    - heading "Unlock your workspace" [level=1] [ref=f1e5]
    - paragraph [ref=f1e6]: Enter your unlock code to open the writing saved in this browser.
    - generic [ref=f1e7]:
      - generic [ref=f1e8]: Unlock code
      - textbox "Unlock code" [ref=f1e9]
      - button "Unlock" [ref=f1e10] [cursor=pointer]
    - button "Remove from this device" [ref=f1e11] [cursor=pointer]
    - button "Use another account" [ref=f1e12] [cursor=pointer]
```

# Test source

```ts
  96  |   await op(queued, 'queued', 'rejected');
  97  |   expect(await call(queued, 'state')).toMatchObject({
  98  |     initializations: 0,
  99  |     operations: { queued: { code: 'app-update-required' } },
  100 |   });
  101 |   const before = await call(page, 'census');
  102 |   await queued.goto('/');
  103 |   await expect(queued.locator('.local-startup')).toHaveAttribute(
  104 |     'data-state',
  105 |     'app-update-required',
  106 |   );
  107 |   await expect(
  108 |     queued.getByRole('heading', { name: 'This workspace needs a compatible app' }),
  109 |   ).toBeVisible();
  110 |   await expect(queued.getByLabel('Device-lock code', { exact: true })).toHaveCount(0);
  111 |   expect(await call(page, 'census')).toEqual(before);
  112 |   // Only the synthetic marker is removed here; no format changed. This is NOT a migration rollback.
  113 |   await call(page, 'unmark');
  114 |   const text = await call(page, 'open', 'verify', code);
  115 |   expect(text).toEqual(expect.stringContaining('retained writing'));
  116 |   expect(text).toEqual(expect.stringContaining('first-tab edit'));
  117 |   expect(text).toEqual(expect.stringContaining('second-tab edit'));
  118 |   await call(page, 'close', 'verify');
  119 | });
  120 | 
  121 | test('renderer death after intent commits leaves cold open and exclusive cleanup blocked', async ({
  122 |   page,
  123 |   context,
  124 | }) => {
  125 |   const { code } = await seed(page);
  126 |   const migrating = await context.newPage();
  127 |   await migrating.goto(fixture);
  128 |   await call(migrating, 'transition', { v: 99, state: 'ready', minReader: 0, minWriter: 0 }, true);
  129 |   await op(migrating, 'committed', 'resolved');
  130 |   const before = await call(page, 'census');
  131 |   const cdp = await context.newCDPSession(migrating);
  132 |   const crashed = migrating.waitForEvent('crash');
  133 |   void cdp.send('Page.crash').catch(() => {});
  134 |   await crashed;
  135 |   // Chromium may co-locate same-origin tabs in the crashed renderer. Use a new realm after death.
  136 |   const cold = await context.newPage();
  137 |   await cold.goto(fixture);
  138 |   await call(cold, 'probe', 'after-death');
  139 |   await op(cold, 'after-death', 'rejected');
  140 |   await call(cold, 'probe', 'exclusive', 'local', true);
  141 |   await op(cold, 'exclusive', 'rejected');
  142 |   await call(cold, 'prepareClear', 'clear', code);
  143 |   await op(cold, 'clear', 'rejected');
  144 |   expect(await call(cold, 'state')).toMatchObject({
  145 |     initializations: 0,
  146 |     operations: { clear: { code: 'app-update-required' } },
  147 |   });
  148 |   expect(await call(cold, 'census')).toEqual(before);
  149 |   await cold.reload();
  150 |   await call(cold, 'probe', 'cold');
  151 |   await op(cold, 'cold', 'rejected');
  152 |   expect(await call(cold, 'census')).toEqual(before);
  153 | });
  154 | 
  155 | test('a cancelled blocked IndexedDB probe retains its permit until native settlement', async ({
  156 |   page,
  157 |   context,
  158 | }) => {
  159 |   await seed(page);
  160 |   await call(page, 'blockVersionUpgrade');
  161 |   await op(page, 'version-blocked', 'resolved');
  162 |   const reader = await context.newPage();
  163 |   await reader.goto(fixture);
  164 |   await call(reader, 'probe', 'blocked');
  165 |   await expect
  166 |     .poll(async () => ((await call(page, 'locks')) as { held: unknown[] }).held.length)
  167 |     .toBe(1);
  168 |   await call(reader, 'cancel', 'blocked');
  169 |   expect(await call(reader, 'state')).toMatchObject({
  170 |     initializations: 0,
  171 |     operations: { blocked: { state: 'pending' } },
  172 |   });
  173 |   expect(((await call(page, 'locks')) as { held: unknown[] }).held).toHaveLength(1);
  174 |   await call(page, 'releaseBlocker');
  175 |   await op(page, 'version-upgrade', 'resolved');
  176 |   await op(reader, 'blocked', 'rejected');
  177 |   await expect
  178 |     .poll(async () => ((await call(page, 'locks')) as { held: unknown[] }).held.length)
  179 |     .toBe(0);
  180 |   expect(await call(reader, 'state')).toMatchObject({ initializations: 0 });
  181 | });
  182 | 
  183 | test('a future document schema held only in the journal refuses without rewriting carriers', async ({
  184 |   page,
  185 | }) => {
  186 |   // Seed before ordinary application initialization so no concurrent schema register obscures the future value.
  187 |   await page.goto(fixture);
  188 |   const { code, scope } = (await call(page, 'seed')) as {
  189 |     code: string;
  190 |     scope: Record<string, string>;
  191 |   };
  192 |   await call(page, 'futureSchema', code, scope);
  193 |   const before = await call(page, 'census');
  194 |   await page.goto('/');
  195 |   await expect(page.locator('.local-startup')).toHaveAttribute('data-state', 'unlock-required');
> 196 |   await page.getByLabel('Device-lock code', { exact: true }).fill(code);
      |                                                              ^ Error: locator.fill: Test timeout of 35000ms exceeded.
  197 |   await page.getByRole('button', { name: 'Unlock', exact: true }).click();
  198 |   await expect(page.locator('.local-startup')).toHaveAttribute('data-state', 'app-update-required');
  199 |   await page.goto(fixture);
  200 |   expect(await call(page, 'census')).toEqual(before);
  201 | });
  202 | 
  203 | test('unrelated slots remain usable and omitting the marker check actually admits an incompatible writer', async ({
  204 |   page,
  205 |   context,
  206 | }) => {
  207 |   await page.goto(fixture);
  208 |   await call(page, 'marker', null, 'local');
  209 |   await call(page, 'probe', 'other', 'other');
  210 |   await op(page, 'other', 'resolved');
  211 |   await call(page, 'probe', 'baseline');
  212 |   await op(page, 'baseline', 'rejected');
  213 |   const mutant = await context.newPage();
  214 |   await mutant.route('**/src/crdt/storageCompatibility.ts*', async (route) => {
  215 |     const response = await route.fetch(),
  216 |       source = await response.text();
  217 |     const anchor = 'if (present) throw new StorageCompatibilityError();';
  218 |     expect(source.split(anchor)).toHaveLength(2);
  219 |     await route.fulfill({
  220 |       response,
  221 |       body: source.replace(anchor, 'void present; // sensitivity control'),
  222 |     });
  223 |   });
  224 |   await mutant.goto(fixture);
  225 |   await call(mutant, 'probe', 'mutant');
  226 |   await op(mutant, 'mutant', 'resolved');
  227 |   expect(await call(mutant, 'state')).toMatchObject({ initializations: 1 });
  228 | });
  229 | 
```
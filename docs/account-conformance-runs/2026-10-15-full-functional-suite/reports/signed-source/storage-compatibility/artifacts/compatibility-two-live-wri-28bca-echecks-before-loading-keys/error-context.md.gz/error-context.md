# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: compatibility.spec.ts >> two live writers block an upgrade; a queued opener rechecks before loading keys
- Location: test/storage-compatibility/compatibility.spec.ts:66:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

Expected: "{\"databases\":[{\"name\":\"done.custody\",\"version\":1,\"stores\":{\"entries\":[[[\"local\",\"52eabc7fdb34f1effc1024b4bb878b5e\",\"e44410026d842ce69cb709058bce6ec0\"],[\"local\",\"52eabc7fdb34f1effc1024b4bb878b5e\",\"e44410026d842ce69cb709058bce6ec0\",\"content-v1\"],[\"local\",\"application-upgrade\"],[\"local\",\"local-genesis-v1\"]],[{\"v\":2,\"state\":\"protected\",\"slot_id\":\"local\",\"principal_id\":\"52eabc7fdb34f1effc1024b4bb878b5e\",\"workspace_id\":\"e44410026d842ce69cb709058bce6ec0\",\"store_id\":\"194d79828030a7ebe72130bee3f4e25b\",\"root_id\":\"8a0f71ef836ea065339b254fe0bd56e4\",\"seals\":[{\"v\":1,\"factor\":\"code\",\"id\":\"code\",\"salt\":[61,54,52,62,92,79,181,153,110,64,110,231,185,47,243,97],\"nonce\":[14,144,4,29,77,101,154,125,205,178,238,146],\"ct\":[59,180,40,118,247,97,86,28,70,109,0,67,32,105,32,89,42,248,151,89,65,198,122,132,239,225,111,76,14,43,69,240,105,90,212,239,42,221,100,167,220,91,240,83,179,51,78,141]}],\"seal_reserved\":3,\"rotation_owed\":false,\"creation_intent\":null,\"envelope\":{\"v\":1,\"gen\":1,\"nonce\":[85,173,200,169,0,187,255,230,178,139,108,104],\"ct\":[250,255,167,170,237,228,148,239,216,63,209,90,162,20,79,52,229,122,113,139,5,246,73,46,88,250,214,189,4,202,217,233,168,139,211,254,106,6,0,83,89,31,203,110,166,22,185,192]},\"credentials\":[{\"role\":\"wrapping\",\"id\":\"7fa95998366aee40d42ad621307206f5\",\"publicKey\":[189,57,194,31,244,100,187,237,186,45,105,137,106,240,237,224,249,62,157,85,126,81,215,167,252,126,208,232,244,184,47,7],\"sealed\":{\"v\":2,\"nonce\":[81,205,211,35,52,127,225,202,64,129,140,43],\"ct\":[109,138,134,0,142,112,46,135,238,250,210,125,112,64,244,1,90,112,58,141,133,3,52,103,180,5,236,192,51,99,42,222,14,243,65,76,70,134,188,175,230,20,212,102,195,179,82,29]}},{\"role\":\"signing\",\"id\":\"259aa8571db9f8a9db3d7dda685ea935\",\"publicKey\":[245,153,167,78,233,32,26,41,9,57,166,82,141,86,139,3,78,36,90,144,252,5,124,230,88,56,106,229,23,221,226,151],\"sealed\":{\"v\":2,\"nonce\":[67,160,85,211,32,235,196,100,70,176,178,170],\"ct\":[84,96,182,85,197,55,89,2,95,253,93,217,225,74,245,200,110,207,58,16,32,108,81,233,5,28,131,4,212,245,232,194,136,248,213,140,31,17,180,217,131,254,67,116,219,136,235,84]}}],\"mac\":[175,5,124,248,8,177,134,216,223,18,19,213,104,142,108,157,187,60,167,38,148,186,47,38,54,105,228,192,243,118,202,138]},{\"v\":1,\"state\":\"ready\",\"intent\":\"a1030e9453497c6ee0f62e9eba848e51\",\"mac\":[96,64,36,231,105,29,120,185,182,251,206,194,50,200,7,254,252,222,243,181,212,114,207,118,199,112,37,252,23,151,111,16]},{\"v\":1,\"state\":\"migrating\",\"targetFormat\":2},{\"v\":1,\"initial\":{\"v\":2,\"state\":\"creating\",\"slot_id\":\"local\",\"principal_id\":\"52eabc7fdb34f1effc1024b4bb878b5e\",\"workspace_id\":\"e44410026d842ce69cb709058bce6ec0\",\"store_id\":\"194d79828030a7ebe72130bee3f4e25b\",\"root_id\":\"8a0f71ef836ea065339b254fe0bd56e4\",\"seals\":[{\"v\":1,\"factor\":\"code\",\"id\":\"code\",\"salt\":[61,54,52,62,92,79,181,153,110,64,110,231,185,47,243,97],\"nonce\":[14,144,4,29,77,101,154,125,205,178,238,146],\"ct\":[59,180,40,118,247,97,86,28,70,109,0,67,32,105,32,89,42,248,151,89,65,198,122,132,239,225,111,76,14,43,69,240,105,90,212,239,42,221,100,167,220,91,240,83,179,51,78,141]}],\"seal_reserved\":0,\"rotation_owed\":false,\"creation_intent\":{\"id\":\"a1030e9453497c6ee0f62e9eba848e51\",\"storeId\":\"194d79828030a7ebe72130bee3f4e25b\",\"rootId\":\"8a0f71ef836ea065339b254fe0bd56e4\",\"wrappingId\":\"7fa95998366aee40d42ad621307206f5\",\"signingId\":\"259aa8571db9f8a9db3d7dda685ea935\"},\"envelope\":null,\"credentials\":null,\"mac\":[209,92,39,36,60,147,243,167,192,220,11,96,24,125,250,62,220,126,56,250,69,36,27,8,160,32,234,12,230,150,17,97]},\"stage\":\"ready\",\"mac\":[139,85,202,55,169,232,179,203,198,56,92,156,133,56,212,216,0,7,113,209,234,114,13,57,210,91,186,66,196,48,232,22]}]]}},{\"name\":\"done.d5e17813c6eaa78405f8eafa2f77cbac\",\"version\":1,\"stores\":{\"content\":[[1,2,3,4],[{\"v\":1,\"gen\":1,\"seq\":1,\"kind\":\"update\",\"nonce\":[119,143,4,243,122,137,87,47,192,155,136,1],\"ct\":[213,12,149,127,78,152,151,219,207,226,43,253,51,229,44,127,211,8,93,175,238,11,68,109,130,230,39,136,183,17,31,22,50,243,186,142,168,2,133,79,167,12,184,236,34,37,188,3,78,5,160,239,17,155,152,183,175,37,221,166,105,184,164,191,192,74,128,201,22,50,62,244,165,106,119,101,57,61,76,244,247,60,223,150,188,36,215,0,20,181,243,226,33,69,52,181,116,107,74,216,57,16,122,199,126,156,58,52,162,176,157,43,166,78,123,184,72,117,144,179,151,230,125,35,169,129,95,150,59,5,47,3,26,49,0,91,55,142,130,63,1,55,140,143,84,7,142,167,33,132,32,22,221,156,234,149,50,254,11,162,20,98,189,157,79,90,68,190,210,177,137,207,4,233,131,146,196,144,122,142,14,213,37,135,200,65,100,129,102,66,166,89,76,63,21,190,199,22,10,127,146,9,21,75,52,252,203,140,60,152,232,63,255,192,236,6,125,178,252,122,141,44,185,230,147,60,247,12,230,52,137,31,99,91,7,201,202,31,173,2,59,62,38]},{\"v\":1,\"gen\":1,\"seq\":2,\"kind\":\"update\",\"nonce\":[75,30,111,53,202,111,239,63,113,131,148,51],\"ct\":[133,202,214,146,101,69,104,151,45,114,156,97,76,52,178,103,139,111,187,89,99,100,150,124,168,74,231,67,68,84,198,60,35,237,165,201,191,100,19,89,185,105,21,134,96,165,217,234,223,109,233]},{\"v\":1,\"gen\":1,\"seq\":3,\"kind\":\"update\",\"nonce\":[10,244,75,13,41,210,184,17,128,164,95,64],\"ct\":[212,140,135,222,29,33,27,143,213,193,7,147,9,33,79,215,248,20]},{\"v\":1,\"gen\":1,\"seq\":4,\"kind\":\"update\",\"nonce\":[99,203,159,189,20,155,99,82,77,129,183,174],\"ct\":[89,83,217,123,74,61,197,210,157,102,169,4,240,249,191,2,114,250]}]],\"heads\":[[],[]],\"meta\":[[\"counter\"],[{\"v\":1,\"store_id\":\"194d79828030a7ebe72130bee3f4e25b\",\"intent\":\"a1030e9453497c6ee0f62e9eba848e51\",\"active_gen\":1,\"next_seq\":5,\"reserved\":{\"1\":4},\"mac\":[81,210,39,5,77,62,104,65,208,243,130,130,122,220,75,160,158,243,218,135,128,223,67,252,101,83,47,120,179,212,177,112]}]],\"outbound\":[[],[]]}},{\"name\":\"done.slots\",\"version\":1,\"stores\":{\"slots\":[[\"local\"],[{\"id\":\"local\",\"status\":\"active\",\"unlockBinding\":null,\"local\":{\"principalId\":\"52eabc7fdb34f1effc1024b4bb878b5e\",\"workspaceId\":\"e44410026d842ce69cb709058bce6ec0\",\"intentId\":\"a1030e9453497c6ee0f62e9eba848e51\"},\"stores\":[{\"principal\":\"52eabc7fdb34f1effc1024b4bb878b5e\",\"workspace\":\"e44410026d842ce69cb709058bce6ec0\",\"dbName\":\"done.d5e17813c6eaa78405f8eafa2f77cbac\"}]}]]}}],\"local\":{\"done.pending-update.done.d5e17813c6eaa78405f8eafa2f77cbac.194d79828030a7ebe72130bee3f4e25b.19db272b3c44d3d3857891545774af37.0000000000000002\":\"2:AAAAAV2H0GjBFJJrG4sOHfT7tqTquoQdz2ybj+3m82XieBxH15kO40YqkagluO2odd4CcW8dKrE94CyPkrEnlhBwzO1roYtnJ6N6FB0=\",\"done.pending-update.done.d5e17813c6eaa78405f8eafa2f77cbac.194d79828030a7ebe72130bee3f4e25b.bfc05a505670d393d439c4a34ba3bd73.0000000000000002\":\"2:AAAAAa0mr4/fZIWTG0oE5Gkx48KhUVgmHV5WSQ4ukh57xDzFM1q6nuK9hi3q7S5DTrBZ54idUDEO91OgeB4F/UBJFyoAZDjzrmvIhQ==\"}}"
Received: "{\"databases\":[{\"name\":\"done.custody\",\"version\":1,\"stores\":{\"entries\":[[[\"local\",\"52eabc7fdb34f1effc1024b4bb878b5e\",\"e44410026d842ce69cb709058bce6ec0\"],[\"local\",\"52eabc7fdb34f1effc1024b4bb878b5e\",\"e44410026d842ce69cb709058bce6ec0\",\"content-v1\"],[\"local\",\"application-upgrade\"],[\"local\",\"local-genesis-v1\"]],[{\"v\":2,\"state\":\"protected\",\"slot_id\":\"local\",\"principal_id\":\"52eabc7fdb34f1effc1024b4bb878b5e\",\"workspace_id\":\"e44410026d842ce69cb709058bce6ec0\",\"store_id\":\"194d79828030a7ebe72130bee3f4e25b\",\"root_id\":\"8a0f71ef836ea065339b254fe0bd56e4\",\"seals\":[{\"v\":1,\"factor\":\"code\",\"id\":\"code\",\"salt\":[61,54,52,62,92,79,181,153,110,64,110,231,185,47,243,97],\"nonce\":[14,144,4,29,77,101,154,125,205,178,238,146],\"ct\":[59,180,40,118,247,97,86,28,70,109,0,67,32,105,32,89,42,248,151,89,65,198,122,132,239,225,111,76,14,43,69,240,105,90,212,239,42,221,100,167,220,91,240,83,179,51,78,141]}],\"seal_reserved\":3,\"rotation_owed\":false,\"creation_intent\":null,\"envelope\":{\"v\":1,\"gen\":1,\"nonce\":[85,173,200,169,0,187,255,230,178,139,108,104],\"ct\":[250,255,167,170,237,228,148,239,216,63,209,90,162,20,79,52,229,122,113,139,5,246,73,46,88,250,214,189,4,202,217,233,168,139,211,254,106,6,0,83,89,31,203,110,166,22,185,192]},\"credentials\":[{\"role\":\"wrapping\",\"id\":\"7fa95998366aee40d42ad621307206f5\",\"publicKey\":[189,57,194,31,244,100,187,237,186,45,105,137,106,240,237,224,249,62,157,85,126,81,215,167,252,126,208,232,244,184,47,7],\"sealed\":{\"v\":2,\"nonce\":[81,205,211,35,52,127,225,202,64,129,140,43],\"ct\":[109,138,134,0,142,112,46,135,238,250,210,125,112,64,244,1,90,112,58,141,133,3,52,103,180,5,236,192,51,99,42,222,14,243,65,76,70,134,188,175,230,20,212,102,195,179,82,29]}},{\"role\":\"signing\",\"id\":\"259aa8571db9f8a9db3d7dda685ea935\",\"publicKey\":[245,153,167,78,233,32,26,41,9,57,166,82,141,86,139,3,78,36,90,144,252,5,124,230,88,56,106,229,23,221,226,151],\"sealed\":{\"v\":2,\"nonce\":[67,160,85,211,32,235,196,100,70,176,178,170],\"ct\":[84,96,182,85,197,55,89,2,95,253,93,217,225,74,245,200,110,207,58,16,32,108,81,233,5,28,131,4,212,245,232,194,136,248,213,140,31,17,180,217,131,254,67,116,219,136,235,84]}}],\"mac\":[175,5,124,248,8,177,134,216,223,18,19,213,104,142,108,157,187,60,167,38,148,186,47,38,54,105,228,192,243,118,202,138]},{\"v\":1,\"state\":\"ready\",\"intent\":\"a1030e9453497c6ee0f62e9eba848e51\",\"mac\":[96,64,36,231,105,29,120,185,182,251,206,194,50,200,7,254,252,222,243,181,212,114,207,118,199,112,37,252,23,151,111,16]},{\"v\":1,\"state\":\"migrating\",\"targetFormat\":2},{\"v\":1,\"initial\":{\"v\":2,\"state\":\"creating\",\"slot_id\":\"local\",\"principal_id\":\"52eabc7fdb34f1effc1024b4bb878b5e\",\"workspace_id\":\"e44410026d842ce69cb709058bce6ec0\",\"store_id\":\"194d79828030a7ebe72130bee3f4e25b\",\"root_id\":\"8a0f71ef836ea065339b254fe0bd56e4\",\"seals\":[{\"v\":1,\"factor\":\"code\",\"id\":\"code\",\"salt\":[61,54,52,62,92,79,181,153,110,64,110,231,185,47,243,97],\"nonce\":[14,144,4,29,77,101,154,125,205,178,238,146],\"ct\":[59,180,40,118,247,97,86,28,70,109,0,67,32,105,32,89,42,248,151,89,65,198,122,132,239,225,111,76,14,43,69,240,105,90,212,239,42,221,100,167,220,91,240,83,179,51,78,141]}],\"seal_reserved\":0,\"rotation_owed\":false,\"creation_intent\":{\"id\":\"a1030e9453497c6ee0f62e9eba848e51\",\"storeId\":\"194d79828030a7ebe72130bee3f4e25b\",\"rootId\":\"8a0f71ef836ea065339b254fe0bd56e4\",\"wrappingId\":\"7fa95998366aee40d42ad621307206f5\",\"signingId\":\"259aa8571db9f8a9db3d7dda685ea935\"},\"envelope\":null,\"credentials\":null,\"mac\":[209,92,39,36,60,147,243,167,192,220,11,96,24,125,250,62,220,126,56,250,69,36,27,8,160,32,234,12,230,150,17,97]},\"stage\":\"ready\",\"mac\":[139,85,202,55,169,232,179,203,198,56,92,156,133,56,212,216,0,7,113,209,234,114,13,57,210,91,186,66,196,48,232,22]}]]}},{\"name\":\"done.d5e17813c6eaa78405f8eafa2f77cbac\",\"version\":1,\"stores\":{\"content\":[[1,2,3,4],[{\"v\":1,\"gen\":1,\"seq\":1,\"kind\":\"update\",\"nonce\":[119,143,4,243,122,137,87,47,192,155,136,1],\"ct\":[213,12,149,127,78,152,151,219,207,226,43,253,51,229,44,127,211,8,93,175,238,11,68,109,130,230,39,136,183,17,31,22,50,243,186,142,168,2,133,79,167,12,184,236,34,37,188,3,78,5,160,239,17,155,152,183,175,37,221,166,105,184,164,191,192,74,128,201,22,50,62,244,165,106,119,101,57,61,76,244,247,60,223,150,188,36,215,0,20,181,243,226,33,69,52,181,116,107,74,216,57,16,122,199,126,156,58,52,162,176,157,43,166,78,123,184,72,117,144,179,151,230,125,35,169,129,95,150,59,5,47,3,26,49,0,91,55,142,130,63,1,55,140,143,84,7,142,167,33,132,32,22,221,156,234,149,50,254,11,162,20,98,189,157,79,90,68,190,210,177,137,207,4,233,131,146,196,144,122,142,14,213,37,135,200,65,100,129,102,66,166,89,76,63,21,190,199,22,10,127,146,9,21,75,52,252,203,140,60,152,232,63,255,192,236,6,125,178,252,122,141,44,185,230,147,60,247,12,230,52,137,31,99,91,7,201,202,31,173,2,59,62,38]},{\"v\":1,\"gen\":1,\"seq\":2,\"kind\":\"update\",\"nonce\":[75,30,111,53,202,111,239,63,113,131,148,51],\"ct\":[133,202,214,146,101,69,104,151,45,114,156,97,76,52,178,103,139,111,187,89,99,100,150,124,168,74,231,67,68,84,198,60,35,237,165,201,191,100,19,89,185,105,21,134,96,165,217,234,223,109,233]},{\"v\":1,\"gen\":1,\"seq\":3,\"kind\":\"update\",\"nonce\":[10,244,75,13,41,210,184,17,128,164,95,64],\"ct\":[212,140,135,222,29,33,27,143,213,193,7,147,9,33,79,215,248,20]},{\"v\":1,\"gen\":1,\"seq\":4,\"kind\":\"update\",\"nonce\":[99,203,159,189,20,155,99,82,77,129,183,174],\"ct\":[89,83,217,123,74,61,197,210,157,102,169,4,240,249,191,2,114,250]}]],\"heads\":[[],[]],\"meta\":[[\"counter\"],[{\"v\":1,\"store_id\":\"194d79828030a7ebe72130bee3f4e25b\",\"intent\":\"a1030e9453497c6ee0f62e9eba848e51\",\"active_gen\":1,\"next_seq\":5,\"reserved\":{\"1\":4},\"mac\":[81,210,39,5,77,62,104,65,208,243,130,130,122,220,75,160,158,243,218,135,128,223,67,252,101,83,47,120,179,212,177,112]}]],\"outbound\":[[],[]]}},{\"name\":\"done.slots\",\"version\":1,\"stores\":{\"slots\":[[\"local\"],[{\"id\":\"local\",\"status\":\"active\",\"unlockBinding\":null,\"local\":{\"principalId\":\"52eabc7fdb34f1effc1024b4bb878b5e\",\"workspaceId\":\"e44410026d842ce69cb709058bce6ec0\",\"intentId\":\"a1030e9453497c6ee0f62e9eba848e51\"},\"stores\":[{\"principal\":\"52eabc7fdb34f1effc1024b4bb878b5e\",\"workspace\":\"e44410026d842ce69cb709058bce6ec0\",\"dbName\":\"done.d5e17813c6eaa78405f8eafa2f77cbac\"}]}]]}}],\"local\":{\"done.application.local-only\":\"1\",\"done.pending-update.done.d5e17813c6eaa78405f8eafa2f77cbac.194d79828030a7ebe72130bee3f4e25b.19db272b3c44d3d3857891545774af37.0000000000000002\":\"2:AAAAAV2H0GjBFJJrG4sOHfT7tqTquoQdz2ybj+3m82XieBxH15kO40YqkagluO2odd4CcW8dKrE94CyPkrEnlhBwzO1roYtnJ6N6FB0=\",\"done.pending-update.done.d5e17813c6eaa78405f8eafa2f77cbac.194d79828030a7ebe72130bee3f4e25b.bfc05a505670d393d439c4a34ba3bd73.0000000000000002\":\"2:AAAAAa0mr4/fZIWTG0oE5Gkx48KhUVgmHV5WSQ4ukh57xDzFM1q6nuK9hi3q7S5DTrBZ54idUDEO91OgeB4F/UBJFyoAZDjzrmvIhQ==\"}}"
```

# Test source

```ts
  11  |     { timeout: 10000 },
  12  |   );
  13  |   return page.evaluate(
  14  |     ({ name, args }) =>
  15  |       (window as unknown as { compat: Record<string, (...args: unknown[]) => unknown> }).compat[
  16  |         name
  17  |       ]!(...args),
  18  |     { name, args },
  19  |   );
  20  | };
  21  | const op = async (page: Page, id: string, state: string) =>
  22  |   expect
  23  |     .poll(async () => {
  24  |       const snapshot = (await call(page, 'state')) as {
  25  |         operations: Record<string, { state: string }>;
  26  |       };
  27  |       return snapshot.operations[id]?.state;
  28  |     })
  29  |     .toBe(state);
  30  | const seed = async (page: Page) => {
  31  |   await page.goto(fixture);
  32  |   const result = (await call(page, 'seed')) as { code: string; scope: Record<string, string> };
  33  |   await call(page, 'open', 'seed', result.code);
  34  |   await call(page, 'edit', 'seed', 'retained writing');
  35  |   await call(page, 'durable', 'seed');
  36  |   await call(page, 'close', 'seed');
  37  |   return result;
  38  | };
  39  | 
  40  | test('fixture calls await a deliberately delayed module initialization', async ({ page }) => {
  41  |   await page.route('**/test/storage-compatibility/browser.mjs', async (route) => {
  42  |     const response = await route.fetch();
  43  |     await route.fulfill({
  44  |       response,
  45  |       body:
  46  |         'await new Promise(resolve => { window.releaseCompatibilityFixture = resolve; });\n' +
  47  |         (await response.text()),
  48  |     });
  49  |   });
  50  |   await page.goto(fixture);
  51  |   expect(await page.evaluate(() => typeof (window as unknown as { compat?: unknown }).compat)).toBe(
  52  |     'undefined',
  53  |   );
  54  |   const pending = call(page, 'state').then(
  55  |     (value) => ({ ok: true, value }),
  56  |     (error) => ({ ok: false, error: String(error) }),
  57  |   );
  58  |   await page.evaluate(() =>
  59  |     (
  60  |       window as unknown as { releaseCompatibilityFixture: () => void }
  61  |     ).releaseCompatibilityFixture(),
  62  |   );
  63  |   expect(await pending).toMatchObject({ ok: true, value: { initializations: 0, operations: {} } });
  64  | });
  65  | 
  66  | test('two live writers block an upgrade; a queued opener rechecks before loading keys', async ({
  67  |   page,
  68  |   context,
  69  | }) => {
  70  |   const { code } = await seed(page),
  71  |     a = await context.newPage(),
  72  |     b = await context.newPage(),
  73  |     queued = await context.newPage();
  74  |   await a.goto(fixture);
  75  |   await b.goto(fixture);
  76  |   await queued.goto(fixture);
  77  |   await call(a, 'open', 'a', code);
  78  |   await call(b, 'open', 'b', code);
  79  |   await call(a, 'edit', 'a', ' first-tab edit');
  80  |   await call(b, 'edit', 'b', ' second-tab edit');
  81  |   await call(page, 'transition', { v: 1, state: 'migrating', targetFormat: 2 });
  82  |   await expect
  83  |     .poll(async () => ((await call(page, 'locks')) as { pending: unknown[] }).pending.length)
  84  |     .toBe(1);
  85  |   await call(queued, 'probe', 'queued');
  86  |   await expect
  87  |     .poll(async () => ((await call(page, 'locks')) as { pending: unknown[] }).pending.length)
  88  |     .toBe(2);
  89  |   await call(a, 'close', 'a');
  90  |   expect(
  91  |     ((await call(page, 'state')) as { operations: Record<string, unknown> }).operations['granted'],
  92  |   ).toBeUndefined();
  93  |   // Accepted edits remain in the exact carrier set captured immediately before transition.
  94  |   await call(b, 'close', 'b');
  95  |   await op(page, 'transition', 'resolved');
  96  |   await op(queued, 'queued', 'rejected');
  97  |   expect(await call(queued, 'state')).toMatchObject({
  98  |     initializations: 0,
  99  |     operations: { queued: { code: 'app-update-required' } },
  100 |   });
  101 |   const before = await call(page, 'census');
  102 |   await queued.goto('/');
  103 |   await expect(queued.locator('.local-startup')).toHaveAttribute(
  104 |     'data-state',
  105 |     'app-update-required',
  106 |   );
  107 |   await expect(
  108 |     queued.getByRole('heading', { name: 'This workspace needs a compatible app' }),
  109 |   ).toBeVisible();
  110 |   await expect(queued.getByLabel('Device-lock code', { exact: true })).toHaveCount(0);
> 111 |   expect(await call(page, 'census')).toEqual(before);
      |                                      ^ Error: expect(received).toEqual(expected) // deep equality
  112 |   // Only the synthetic marker is removed here; no format changed. This is NOT a migration rollback.
  113 |   await call(page, 'unmark');
  114 |   const text = await call(page, 'open', 'verify', code);
  115 |   expect(text).toEqual(expect.stringContaining('retained writing'));
  116 |   expect(text).toEqual(expect.stringContaining('first-tab edit'));
  117 |   expect(text).toEqual(expect.stringContaining('second-tab edit'));
  118 |   await call(page, 'close', 'verify');
  119 | });
  120 | 
  121 | test('renderer death after intent commits leaves cold open and exclusive cleanup blocked', async ({
  122 |   page,
  123 |   context,
  124 | }) => {
  125 |   const { code } = await seed(page);
  126 |   const migrating = await context.newPage();
  127 |   await migrating.goto(fixture);
  128 |   await call(migrating, 'transition', { v: 99, state: 'ready', minReader: 0, minWriter: 0 }, true);
  129 |   await op(migrating, 'committed', 'resolved');
  130 |   const before = await call(page, 'census');
  131 |   const cdp = await context.newCDPSession(migrating);
  132 |   const crashed = migrating.waitForEvent('crash');
  133 |   void cdp.send('Page.crash').catch(() => {});
  134 |   await crashed;
  135 |   // Chromium may co-locate same-origin tabs in the crashed renderer. Use a new realm after death.
  136 |   const cold = await context.newPage();
  137 |   await cold.goto(fixture);
  138 |   await call(cold, 'probe', 'after-death');
  139 |   await op(cold, 'after-death', 'rejected');
  140 |   await call(cold, 'probe', 'exclusive', 'local', true);
  141 |   await op(cold, 'exclusive', 'rejected');
  142 |   await call(cold, 'prepareClear', 'clear', code);
  143 |   await op(cold, 'clear', 'rejected');
  144 |   expect(await call(cold, 'state')).toMatchObject({
  145 |     initializations: 0,
  146 |     operations: { clear: { code: 'app-update-required' } },
  147 |   });
  148 |   expect(await call(cold, 'census')).toEqual(before);
  149 |   await cold.reload();
  150 |   await call(cold, 'probe', 'cold');
  151 |   await op(cold, 'cold', 'rejected');
  152 |   expect(await call(cold, 'census')).toEqual(before);
  153 | });
  154 | 
  155 | test('a cancelled blocked IndexedDB probe retains its permit until native settlement', async ({
  156 |   page,
  157 |   context,
  158 | }) => {
  159 |   await seed(page);
  160 |   await call(page, 'blockVersionUpgrade');
  161 |   await op(page, 'version-blocked', 'resolved');
  162 |   const reader = await context.newPage();
  163 |   await reader.goto(fixture);
  164 |   await call(reader, 'probe', 'blocked');
  165 |   await expect
  166 |     .poll(async () => ((await call(page, 'locks')) as { held: unknown[] }).held.length)
  167 |     .toBe(1);
  168 |   await call(reader, 'cancel', 'blocked');
  169 |   expect(await call(reader, 'state')).toMatchObject({
  170 |     initializations: 0,
  171 |     operations: { blocked: { state: 'pending' } },
  172 |   });
  173 |   expect(((await call(page, 'locks')) as { held: unknown[] }).held).toHaveLength(1);
  174 |   await call(page, 'releaseBlocker');
  175 |   await op(page, 'version-upgrade', 'resolved');
  176 |   await op(reader, 'blocked', 'rejected');
  177 |   await expect
  178 |     .poll(async () => ((await call(page, 'locks')) as { held: unknown[] }).held.length)
  179 |     .toBe(0);
  180 |   expect(await call(reader, 'state')).toMatchObject({ initializations: 0 });
  181 | });
  182 | 
  183 | test('a future document schema held only in the journal refuses without rewriting carriers', async ({
  184 |   page,
  185 | }) => {
  186 |   // Seed before ordinary application initialization so no concurrent schema register obscures the future value.
  187 |   await page.goto(fixture);
  188 |   const { code, scope } = (await call(page, 'seed')) as {
  189 |     code: string;
  190 |     scope: Record<string, string>;
  191 |   };
  192 |   await call(page, 'futureSchema', code, scope);
  193 |   const before = await call(page, 'census');
  194 |   await page.goto('/');
  195 |   await expect(page.locator('.local-startup')).toHaveAttribute('data-state', 'unlock-required');
  196 |   await page.getByLabel('Device-lock code', { exact: true }).fill(code);
  197 |   await page.getByRole('button', { name: 'Unlock', exact: true }).click();
  198 |   await expect(page.locator('.local-startup')).toHaveAttribute('data-state', 'app-update-required');
  199 |   await page.goto(fixture);
  200 |   expect(await call(page, 'census')).toEqual(before);
  201 | });
  202 | 
  203 | test('unrelated slots remain usable and omitting the marker check actually admits an incompatible writer', async ({
  204 |   page,
  205 |   context,
  206 | }) => {
  207 |   await page.goto(fixture);
  208 |   await call(page, 'marker', null, 'local');
  209 |   await call(page, 'probe', 'other', 'other');
  210 |   await op(page, 'other', 'resolved');
  211 |   await call(page, 'probe', 'baseline');
```
# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: setup.spec.ts >> password-manager app switching preserves code-saving and confirmation steps
- Location: test/first-device-setup/setup.spec.ts:163:1

# Error details

```
Test timeout of 90000ms exceeded.
```

```
Error: locator.click: Test timeout of 90000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: 'I already have a workspace', exact: true })

```

# Page snapshot

```yaml
- generic [ref=e4]:
  - complementary "Menu" [ref=e5]:
    - generic [ref=e6]:
      - heading "Day" [level=2] [ref=e7]
      - paragraph [ref=e8]: Thu 15 Oct 2026
      - generic [ref=e9]:
        - button "Thu 8 Oct" [ref=e10] [cursor=pointer]
        - button "Tue 13 Oct" [ref=e11] [cursor=pointer]
        - button "Yesterday" [ref=e12] [cursor=pointer]
        - button "Today" [ref=e13] [cursor=pointer]
        - button "Tomorrow" [ref=e14] [cursor=pointer]
        - button "Sat 17 Oct" [ref=e15] [cursor=pointer]
        - button "Thu 22 Oct" [ref=e16] [cursor=pointer]
      - generic [ref=e17]:
        - text: Go to date
        - textbox "Go to date" [ref=e18]: 2026-10-15
    - generic [ref=e19]:
      - heading "Data" [level=2] [ref=e20]
      - generic [ref=e21]:
        - generic [ref=e22]: Local data
        - generic [ref=e23]: Best-effort
      - paragraph [ref=e24]: Writing is encrypted in this browser. Export a readable backup when you need one.
      - button "Export markdown" [ref=e25] [cursor=pointer]
      - button "Remove from this device" [ref=e26] [cursor=pointer]
      - generic [ref=e27]:
        - button "Undo" [disabled] [ref=e28] [cursor=pointer]
        - button "Redo" [disabled] [ref=e29] [cursor=pointer]
    - generic [ref=e30]:
      - heading "Protection" [level=2] [ref=e31]
      - paragraph [ref=e32]: Opens automatically. Anyone using this browser can open your list.
      - button "Add an unlock code" [ref=e33] [cursor=pointer]
    - generic [ref=e34]:
      - heading "Sync" [level=2] [ref=e35]
      - button "Use another account" [ref=e36] [cursor=pointer]
      - paragraph [ref=e37]: Saved only in this browser. Sync is off.
      - button "Set up sync" [ref=e38] [cursor=pointer]
    - generic [ref=e39]:
      - heading "Personalize" [level=2] [ref=e40]
      - generic [ref=e41]:
        - generic [ref=e42]: Actor
        - generic [ref=e43]: You
      - generic [ref=e45]:
        - generic [ref=e46]: Version
        - generic [ref=e47]: 5afdd0ad
      - generic [ref=e48]:
        - generic [ref=e49]:
          - generic [ref=e50]: Device
          - textbox "Device name" [ref=e51]: Chrome - macOS
        - generic [ref=e52]:
          - generic [ref=e53]: Name
          - textbox "Actor name" [ref=e54]: You
        - generic [ref=e55]:
          - generic [ref=e56]: Color
          - textbox "Actor color" [ref=e57]: "#e0662f"
        - generic [ref=e58]:
          - generic [ref=e59]: Day rollover
          - combobox "Day rollover hour" [ref=e60]:
            - option "00:00" [selected]
            - option "01:00"
            - option "02:00"
            - option "03:00"
            - option "04:00"
            - option "05:00"
            - option "06:00"
            - option "07:00"
            - option "08:00"
            - option "09:00"
            - option "10:00"
            - option "11:00"
            - option "12:00"
            - option "13:00"
            - option "14:00"
            - option "15:00"
            - option "16:00"
            - option "17:00"
            - option "18:00"
            - option "19:00"
            - option "20:00"
            - option "21:00"
            - option "22:00"
            - option "23:00"
        - button "Save preferences" [ref=e61] [cursor=pointer]
    - region "Install" [ref=e62]:
      - heading "Install" [level=2] [ref=e63]
      - paragraph [ref=e64]: Check permission to keep local writing in this browser.
      - paragraph [ref=e65]: You can also install done from your browser’s menu.
      - button "Install" [ref=e66] [cursor=pointer]
  - complementary [ref=e67]:
    - generic [ref=e68]:
      - heading [level=2] [ref=e69]: Unfiled
      - generic [ref=e70]: "0"
      - button [ref=e71] [cursor=pointer]: Close
    - paragraph [ref=e73]: These cards were retained because their original collection can no longer display them. Choose a new home or remove them explicitly.
  - button "Close unfiled cards"
  - main "Days" [ref=e75]:
    - generic:
      - button "Go to Yesterday" [ref=e76] [cursor=pointer]
      - button "Go to Tomorrow" [ref=e77] [cursor=pointer]
    - generic [ref=e78]:
      - region:
        - generic:
          - heading [level=1]: Wed 14 Oct
          - button: Today
        - generic:
          - generic:
            - heading [level=2]:
              - generic: Next
              - generic: 0/3
            - paragraph: The three most important things to focus on next.
          - generic:
            - heading [level=2]:
              - generic: Done
            - paragraph: Anything you finished counts, planned or unplanned.
            - generic:
              - textbox:
                - /placeholder: What got done?
              - button [disabled]: Add
          - generic:
            - heading [level=2]:
              - generic: Scheduled
            - paragraph: Things planned for this day.
            - generic:
              - textbox:
                - /placeholder: What’s scheduled?
              - button [disabled]: Add
      - region "Today" [ref=e79]:
        - heading "Thu 15 Oct" [level=1] [ref=e81]
        - generic [ref=e82]:
          - complementary "Getting started" [ref=e83]:
            - paragraph [ref=e84]: Write everything in Goals. Choose three things for Next. Record what got done.
            - button "Open Goals" [ref=e85] [cursor=pointer]
            - button "Dismiss introduction" [ref=e86] [cursor=pointer]: Dismiss
          - generic [ref=e87]:
            - heading "Next 0 of 3" [level=2] [ref=e88]:
              - generic [ref=e89]: Next
              - generic "0 of 3" [ref=e90]: 0/3
            - paragraph [ref=e91]: The three most important things to focus on next.
          - generic [ref=e92]:
            - heading "Done" [level=2] [ref=e93]
            - paragraph [ref=e95]: Anything you finished counts, planned or unplanned.
            - generic [ref=e96]:
              - textbox "What got done?" [ref=e97]
              - button "Add" [disabled] [ref=e98]
          - generic [ref=e99]:
            - heading "Scheduled" [level=2] [ref=e100]
            - paragraph [ref=e102]: Things planned for this day.
            - generic [ref=e103]:
              - textbox "What’s scheduled?" [ref=e104]
              - button "Add" [disabled] [ref=e105]
      - region:
        - generic:
          - heading [level=1]: Fri 16 Oct
          - button: Today
        - generic:
          - generic:
            - heading [level=2]:
              - generic: Next
              - generic: 0/3
            - paragraph: The three most important things to focus on next.
          - generic:
            - heading [level=2]:
              - generic: Done
            - paragraph: Anything you finished counts, planned or unplanned.
            - generic:
              - textbox:
                - /placeholder: What got done?
              - button [disabled]: Add
          - generic:
            - heading [level=2]:
              - generic: Scheduled
            - paragraph: Things planned for this day.
            - generic:
              - textbox:
                - /placeholder: What’s scheduled?
              - button [disabled]: Add
  - complementary "Goals" [ref=e106]:
    - heading [level=2] [ref=e108]:
      - button "Goals. Open document outline" [ref=e109] [cursor=pointer]:
        - generic [ref=e110]: Goals
    - generic [ref=e115]:
      - status
      - textbox [ref=e118]:
        - generic [ref=e119]: Your running list of tasks, projects, someday-maybes, notes to self, and ideas.
    - group "Selected lines" [ref=e121]:
      - generic [ref=e122]:
        - group "Transfer selected lines" [ref=e123]:
          - generic [ref=e125] [cursor=pointer]:
            - radio "Copy to" [checked] [ref=e126]
            - generic: Copy to
          - generic [ref=e127] [cursor=pointer]:
            - radio "Move to" [ref=e128]
            - generic: Move to
        - button "More Goals actions" [ref=e130] [cursor=pointer]
      - generic [ref=e135]:
        - button "Next" [disabled] [ref=e136]
        - button "Scheduled" [disabled] [ref=e137]
        - button "Done" [disabled] [ref=e138]
```

# Test source

```ts
  106 |   page,
  107 | }) => {
  108 |   const localCode = await local(page);
  109 |   const beforeLocal = await slot(page);
  110 |   await page.getByRole('button', { name: 'Lock workspace', exact: true }).click();
  111 |   await expect(page.locator('[data-state="unlock-required"]')).toBeVisible();
  112 |   await page.reload();
  113 |   await page.getByRole('button', { name: 'Use another account', exact: true }).click();
  114 |   await phase(page, 'account-choice');
  115 |   await expect(page.locator('.cm-editor')).toHaveCount(0);
  116 |   await expect(page.getByRole('button', { name: 'Open local-only workspace' })).toBeVisible();
  117 |   const accountCode = await startNewAccount(page, 'Another person');
  118 |   await authenticator(page);
  119 |   const recovery = await recoveryCode(page);
  120 |   await page.getByRole('button', { name: 'I saved my recovery code' }).click();
  121 |   await page.getByLabel('Recovery code', { exact: true }).fill(recovery);
  122 |   await page.getByRole('button', { name: 'Finish account setup', exact: true }).click();
  123 |   await expect(page.locator('.shell')).toBeVisible();
  124 |   const id = (await page.getByLabel('Account ID', { exact: true }).textContent())!;
  125 |   await expect(page.locator('.day-panel[data-active="true"] .card')).toHaveCount(0);
  126 |   const compose = page.locator(
  127 |     '.day-panel[data-active="true"] .collection[data-section="done"] .compose-field',
  128 |   );
  129 |   await compose.fill('Only the other person’s writing');
  130 |   await compose.press('Enter');
  131 |   expect(await slot(page)).toEqual(beforeLocal);
  132 |   await page.getByRole('button', { name: 'Lock workspace', exact: true }).click();
  133 |   await page.getByRole('button', { name: 'Use another account', exact: true }).click();
  134 |   await page.getByRole('button', { name: 'Open local-only workspace' }).click();
  135 |   await expect(page.locator('[data-state="unlock-required"]')).toBeVisible();
  136 |   await page.reload();
  137 |   await expect(page.locator('[data-state="unlock-required"]')).toBeVisible();
  138 |   await page.getByLabel('Device-lock code', { exact: true }).fill(accountCode);
  139 |   await page.getByRole('button', { name: 'Unlock', exact: true }).click();
  140 |   await expect(page.locator('[data-state="unlock-failed"]')).toBeVisible();
  141 |   await expect(
  142 |     page.getByRole('button', { name: 'Use another account', exact: true }),
  143 |   ).toBeVisible();
  144 |   await page.getByLabel('Device-lock code', { exact: true }).fill(localCode);
  145 |   await page.getByRole('button', { name: 'Unlock', exact: true }).click();
  146 |   await expect(page.locator('.shell')).toBeVisible();
  147 |   await expect(page.locator('.day-panel[data-active="true"] .card')).toHaveCount(1);
  148 |   await expect(page.locator('.day-panel[data-active="true"] .card')).toContainText(
  149 |     'Writing from before account setup',
  150 |   );
  151 |   await page.getByRole('button', { name: 'Use another account', exact: true }).click();
  152 |   await page
  153 |     .getByRole('button', { name: `Unlock Another person, account ${id}`, exact: true })
  154 |     .click();
  155 |   await reopen(page, accountCode);
  156 |   await expect(page.locator('.shell')).toBeVisible();
  157 |   await expect(page.locator('.day-panel[data-active="true"] .card')).toHaveCount(1);
  158 |   await expect(page.locator('.day-panel[data-active="true"] .card')).toContainText(
  159 |     'Only the other person’s writing',
  160 |   );
  161 | });
  162 | 
  163 | test('password-manager app switching preserves code-saving and confirmation steps', async ({
  164 |   page,
  165 | }) => {
  166 |   await page.addInitScript(() => {
  167 |     const NativeWebSocket = window.WebSocket;
  168 |     const sockets: WebSocket[] = [];
  169 |     Object.assign(window, {
  170 |       setupPageInstance: crypto.randomUUID(),
  171 |       setupDevelopmentSockets: sockets,
  172 |     });
  173 |     window.WebSocket = class extends NativeWebSocket {
  174 |       constructor(url: string | URL, protocols?: string | string[]) {
  175 |         super(url, protocols);
  176 |         if (protocols === 'vite-hmr') sockets.push(this);
  177 |       }
  178 |     };
  179 |   });
  180 |   await page.goto(entry);
  181 |   const instance = await page.evaluate(() => (window as any).setupPageInstance);
  182 |   const cdp = await page.context().newCDPSession(page);
  183 |   const awayAndBack = async () => {
  184 |     await page.evaluate(() => {
  185 |       window.dispatchEvent(new Event('blur'));
  186 |       Object.defineProperty(document, 'visibilityState', {
  187 |         configurable: true,
  188 |         get: () => 'hidden',
  189 |       });
  190 |       document.dispatchEvent(new Event('visibilitychange'));
  191 |       // The former preview reloads after this socket loss, without any app lock request.
  192 |       for (const socket of (window as any).setupDevelopmentSockets as WebSocket[])
  193 |         if (socket.readyState === WebSocket.OPEN) socket.close();
  194 |     });
  195 |     await page.context().setOffline(true);
  196 |     await cdp.send('Page.setWebLifecycleState', { state: 'frozen' });
  197 |     await cdp.send('Page.setWebLifecycleState', { state: 'active' });
  198 |     await page.context().setOffline(false);
  199 |     await page.evaluate(() => {
  200 |       delete (document as any).visibilityState;
  201 |       document.dispatchEvent(new Event('visibilitychange'));
  202 |       window.dispatchEvent(new Event('focus'));
  203 |     });
  204 |     expect(await page.evaluate(() => (window as any).setupPageInstance)).toBe(instance);
  205 |   };
> 206 |   await page.getByRole('button', { name: 'I already have a workspace', exact: true }).click();
      |                                                                                       ^ Error: locator.click: Test timeout of 90000ms exceeded.
  207 |   await page.getByRole('button', { name: 'Create a new account', exact: true }).click();
  208 |   await page.getByLabel('Your name', { exact: true }).fill('Mobile setup');
  209 |   await page.getByRole('button', { name: 'Create account', exact: true }).click();
  210 |   const code = (await page.getByLabel('Generated device-lock code').textContent())!;
  211 |   await awayAndBack();
  212 |   await expect(page.getByLabel('Generated device-lock code')).toHaveText(code);
  213 |   await page.getByRole('button', { name: 'I saved my device-lock code' }).click();
  214 |   await page.getByLabel('Device-lock code', { exact: true }).fill(code);
  215 |   await awayAndBack();
  216 |   await expect(page.getByLabel('Device-lock code', { exact: true })).toHaveValue(code);
  217 |   await page.getByRole('button', { name: 'Confirm device-lock code', exact: true }).click();
  218 |   await authenticator(page);
  219 |   const recovery = await recoveryCode(page);
  220 |   await awayAndBack();
  221 |   await expect(page.getByLabel('Generated recovery code')).toHaveText(recovery);
  222 |   await page.getByRole('button', { name: 'I saved my recovery code' }).click();
  223 |   await page.getByLabel('Recovery code', { exact: true }).fill(recovery);
  224 |   await awayAndBack();
  225 |   await expect(page.getByLabel('Recovery code', { exact: true })).toHaveValue(recovery);
  226 |   await page.getByRole('button', { name: 'Finish account setup', exact: true }).click();
  227 |   await expect(page.locator('.shell')).toBeVisible();
  228 |   expect(await page.evaluate(() => (window as any).setupPageInstance)).toBe(instance);
  229 |   // Explicit lock still ends the open session and requires its factors again.
  230 |   await page.getByRole('button', { name: 'Lock workspace', exact: true }).click();
  231 |   await phase(page, 'unlock');
  232 |   await expect(page.locator('.cm-editor')).toHaveCount(0);
  233 | });
  234 | 
  235 | test('homepage welcome opens account choice and a first account reopens through either entry', async ({
  236 |   page,
  237 | }) => {
  238 |   await page.goto('/');
  239 |   await page.getByRole('button', { name: 'I already have a workspace', exact: true }).click();
  240 |   await phase(page, 'account-choice');
  241 |   await expect(page.getByRole('heading', { name: 'Choose an account', exact: true })).toBeVisible();
  242 |   await page.reload();
  243 |   await phase(page, 'account-choice');
  244 |   await page.goto('/');
  245 |   await expect(page.getByRole('heading', { name: 'Your Workspace', exact: true })).toBeVisible();
  246 |   await page.getByRole('button', { name: 'I already have a workspace', exact: true }).click();
  247 |   await phase(page, 'account-choice');
  248 |   await authenticator(page);
  249 |   const code = await startNewAccount(page, 'Alex');
  250 |   const recovery = await recoveryCode(page);
  251 |   await page.getByRole('button', { name: 'I saved my recovery code' }).click();
  252 |   await page.getByLabel('Recovery code', { exact: true }).fill(recovery);
  253 |   await page.getByRole('button', { name: 'Finish account setup', exact: true }).click();
  254 |   await expect(page.locator('.shell')).toBeVisible();
  255 |   const id = (await page.getByLabel('Account ID', { exact: true }).textContent())!;
  256 |   for (const url of [entry, '/local.html', '/']) {
  257 |     await page.goto(url);
  258 |     if (url === '/') {
  259 |       await expect(
  260 |         page.getByRole('heading', { name: 'Your Workspace', exact: true }),
  261 |       ).toBeVisible();
  262 |       await page.getByRole('button', { name: 'I already have a workspace', exact: true }).click();
  263 |       await page.getByRole('button', { name: `Unlock Alex, account ${id}`, exact: true }).click();
  264 |     }
  265 |     await phase(page, 'unlock');
  266 |     await expect(page.getByLabel('Account ID', { exact: true })).toHaveText(id);
  267 |     await expect(
  268 |       page.getByRole('button', { name: 'Confirm code and unlock with passkey', exact: true }),
  269 |     ).toBeVisible();
  270 |     await reopen(page, code);
  271 |     await expect(page.locator('.shell')).toBeVisible();
  272 |   }
  273 | });
  274 | 
  275 | test('root splash preserves Local writing and an unfinished account until explicitly selected', async ({
  276 |   page,
  277 | }) => {
  278 |   const code = await local(page, '/');
  279 |   const before = await slot(page);
  280 |   await page.goto('/private/account-enrollment.html');
  281 |   await page.evaluate(() => history.back());
  282 |   await phase(page, 'account-choice');
  283 |   await page.goto('/');
  284 |   await expect(page.getByRole('heading', { name: 'Your Workspace', exact: true })).toBeVisible();
  285 |   await page.reload();
  286 |   await expect(page.getByRole('heading', { name: 'Your Workspace', exact: true })).toBeVisible();
  287 |   await page.getByRole('button', { name: 'I already have a workspace', exact: true }).click();
  288 |   await page.getByRole('button', { name: 'Create a new account', exact: true }).click();
  289 |   await expect(
  290 |     page.getByRole('heading', { name: 'Create a new account', exact: true }),
  291 |   ).toBeVisible();
  292 |   const selected = await page.evaluate(() =>
  293 |     sessionStorage.getItem('done.account-setup.selected-slot'),
  294 |   );
  295 |   await page.reload();
  296 |   await phase(page, 'intro');
  297 |   await page.goto('/');
  298 |   await expect(page.getByRole('heading', { name: 'Your Workspace', exact: true })).toBeVisible();
  299 |   await expect(
  300 |     page.getByRole('heading', { name: 'Create a new account', exact: true }),
  301 |   ).toHaveCount(0);
  302 |   await page.getByRole('button', { name: 'I already have a workspace', exact: true }).click();
  303 |   await page.getByRole('button', { name: 'Continue setup for new account', exact: true }).click();
  304 |   await expect(
  305 |     page.getByRole('heading', { name: 'Create a new account', exact: true }),
  306 |   ).toBeVisible();
```
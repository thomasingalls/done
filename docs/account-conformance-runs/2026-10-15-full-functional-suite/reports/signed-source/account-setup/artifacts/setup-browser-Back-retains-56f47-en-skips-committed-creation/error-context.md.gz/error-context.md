# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: setup.spec.ts >> browser Back retains unconfirmed device codes and name drafts, then skips committed creation
- Location: test/first-device-setup/setup.spec.ts:831:1

# Error details

```
Test timeout of 90000ms exceeded.
```

```
Error: locator.click: Test timeout of 90000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: 'Create a local-only workspace' })

```

# Page snapshot

```yaml
- generic [ref=e4]:
  - complementary "Menu" [ref=e5]:
    - generic [ref=e6]:
      - heading "Day" [level=2] [ref=e7]
      - paragraph [ref=e8]: Thu 15 Oct 2026
      - generic [ref=e9]:
        - button "Thu 8 Oct" [ref=e10] [cursor=pointer]
        - button "Tue 13 Oct" [ref=e11] [cursor=pointer]
        - button "Yesterday" [ref=e12] [cursor=pointer]
        - button "Today" [ref=e13] [cursor=pointer]
        - button "Tomorrow" [ref=e14] [cursor=pointer]
        - button "Sat 17 Oct" [ref=e15] [cursor=pointer]
        - button "Thu 22 Oct" [ref=e16] [cursor=pointer]
      - generic [ref=e17]:
        - text: Go to date
        - textbox "Go to date" [ref=e18]: 2026-10-15
    - generic [ref=e19]:
      - heading "Data" [level=2] [ref=e20]
      - generic [ref=e21]:
        - generic [ref=e22]: Local data
        - generic [ref=e23]: Best-effort
      - paragraph [ref=e24]: Writing is encrypted in this browser. Export a readable backup when you need one.
      - button "Export markdown" [ref=e25] [cursor=pointer]
      - button "Remove from this device" [ref=e26] [cursor=pointer]
      - generic [ref=e27]:
        - button "Undo" [disabled] [ref=e28] [cursor=pointer]
        - button "Redo" [disabled] [ref=e29] [cursor=pointer]
    - generic [ref=e30]:
      - heading "Protection" [level=2] [ref=e31]
      - paragraph [ref=e32]: Opens automatically. Anyone using this browser can open your list.
      - button "Add an unlock code" [ref=e33] [cursor=pointer]
    - generic [ref=e34]:
      - heading "Sync" [level=2] [ref=e35]
      - button "Use another account" [ref=e36] [cursor=pointer]
      - paragraph [ref=e37]: Saved only in this browser. Sync is off.
      - button "Set up sync" [ref=e38] [cursor=pointer]
    - generic [ref=e39]:
      - heading "Personalize" [level=2] [ref=e40]
      - generic [ref=e41]:
        - generic [ref=e42]: Actor
        - generic [ref=e43]: You
      - generic [ref=e45]:
        - generic [ref=e46]: Version
        - generic [ref=e47]: 5afdd0ad
      - generic [ref=e48]:
        - generic [ref=e49]:
          - generic [ref=e50]: Device
          - textbox "Device name" [ref=e51]: Chrome - macOS
        - generic [ref=e52]:
          - generic [ref=e53]: Name
          - textbox "Actor name" [ref=e54]: You
        - generic [ref=e55]:
          - generic [ref=e56]: Color
          - textbox "Actor color" [ref=e57]: "#e0662f"
        - generic [ref=e58]:
          - generic [ref=e59]: Day rollover
          - combobox "Day rollover hour" [ref=e60]:
            - option "00:00" [selected]
            - option "01:00"
            - option "02:00"
            - option "03:00"
            - option "04:00"
            - option "05:00"
            - option "06:00"
            - option "07:00"
            - option "08:00"
            - option "09:00"
            - option "10:00"
            - option "11:00"
            - option "12:00"
            - option "13:00"
            - option "14:00"
            - option "15:00"
            - option "16:00"
            - option "17:00"
            - option "18:00"
            - option "19:00"
            - option "20:00"
            - option "21:00"
            - option "22:00"
            - option "23:00"
        - button "Save preferences" [ref=e61] [cursor=pointer]
    - region "Install" [ref=e62]:
      - heading "Install" [level=2] [ref=e63]
      - paragraph [ref=e64]: Check permission to keep local writing in this browser.
      - paragraph [ref=e65]: You can also install done from your browser’s menu.
      - button "Install" [ref=e66] [cursor=pointer]
  - complementary [ref=e67]:
    - generic [ref=e68]:
      - heading [level=2] [ref=e69]: Unfiled
      - generic [ref=e70]: "0"
      - button [ref=e71] [cursor=pointer]: Close
    - paragraph [ref=e73]: These cards were retained because their original collection can no longer display them. Choose a new home or remove them explicitly.
  - button "Close unfiled cards"
  - main "Days" [ref=e75]:
    - generic:
      - button "Go to Yesterday" [ref=e76] [cursor=pointer]
      - button "Go to Tomorrow" [ref=e77] [cursor=pointer]
    - generic [ref=e78]:
      - region:
        - generic:
          - heading [level=1]: Wed 14 Oct
          - button: Today
        - generic:
          - generic:
            - heading [level=2]:
              - generic: Next
              - generic: 0/3
            - paragraph: The three most important things to focus on next.
          - generic:
            - heading [level=2]:
              - generic: Done
            - paragraph: Anything you finished counts, planned or unplanned.
            - generic:
              - textbox:
                - /placeholder: What got done?
              - button [disabled]: Add
          - generic:
            - heading [level=2]:
              - generic: Scheduled
            - paragraph: Things planned for this day.
            - generic:
              - textbox:
                - /placeholder: What’s scheduled?
              - button [disabled]: Add
      - region "Today" [ref=e79]:
        - heading "Thu 15 Oct" [level=1] [ref=e81]
        - generic [ref=e82]:
          - complementary "Getting started" [ref=e83]:
            - paragraph [ref=e84]: Write everything in Goals. Choose three things for Next. Record what got done.
            - button "Open Goals" [ref=e85] [cursor=pointer]
            - button "Dismiss introduction" [ref=e86] [cursor=pointer]: Dismiss
          - generic [ref=e87]:
            - heading "Next 0 of 3" [level=2] [ref=e88]:
              - generic [ref=e89]: Next
              - generic "0 of 3" [ref=e90]: 0/3
            - paragraph [ref=e91]: The three most important things to focus on next.
          - generic [ref=e92]:
            - heading "Done" [level=2] [ref=e93]
            - paragraph [ref=e95]: Anything you finished counts, planned or unplanned.
            - generic [ref=e96]:
              - textbox "What got done?" [ref=e97]
              - button "Add" [disabled] [ref=e98]
          - generic [ref=e99]:
            - heading "Scheduled" [level=2] [ref=e100]
            - paragraph [ref=e102]: Things planned for this day.
            - generic [ref=e103]:
              - textbox "What’s scheduled?" [ref=e104]
              - button "Add" [disabled] [ref=e105]
      - region:
        - generic:
          - heading [level=1]: Fri 16 Oct
          - button: Today
        - generic:
          - generic:
            - heading [level=2]:
              - generic: Next
              - generic: 0/3
            - paragraph: The three most important things to focus on next.
          - generic:
            - heading [level=2]:
              - generic: Done
            - paragraph: Anything you finished counts, planned or unplanned.
            - generic:
              - textbox:
                - /placeholder: What got done?
              - button [disabled]: Add
          - generic:
            - heading [level=2]:
              - generic: Scheduled
            - paragraph: Things planned for this day.
            - generic:
              - textbox:
                - /placeholder: What’s scheduled?
              - button [disabled]: Add
  - complementary "Goals" [ref=e106]:
    - heading [level=2] [ref=e108]:
      - button "Goals. Open document outline" [ref=e109] [cursor=pointer]:
        - generic [ref=e110]: Goals
    - generic [ref=e115]:
      - status
      - textbox [ref=e118]:
        - generic [ref=e119]: Your running list of tasks, projects, someday-maybes, notes to self, and ideas.
    - group "Selected lines" [ref=e121]:
      - generic [ref=e122]:
        - group "Transfer selected lines" [ref=e123]:
          - generic [ref=e125] [cursor=pointer]:
            - radio "Copy to" [checked] [ref=e126]
            - generic: Copy to
          - generic [ref=e127] [cursor=pointer]:
            - radio "Move to" [ref=e128]
            - generic: Move to
        - button "More Goals actions" [ref=e130] [cursor=pointer]
      - generic [ref=e135]:
        - button "Next" [disabled] [ref=e136]
        - button "Scheduled" [disabled] [ref=e137]
        - button "Done" [disabled] [ref=e138]
```

# Test source

```ts
  735 |     'Writing from before account setup',
  736 |   );
  737 | });
  738 | 
  739 | test('saved account choice works by keyboard and still requires local unlock', async ({
  740 |   page,
  741 | }, testInfo) => {
  742 |   const a = await connectedAccount(page);
  743 |   await page.getByRole('button', { name: 'Lock workspace' }).click();
  744 |   await page.getByRole('button', { name: 'Use another account', exact: true }).click();
  745 |   await expect(page.getByRole('heading', { name: 'Choose an account' })).toBeVisible();
  746 |   const savedAccounts = page.getByRole('list', { name: 'Saved accounts' });
  747 |   await expect(savedAccounts.getByRole('listitem')).toHaveCount(1);
  748 |   const savedAccount = savedAccounts.getByRole('button', {
  749 |     name: `Unlock Alex, account ${a.id}`,
  750 |     exact: true,
  751 |   });
  752 |   await expect(savedAccount).toBeVisible();
  753 |   await expect(page.getByRole('button', { name: 'Back to saved account' })).toHaveCount(0);
  754 |   await page.screenshot({ path: testInfo.outputPath('saved-account-picker.png') });
  755 |   await page.setViewportSize({ width: 390, height: 844 });
  756 |   await page.screenshot({ path: testInfo.outputPath('saved-account-picker-narrow.png') });
  757 |   await savedAccount.focus();
  758 |   await savedAccount.press('Enter');
  759 |   await phase(page, 'unlock');
  760 |   await expect(page.locator('.cm-editor')).toHaveCount(0);
  761 |   await expect(page.getByLabel('Account ID', { exact: true })).toHaveText(a.id);
  762 |   await reopen(page, a.code);
  763 |   await expect(page.locator('.shell')).toBeVisible();
  764 | });
  765 | 
  766 | test('wrong local code never starts registration; a lost registration reply reuses the same passkey', async ({
  767 |   page,
  768 | }) => {
  769 |   const code = await local(page);
  770 |   const { cdp, authenticatorId } = await authenticator(page);
  771 |   let begins = 0;
  772 |   page.on('request', (req) => {
  773 |     if (req.url().endsWith('/__account-setup/begin')) begins++;
  774 |   });
  775 |   await page.getByRole('button', { name: 'Connect this workspace' }).click();
  776 |   await page.getByLabel('Your name', { exact: true }).fill('Alex');
  777 |   await page.getByRole('button', { name: 'Get started' }).click();
  778 |   await reopen(page, 'wrong-code');
  779 |   await expect(page.getByRole('alert')).toBeVisible();
  780 |   expect(begins).toBe(0);
  781 |   await reopen(page, code);
  782 |   await phase(page, 'passkey');
  783 |   let lost = false;
  784 |   await page.route('**/__account-setup/finish', async (route) => {
  785 |     if (lost) return route.continue();
  786 |     lost = true;
  787 |     await route.fetch();
  788 |     await route.abort('failed');
  789 |   });
  790 |   await page.getByRole('button', { name: 'Create passkey', exact: true }).click();
  791 |   await expect(page.getByRole('alert')).toBeVisible();
  792 |   await page.reload();
  793 |   await reopen(page, code);
  794 |   await phase(page, 'confirm-passkey');
  795 |   expect((await cdp.send('WebAuthn.getCredentials', { authenticatorId })).credentials).toHaveLength(
  796 |     1,
  797 |   );
  798 |   await page.getByRole('button', { name: 'Use my passkey' }).click();
  799 |   await phase(page, 'save-recovery');
  800 | });
  801 | 
  802 | test('an unsaved recovery code can be abandoned without changing Local writing', async ({
  803 |   page,
  804 | }) => {
  805 |   const code = await local(page),
  806 |     before = await slot(page);
  807 |   await authenticator(page);
  808 |   await start(page, code);
  809 |   await recoveryCode(page);
  810 |   page.once('dialog', (dialog) => dialog.accept());
  811 |   await page.reload();
  812 |   await reopen(page, code);
  813 |   await phase(page, 'confirm-recovery');
  814 |   await page.getByRole('button', { name: 'I didn’t save the code — start again' }).click();
  815 |   await phase(page, 'intro');
  816 |   await page.getByRole('button', { name: 'Back to workspace' }).click();
  817 |   await page.getByLabel('Device-lock code', { exact: true }).fill(code);
  818 |   await page.getByRole('button', { name: 'Unlock', exact: true }).click();
  819 |   await expect(page.locator('.shell')).toBeVisible();
  820 |   expect(await slot(page)).toEqual(before);
  821 |   await expect(page.locator('.day-panel[data-active="true"] .card')).toContainText(
  822 |     'Writing from before account setup',
  823 |   );
  824 | });
  825 | 
  826 | // Browser history is driven without waiting for a document load: a blocked POP
  827 | // can intentionally stay in the same document while its owner drains.
  828 | const back = (page: Page) => page.evaluate(() => history.back());
  829 | const forward = (page: Page) => page.evaluate(() => history.forward());
  830 | 
  831 | test('browser Back retains unconfirmed device codes and name drafts, then skips committed creation', async ({
  832 |   page,
  833 | }) => {
  834 |   await page.goto('/');
> 835 |   await page.getByRole('button', { name: 'Create a local-only workspace' }).click();
      |                                                                             ^ Error: locator.click: Test timeout of 90000ms exceeded.
  836 |   const localCode = (await page.getByLabel('Generated device-lock code').textContent())!;
  837 |   await page.getByRole('button', { name: 'I saved my code', exact: true }).click();
  838 |   await back(page);
  839 |   await expect(page.getByLabel('Generated device-lock code')).toHaveText(localCode);
  840 |   await back(page);
  841 |   await expect(page.getByRole('heading', { name: 'Your Workspace' })).toBeVisible();
  842 |   await forward(page);
  843 |   await expect(page.getByLabel('Generated device-lock code')).toHaveText(localCode);
  844 |   await page.getByRole('button', { name: 'I saved my code', exact: true }).click();
  845 |   await page.getByLabel('Device-lock code', { exact: true }).fill(localCode);
  846 |   await page.getByRole('button', { name: 'Confirm and create' }).click();
  847 |   await expect(page.locator('.shell')).toBeVisible();
  848 |   const before = await slot(page);
  849 |   await back(page);
  850 |   await phase(page, 'account-choice');
  851 |   await expect(page.locator('.cm-editor')).toHaveCount(0);
  852 |   await page.getByRole('button', { name: 'Create a new account', exact: true }).click();
  853 |   await page.getByLabel('Your name', { exact: true }).fill('Remember this draft');
  854 |   await back(page);
  855 |   await phase(page, 'account-choice');
  856 |   await page.getByRole('button', { name: 'Continue new account setup', exact: true }).click();
  857 |   await expect(page.getByLabel('Your name', { exact: true })).toHaveValue('Remember this draft');
  858 |   await page.getByRole('button', { name: 'Create account', exact: true }).click();
  859 |   const code = (await page.getByLabel('Generated device-lock code').textContent())!;
  860 |   await page.getByRole('button', { name: 'I saved my device-lock code' }).click();
  861 |   await back(page);
  862 |   await expect(page.getByLabel('Generated device-lock code')).toHaveText(code);
  863 |   await back(page);
  864 |   await phase(page, 'intro');
  865 |   await page.getByRole('button', { name: 'Create account', exact: true }).click();
  866 |   await expect(page.getByLabel('Generated device-lock code')).toHaveText(code);
  867 |   await page.getByRole('button', { name: 'I saved my device-lock code' }).click();
  868 |   await page.getByLabel('Device-lock code', { exact: true }).fill(code);
  869 |   await page.getByRole('button', { name: 'Confirm device-lock code' }).click();
  870 |   await phase(page, 'passkey');
  871 |   const selected = await page.evaluate(() =>
  872 |     sessionStorage.getItem('done.account-setup.selected-slot'),
  873 |   );
  874 |   const created = await slot(page, selected!);
  875 |   await back(page);
  876 |   await phase(page, 'account-choice');
  877 |   await page.getByRole('button', { name: /^Continue setup for Remember this draft/ }).click();
  878 |   await reopen(page, code);
  879 |   await phase(page, 'passkey');
  880 |   expect(await slot(page, selected!)).toEqual(created);
  881 |   expect(await slot(page)).toEqual(before);
  882 | });
  883 | 
  884 | test('browser Back redisplays recovery only within its unfinished ceremony and warns before retiring it', async ({
  885 |   page,
  886 | }) => {
  887 |   await page.goto('/');
  888 |   await page.getByRole('button', { name: 'I already have a workspace', exact: true }).click();
  889 |   const code = await startNewAccount(page, 'Recovery navigation');
  890 |   const auth = await authenticator(page);
  891 |   await page.getByRole('button', { name: 'Create passkey', exact: true }).click();
  892 |   await phase(page, 'confirm-passkey');
  893 |   const credentials = await auth.cdp.send('WebAuthn.getCredentials', {
  894 |     authenticatorId: auth.authenticatorId,
  895 |   });
  896 |   await back(page);
  897 |   await phase(page, 'account-choice');
  898 |   await page.getByRole('button', { name: /^Continue setup for Recovery navigation/ }).click();
  899 |   await reopen(page, code);
  900 |   await phase(page, 'confirm-passkey');
  901 |   const retained = await auth.cdp.send('WebAuthn.getCredentials', {
  902 |     authenticatorId: auth.authenticatorId,
  903 |   });
  904 |   expect(retained.credentials.map((value) => value.credentialId)).toEqual(
  905 |     credentials.credentials.map((value) => value.credentialId),
  906 |   );
  907 |   await page.getByRole('button', { name: 'Use my passkey' }).click();
  908 |   const recovery = (await page.getByLabel('Generated recovery code').textContent())!;
  909 |   await page.getByRole('button', { name: 'I saved my recovery code' }).click();
  910 |   await back(page);
  911 |   await expect(page.getByLabel('Generated recovery code')).toHaveText(recovery);
  912 |   await forward(page);
  913 |   await phase(page, 'confirm-recovery');
  914 |   await back(page);
  915 |   await phase(page, 'save-recovery');
  916 |   const warning = page.waitForEvent('dialog');
  917 |   await back(page);
  918 |   const dialog = await warning;
  919 |   expect(dialog.message()).toContain('discard the recovery code');
  920 |   await dialog.dismiss();
  921 |   await expect(page).toHaveURL(/\/save-recovery$/);
  922 |   await expect(page.getByLabel('Generated recovery code')).toHaveText(recovery);
  923 |   page.once('dialog', async (dialog) => {
  924 |     await dialog.accept();
  925 |   });
  926 |   await page.getByRole('button', { name: 'Choose an account', exact: true }).click();
  927 |   await phase(page, 'account-choice');
  928 |   await page.getByRole('button', { name: /^Continue setup for Recovery navigation/ }).click();
  929 |   await reopen(page, code);
  930 |   await phase(page, 'confirm-recovery');
  931 |   await expect(page.getByLabel('Generated recovery code')).toHaveCount(0);
  932 |   await page.getByLabel('Recovery code', { exact: true }).fill(recovery);
  933 |   await page.getByRole('button', { name: 'Finish account setup', exact: true }).click();
  934 |   await expect(page.locator('.shell')).toBeVisible();
  935 |   await back(page);
```
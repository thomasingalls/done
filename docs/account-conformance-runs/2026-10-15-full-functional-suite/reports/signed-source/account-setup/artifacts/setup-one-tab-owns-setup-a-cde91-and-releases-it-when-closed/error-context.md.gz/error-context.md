# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: setup.spec.ts >> one tab owns setup across idle screens and releases it when closed
- Location: test/first-device-setup/setup.spec.ts:509:1

# Error details

```
Test timeout of 90000ms exceeded.
```

```
Error: locator.click: Test timeout of 90000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: 'Create a local-only workspace' })

```

# Page snapshot

```yaml
- generic [ref=e4]:
  - complementary "Menu" [ref=e5]:
    - generic [ref=e6]:
      - heading "Day" [level=2] [ref=e7]
      - paragraph [ref=e8]: Thu 15 Oct 2026
      - generic [ref=e9]:
        - button "Thu 8 Oct" [ref=e10] [cursor=pointer]
        - button "Tue 13 Oct" [ref=e11] [cursor=pointer]
        - button "Yesterday" [ref=e12] [cursor=pointer]
        - button "Today" [ref=e13] [cursor=pointer]
        - button "Tomorrow" [ref=e14] [cursor=pointer]
        - button "Sat 17 Oct" [ref=e15] [cursor=pointer]
        - button "Thu 22 Oct" [ref=e16] [cursor=pointer]
      - generic [ref=e17]:
        - text: Go to date
        - textbox "Go to date" [ref=e18]: 2026-10-15
    - generic [ref=e19]:
      - heading "Data" [level=2] [ref=e20]
      - generic [ref=e21]:
        - generic [ref=e22]: Local data
        - generic [ref=e23]: Best-effort
      - paragraph [ref=e24]: Writing is encrypted in this browser. Export a readable backup when you need one.
      - button "Export markdown" [ref=e25] [cursor=pointer]
      - button "Remove from this device" [ref=e26] [cursor=pointer]
      - generic [ref=e27]:
        - button "Undo" [disabled] [ref=e28] [cursor=pointer]
        - button "Redo" [disabled] [ref=e29] [cursor=pointer]
    - generic [ref=e30]:
      - heading "Protection" [level=2] [ref=e31]
      - paragraph [ref=e32]: Opens automatically. Anyone using this browser can open your list.
      - button "Add an unlock code" [ref=e33] [cursor=pointer]
    - generic [ref=e34]:
      - heading "Sync" [level=2] [ref=e35]
      - button "Use another account" [ref=e36] [cursor=pointer]
      - paragraph [ref=e37]: Saved only in this browser. Sync is off.
      - button "Set up sync" [ref=e38] [cursor=pointer]
    - generic [ref=e39]:
      - heading "Personalize" [level=2] [ref=e40]
      - generic [ref=e41]:
        - generic [ref=e42]: Actor
        - generic [ref=e43]: You
      - generic [ref=e45]:
        - generic [ref=e46]: Version
        - generic [ref=e47]: 5afdd0ad
      - generic [ref=e48]:
        - generic [ref=e49]:
          - generic [ref=e50]: Device
          - textbox "Device name" [ref=e51]: Chrome - macOS
        - generic [ref=e52]:
          - generic [ref=e53]: Name
          - textbox "Actor name" [ref=e54]: You
        - generic [ref=e55]:
          - generic [ref=e56]: Color
          - textbox "Actor color" [ref=e57]: "#e0662f"
        - generic [ref=e58]:
          - generic [ref=e59]: Day rollover
          - combobox "Day rollover hour" [ref=e60]:
            - option "00:00" [selected]
            - option "01:00"
            - option "02:00"
            - option "03:00"
            - option "04:00"
            - option "05:00"
            - option "06:00"
            - option "07:00"
            - option "08:00"
            - option "09:00"
            - option "10:00"
            - option "11:00"
            - option "12:00"
            - option "13:00"
            - option "14:00"
            - option "15:00"
            - option "16:00"
            - option "17:00"
            - option "18:00"
            - option "19:00"
            - option "20:00"
            - option "21:00"
            - option "22:00"
            - option "23:00"
        - button "Save preferences" [ref=e61] [cursor=pointer]
    - region "Install" [ref=e62]:
      - heading "Install" [level=2] [ref=e63]
      - paragraph [ref=e64]: Check permission to keep local writing in this browser.
      - paragraph [ref=e65]: You can also install done from your browser’s menu.
      - button "Install" [ref=e66] [cursor=pointer]
  - complementary [ref=e67]:
    - generic [ref=e68]:
      - heading [level=2] [ref=e69]: Unfiled
      - generic [ref=e70]: "0"
      - button [ref=e71] [cursor=pointer]: Close
    - paragraph [ref=e73]: These cards were retained because their original collection can no longer display them. Choose a new home or remove them explicitly.
  - button "Close unfiled cards"
  - main "Days" [ref=e75]:
    - generic:
      - button "Go to Yesterday" [ref=e76] [cursor=pointer]
      - button "Go to Tomorrow" [ref=e77] [cursor=pointer]
    - generic [ref=e78]:
      - region:
        - generic:
          - heading [level=1]: Wed 14 Oct
          - button: Today
        - generic:
          - generic:
            - heading [level=2]:
              - generic: Next
              - generic: 0/3
            - paragraph: The three most important things to focus on next.
          - generic:
            - heading [level=2]:
              - generic: Done
            - paragraph: Anything you finished counts, planned or unplanned.
            - generic:
              - textbox:
                - /placeholder: What got done?
              - button [disabled]: Add
          - generic:
            - heading [level=2]:
              - generic: Scheduled
            - paragraph: Things planned for this day.
            - generic:
              - textbox:
                - /placeholder: What’s scheduled?
              - button [disabled]: Add
      - region "Today" [ref=e79]:
        - heading "Thu 15 Oct" [level=1] [ref=e81]
        - generic [ref=e82]:
          - complementary "Getting started" [ref=e83]:
            - paragraph [ref=e84]: Write everything in Goals. Choose three things for Next. Record what got done.
            - button "Open Goals" [ref=e85] [cursor=pointer]
            - button "Dismiss introduction" [ref=e86] [cursor=pointer]: Dismiss
          - generic [ref=e87]:
            - heading "Next 0 of 3" [level=2] [ref=e88]:
              - generic [ref=e89]: Next
              - generic "0 of 3" [ref=e90]: 0/3
            - paragraph [ref=e91]: The three most important things to focus on next.
          - generic [ref=e92]:
            - heading "Done" [level=2] [ref=e93]
            - paragraph [ref=e95]: Anything you finished counts, planned or unplanned.
            - generic [ref=e96]:
              - textbox "What got done?" [ref=e97]
              - button "Add" [disabled] [ref=e98]
          - generic [ref=e99]:
            - heading "Scheduled" [level=2] [ref=e100]
            - paragraph [ref=e102]: Things planned for this day.
            - generic [ref=e103]:
              - textbox "What’s scheduled?" [ref=e104]
              - button "Add" [disabled] [ref=e105]
      - region:
        - generic:
          - heading [level=1]: Fri 16 Oct
          - button: Today
        - generic:
          - generic:
            - heading [level=2]:
              - generic: Next
              - generic: 0/3
            - paragraph: The three most important things to focus on next.
          - generic:
            - heading [level=2]:
              - generic: Done
            - paragraph: Anything you finished counts, planned or unplanned.
            - generic:
              - textbox:
                - /placeholder: What got done?
              - button [disabled]: Add
          - generic:
            - heading [level=2]:
              - generic: Scheduled
            - paragraph: Things planned for this day.
            - generic:
              - textbox:
                - /placeholder: What’s scheduled?
              - button [disabled]: Add
  - complementary "Goals" [ref=e106]:
    - heading [level=2] [ref=e108]:
      - button "Goals. Open document outline" [ref=e109] [cursor=pointer]:
        - generic [ref=e110]: Goals
    - generic [ref=e115]:
      - status
      - textbox [ref=e118]:
        - generic [ref=e119]: Your running list of tasks, projects, someday-maybes, notes to self, and ideas.
    - group "Selected lines" [ref=e121]:
      - generic [ref=e122]:
        - group "Transfer selected lines" [ref=e123]:
          - generic [ref=e125] [cursor=pointer]:
            - radio "Copy to" [checked] [ref=e126]
            - generic: Copy to
          - generic [ref=e127] [cursor=pointer]:
            - radio "Move to" [ref=e128]
            - generic: Move to
        - button "More Goals actions" [ref=e130] [cursor=pointer]
      - generic [ref=e135]:
        - button "Next" [disabled] [ref=e136]
        - button "Scheduled" [disabled] [ref=e137]
        - button "Done" [disabled] [ref=e138]
```

# Test source

```ts
  1   | import { test, expect, type Page } from '@playwright/test';
  2   | const entry = '/private/account-setup.html';
  3   | const phase = (page: Page, name: string) =>
  4   |   expect(page.locator('.account-setup')).toHaveAttribute('data-setup-state', name);
  5   | async function local(page: Page, path = entry) {
  6   |   await page.goto(path);
> 7   |   await page.getByRole('button', { name: 'Create a local-only workspace' }).click();
      |                                                                             ^ Error: locator.click: Test timeout of 90000ms exceeded.
  8   |   const code = (await page.getByLabel('Generated device-lock code').textContent())!;
  9   |   await page.getByRole('button', { name: 'I saved my code', exact: true }).click();
  10  |   await page.getByLabel('Device-lock code', { exact: true }).fill(code);
  11  |   await page.getByRole('button', { name: 'Confirm and create' }).click();
  12  |   await expect(page.locator('.shell')).toBeVisible();
  13  |   const compose = page.locator(
  14  |     '.day-panel[data-active="true"] .collection[data-section="done"] .compose-field',
  15  |   );
  16  |   await compose.fill('Writing from before account setup');
  17  |   await compose.press('Enter');
  18  |   await expect(page.locator('.day-panel[data-active="true"] .card')).toContainText(
  19  |     'Writing from before account setup',
  20  |   );
  21  |   return code;
  22  | }
  23  | async function start(page: Page, code: string) {
  24  |   await page.getByRole('button', { name: 'Connect this workspace', exact: true }).click();
  25  |   if (!(await page.getByLabel('Your name', { exact: true }).inputValue()))
  26  |     await page.getByLabel('Your name', { exact: true }).fill('Alex');
  27  |   await page.getByRole('button', { name: 'Get started', exact: true }).click();
  28  |   await page.getByLabel('Device-lock code', { exact: true }).fill(code);
  29  |   await page.getByRole('button', { name: 'Continue', exact: true }).click();
  30  |   await phase(page, 'passkey');
  31  | }
  32  | async function authenticator(page: Page) {
  33  |   const cdp = await page.context().newCDPSession(page);
  34  |   await cdp.send('WebAuthn.enable');
  35  |   const { authenticatorId } = await cdp.send('WebAuthn.addVirtualAuthenticator', {
  36  |     options: {
  37  |       protocol: 'ctap2',
  38  |       transport: 'internal',
  39  |       hasResidentKey: true,
  40  |       hasUserVerification: true,
  41  |       isUserVerified: true,
  42  |       automaticPresenceSimulation: true,
  43  |     },
  44  |   });
  45  |   return { cdp, authenticatorId };
  46  | }
  47  | async function recoveryCode(page: Page) {
  48  |   await page.getByRole('button', { name: 'Create passkey', exact: true }).click();
  49  |   await phase(page, 'confirm-passkey');
  50  |   await page.getByRole('button', { name: 'Use my passkey' }).click();
  51  |   await phase(page, 'save-recovery');
  52  |   return (await page.getByLabel('Generated recovery code').textContent())!;
  53  | }
  54  | async function reopen(page: Page, code: string) {
  55  |   await page.getByLabel('Device-lock code', { exact: true }).fill(code);
  56  |   await page
  57  |     .getByRole('button', { name: /^(Continue|Confirm code and unlock with passkey)$/ })
  58  |     .click();
  59  | }
  60  | async function connectedAccount(page: Page) {
  61  |   const code = await local(page);
  62  |   const auth = await authenticator(page);
  63  |   await start(page, code);
  64  |   const recovery = await recoveryCode(page);
  65  |   await page.getByRole('button', { name: 'I saved my recovery code' }).click();
  66  |   await page.getByLabel('Recovery code', { exact: true }).fill(recovery);
  67  |   await page.getByRole('button', { name: 'Confirm and connect' }).click();
  68  |   await expect(page.locator('.shell')).toBeVisible();
  69  |   return { code, auth, id: (await page.getByLabel('Account ID', { exact: true }).textContent())! };
  70  | }
  71  | async function slot(page: Page, slotId = 'local') {
  72  |   return page.evaluate(async (selected) => {
  73  |     const db = await new Promise<IDBDatabase>((resolve, reject) => {
  74  |       const r = indexedDB.open('done.slots');
  75  |       r.onsuccess = () => resolve(r.result);
  76  |       r.onerror = () => reject(r.error);
  77  |     });
  78  |     try {
  79  |       return await new Promise<any>((resolve, reject) => {
  80  |         const tx = db.transaction('slots'),
  81  |           r = tx.objectStore('slots').get(selected);
  82  |         tx.oncomplete = () => resolve(r.result);
  83  |         tx.onabort = () => reject(tx.error);
  84  |       });
  85  |     } finally {
  86  |       db.close();
  87  |     }
  88  |   }, slotId);
  89  | }
  90  | 
  91  | async function startNewAccount(page: Page, name: string) {
  92  |   await page.getByRole('button', { name: 'Create a new account', exact: true }).click();
  93  |   await expect(page.getByRole('heading', { name: 'Create a new account' })).toBeVisible();
  94  |   await page.getByLabel('Your name', { exact: true }).fill(name);
  95  |   await page.getByRole('button', { name: 'Create account', exact: true }).click();
  96  |   await phase(page, 'save-device-code');
  97  |   const code = (await page.getByLabel('Generated device-lock code').textContent())!;
  98  |   await page.getByRole('button', { name: 'I saved my device-lock code' }).click();
  99  |   await page.getByLabel('Device-lock code', { exact: true }).fill(code);
  100 |   await page.getByRole('button', { name: 'Confirm device-lock code' }).click();
  101 |   await phase(page, 'passkey');
  102 |   return code;
  103 | }
  104 | 
  105 | test('a locked local workspace keeps account creation and switching available for another person', async ({
  106 |   page,
  107 | }) => {
```
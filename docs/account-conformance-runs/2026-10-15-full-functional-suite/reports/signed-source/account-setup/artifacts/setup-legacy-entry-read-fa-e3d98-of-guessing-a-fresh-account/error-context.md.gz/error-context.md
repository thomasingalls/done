# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: setup.spec.ts >> legacy entry read failure keeps an explicit error instead of guessing a fresh account
- Location: test/first-device-setup/setup.spec.ts:991:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('heading', { name: 'Your Workspace' })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for getByRole('heading', { name: 'Your Workspace' })

```

```yaml
- main:
  - region "Choose an account":
    - text: done
    - heading "Choose an account" [level=1]
    - paragraph: Select a saved account, connect devices, or create a new account.
    - region "Saved on this device":
      - heading "Saved on this device" [level=2]
      - alert: Saved accounts and device connections could not be read. Reload to try again.
    - button "Open local-only workspace"
    - button "Use another account"
    - paragraph: Connect devices, or recover using your saved recovery code and account passkey.
    - button "Create a new account"
    - paragraph: Start with an empty list and a new passkey.
```

# Test source

```ts
  907  |   await page.getByRole('button', { name: 'Use my passkey' }).click();
  908  |   const recovery = (await page.getByLabel('Generated recovery code').textContent())!;
  909  |   await page.getByRole('button', { name: 'I saved my recovery code' }).click();
  910  |   await back(page);
  911  |   await expect(page.getByLabel('Generated recovery code')).toHaveText(recovery);
  912  |   await forward(page);
  913  |   await phase(page, 'confirm-recovery');
  914  |   await back(page);
  915  |   await phase(page, 'save-recovery');
  916  |   const warning = page.waitForEvent('dialog');
  917  |   await back(page);
  918  |   const dialog = await warning;
  919  |   expect(dialog.message()).toContain('discard the recovery code');
  920  |   await dialog.dismiss();
  921  |   await expect(page).toHaveURL(/\/save-recovery$/);
  922  |   await expect(page.getByLabel('Generated recovery code')).toHaveText(recovery);
  923  |   page.once('dialog', async (dialog) => {
  924  |     await dialog.accept();
  925  |   });
  926  |   await page.getByRole('button', { name: 'Choose an account', exact: true }).click();
  927  |   await phase(page, 'account-choice');
  928  |   await page.getByRole('button', { name: /^Continue setup for Recovery navigation/ }).click();
  929  |   await reopen(page, code);
  930  |   await phase(page, 'confirm-recovery');
  931  |   await expect(page.getByLabel('Generated recovery code')).toHaveCount(0);
  932  |   await page.getByLabel('Recovery code', { exact: true }).fill(recovery);
  933  |   await page.getByRole('button', { name: 'Finish account setup', exact: true }).click();
  934  |   await expect(page.locator('.shell')).toBeVisible();
  935  |   await back(page);
  936  |   await phase(page, 'account-choice');
  937  |   await expect(page.getByLabel('Generated recovery code')).toHaveCount(0);
  938  |   await expect(page.getByRole('button', { name: 'Finish account setup', exact: true })).toHaveCount(
  939  |     0,
  940  |   );
  941  |   const retainedState = await page.evaluate(() =>
  942  |     JSON.stringify({
  943  |       history: history.state,
  944  |       session: { ...sessionStorage },
  945  |       local: { ...localStorage },
  946  |     }),
  947  |   );
  948  |   expect(retainedState).not.toContain(code);
  949  |   expect(retainedState).not.toContain(recovery);
  950  | });
  951  | 
  952  | test('Back during registration drains the owner and resumes the saved passkey proof after a lost reply', async ({
  953  |   page,
  954  | }) => {
  955  |   await page.goto('/');
  956  |   await page.getByRole('button', { name: 'I already have a workspace', exact: true }).click();
  957  |   const code = await startNewAccount(page, 'Pending registration');
  958  |   const auth = await authenticator(page);
  959  |   let release!: () => void;
  960  |   const gate = new Promise<void>((resolve) => {
  961  |     release = resolve;
  962  |   });
  963  |   let committed!: () => void;
  964  |   const received = new Promise<void>((resolve) => {
  965  |     committed = resolve;
  966  |   });
  967  |   await page.route(
  968  |     '**/__account-setup/finish',
  969  |     async (route) => {
  970  |       const response = await route.fetch();
  971  |       committed();
  972  |       await gate;
  973  |       await route.fulfill({ response }).catch(() => {});
  974  |     },
  975  |     { times: 1 },
  976  |   );
  977  |   await page.getByRole('button', { name: 'Create passkey', exact: true }).click();
  978  |   await received;
  979  |   await back(page);
  980  |   await phase(page, 'account-choice');
  981  |   release();
  982  |   await page.getByRole('button', { name: /^Continue setup for Pending registration/ }).click();
  983  |   await reopen(page, code);
  984  |   await phase(page, 'confirm-passkey');
  985  |   const { credentials } = await auth.cdp.send('WebAuthn.getCredentials', {
  986  |     authenticatorId: auth.authenticatorId,
  987  |   });
  988  |   expect(credentials).toHaveLength(1);
  989  | });
  990  | 
  991  | test('legacy entry read failure keeps an explicit error instead of guessing a fresh account', async ({
  992  |   page,
  993  | }) => {
  994  |   await page.addInitScript(() => {
  995  |     const open = indexedDB.open.bind(indexedDB);
  996  |     indexedDB.open = (...args: Parameters<IDBFactory['open']>) => {
  997  |       if (args[0] === 'done.first-device-setup.v1') throw Error('Focused saved setup read failure');
  998  |       return open(...args);
  999  |     };
  1000 |   });
  1001 |   await page.goto(entry);
  1002 |   await expect(page.getByRole('alert')).toHaveText(
  1003 |     'Saved setup could not be read. Your browser data has been kept.',
  1004 |   );
  1005 |   await expect(page.getByRole('button', { name: 'Create a new account' })).toHaveCount(0);
  1006 |   await page.getByRole('link', { name: 'Return to done' }).click();
> 1007 |   await expect(page.getByRole('heading', { name: 'Your Workspace' })).toBeVisible();
       |                                                                       ^ Error: expect(locator).toBeVisible() failed
  1008 | });
  1009 | 
```
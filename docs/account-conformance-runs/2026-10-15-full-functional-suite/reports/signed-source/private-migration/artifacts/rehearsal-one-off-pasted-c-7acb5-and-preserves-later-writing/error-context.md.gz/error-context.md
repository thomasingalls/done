# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: rehearsal.spec.ts >> one-off pasted cleanup helper authenticates files and factor, removes source and preserves later writing
- Location: test/private-migration/rehearsal.spec.ts:137:1

# Error details

```
Test timeout of 90000ms exceeded.
```

```
Error: locator.fill: Test timeout of 90000ms exceeded.
Call log:
  - waiting for getByLabel('Device-lock code', { exact: true })

```

# Test source

```ts
  50  |       const tx = db.transaction('updates');
  51  |       const r = tx.objectStore('updates').openCursor();
  52  |       r.onsuccess = () => {
  53  |         const c = r.result;
  54  |         if (c) {
  55  |           result.push({ key: c.key, bytes: [...c.value] });
  56  |           c.continue();
  57  |         }
  58  |       };
  59  |       tx.oncomplete = () => resolve(result);
  60  |       tx.onabort = () => reject(tx.error);
  61  |     });
  62  |     db.close();
  63  |     return {
  64  |       rows,
  65  |       local: Object.fromEntries(
  66  |         Object.entries(localStorage).filter(
  67  |           ([key]) =>
  68  |             /^done\.pending-update\.done\.fixture\./.test(key) ||
  69  |             ['done.actor', 'done.device', 'done.sync', 'done.sync.last'].includes(key),
  70  |         ),
  71  |       ),
  72  |     };
  73  |   });
  74  | const save = async (page: Page, button: string, target: string) => {
  75  |   const pending = page.waitForEvent('download');
  76  |   await page.getByRole('button', { name: button, exact: true }).click();
  77  |   await (await pending).saveAs(target);
  78  | };
  79  | const capture = async (page: Page, info: TestInfo) => {
  80  |   await page.getByRole('button', { name: 'Capture recovery files' }).click();
  81  |   await phase(page, 'captured');
  82  |   const packet = info.outputPath('recovery.json'),
  83  |     binding = info.outputPath('binding.json'),
  84  |     preview = info.outputPath('preview.zip');
  85  |   await save(page, 'Save recovery packet', packet);
  86  |   await save(page, 'Save binding file', binding);
  87  |   await save(page, 'Save Markdown preview', preview);
  88  |   await expect(page.getByRole('button', { name: 'Generate device-lock code' })).toHaveCount(0);
  89  |   await page.getByRole('button', { name: 'Restart to verify saved files' }).click();
  90  |   await acknowledge(page);
  91  |   return { packet, binding, preview };
  92  | };
  93  | const load = async (page: Page, files: { packet: string; binding: string }) => {
  94  |   await page.getByLabel('Recovery packet', { exact: true }).setInputFiles(files.packet);
  95  |   await page.getByLabel('Saved binding', { exact: true }).setInputFiles(files.binding);
  96  |   await page.getByRole('button', { name: 'Verify saved files' }).click();
  97  | };
  98  | const confirm = async (page: Page) => {
  99  |   await phase(page, 'verified');
  100 |   await page.getByRole('button', { name: 'Generate device-lock code' }).click();
  101 |   await phase(page, 'save-code');
  102 |   const code = (await page.getByLabel('Generated device-lock code').textContent())!;
  103 |   await page.getByRole('button', { name: 'I saved my code' }).click();
  104 |   await expect(page.getByLabel('Generated device-lock code')).toHaveCount(0);
  105 |   await page.getByLabel('Device-lock code', { exact: true }).fill(code);
  106 |   await page.getByRole('button', { name: 'Confirm and begin import' }).click();
  107 |   return code;
  108 | };
  109 | const resume = async (page: Page, files: { packet: string; binding: string }, code: string) => {
  110 |   await page.goto('/private/migration.html');
  111 |   await acknowledge(page);
  112 |   await expect(page.getByRole('button', { name: 'Capture recovery files' })).toHaveCount(0);
  113 |   await load(page, files);
  114 |   await phase(page, 'verified');
  115 |   await expect(page.getByRole('button', { name: 'Generate device-lock code' })).toHaveCount(0);
  116 |   await page.getByLabel('Device-lock code', { exact: true }).fill(code);
  117 |   await page.getByRole('button', { name: 'Unlock migration' }).click();
  118 |   await phase(page, 'authenticated');
  119 | };
  120 | const finishImport = async (page: Page) => {
  121 |   for (let i = 0; i < 20; i++) {
  122 |     const button = page.getByRole('button', { name: 'Continue import', exact: true });
  123 |     if (!(await button.count())) break;
  124 |     await expect(button).toBeEnabled();
  125 |     await button.click();
  126 |     await expect(page.getByText('Waiting for the current storage operation…')).toHaveCount(0);
  127 |     await expect(page.getByRole('alert')).toHaveCount(0);
  128 |   }
  129 |   await page.getByRole('button', { name: 'Select imported workspace' }).click();
  130 |   await expect(page.getByRole('heading', { name: 'Destination selected' })).toBeVisible();
  131 | };
  132 | const unzip = (path: string): { path: string; content: string }[] =>
  133 |   JSON.parse(
  134 |     execFileSync('python3', ['scripts/legacy-export/unzip.py', path], { encoding: 'utf8' }),
  135 |   );
  136 | 
  137 | test('one-off pasted cleanup helper authenticates files and factor, removes source and preserves later writing', async ({
  138 |   page,
  139 | }, info) => {
  140 |   execFileSync(process.execPath, ['scripts/build-private-cleanup.mjs']);
  141 |   const helper = await readFile('.dev/private-cleanup/paste.js', 'utf8');
  142 |   await seed(page);
  143 |   const files = await capture(page, info);
  144 |   await load(page, files);
  145 |   const code = await confirm(page);
  146 |   await phase(page, 'authenticated');
  147 |   await finishImport(page);
  148 |   const before = await census(page);
  149 |   await page.getByRole('button', { name: 'Open Local editor' }).click();
> 150 |   await page.getByLabel('Device-lock code', { exact: true }).fill(code);
      |                                                              ^ Error: locator.fill: Test timeout of 90000ms exceeded.
  151 |   await page.getByRole('button', { name: 'Unlock', exact: true }).click();
  152 |   const master = page.locator('.goals .cm-content');
  153 |   await master.click();
  154 |   await master.press('ControlOrMeta+End');
  155 |   await page.keyboard.insertText('Later writing survives the cleanup helper');
  156 |   await expect(master).toContainText('Later writing survives the cleanup helper');
  157 |   await page.getByRole('button', { name: 'Lock workspace' }).click();
  158 |   await expect(page.locator('.local-startup')).toHaveAttribute('data-state', 'unlock-required');
  159 |   const modernJournals = await page.evaluate(
  160 |     (sourceKeys) =>
  161 |       Object.fromEntries(
  162 |         Object.entries(localStorage).filter(
  163 |           ([key]) => key.startsWith('done.pending-update.done.') && !sourceKeys.includes(key),
  164 |         ),
  165 |       ),
  166 |     Object.keys(before.local),
  167 |   );
  168 |   await page.addScriptTag({ content: helper });
  169 |   const dialog = page.locator('#done-private-cleanup');
  170 |   await dialog.getByLabel('Recovery packet').setInputFiles(files.packet);
  171 |   await dialog.getByLabel('Saved binding').setInputFiles(files.binding);
  172 |   await dialog.getByLabel('Device-lock code').fill('wrong code');
  173 |   await dialog.getByRole('button', { name: 'Clean up source' }).click();
  174 |   await expect(dialog.getByRole('button', { name: 'Clean up source' })).toBeEnabled();
  175 |   expect(await census(page)).toEqual(before);
  176 |   await dialog.getByLabel('Device-lock code').fill(code);
  177 |   await dialog.getByRole('button', { name: 'Clean up source' }).click();
  178 |   await expect(dialog.getByRole('status')).toContainText('Source cleanup complete');
  179 |   expect(
  180 |     await page.evaluate(async () => (await indexedDB.databases()).some((db) => db.name === 'done')),
  181 |   ).toBe(false);
  182 |   expect(
  183 |     await page.evaluate(
  184 |       (keys) => keys.every((key) => localStorage.getItem(key) === null),
  185 |       Object.keys(before.local),
  186 |     ),
  187 |   ).toBe(true);
  188 |   expect(
  189 |     await page.evaluate(
  190 |       (keys) => Object.fromEntries(keys.map((key) => [key, localStorage.getItem(key)])),
  191 |       Object.keys(modernJournals),
  192 |     ),
  193 |   ).toEqual(modernJournals);
  194 |   await dialog.getByRole('button', { name: 'Close', exact: true }).click();
  195 |   await page.reload();
  196 |   await page.getByLabel('Device-lock code', { exact: true }).fill(code);
  197 |   await page.getByRole('button', { name: 'Unlock', exact: true }).click();
  198 |   await expect(page.locator('.goals .cm-content')).toContainText(
  199 |     'Later writing survives the cleanup helper',
  200 |   );
  201 |   await expect(page.locator('.goals .cm-content')).toContainText('journal-only ✔');
  202 | });
  203 | 
  204 | test('saved files, renderer death, resumed selection and ordinary editor cold recovery preserve the ledger', async ({
  205 |   page,
  206 |   context,
  207 | }, info) => {
  208 |   const errors: string[] = [];
  209 |   page.on('pageerror', (error) => errors.push(error.message));
  210 |   await seed(page);
  211 |   const before = await census(page);
  212 |   const files = await capture(page, info);
  213 |   const preview = unzip(files.preview);
  214 |   // The external input-string oracle never reads the Y.Doc or either produced archive.
  215 |   const ledger: { path: string; content: string }[] = JSON.parse(
  216 |     execFileSync(
  217 |       'node',
  218 |       [
  219 |         '--input-type=module',
  220 |         '-e',
  221 |         "import {expected} from './scripts/legacy-export/oracle.mjs'; process.stdout.write(JSON.stringify(expected(JSON.parse(process.argv[1]))));",
  222 |         JSON.stringify(source),
  223 |       ],
  224 |       { encoding: 'utf8' },
  225 |     ),
  226 |   );
  227 |   expect(preview).toEqual(ledger);
  228 |   await load(page, files);
  229 |   const code = await confirm(page);
  230 |   await phase(page, 'authenticated');
  231 |   await expect(page.getByRole('button', { name: 'Continue import' })).toBeVisible();
  232 |   const cdp = await context.newCDPSession(page);
  233 |   const crashed = page.waitForEvent('crash', { timeout: 10_000 });
  234 |   // A crashed renderer cannot reply to this command. Observe the independent crash event.
  235 |   void cdp.send('Page.crash').catch(() => {});
  236 |   await crashed;
  237 |   await page.close();
  238 |   const reopened = await context.newPage();
  239 |   reopened.on('pageerror', (error) => errors.push(error.message));
  240 |   await resume(reopened, files, code);
  241 |   await finishImport(reopened);
  242 |   expect(await census(reopened)).toEqual(before);
  243 |   await reopened.getByRole('button', { name: 'Open Local editor' }).click();
  244 |   await expect(reopened.locator('.local-startup')).toHaveAttribute('data-state', 'unlock-required');
  245 |   await reopened.getByLabel('Device-lock code', { exact: true }).fill(code);
  246 |   await reopened.getByRole('button', { name: 'Unlock', exact: true }).click();
  247 |   await expect(reopened.locator('.goals .cm-content')).toContainText('journal-only ✔');
  248 |   await reopened.getByLabel('Go to date', { exact: true }).fill('2026-01-02');
  249 |   await expect(
  250 |     reopened.locator('.day-panel[data-active="true"] .collection[data-section="next"] .card'),
```
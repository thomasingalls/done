# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: reader-first.spec.ts >> reader-first update, private conversion, compatible rollback and incompatible cached-reader refusal preserve both profiles
- Location: test/local-baseline/reader-first.spec.ts:27:1

# Error details

```
Test timeout of 180000ms exceeded.
```

# Page snapshot

```yaml
- main [ref=e4]:
  - generic:
    - complementary:
      - generic: done
      - generic: Today
      - generic: Yesterday
      - generic: Tomorrow
      - generic: Your space, at your pace.
    - generic:
      - generic: Today
      - generic:
        - generic:
          - generic:
            - text: Next
            - generic: 2 / 3
          - generic:
            - generic:
              - generic: Make a little room for the big idea
              - generic:
                - text: Done
                - generic: Later
            - generic:
              - generic: Take the long way home
              - generic:
                - text: Done
                - generic: Later
        - generic:
          - generic: Done
          - generic:
            - generic: Got the idea out of my head
            - generic: Sent the message I was putting off
            - generic: Made time for a walk
          - generic:
            - text: What got done?
            - generic: +
    - complementary:
      - generic: Goals
      - generic:
        - strong: A little space for everything
        - generic: Ideas, plans, loose ends.
        - generic: Things to come back to.
        - strong: Make something of my own
        - generic: Write down the spark
        - generic: Find one small place to start
        - generic: Share a first draft
        - strong: Outside of work
        - generic: Learn to make really good bread
        - generic: Plan a weekend with no plans
        - generic: More dinners with friends
  - region [ref=e5]:
    - text: done
    - button "Back" [ref=e6] [cursor=pointer]
    - heading "Unlock Device owner’s account" [active] [level=1] [ref=e7]
    - generic [ref=e8]:
      - generic [ref=e9]: Account ID
      - code [ref=e10]: 21vXBtAfT_NhEjky1u3NExhaM-HqBJvQQVGBLc5v3Mk
    - paragraph [ref=e11]: Enter your unlock code, then use your passkey to open your saved writing.
    - paragraph [ref=e12]: You can unlock on this device offline.
    - generic [ref=e13]:
      - generic [ref=e14]: Unlock code
      - textbox "Unlock code" [ref=e15]
      - button "Confirm code and unlock with passkey" [ref=e16] [cursor=pointer]
    - button "Use another account" [ref=e17] [cursor=pointer]
    - button "Remove from this device" [ref=e18] [cursor=pointer]
```
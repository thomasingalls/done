from pathlib import Path
import json,difflib
root=Path.cwd();out=Path('<tmp>/done-f17-handoff');path='src/crdt/workspacePreparation.ts';s=(root/path).read_text()
cases=[
('context-identity','slot.context !== context || ','','opaque contexts reject forgery foreign owners and reuse without consuming legitimate work','only issued context identity authorizes preparation'),
('revision-binding','head.revision !== entry.head.revision + (promoted ? 1 : 0) ||','false ||','every head field and the independently verified revision binds preparation and revokes stale borrows','every preparation basis component must agree'),
('premature-erasure','if (slot?.invalid && !slot.users)','if (slot?.invalid)','close revokes a borrowed write immediately but defers erasure until its idempotent release','an in-flight write retains its bytes until release'),
('history-leak','if (old.state) destroy(old.state);','if (old.state) void old.state;','close revokes a borrowed write immediately but defers erasure until its idempotent release','revoked history must be destroyed after drain'),
('source-check','if (synchronous(verify(prepared)) !== true)','if (false)','failed source verification prevents custody capture even when the proposed update is well formed','source verification must precede custody capture'),
('adoption-check','if (synchronous(verify(entry.prepared!)) !== true)','if (false)','adoption requires this job and slice at exactly the next revision and successful full comparison','unverified or mismatched promotion must never transfer history'),
('returned-buffers','for (const bytes of returnedBuffers(result)) entry.buffers.add(bytes);','/* fault: omit acquisition of returned buffers */','a closing command reclaims every returned buffer before refusing the handoff','all returned resources must be reclaimed on cancellation'),
('late-result-cleanup','.then(late)','','rejected async results erase late returned update remainder source and capture buffers','late asynchronous results must be erased')]
rows=[]
for name,old,new,title,marker in cases:
 assert s.count(old)==1,(name,s.count(old))
 (out/(name+'.patch')).write_text(''.join(difflib.unified_diff(s.splitlines(True),s.replace(old,new).splitlines(True),fromfile='a/'+path,tofile='b/'+path)))
 (out/(name+'.config.mts')).write_text('import base from '+json.dumps(str(root/'vite.config.ts'))+';\nexport default {...base,root:'+json.dumps(str(root))+',plugins:[...base.plugins,{name:'+json.dumps(name)+',enforce:"pre",transform(code,id){if(!id.endsWith('+json.dumps('/'+path)+'))return;const from='+json.dumps(old)+';if(code.split(from).length!==2)throw Error("mutation must match exactly once");return code.replace(from,'+json.dumps(new)+');}}],test:{...base.test,include:["test/workspacePreparation.test.ts"],maxWorkers:1,fileParallelism:false,retry:0}};\n')
 rows.append({'name':name,'title':title,'marker':marker})
(out/'controls.json').write_text(json.dumps(rows,indent=2)+'\n')

from pathlib import Path
import os,subprocess,json,hashlib
out=Path('test-results/workspace-admission-adapter-option-controls')
unsupported=out/'unsupported-browser-output';env={**os.environ,'CHROMIUM_PATH':'/invalid/owned-browser-override'}
r=subprocess.run(['/opt/homebrew/bin/node','scripts/workspace-admission/run.mjs','--case','W09.initialize','--output',str(unsupported)],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=15)
(out/'unsupported-browser.log').write_bytes(r.stdout)
assert r.returncode!=0 and not unsupported.exists() and b'CHROMIUM_PATH overrides are not supported' in r.stdout
report=Path('test-results/workspace-admission-adapter-baseline-initialize/report.json')
sha=lambda:hashlib.sha256(report.read_bytes()).hexdigest()
before=sha()
s=subprocess.run(['/opt/homebrew/bin/node','scripts/workspace-admission/run.mjs','--case','W09.initialize','--no-mutants','--output',str(report.parent)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=15)
(out/'existing-output.log').write_bytes(s.stdout)
assert s.returncode!=0 and b'Refusing existing execution output' in s.stdout and sha()==before
assert report.read_bytes()==next(report.parent.glob('stages/*/cases.json')).read_bytes()
(out/'summary.json').write_text(json.dumps({'status':'passed','initialControlCorrection':'The first ad-hoc control expected Refusing existing output rather than Refusing existing execution output. The application refused correctly; no runtime repair or rerun of the catalogue was needed.','unsupportedBrowser':{'exit':r.returncode,'outputCreated':False},'existingOutput':{'exit':s.returncode,'reportUnchanged':True,'reportMatchesOwnedArtifact':True,'reportSha256':before}},indent=2)+'\n')
print('Option refusals pass; baseline report unchanged and matches owned artifact')

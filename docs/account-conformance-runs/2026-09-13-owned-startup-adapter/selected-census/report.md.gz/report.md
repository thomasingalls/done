# Encrypted-store conformance execution

Scope: owned-startup-browser; candidates: startup. Exit: 0.

Run: 2026-09-13T11:52:23.066Z · harness ddd77a373416f41ecb5c490dbe32d5a6cdd1cf6a (working-tree changes)

Subcase passes establish only the named oracle. Remaining obligations prevent a whole-contract pass.

| Scenario | startup |
| --- | --- |
| O01.absence | pass |
| O02.orphan | pass |
| O11.recheck | pass |

Mutation controls:
- probe-creates-database: detected (preflight-no-database-side-effects)
- orphan-is-fresh: detected (orphan-not-fresh)
- skip-open-classification: detected (open-rechecks-after-grant)

Detailed assertions, fault schedules, source/adapter hashes, browser version and storage inventories are in report.json and the per-case artifacts.

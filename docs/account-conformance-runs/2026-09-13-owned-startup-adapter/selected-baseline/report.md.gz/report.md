# Encrypted-store conformance execution

Scope: owned-startup-browser; candidates: startup. Exit: 0.

Run: 2026-09-13T11:52:38.189Z · harness ddd77a373416f41ecb5c490dbe32d5a6cdd1cf6a (working-tree changes)

Subcase passes establish only the named oracle. Remaining obligations prevent a whole-contract pass.

| Scenario | startup |
| --- | --- |
| O12.replay | pass |
| O13.init-death | pass |

Mutation controls:

Detailed assertions, fault schedules, source/adapter hashes, browser version and storage inventories are in report.json and the per-case artifacts.

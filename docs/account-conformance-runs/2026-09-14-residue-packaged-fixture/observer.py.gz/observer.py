import json,time,os,hashlib
from pathlib import Path
prefix='<tmp>/done-residue-packaged-fixture-';start=time.time();root=Path(os.environ['TMPDIR'])
names=['fresh-outcome','fresh-export','fresh-worker-control','fresh-profiles','migration-outcome','migration-profiles','fresh-assets','migration-assets']
while time.time()<start+300:
 for f in root.glob('done-release-validation-*/checkout/test-results/privacy-extended/*/migration-outcome.json'):
  try:
   if f.stat().st_mtime<start:continue
   raw={n:(f.parent/(n+'.json')).read_bytes() for n in names}
   if any(len(v)>1048576 for v in raw.values()):raise SystemExit('Auxiliary observation exceeds per-file one-MiB bound')
   if any(v!=(f.parent/(n+'.json')).read_bytes() for n,v in raw.items()):continue
   data={n:json.loads(v) for n,v in raw.items()}
   if not all(r['closed'] for n in ['fresh-profiles','migration-profiles'] for r in data[n]):continue
   meta=dict(capturedAt=time.time(),observerStartedAt=start,source=str(f.parent),files=[dict(name=n+'.json',sha256=hashlib.sha256(v).hexdigest(),bytes=len(v)) for n,v in raw.items()])
   Path(prefix+'observed.json').write_text(json.dumps(data,indent=2)+'\n');Path(prefix+'observed-source.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(dict(fresh=data['fresh-outcome'],migration=data['migration-outcome']['logical'],profiles=sum(len(data[n]) for n in ['fresh-profiles','migration-profiles']))),flush=True);raise SystemExit(0)
  except (FileNotFoundError,json.JSONDecodeError):pass
 time.sleep(.1)
raise SystemExit('No final packaged auxiliary reports observed within 300 seconds')
